#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in baseline fullpair_scalar fullpair_batch; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done
echo "===== GPU CORRECTNESS ORACLES ====="
for v in baseline fullpair_scalar fullpair_batch; do echo "--- $v ---"; "$ROOT/bin/test_gf_$v"; done
echo
echo "===== STATIC SASS AUDIT ====="
python3 "$ROOT/sass-audit.py"
echo
python3 "$ROOT/benchmark_fullsbox.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste STATIC SASS AUDIT, FINAL RED2/512 FULL-SBOX ILP RANKING, and FULL-SBOX ILP WINNER PROTOCOL back into chat."
echo "This experiment did NOT install or replace the HiveOS miner. Restart normal mining when finished: miner start"
