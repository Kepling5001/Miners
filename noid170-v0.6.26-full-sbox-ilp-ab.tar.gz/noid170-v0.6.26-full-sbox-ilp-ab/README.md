# NOID170 v0.6.26 full-round X^7 ILP A/B

Correctness-gated CMP170HX A/B test. Does not install or replace the live HiveOS miner.

Exact production baseline is held fixed: red2 / 512 threads, r4top, square3+LOP3, original X^7, factorized full MDS, paired nonvolatile CLMAD, 2ms event polling.

This experiment changes only how the four independent X^7 S-boxes in each **full Poseidon round** are exposed to ptxas:

- `baseline`: current unrolled scalar loop.
- `fullpair_scalar`: stage two independent X^7 chains at a time, retaining scalar `gf_mul`.
- `fullpair_batch`: stage two chains and use existing pair-batched general GF multiplication for the x^3/x^7 multiplications.

Why this is distinct from the failed dual-nonce experiment: it does not duplicate a Poseidon state or nonce. Full rounds already contain four mathematically independent S-boxes before the MDS; this only exposes that existing ILP.

## Run

```bash
cd /home/user/noid170-v0.6.26-full-sbox-ilp-ab
./build-on-rig.sh
miner stop
set -a
source /hive/miners/custom/noid170/noid170.conf
set +a
./test-fullsbox.sh
miner start
```

Return `STATIC SASS AUDIT`, `FINAL RED2/512 FULL-SBOX ILP RANKING`, and `FULL-SBOX ILP WINNER PROTOCOL: PASS`.
