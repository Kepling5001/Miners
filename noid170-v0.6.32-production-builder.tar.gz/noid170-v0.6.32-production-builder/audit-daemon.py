#!/usr/bin/env python3
import os,re,subprocess,sys,collections
from pathlib import Path
if len(sys.argv)!=2:
    print('usage: audit-daemon.py <daemon>', file=sys.stderr); sys.exit(2)
exe=Path(sys.argv[1])
cu=os.environ.get('CUOBJDUMP','/usr/local/cuda-13.3/bin/cuobjdump')
if not Path(cu).exists():
    print(f'ERROR: CUDA 13.3 cuobjdump not found: {cu}', file=sys.stderr); sys.exit(1)
env=os.environ.copy(); env['PATH']='/usr/local/cuda-13.3/bin:'+env.get('PATH','')
ru=subprocess.check_output([cu,'--dump-resource-usage',str(exe)],text=True,stderr=subprocess.STDOUT,env=env)
m=re.search(r'Function\s+_Z11mine_kernel[^:]*:\s*\n\s*REG:(\d+)\s+STACK:(\d+)\s+SHARED:(\d+)\s+LOCAL:(\d+)',ru)
if not m:
    print('ERROR: mine_kernel resource usage not found', file=sys.stderr); sys.exit(1)
regs,local=int(m.group(1)),int(m.group(4))
text=subprocess.check_output([cu,'--dump-sass',str(exe)],text=True,stderr=subprocess.STDOUT,env=env)
parts=re.split(r'(?m)^\s*Function\s*:\s*',text); body=''
for p in parts[1:]:
    lines=p.splitlines(); fn=lines[0].strip() if lines else ''
    if 'mine_kernel' in fn:
        body='\n'.join(lines[1:]); break
if not body:
    print('ERROR: mine_kernel SASS not found', file=sys.stderr); sys.exit(1)
c=collections.Counter()
for line in body.splitlines():
    if not re.search(r'/\*[0-9a-fA-F]+\*/',line): continue
    a=re.sub(r'^.*?/\*[0-9a-fA-F]+\*/\s*','',line,count=1)
    a=re.sub(r'^@!?P\d+\s+','',a)
    mm=re.match(r'([A-Z][A-Z0-9_.]*)\b',a)
    if mm: c[mm.group(1).split('.')[0]]+=1
vals=dict(total=sum(c.values()),CLMAD=c['CLMAD'],LOP3=c['LOP3']+c['ULOP3'],SHF=c['SHF'],IMAD=c['IMAD'],REG=regs,LOCAL=local)
print('SHARE4 DAEMON SASS:', ' '.join(f'{k}={v}' for k,v in vals.items()))
expected=dict(total=2976,CLMAD=966,LOP3=1233,SHF=395,IMAD=242,REG=58,LOCAL=0)
bad={k:(vals[k],v) for k,v in expected.items() if vals[k]!=v}
if bad:
    print('ERROR: daemon does not match the confirmed share4 codegen signature:',bad,file=sys.stderr); sys.exit(1)
print('SHARE4 DAEMON SASS VERIFICATION: PASS')
