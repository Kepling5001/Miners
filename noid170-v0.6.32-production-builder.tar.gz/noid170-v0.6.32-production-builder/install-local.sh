#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE="${1:-$ROOT/dist/noid170-0.6.32.tar.gz}"
DEST="/hive/miners/custom/noid170"
[[ -f "$ARCHIVE" ]] || { echo "ERROR: build release first: ./build-production.sh"; exit 1; }
TS=$(date +%Y%m%d-%H%M%S)
if [[ -d "$DEST" ]]; then
  cp -a "$DEST" "/hive/miners/custom/noid170.backup-$TS"
  echo "Backup: /hive/miners/custom/noid170.backup-$TS"
fi
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
tar -xzf "$ARCHIVE" -C "$TMP"
rm -rf "$DEST"
cp -a "$TMP/noid170" "$DEST"
chmod 755 "$DEST"/noid_live_job_daemon "$DEST"/noid_live_job_cont "$DEST"/*.sh "$DEST"/*.py
printf 'Installed v0.6.32 to %s\n' "$DEST"
printf 'Re-apply your Hive flight sheet / miner config, then start the miner.\n'
