# NOID170 v0.6.32 production builder

Purpose: create the HiveOS custom-miner tarball for the confirmed ~160.9 MH/s CMP170HX `share4` kernel while preserving the stale-share/capability recovery behavior from v0.6.23.

## Kernel checkpoint

The release daemon is the v0.6.29 `share4` winner:

- 512 threads
- 128 blocks/SM launch grid (`blocks=8960` on the 70-SM CMP170HX)
- partial-MDS `red2` (`NOID_PARTIAL_ILP=2`)
- r4top reduction (`NOID_REDUCE_VARIANT=41`)
- square reducer 3 + LOP3
- original X^7 schedule
- factorized full MDS
- CLMAD squaring + accumulator + paired outputs/reduction + nonvolatile scheduling
- first-round four-lane Frobenius square sharing (`NOID_FIRST_ROUND_SQUARE_SHARE=3`)
- natural ptxas codegen: 58 registers, 0 local bytes
- confirmed against exact prior production: ~160.89 MH/s kernel, ~+0.9% wall, accepted-share protocol PASS

The builder prefers the already-benchmarked binary at:

`/home/user/noid170-v0.6.29-share4-schedule-confirm/bin/noid_daemon_share4`

If that binary is not present, it recompiles the exact source/flags with CUDA 13.3 and then requires the exact confirmed SASS signature before packaging.

## Stale-share protection

`noid170_aria.py` is copied from v0.6.23, the corrected adaptive capability-recovery release. The production builder rejects the package if that wrapper differs from v0.6.23 after normalizing only these two intentional changes:

1. version `0.6.23` -> `0.6.32`
2. default `NOID_CARD_MH` `159.4` -> `160.9`

The retained v0.6.23 behavior includes:

- adaptive capability mode
- single-use capability serialization
- valid-capability waiting
- nonblocking capability refresh/backoff
- same-work capability rebinds
- invalidation after a consumed/accepted capability
- compatible stale-nonce retry
- stale recovery accounting (`STALE-RECOVERED`)
- refresh after accepted shares
- ID-churn suppression / meaningful-work refresh behavior

`h-run.sh` explicitly exports `NOID_CAPABILITY_MODE=adaptive`.

## Build on OctominerTEST

```bash
cd /home/user
tar -xzf noid170-v0.6.32-production-builder.tar.gz
cd noid170-v0.6.32-production-builder
./build-production.sh
```

The builder runs:

1. stale-wrapper identity gate
2. offline arithmetic model checks
3. share4 daemon selection or exact rebuild
4. exact share4 SASS/resource signature check
5. GPU GF/Poseidon + square-sharing correctness tests
6. HiveOS wrapper syntax checks
7. final archive verification

Output:

`dist/noid170-0.6.32.tar.gz`

and its SHA256 file.

The build does **not** install or replace the current miner.

## HiveOS custom miner package

The final tar contains exactly:

- `noid170/noid_live_job_daemon`
- `noid170/noid_live_job_cont`
- `noid170/noid170_aria.py`
- `noid170/h-manifest.conf`
- `noid170/h-config.sh`
- `noid170/h-run.sh`
- `noid170/h-stats.sh`
- `noid170/hive_stats.py`

Default RPC remains `https://pool.ariabrain.com/noid-rpc/`.
The flight-sheet wallet/worker template is passed through `CUSTOM_TEMPLATE` as before.
Default estimated card rate is now 160.9 MH/s.

## Optional local install after verification

```bash
./install-local.sh dist/noid170-0.6.32.tar.gz
```

This backs up the current `/hive/miners/custom/noid170` directory before replacing it.
