#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
TEMPLATE="$ROOT/template/noid170"
DIST="$ROOT/dist"
VERSION="0.6.32"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
# Prefer the exact share4 binary that was benchmarked on OctominerTEST in v0.6.29.
PROVEN_SHARE4="${NOID_SHARE4_DAEMON:-/home/user/noid170-v0.6.29-share4-schedule-confirm/bin/noid_daemon_share4}"
BUILD="$ROOT/build"
mkdir -p "$BUILD" "$DIST"
rm -f "$TEMPLATE/noid_live_job_daemon"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }

echo "===== v$VERSION STALE-SHARE WRAPPER GATE ====="
python3 "$ROOT/verify-stale-wrapper.py"

echo
echo "===== OFFLINE ARITHMETIC MODEL GATE ====="
python3 "$ROOT/offline_verify.py"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512
  -DNOID_BLOCKS_PER_SM=128
  -DNOID_FIRST_MDS_HOIST=0
  -DNOID_FIRST_ROUND_SQUARE_SHARE=3
  -Xptxas=-v
)

if [[ -x "$PROVEN_SHARE4" ]]; then
  echo
echo "===== USING EXACT BENCHMARKED SHARE4 BINARY ====="
  echo "Source: $PROVEN_SHARE4"
  cp -f "$PROVEN_SHARE4" "$BUILD/noid_live_job_daemon"
else
  echo
echo "===== PROVEN BINARY NOT FOUND; RECOMPILING EXACT SHARE4 SOURCE ====="
  echo "Expected path was: $PROVEN_SHARE4"
  "$NVCC" "${COMMON[@]}" "$SRC/noid_live_job_daemon.cu" -o "$BUILD/noid_live_job_daemon" 2>&1 | tee "$BUILD/build-daemon.log"
fi
chmod 755 "$BUILD/noid_live_job_daemon"
sha256sum "$BUILD/noid_live_job_daemon"

echo
echo "===== SHARE4 SASS/RESOURCE GATE ====="
python3 "$ROOT/audit-daemon.py" "$BUILD/noid_live_job_daemon"

echo
echo "===== GPU CORRECTNESS GATES ====="
"$NVCC" "${COMMON[@]}" "$ROOT/test_gf_primitives.cu" -o "$BUILD/test_gf_share4" 2>&1 | tee "$BUILD/build-test-gf.log"
"$NVCC" "${COMMON[@]}" "$ROOT/test_first_square_share.cu" -o "$BUILD/test_first_square_share" 2>&1 | tee "$BUILD/build-test-share.log"
chmod 755 "$BUILD/test_gf_share4" "$BUILD/test_first_square_share"
"$BUILD/test_gf_share4"
"$BUILD/test_first_square_share"

echo
echo "===== HIVEOS WRAPPER SYNTAX GATES ====="
python3 -m py_compile "$TEMPLATE/noid170_aria.py" "$TEMPLATE/hive_stats.py"
bash -n "$TEMPLATE/h-config.sh" "$TEMPLATE/h-run.sh" "$TEMPLATE/h-stats.sh"

cp -f "$BUILD/noid_live_job_daemon" "$TEMPLATE/noid_live_job_daemon"
chmod 755 "$TEMPLATE/noid_live_job_daemon"

# Package with the directory name HiveOS expects for this custom miner.
OUT="$DIST/noid170-$VERSION.tar.gz"
rm -f "$OUT" "$OUT.sha256"
(
  cd "$ROOT/template"
  tar --sort=name --mtime='UTC 2026-09-01' --owner=0 --group=0 --numeric-owner -czf "$OUT" noid170
)
sha256sum "$OUT" | tee "$OUT.sha256"

echo
echo "===== RELEASE CONTENTS ====="
tar -tzf "$OUT"

echo
echo "===== RELEASE VERIFY ====="
"$ROOT/verify-release.sh" "$OUT"

echo
echo "===== PRODUCTION BUILD COMPLETE ====="
echo "HiveOS custom-miner archive: $OUT"
echo "SHA256: $OUT.sha256"
echo "Kernel: share4 / red2 / 512 threads / natural 58-register codegen"
echo "Stale-share logic: exact v0.6.23 adaptive capability-recovery logic (only version/card-rate defaults changed)"
echo "This script does NOT install or replace the running HiveOS miner."
