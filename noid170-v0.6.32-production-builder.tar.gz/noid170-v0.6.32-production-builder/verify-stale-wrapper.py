#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT = Path(__file__).resolve().parent
ref = (ROOT/'reference/noid170_aria.v0.6.23.py').read_text()
cur = (ROOT/'template/noid170/noid170_aria.py').read_text()
normalized = cur.replace('VERSION = "0.6.32"','VERSION = "0.6.23"',1).replace(
    'CARD_MH = float(os.environ.get("NOID_CARD_MH", "160.9"))',
    'CARD_MH = float(os.environ.get("NOID_CARD_MH", "159.4"))',1)
if normalized != ref:
    print('ERROR: noid170_aria.py differs from the proven v0.6.23 stale-share wrapper beyond version/card-rate changes.', file=sys.stderr)
    sys.exit(1)
markers = [
    'CAPABILITY_MODE = os.environ.get("NOID_CAPABILITY_MODE", "adaptive")',
    'capability_flow_lock = threading.Lock()',
    'def rebind_template_capability(',
    'def invalidate_template_capability(',
    'def wait_for_valid_capability(',
    'def fetch_capability_for_seq_nonblocking(',
    'def refresh_after_accept(',
    'stats["stale_retry_attempts"] += 1',
    'print(f"STALE-RECOVERED seq={seq} height={height}", flush=True)',
    'capability_retry_not_before',
    'refresh_now_event',
]
missing=[m for m in markers if m not in cur]
if missing:
    print('ERROR: missing stale/capability recovery markers:', file=sys.stderr)
    for m in missing: print('  '+m, file=sys.stderr)
    sys.exit(1)
print('STALE-SHARE WRAPPER VERIFICATION: PASS')
print('v0.6.32 Python wrapper is byte-identical to v0.6.23 after normalizing only VERSION and NOID_CARD_MH default.')
print('reference sha256:', hashlib.sha256(ref.encode()).hexdigest())
print('release   sha256:', hashlib.sha256(cur.encode()).hexdigest())
