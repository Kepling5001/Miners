#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE="${1:-$ROOT/dist/noid170-0.6.32.tar.gz}"
[[ -f "$ARCHIVE" ]] || { echo "ERROR: archive not found: $ARCHIVE"; exit 1; }
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
tar -xzf "$ARCHIVE" -C "$TMP"
D="$TMP/noid170"
for f in noid_live_job_daemon noid_live_job_cont noid170_aria.py h-manifest.conf h-stats.sh h-run.sh hive_stats.py h-config.sh; do
  [[ -f "$D/$f" ]] || { echo "ERROR: missing $f"; exit 1; }
done
[[ -x "$D/noid_live_job_daemon" ]] || { echo "ERROR: daemon not executable"; exit 1; }
[[ -x "$D/noid_live_job_cont" ]] || { echo "ERROR: warmup binary not executable"; exit 1; }
grep -q 'CUSTOM_VERSION="0.6.32"' "$D/h-manifest.conf"
grep -q 'card_mh="160.9"' "$D/h-config.sh"
grep -q 'NOID_CAPABILITY_MODE="adaptive"' "$D/h-run.sh"
grep -q 'Single-use capability serialization: enabled' "$D/h-run.sh"
grep -q 'Compatible stale nonce retry: enabled' "$D/h-run.sh"
grep -q 'Nonblocking adaptive capability refresh: enabled' "$D/h-run.sh"
grep -q 'First-round four-lane Frobenius square sharing: enabled' "$D/h-run.sh"
python3 -m py_compile "$D/noid170_aria.py" "$D/hive_stats.py"
bash -n "$D/h-config.sh" "$D/h-run.sh" "$D/h-stats.sh"
python3 "$ROOT/audit-daemon.py" "$D/noid_live_job_daemon"
# Compare Python wrapper to the proven v0.6.23 implementation after normalizing the two intentional edits.
python3 - "$ROOT/reference/noid170_aria.v0.6.23.py" "$D/noid170_aria.py" <<'PY'
import sys
from pathlib import Path
ref=Path(sys.argv[1]).read_text(); cur=Path(sys.argv[2]).read_text()
cur=cur.replace('VERSION = "0.6.32"','VERSION = "0.6.23"',1).replace('CARD_MH = float(os.environ.get("NOID_CARD_MH", "160.9"))','CARD_MH = float(os.environ.get("NOID_CARD_MH", "159.4"))',1)
if cur != ref:
    raise SystemExit('ERROR: packaged stale-share wrapper drifted from v0.6.23')
print('PACKAGED STALE-SHARE WRAPPER: PASS')
PY
printf 'HIVEOS RELEASE VERIFICATION: PASS\n'
