#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${NOID_MINING_KEY:-}" ]]; then
  echo "ERROR: export NOID_MINING_KEY='your_NOID_address.timing' first"
  exit 1
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec python3 -u "$SCRIPT_DIR/compare_aria_local.py" "$@"
