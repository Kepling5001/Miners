#!/usr/bin/env python3
"""Passive Aria-versus-local Parano1d template timing comparison."""

import argparse
import csv
import datetime as dt
import http.client
import json
import os
import re
import signal
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urlparse


HEIGHT_RE = re.compile(r"^\s*Height\s+(\d+)\s*$", re.MULTILINE)
PROOF_MS_RE = re.compile(r"history_step_ms=(\d+)")
PAGES_RE = re.compile(r"user_pages=(\d+)")
OFFSETS = (-1, 0, 1)


def percentile(values, pct):
    if not values:
        return float("nan")
    ordered = sorted(values)
    pos = (len(ordered) - 1) * pct / 100.0
    lo = int(pos)
    hi = min(lo + 1, len(ordered) - 1)
    frac = pos - lo
    return ordered[lo] * (1.0 - frac) + ordered[hi] * frac


def parse_docker_timestamp(token):
    token = token.strip()
    if token.endswith("Z"):
        token = token[:-1] + "+00:00"
    return dt.datetime.fromisoformat(token).timestamp()


class AriaClient:
    def __init__(self, url, key):
        parsed = urlparse(url)
        self.scheme = parsed.scheme
        self.host = parsed.hostname
        self.port = parsed.port or (443 if parsed.scheme == "https" else 80)
        self.path = parsed.path or "/"
        self.key = key
        self.conn = None

    def close(self):
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
        self.conn = None

    def fetch(self):
        if self.conn is None:
            cls = http.client.HTTPSConnection if self.scheme == "https" else http.client.HTTPConnection
            self.conn = cls(self.host, self.port, timeout=5)
        body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "paranoid_getBlockTemplate",
            "params": [""],
        })
        try:
            self.conn.request(
                "POST",
                self.path,
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.key}",
                    "User-Agent": "noid-solo-timing/1.0",
                    "Connection": "keep-alive",
                },
            )
            response = self.conn.getresponse()
            raw = response.read()
            if response.status != 200:
                raise RuntimeError(f"HTTP {response.status}: {raw.decode(errors='replace')}")
            decoded = json.loads(raw)
            if decoded.get("error"):
                error = decoded["error"]
                if isinstance(error, dict) and error.get("code") == -32011:
                    return None
                raise RuntimeError(str(error))
            result = decoded["result"]
            return int(result["height"]), str(result.get("template_id", result.get("id", "")))
        except Exception:
            self.close()
            raise


def docker_cli_height(node_cid):
    proc = subprocess.run(
        ["docker", "exec", node_cid, "parano1d-cli", "mining"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=10,
        check=True,
    )
    match = HEIGHT_RE.search(proc.stdout)
    if not match:
        raise RuntimeError(f"could not parse node height from: {proc.stdout!r}")
    return int(match.group(1))


def discover_node_container(explicit):
    if explicit:
        return explicit
    attempts = [
        ["docker", "compose", "ps", "-q", "node"],
        ["docker", "ps", "--filter", "name=parano1d-pool-node", "--format", "{{.ID}}"],
        ["docker", "ps", "--filter", "ancestor=peakminer/parano1d-node:1.0.4", "--format", "{{.ID}}"],
    ]
    for command in attempts:
        proc = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        candidate = proc.stdout.strip().splitlines()
        if candidate and candidate[0]:
            return candidate[0]
    raise RuntimeError("could not discover the Parano1d node container; set NOID_NODE_CID")


def choose_offset(aria, local):
    scored = []
    for offset in OFFSETS:
        count = sum(1 for lh in local if lh + offset in aria)
        scored.append((count, -abs(offset), offset))
    return max(scored)[2]


def matched_rows(aria, local, offset, minimum_height):
    rows = []
    for local_height, local_event in local.items():
        aria_height = local_height + offset
        if aria_height <= minimum_height or aria_height not in aria:
            continue
        aria_event = aria[aria_height]
        rows.append({
            "height": aria_height,
            "aria_utc": dt.datetime.fromtimestamp(aria_event[0], dt.timezone.utc).isoformat(),
            "local_utc": dt.datetime.fromtimestamp(local_event[0], dt.timezone.utc).isoformat(),
            "local_minus_aria_ms": (local_event[0] - aria_event[0]) * 1000.0,
            "history_step_ms": local_event[1],
            "user_pages": local_event[2],
            "aria_template_id": aria_event[1],
        })
    return sorted(rows, key=lambda row: row["height"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--matches", type=int, default=int(os.getenv("NOID_TIMING_HEIGHTS", "50")))
    parser.add_argument("--timeout", type=int, default=int(os.getenv("NOID_TIMING_TIMEOUT", "3600")))
    parser.add_argument("--output", default=os.getenv("NOID_TIMING_OUTPUT", "/run/noid-solo-timing"))
    args = parser.parse_args()

    key = os.getenv("NOID_MINING_KEY", "").strip()
    if not key or key.startswith("your_") or "YOUR_" in key:
        raise SystemExit("ERROR: export NOID_MINING_KEY='your_NOID_address.timing' first")
    url = os.getenv("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
    node_cid = discover_node_container(os.getenv("NOID_NODE_CID", "").strip())
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    stop = threading.Event()
    lock = threading.Lock()
    aria = {}
    local = {}
    errors = []
    client = AriaClient(url, key)

    print("===== PASSIVE ARIA VS LOCAL TEMPLATE TIMING =====", flush=True)
    print(f"node container: {node_cid}", flush=True)
    print(f"target matched heights: {args.matches}", flush=True)
    print("Mining and PeakPool remain running. No local template RPC is called.", flush=True)

    # Establish both current heights so startup's already-ready template is excluded.
    local_start = docker_cli_height(node_cid)
    aria_start = None
    deadline = time.monotonic() + 20
    while aria_start is None and time.monotonic() < deadline:
        try:
            value = client.fetch()
            if value:
                aria_start = value[0]
        except Exception as exc:
            print(f"waiting for initial Aria template: {exc}", flush=True)
            time.sleep(0.5)
    if aria_start is None:
        raise SystemExit("ERROR: could not obtain initial Aria template")
    minimum_height = min(local_start, aria_start)
    print(f"starting heights: aria={aria_start} local={local_start}; startup height excluded", flush=True)

    def aria_worker():
        last_height = aria_start
        while not stop.is_set():
            try:
                value = client.fetch()
                received = time.time()
                if value:
                    height, template_id = value
                    if height != last_height:
                        with lock:
                            aria.setdefault(height, (received, template_id))
                        print(f"ARIA  height={height} first_job={dt.datetime.fromtimestamp(received).strftime('%H:%M:%S.%f')[:-3]}", flush=True)
                        last_height = height
                time.sleep(0.03)
            except Exception as exc:
                errors.append(f"Aria: {exc}")
                time.sleep(0.25)
        client.close()

    def local_worker():
        proc = subprocess.Popen(
            ["docker", "logs", "--follow", "--timestamps", "--since", "2s", node_cid],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
        )
        try:
            for line in proc.stdout:
                if stop.is_set():
                    break
                if "external mining template proved" not in line:
                    continue
                parts = line.split(maxsplit=1)
                try:
                    event_time = parse_docker_timestamp(parts[0])
                    height = docker_cli_height(node_cid)
                    proof_match = PROOF_MS_RE.search(line)
                    pages_match = PAGES_RE.search(line)
                    proof_ms = int(proof_match.group(1)) if proof_match else -1
                    pages = int(pages_match.group(1)) if pages_match else -1
                    if height > local_start:
                        with lock:
                            is_new = height not in local
                            local.setdefault(height, (event_time, proof_ms, pages))
                        if is_new:
                            print(f"LOCAL height={height} proved={dt.datetime.fromtimestamp(event_time).strftime('%H:%M:%S.%f')[:-3]} proof_ms={proof_ms}", flush=True)
                except Exception as exc:
                    errors.append(f"local log: {exc}")
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    threads = [threading.Thread(target=aria_worker, daemon=True), threading.Thread(target=local_worker, daemon=True)]
    for thread in threads:
        thread.start()

    interrupted = False
    started = time.monotonic()

    def handle_signal(signum, frame):
        nonlocal interrupted
        interrupted = True
        stop.set()

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    last_reported = -1
    while not stop.is_set() and time.monotonic() - started < args.timeout:
        with lock:
            offset = choose_offset(aria, local)
            rows = matched_rows(aria, local, offset, minimum_height)
        if len(rows) != last_reported:
            print(f"progress: matched={len(rows)}/{args.matches} height_offset={offset:+d} aria_seen={len(aria)} local_seen={len(local)}", flush=True)
            last_reported = len(rows)
        if len(rows) >= args.matches:
            stop.set()
            break
        time.sleep(0.5)

    stop.set()
    for thread in threads:
        thread.join(timeout=5)
    with lock:
        offset = choose_offset(aria, local)
        rows = matched_rows(aria, local, offset, minimum_height)
    if len(rows) > args.matches:
        rows = rows[:args.matches]

    csv_path = output / "matched_heights.csv"
    with csv_path.open("w", newline="") as handle:
        fields = ["height", "aria_utc", "local_utc", "local_minus_aria_ms", "history_step_ms", "user_pages", "aria_template_id"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    raw_path = output / "raw_events.json"
    raw_path.write_text(json.dumps({
        "aria": aria,
        "local": local,
        "height_offset": offset,
        "minimum_height": minimum_height,
        "errors": errors[-50:],
    }, indent=2, sort_keys=True))

    print("\n===== FINAL ARIA VS LOCAL TEMPLATE TIMING =====")
    print(f"matched heights: {len(rows)}  height offset: {offset:+d}")
    if rows:
        deltas = [row["local_minus_aria_ms"] for row in rows]
        proof_times = [row["history_step_ms"] for row in rows if row["history_step_ms"] >= 0]
        local_wins = sum(delta < 0 for delta in deltas)
        print(f"local minus Aria: mean={statistics.mean(deltas):.1f} ms median={statistics.median(deltas):.1f} ms p95={percentile(deltas, 95):.1f} ms")
        print(f"local first: {local_wins}/{len(deltas)} ({100.0 * local_wins / len(deltas):.1f}%)")
        if proof_times:
            print(f"local proof: mean={statistics.mean(proof_times):.1f} ms median={statistics.median(proof_times):.1f} ms p95={percentile(proof_times, 95):.1f} ms")
        median_delta = statistics.median(deltas)
        if median_delta <= 500:
            decision = "VIABLE — local work is effectively as early as Aria; proceed to a solo-coordinator live A/B"
        elif median_delta <= 2000:
            decision = "BORDERLINE — local trails modestly; a short solo-coordinator live A/B is justified"
        else:
            decision = "FAIL — local work arrives too far behind Aria for solo mining to recover with lower stales"
        print(f"decision: {decision}")
    else:
        print("decision: INCOMPLETE — no matched heights; inspect raw_events.json and errors")
    if interrupted:
        print("note: stopped early by user; partial results were retained")
    elif time.monotonic() - started >= args.timeout:
        print("note: timeout reached; partial results were retained")
    print(f"results: {output}")
    print("Paste this complete final block back into chat.")

    if len(rows) < 5:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
