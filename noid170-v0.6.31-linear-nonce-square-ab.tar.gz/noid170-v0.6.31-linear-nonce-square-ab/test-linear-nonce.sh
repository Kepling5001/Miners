#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY first"; exit 1; }
echo "===== LINEAR NONCE CORRECTNESS ====="
CUDA_VISIBLE_DEVICES=0 "$ROOT/bin/test_linear_nonce"
echo
echo "===== STATIC SASS AUDIT ====="
python3 "$ROOT/sass-audit.py" prod share4 aligned_clmad linear_spread linear_direct4
echo
python3 "$ROOT/benchmark_linear_nonce.py"
echo
python3 "$ROOT/test-persistent.py"
