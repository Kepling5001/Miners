#!/usr/bin/env python3
import os,re,subprocess,sys,tempfile,shutil
ROOT=os.path.dirname(os.path.abspath(__file__)); BIN=os.path.join(ROOT,'bin'); CU=os.environ.get('CUOBJDUMP','/usr/local/cuda-13.3/bin/cuobjdump'); NV=os.environ.get('NVDISASM_PATH','/usr/local/cuda-13.3/bin/nvdisasm')
names=sys.argv[1:] or ['prod','share4','aligned_clmad','linear_spread','linear_direct4']
def audit(name):
 path=os.path.join(BIN,'noid_daemon_'+name); td=tempfile.mkdtemp(prefix='sass631_')
 try:
  subprocess.run([CU,'-xelf','all',path],cwd=td,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
  cub=next((os.path.join(td,x) for x in os.listdir(td) if x.endswith('.cubin')),None)
  txt=subprocess.check_output([NV,cub],text=True,stderr=subprocess.STDOUT)
  # isolate mine_kernel function by function header boundaries
  m=re.search(r'\.section\s+\.text\._Z11mine_kernel.*?(?=\n\s*\.section\s+\.text\.|\Z)',txt,re.S)
  seg=m.group(0) if m else txt
  ops=re.findall(r'/\*[0-9a-fA-F]+\*/\s+(?:@\S+\s+)?([A-Z][A-Z0-9_.]*)',seg)
  base=[x.split('.')[0] for x in ops]; cl=base.count('CLMAD'); lop=sum(1 for x in base if x in ('LOP3','ULOP3')); shf=base.count('SHF'); imad=base.count('IMAD')
  ru=subprocess.check_output([CU,'--dump-resource-usage',path],text=True,stderr=subprocess.STDOUT)
  r=re.search(r'Function\s+_Z11mine_kernel[^:]*:\s*\n\s*REG:(\d+)\s+STACK:(\d+)\s+SHARED:(\d+)\s+LOCAL:(\d+)',ru); reg=local='?'
  if r: reg=r.group(1); local=r.group(4)
  return len(ops),cl,lop,shf,imad,reg,local
 finally: shutil.rmtree(td,ignore_errors=True)
for n in names:
 t,cl,lo,sh,im,r,l=audit(n); print(f'{n:18s} total={t:4d} CLMAD={cl:4d} LOP3={lo:4d} SHF={sh:4d} IMAD={im:4d} REG={r} LOCAL={l}')
