__device__ __forceinline__
U128 bxor(U128 a, U128 b)
{
    return {a.lo ^ b.lo, a.hi ^ b.hi};
}

__device__ __forceinline__
bool nonzero(U128 a)
{
    return (a.lo | a.hi) != 0ULL;
}

/*
 * Scheduling audit switch.  The production path keeps each CLMAD inline-PTX
 * statement volatile.  The audit can remove that compiler barrier so ptxas
 * may move independent low/high products, and can optionally expose the
 * low/high pair as one multi-output statement.
 */
#if defined(NOID_CLMAD_NONVOLATILE)
#define NOID_CLMAD_ASM asm
#else
#define NOID_CLMAD_ASM asm volatile
#endif

/*
 * Correctness-first GF(2^128) multiplication.
 *
 * Flat/GCM basis polynomial:
 *     x^128 + x^7 + x^2 + x + 1
 *
 * This version is intentionally simple.
 * We optimize it only AFTER matching the Rust oracle.
 */

__device__ __forceinline__
U128 shl128(U128 a, unsigned n)
{
    if (n == 0)
        return a;

    U128 r;
    r.lo = a.lo << n;
    r.hi = (a.hi << n) | (a.lo >> (64 - n));
    return r;
}

__device__ __forceinline__
U128 clmul64_nibble(
    unsigned long long a,
    unsigned long long b)
{
    unsigned long long lo;
    unsigned long long hi;
    const unsigned long long zero = 0ULL;

#if defined(NOID_CLMAD_PAIR_OUTPUTS)
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %2, %3, %4;\n\t"
        "clmad.hi.u64 %1, %2, %3, %4;"
        : "=l"(lo), "=l"(hi)
        : "l"(a), "l"(b), "l"(zero)
    );
#else
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(zero)
    );

    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(zero)
    );
#endif

    return {lo, hi};
}

__device__ __forceinline__
U128 clmul64_accumulate(
    unsigned long long a,
    unsigned long long b,
    U128 accumulator)
{
    unsigned long long lo;
    unsigned long long hi;

    // PTX clmad performs carry-less multiplication followed by XOR with c.
#if defined(NOID_CLMAD_PAIR_OUTPUTS)
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %2, %3, %4;\n\t"
        "clmad.hi.u64 %1, %2, %3, %5;"
        : "=l"(lo), "=l"(hi)
        : "l"(a), "l"(b), "l"(accumulator.lo), "l"(accumulator.hi)
    );
#else
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(accumulator.lo)
    );

    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(accumulator.hi)
    );
#endif

    return {lo, hi};
}

/* Optional audit form for the two independent first reduction folds. */
__device__ __forceinline__
U128 clmad_reduce_pair(
    unsigned long long a,
    unsigned long long b,
    unsigned long long c_lo,
    unsigned long long c_hi)
{
    unsigned long long lo;
    unsigned long long hi;
#if defined(NOID_CLMAD_PAIR_REDUCE)
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %2, %3, %4;\n\t"
        "clmad.hi.u64 %1, %2, %3, %5;"
        : "=l"(lo), "=l"(hi)
        : "l"(a), "l"(b), "l"(c_lo), "l"(c_hi)
    );
#else
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(c_lo)
    );
    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(c_hi)
    );
#endif
    return {lo, hi};
}

__device__ __forceinline__
U128 reduce_gcm_256_shift(U128 hi, U128 lo)
{
    // x^128 = x^7 + x^2 + x + 1  (0x87)
    U128 t = hi;
    t = bxor(t, shl128(hi, 1));
    t = bxor(t, shl128(hi, 2));
    t = bxor(t, shl128(hi, 7));

    unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    unsigned long long fold =
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    U128 r = bxor(lo, t);
    r.lo ^= fold;

    return r;
}

__device__ __forceinline__
U128 reduce_gcm_256_clmad(U128 hi, U128 lo)
{
    /*
     * Reduce hi*x^128 + lo modulo x^128 + x^7 + x^2 + x + 1.
     * Since x^128 == 0x87, first fold hi*0x87 into lo.  That product
     * can extend by at most seven bits; fold those bits by 0x87 once more.
     *
     * CLMAD's accumulator operand absorbs every XOR into the five
     * carry-less multiply instructions below:
     *
     *   r.lo = lo.lo ^ low64(hi.lo * 0x87)
     *   r.hi = lo.hi ^ high64(hi.lo * 0x87)
     *                    ^ low64(hi.hi * 0x87)
     *   r.lo ^= low64(high64(hi.hi * 0x87) * 0x87)
     */
    const unsigned long long polynomial = 0x87ULL;
    const unsigned long long zero = 0ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long overflow;
    unsigned long long folded_lo;

    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );

    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );

    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(overflow)
        : "l"(hi.hi), "l"(polynomial), "l"(zero)
    );

    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(folded_lo)
        : "l"(overflow), "l"(polynomial), "l"(r_lo)
    );

    return {folded_lo, r_hi};
}

/*
 * Four-CLMAD hybrid A: derive the seven-bit overflow with integer shifts,
 * then retain CLMAD for the final low-limb fold.  This removes the dependent
 * clmad.hi without returning to the expensive full shift reduction.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r4_topshift(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long folded_lo;

    const U128 first = clmad_reduce_pair(
        hi.lo, polynomial, lo.lo, lo.hi);
    r_lo = first.lo;
    r_hi_mid = first.hi;
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    const unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(folded_lo)
        : "l"(overflow), "l"(polynomial), "l"(r_lo)
    );

    return {folded_lo, r_hi};
}

/*
 * Four-CLMAD hybrid B: retain CLMAD for the high overflow extraction and
 * replace only the tiny final overflow*0x87 product with shifts/XORs.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r4_foldshift(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    const unsigned long long zero = 0ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long overflow;

    const U128 first = clmad_reduce_pair(
        hi.lo, polynomial, lo.lo, lo.hi);
    r_lo = first.lo;
    r_hi_mid = first.hi;
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );
    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(overflow)
        : "l"(hi.hi), "l"(polynomial), "l"(zero)
    );

    r_lo ^=
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    return {r_lo, r_hi};
}

/*
 * Three-CLMAD hybrid: CLMAD performs the two full-width folds while shifts
 * handle the at-most-seven-bit overflow and its final multiplication by 0x87.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r3_hybrid(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;

    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );
    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    const unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    r_lo ^=
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    return {r_lo, r_hi};
}

/*
 * Square-only GCM reductions.
 *
 * The two 128-bit halves entering reduction are carry-less self-products.
 * Their odd-numbered bits are therefore zero.  For either 64-bit high limb
 * h, high64(h*0x87) simplifies exactly from
 *
 *     (h >> 63) ^ (h >> 62) ^ (h >> 57)
 *
 * to
 *
 *     (h >> 62) ^ (h >> 57)
 *
 * because bit 63 is always zero.  These variants keep multiplication on the
 * production r4top path and specialize only the reductions reached by
 * square_flat_clmad().
 */
__device__ __forceinline__
unsigned long long square_mul87_hi(unsigned long long h)
{
    return (h >> 62) ^ (h >> 57);
}

__device__ __forceinline__
unsigned long long square_xor3_lop3(
    unsigned long long a,
    unsigned long long b,
    unsigned long long c)
{
    unsigned lo, hi;
    asm volatile(
        "lop3.b32 %0, %1, %2, %3, 0x96;"
        : "=r"(lo)
        : "r"((unsigned)a), "r"((unsigned)b), "r"((unsigned)c)
    );
    asm volatile(
        "lop3.b32 %0, %1, %2, %3, 0x96;"
        : "=r"(hi)
        : "r"((unsigned)(a >> 32)),
          "r"((unsigned)(b >> 32)),
          "r"((unsigned)(c >> 32))
    );
    return (unsigned long long)lo | ((unsigned long long)hi << 32);
}

__device__ __forceinline__
unsigned long long square_mul87_lo(unsigned long long h)
{
    const unsigned long long h1 = h << 1;
    const unsigned long long h2 = h << 2;
    const unsigned long long h7 = h << 7;
#ifdef NOID_SQUARE_FOLD_LOP3
    return square_xor3_lop3(h, h1, h2) ^ h7;
#else
    return h ^ h1 ^ h2 ^ h7;
#endif
}

__device__ __forceinline__
unsigned long long square_clmad_lo(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
unsigned long long square_clmad_hi(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
U128 reduce_square_r3_even(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo = square_clmad_lo(hi.lo, polynomial, lo.lo);
    const unsigned long long r_hi_mid =
        square_clmad_hi(hi.lo, polynomial, lo.hi);
    const unsigned long long r_hi =
        square_clmad_lo(hi.hi, polynomial, r_hi_mid);
    r_lo ^= square_mul87_lo(square_mul87_hi(hi.hi));
    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_square_r2_even(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo = square_clmad_lo(hi.lo, polynomial, lo.lo);
    const unsigned long long r_hi = square_clmad_lo(
        hi.hi,
        polynomial,
        lo.hi ^ square_mul87_hi(hi.lo));
    r_lo ^= square_mul87_lo(square_mul87_hi(hi.hi));
    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_square_r1_low(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo = square_clmad_lo(hi.lo, polynomial, lo.lo);
    r_lo ^= square_mul87_lo(square_mul87_hi(hi.hi));
    const unsigned long long r_hi =
        lo.hi ^ square_mul87_hi(hi.lo) ^ square_mul87_lo(hi.hi);
    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_square_r1_high(U128 hi, U128 lo)
{
    unsigned long long r_lo =
        lo.lo ^ square_mul87_lo(hi.lo) ^
        square_mul87_lo(square_mul87_hi(hi.hi));
    const unsigned long long r_hi = square_clmad_lo(
        hi.hi,
        0x87ULL,
        lo.hi ^ square_mul87_hi(hi.lo));
    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_square_r0_shift(U128 hi, U128 lo)
{
    const unsigned long long r_lo =
        lo.lo ^ square_mul87_lo(hi.lo) ^
        square_mul87_lo(square_mul87_hi(hi.hi));
    const unsigned long long r_hi =
        lo.hi ^ square_mul87_hi(hi.lo) ^ square_mul87_lo(hi.hi);
    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_gcm_256(U128 hi, U128 lo)
{
#if !defined(NOID_REDUCE_VARIANT) || NOID_REDUCE_VARIANT == 5
    return reduce_gcm_256_clmad(hi, lo);
#elif NOID_REDUCE_VARIANT == 41
    return reduce_gcm_256_r4_topshift(hi, lo);
#elif NOID_REDUCE_VARIANT == 42
    return reduce_gcm_256_r4_foldshift(hi, lo);
#elif NOID_REDUCE_VARIANT == 3
    return reduce_gcm_256_r3_hybrid(hi, lo);
#else
#error "Unsupported NOID_REDUCE_VARIANT"
#endif
}

__device__ __forceinline__
U128 gf_mul_current(U128 a, U128 b)
{
    // Karatsuba: three 64x64 carry-less multiplies.
    U128 p0 = clmul64_nibble(a.lo, b.lo);
    U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_nibble(a.lo ^ a.hi, b.lo ^ b.hi);

    pm = bxor(pm, p0);
    pm = bxor(pm, p1);

    U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 gf_mul_accum(U128 a, U128 b)
{
    /*
     * Karatsuba with p0 accumulated directly into the middle product.
     *
     * current:
     *   pm = CLMUL(am, bm) ^ p0 ^ p1
     * accumulator variant:
     *   pm = CLMAD(am, bm, p0) ^ p1
     *
     * This removes one 128-bit XOR (two 64-bit XOR instructions) without
     * changing any field arithmetic or reduction.
     */
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_accumulate(
        a.lo ^ a.hi,
        b.lo ^ b.hi,
        p0);

    pm = bxor(pm, p1);

    const U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    const U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

/*
 * Fused Karatsuba layout.  The middle-product XORs are folded into CLMAD's
 * accumulator operands so the final 256-bit product limbs are produced
 * directly.  The arithmetic is identical to gf_mul_accum; this variant tests
 * whether a shorter dependency graph schedules better on GA100.
 */
__device__ __forceinline__
U128 gf_mul_fused(U128 a, U128 b)
{
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);

    const unsigned long long am = a.lo ^ a.hi;
    const unsigned long long bm = b.lo ^ b.hi;
    const U128 limb_accumulator{
        p0.lo ^ p1.lo ^ p0.hi,
        p0.hi ^ p1.hi ^ p1.lo
    };
    const U128 middle = clmul64_accumulate(am, bm, limb_accumulator);

    const U128 lo{p0.lo, middle.lo};
    const U128 hi{middle.hi, p1.hi};
    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 gf_mul(U128 a, U128 b)
{
#ifdef NOID_GF_FUSED
    return gf_mul_fused(a, b);
#elif defined(NOID_CLMAD_ACCUM)
    return gf_mul_accum(a, b);
#else
    return gf_mul_current(a, b);
#endif
}

/*
 * Stage-major carry-less multiplication helpers for partial-MDS ILP tests.
 * The scheduling audit below compares the production volatile form with
 * non-volatile and multi-output forms.  Arithmetic and instruction counts are
 * unchanged; only compiler visibility and output grouping differ.
 */
__device__ __forceinline__
unsigned long long clmad_lo_acc(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    NOID_CLMAD_ASM(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
unsigned long long clmad_hi_acc(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    NOID_CLMAD_ASM(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
void gf_product_scalar(U128 a, U128 b, U128 &lo, U128 &hi)
{
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_accumulate(a.lo ^ a.hi, b.lo ^ b.hi, p0);
    pm = bxor(pm, p1);
    lo = {p0.lo, p0.hi ^ pm.lo};
    hi = {p1.lo ^ pm.hi, p1.hi};
}

template <int N>
__device__ __forceinline__
void gf_product_batch(
    const U128 (&a)[N],
    const U128 (&b)[N],
    U128 (&lo)[N],
    U128 (&hi)[N])
{
    unsigned long long p0_lo[N], p0_hi[N];
    unsigned long long p1_lo[N], p1_hi[N];
    unsigned long long pm_lo[N], pm_hi[N];

    #pragma unroll
    for (int i = 0; i < N; ++i)
        p0_lo[i] = clmad_lo_acc(a[i].lo, b[i].lo, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p0_hi[i] = clmad_hi_acc(a[i].lo, b[i].lo, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p1_lo[i] = clmad_lo_acc(a[i].hi, b[i].hi, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p1_hi[i] = clmad_hi_acc(a[i].hi, b[i].hi, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        pm_lo[i] = clmad_lo_acc(
            a[i].lo ^ a[i].hi,
            b[i].lo ^ b[i].hi,
            p0_lo[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        pm_hi[i] = clmad_hi_acc(
            a[i].lo ^ a[i].hi,
            b[i].lo ^ b[i].hi,
            p0_hi[i]);

    #pragma unroll
    for (int i = 0; i < N; ++i) {
        pm_lo[i] ^= p1_lo[i];
        pm_hi[i] ^= p1_hi[i];
        lo[i] = {p0_lo[i], p0_hi[i] ^ pm_lo[i]};
        hi[i] = {p1_lo[i] ^ pm_hi[i], p1_hi[i]};
    }
}

template <int N>
__device__ __forceinline__
void reduce_r4top_batch(
    const U128 (&hi)[N],
    const U128 (&lo)[N],
    U128 (&out)[N])
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo[N];
    unsigned long long r_hi_mid[N];
    unsigned long long r_hi[N];
    unsigned long long overflow[N];
    unsigned long long folded_lo[N];

    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_lo[i] = clmad_lo_acc(hi[i].lo, polynomial, lo[i].lo);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_hi_mid[i] = clmad_hi_acc(hi[i].lo, polynomial, lo[i].hi);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_hi[i] = clmad_lo_acc(hi[i].hi, polynomial, r_hi_mid[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i) {
        overflow[i] =
            (hi[i].hi >> 63) ^
            (hi[i].hi >> 62) ^
            (hi[i].hi >> 57);
    }
    #pragma unroll
    for (int i = 0; i < N; ++i)
        folded_lo[i] = clmad_lo_acc(overflow[i], polynomial, r_lo[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        out[i] = {folded_lo[i], r_hi[i]};
}

template <int N>
__device__ __forceinline__
void gf_mul_batch(
    const U128 (&a)[N],
    const U128 (&b)[N],
    U128 (&out)[N])
{
    U128 lo[N], hi[N];
    gf_product_batch<N>(a, b, lo, hi);
    reduce_r4top_batch<N>(hi, lo, out);
}

__device__ __forceinline__
unsigned long long spread32(unsigned x)
{
    unsigned long long v = x;

    v = (v | (v << 16)) & 0x0000FFFF0000FFFFULL;
    v = (v | (v <<  8)) & 0x00FF00FF00FF00FFULL;
    v = (v | (v <<  4)) & 0x0F0F0F0F0F0F0F0FULL;
    v = (v | (v <<  2)) & 0x3333333333333333ULL;
    v = (v | (v <<  1)) & 0x5555555555555555ULL;

    return v;
}

/*
 * Mining nonce-window helpers.
 *
 * When the batch base is aligned to a power-of-two window and tid occupies
 * only those low bits, nonce = base XOR tid.  Frobenius squaring is GF(2)
 * linear, so nonce^2 = base^2 XOR tid^2 and likewise for nonce^4.
 *
 * tid is < 2^23 on the current 512x8960 launch.  Its square therefore fits in
 * the low 64 bits without polynomial reduction.  tid^4 fits in 128 bits.
 */
__device__ __forceinline__
U128 noid_tid_square2(unsigned tid)
{
    return {spread32(tid), 0ULL};
}

__device__ __forceinline__
U128 noid_tid_square4_from_square2(U128 tid2)
{
    return {
        spread32((unsigned)tid2.lo),
        spread32((unsigned)(tid2.lo >> 32))
    };
}

__device__ __forceinline__
unsigned long long noid_spread4_16(unsigned x)
{
    unsigned long long v = (unsigned long long)(x & 0xFFFFU);
    v = (v | (v << 24)) & 0x000000FF000000FFULL;
    v = (v | (v << 12)) & 0x000F000F000F000FULL;
    v = (v | (v <<  6)) & 0x0303030303030303ULL;
    v = (v | (v <<  3)) & 0x1111111111111111ULL;
    return v;
}

__device__ __forceinline__
U128 noid_tid_square4_direct(unsigned tid)
{
    return {
        noid_spread4_16(tid),
        noid_spread4_16(tid >> 16)
    };
}

__device__ __forceinline__
U128 expand64(unsigned long long x)
{
    return {
        spread32((unsigned)x),
        spread32((unsigned)(x >> 32))
    };
}

__device__ __forceinline__
U128 square_flat_spread(U128 a)
{
    // Squaring in characteristic two = inserting zeros between bits,
    // followed by reduction modulo the GCM polynomial.
    U128 lo = expand64(a.lo);
    U128 hi = expand64(a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 square_flat_clmad(U128 a)
{
    /*
     * In characteristic two, cross terms cancel when a polynomial is
     * squared.  The low and high 64-bit limbs can therefore be squared
     * independently with carry-less self-multiplication, then passed to the
     * same exact GCM reduction as the spread-bit implementation.
     */
    const U128 lo = clmul64_nibble(a.lo, a.lo);
    const U128 hi = clmul64_nibble(a.hi, a.hi);

#if !defined(NOID_SQUARE_REDUCE_VARIANT) || NOID_SQUARE_REDUCE_VARIANT == 0
    return reduce_gcm_256(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 1
    return reduce_gcm_256_r3_hybrid(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 2
    return reduce_square_r3_even(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 3
    return reduce_square_r2_even(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 4
    return reduce_square_r1_low(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 5
    return reduce_square_r1_high(hi, lo);
#elif NOID_SQUARE_REDUCE_VARIANT == 6
    return reduce_square_r0_shift(hi, lo);
#else
#error "Unsupported NOID_SQUARE_REDUCE_VARIANT"
#endif
}

__device__ __forceinline__
U128 square_flat(U128 a)
{
#ifdef NOID_SQUARE_CLMAD
    return square_flat_clmad(a);
#else
    return square_flat_spread(a);
#endif
}

__device__ __forceinline__
U128 sbox_x7_spread(U128 x)
{
    // Production Parano1d schedule:
    // x2 = square(x)
    // x4 = square(x2)
    // x6 = x * x2
    // x7 = x6 * x4
    const U128 x2 = square_flat_spread(x);
    const U128 x4 = square_flat_spread(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
U128 sbox_x7_clmad(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const U128 x4 = square_flat_clmad(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

/*
 * Fused x^7 experiments.
 *
 * The production addition chain has two independent branches after x2:
 *
 *     x4 = square(x2)
 *     x3 = x * x2
 *
 * sbox_x7_branch_fused() exposes all raw products from those branches before
 * either reduction.  Their unlike reductions (r2lop3 for the square and
 * r4top for the general product) are then interleaved explicitly.  This does
 * not change the instruction count; it tests whether a single straight-line
 * primitive lets ptxas cover CLMAD dependency latency better than four
 * separately inlined field operations.
 */
template <bool PAIR_ASM>
__device__ __forceinline__
void x7_clmad_lo_pair(
    unsigned long long a0,
    unsigned long long b0,
    unsigned long long c0,
    unsigned long long a1,
    unsigned long long b1,
    unsigned long long c1,
    unsigned long long &out0,
    unsigned long long &out1)
{
    if constexpr (PAIR_ASM) {
        NOID_CLMAD_ASM(
            "clmad.lo.u64 %0, %2, %3, %4;\n\t"
            "clmad.lo.u64 %1, %5, %6, %7;"
            : "=&l"(out0), "=&l"(out1)
            : "l"(a0), "l"(b0), "l"(c0),
              "l"(a1), "l"(b1), "l"(c1)
        );
    } else {
        out0 = clmad_lo_acc(a0, b0, c0);
        out1 = clmad_lo_acc(a1, b1, c1);
    }
}

template <bool PAIR_ASM>
__device__ __forceinline__
void x7_clmad_hi_pair(
    unsigned long long a0,
    unsigned long long b0,
    unsigned long long c0,
    unsigned long long a1,
    unsigned long long b1,
    unsigned long long c1,
    unsigned long long &out0,
    unsigned long long &out1)
{
    if constexpr (PAIR_ASM) {
        NOID_CLMAD_ASM(
            "clmad.hi.u64 %0, %2, %3, %4;\n\t"
            "clmad.hi.u64 %1, %5, %6, %7;"
            : "=&l"(out0), "=&l"(out1)
            : "l"(a0), "l"(b0), "l"(c0),
              "l"(a1), "l"(b1), "l"(c1)
        );
    } else {
        out0 = clmad_hi_acc(a0, b0, c0);
        out1 = clmad_hi_acc(a1, b1, c1);
    }
}

template <bool PAIR_ASM>
__device__ __forceinline__
U128 sbox_x7_branch_fused(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const unsigned long long zero = 0ULL;

    unsigned long long sq0_lo, p0_lo;
    unsigned long long sq0_hi, p0_hi;
    unsigned long long sq1_lo, p1_lo;
    unsigned long long sq1_hi, p1_hi;
    x7_clmad_lo_pair<PAIR_ASM>(
        x2.lo, x2.lo, zero, x.lo, x2.lo, zero, sq0_lo, p0_lo);
    x7_clmad_hi_pair<PAIR_ASM>(
        x2.lo, x2.lo, zero, x.lo, x2.lo, zero, sq0_hi, p0_hi);
    x7_clmad_lo_pair<PAIR_ASM>(
        x2.hi, x2.hi, zero, x.hi, x2.hi, zero, sq1_lo, p1_lo);
    x7_clmad_hi_pair<PAIR_ASM>(
        x2.hi, x2.hi, zero, x.hi, x2.hi, zero, sq1_hi, p1_hi);

    const unsigned long long am = x.lo ^ x.hi;
    const unsigned long long bm = x2.lo ^ x2.hi;
    unsigned long long pm_lo = clmad_lo_acc(am, bm, p0_lo);
    unsigned long long pm_hi = clmad_hi_acc(am, bm, p0_hi);
    pm_lo ^= p1_lo;
    pm_hi ^= p1_hi;

    const U128 square_lo{sq0_lo, sq0_hi};
    const U128 square_hi{sq1_lo, sq1_hi};
    const U128 product_lo{p0_lo, p0_hi ^ pm_lo};
    const U128 product_hi{p1_lo ^ pm_hi, p1_hi};

    const unsigned long long polynomial = 0x87ULL;
    unsigned long long square_r_lo, product_r_lo;
    x7_clmad_lo_pair<PAIR_ASM>(
        square_hi.lo, polynomial, square_lo.lo,
        product_hi.lo, polynomial, product_lo.lo,
        square_r_lo, product_r_lo);

    const unsigned long long square_hi_acc =
        square_lo.hi ^ square_mul87_hi(square_hi.lo);
    unsigned long long square_r_hi =
        clmad_lo_acc(square_hi.hi, polynomial, square_hi_acc);
    square_r_lo ^=
        square_mul87_lo(square_mul87_hi(square_hi.hi));

    unsigned long long product_r_hi_mid =
        clmad_hi_acc(product_hi.lo, polynomial, product_lo.hi);
    unsigned long long product_r_hi =
        clmad_lo_acc(product_hi.hi, polynomial, product_r_hi_mid);
    const unsigned long long product_overflow =
        (product_hi.hi >> 63) ^
        (product_hi.hi >> 62) ^
        (product_hi.hi >> 57);
    product_r_lo =
        clmad_lo_acc(product_overflow, polynomial, product_r_lo);

    const U128 x4{square_r_lo, square_r_hi};
    const U128 x3{product_r_lo, product_r_hi};
    return gf_mul(x3, x4);
}

/*
 * True lazy-reduction candidate.
 *
 * The x3 product is kept as 256 bits and multiplied by reduced x4 before a
 * single 384->128 reduction.  For z=x^128 and q=0x87, z=q in the field:
 *
 *   C0 + C1*z + C2*z^2 = C0 + C1*q + C2*q^2,
 *   q^2 = 0x4015.
 *
 * Multiplication by the tiny q constants is synthesized with shifts/XORs so
 * this route removes two CLMAD instructions per S-box.  It deliberately
 * trades integer instructions and registers for CLMAD pressure; the A/B test
 * decides whether GA100 can profit from that trade.
 */
struct X7SmallProduct {
    U128 low;
    unsigned long long overflow;
};

__device__ __forceinline__
unsigned long long x7_xor3_64(
    unsigned long long a,
    unsigned long long b,
    unsigned long long c)
{
#if defined(NOID_X7_LAZY_LOP3)
    return square_xor3_lop3(a, b, c);
#else
    return a ^ b ^ c;
#endif
}

__device__ __forceinline__
unsigned long long x7_xor4_64(
    unsigned long long a,
    unsigned long long b,
    unsigned long long c,
    unsigned long long d)
{
    return x7_xor3_64(a, b, c) ^ d;
}

__device__ __forceinline__
X7SmallProduct x7_mul_q(U128 a)
{
    const unsigned long long low = x7_xor4_64(
        a.lo, a.lo << 1, a.lo << 2, a.lo << 7);
    const unsigned long long high = x7_xor4_64(
        a.hi, a.hi << 1, a.hi << 2, a.hi << 7) ^
        x7_xor3_64(a.lo >> 63, a.lo >> 62, a.lo >> 57);
    const unsigned long long overflow =
        (a.hi >> 63) ^ (a.hi >> 62) ^ (a.hi >> 57);
    return {{low, high}, overflow};
}

__device__ __forceinline__
X7SmallProduct x7_mul_q2(U128 a)
{
    /* q^2 = 1 + x^2 + x^4 + x^14. */
    const unsigned long long low = x7_xor4_64(
        a.lo, a.lo << 2, a.lo << 4, a.lo << 14);
    const unsigned long long high = x7_xor4_64(
        a.hi, a.hi << 2, a.hi << 4, a.hi << 14) ^
        x7_xor3_64(a.lo >> 62, a.lo >> 60, a.lo >> 50);
    const unsigned long long overflow =
        (a.hi >> 62) ^ (a.hi >> 60) ^ (a.hi >> 50);
    return {{low, high}, overflow};
}

__device__ __forceinline__
U128 x7_reduce_384_shift(U128 c0, U128 c1, U128 c2)
{
    const X7SmallProduct q1 = x7_mul_q(c1);
    const X7SmallProduct q2 = x7_mul_q2(c2);
    const unsigned long long overflow = q1.overflow ^ q2.overflow;
    const unsigned long long final_fold = x7_xor4_64(
        overflow,
        overflow << 1,
        overflow << 2,
        overflow << 7);
    return {
        c0.lo ^ q1.low.lo ^ q2.low.lo ^ final_fold,
        c0.hi ^ q1.low.hi ^ q2.low.hi
    };
}

__device__ __forceinline__
U128 x7_mul_256x128_reduce_shift(U128 a_lo, U128 a_hi, U128 b)
{
    U128 p0_lo, p0_hi, p1_lo, p1_hi;
    gf_product_scalar(a_lo, b, p0_lo, p0_hi);
    gf_product_scalar(a_hi, b, p1_lo, p1_hi);
    const U128 c0 = p0_lo;
    const U128 c1 = bxor(p0_hi, p1_lo);
    const U128 c2 = p1_hi;
    return x7_reduce_384_shift(c0, c1, c2);
}

__device__ __forceinline__
U128 sbox_x7_lazy_x3(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const U128 x4 = square_flat_clmad(x2);
    U128 x3_lo, x3_hi;
    gf_product_scalar(x, x2, x3_lo, x3_hi);
    return x7_mul_256x128_reduce_shift(x3_lo, x3_hi, x4);
}

__device__ __forceinline__
U128 sbox_x7(U128 x)
{
#if defined(NOID_SBOX_FUSE_VARIANT) && NOID_SBOX_FUSE_VARIANT == 1
    return sbox_x7_branch_fused<false>(x);
#elif defined(NOID_SBOX_FUSE_VARIANT) && NOID_SBOX_FUSE_VARIANT == 2
    return sbox_x7_branch_fused<true>(x);
#elif defined(NOID_SBOX_FUSE_VARIANT) && \
      (NOID_SBOX_FUSE_VARIANT == 3 || NOID_SBOX_FUSE_VARIANT == 4)
    return sbox_x7_lazy_x3(x);
#elif defined(NOID_SBOX_FUSE_VARIANT) && NOID_SBOX_FUSE_VARIANT != 0
#error "Unsupported NOID_SBOX_FUSE_VARIANT"
#elif defined(NOID_SQUARE_CLMAD)
    return sbox_x7_clmad(x);
#else
    return sbox_x7_spread(x);
#endif
}

/*
 * X^7 helper when Frobenius powers x^2 and x^4 are already available.
 * Used only by the first nonce-dependent full-round sharing experiment.
 */
__device__ __forceinline__
U128 sbox_x7_from_powers(U128 x, U128 x2, U128 x4)
{
    const U128 x3 = gf_mul(x, x2);
    return gf_mul(x3, x4);
}

/*
 * Full-round S-box ILP experiments.  Full Poseidon rounds have four
 * independent X^7 evaluations before the MDS.  The production loop presents
 * them one at a time; these helpers explicitly stage two independent chains
 * so ptxas can interleave CLMAD dependency chains without duplicating an
 * entire nonce/Poseidon state.
 */
__device__ __forceinline__
void sbox_x7_pair_scalar(U128 &a, U128 &b)
{
    const U128 a2 = square_flat_clmad(a);
    const U128 b2 = square_flat_clmad(b);
    const U128 a4 = square_flat_clmad(a2);
    const U128 b4 = square_flat_clmad(b2);
    const U128 a6 = gf_mul(a, a2);
    const U128 b6 = gf_mul(b, b2);
    a = gf_mul(a6, a4);
    b = gf_mul(b6, b4);
}

__device__ __forceinline__
void sbox_x7_pair_batch(U128 &a, U128 &b)
{
    const U128 a2 = square_flat_clmad(a);
    const U128 b2 = square_flat_clmad(b);
    const U128 a4 = square_flat_clmad(a2);
    const U128 b4 = square_flat_clmad(b2);

    const U128 x_in[2] = {a, b};
    const U128 x2_in[2] = {a2, b2};
    U128 x6[2];
    gf_mul_batch<2>(x_in, x2_in, x6);

    const U128 x4_in[2] = {a4, b4};
    U128 x7[2];
    gf_mul_batch<2>(x6, x4_in, x7);
    a = x7[0];
    b = x7[1];
}

__device__ __forceinline__
void apply_full_round_sboxes(U128 s[4], int r)
{
#if !defined(NOID_FULL_SBOX_ILP) || NOID_FULL_SBOX_ILP == 0
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        s[i] = bxor(s[i], NOID_RC[i][r]);
        s[i] = sbox_x7(s[i]);
    }
#elif NOID_FULL_SBOX_ILP == 1
    s[0] = bxor(s[0], NOID_RC[0][r]);
    s[1] = bxor(s[1], NOID_RC[1][r]);
    sbox_x7_pair_scalar(s[0], s[1]);
    s[2] = bxor(s[2], NOID_RC[2][r]);
    s[3] = bxor(s[3], NOID_RC[3][r]);
    sbox_x7_pair_scalar(s[2], s[3]);
#elif NOID_FULL_SBOX_ILP == 2
    s[0] = bxor(s[0], NOID_RC[0][r]);
    s[1] = bxor(s[1], NOID_RC[1][r]);
    sbox_x7_pair_batch(s[0], s[1]);
    s[2] = bxor(s[2], NOID_RC[2][r]);
    s[3] = bxor(s[3], NOID_RC[3][r]);
    sbox_x7_pair_batch(s[2], s[3]);
#else
#error "Unsupported NOID_FULL_SBOX_ILP"
#endif
}

__device__ __forceinline__
void apply_mds_full_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_FULL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

__device__ __forceinline__
void apply_mds_partial_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_PARTIAL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

/*
 * Exact Poseidon2 M4 factorization for the external/full linear layer.
 *
 * Tower-basis matrix:
 *   [5 7 1 3]
 *   [4 6 1 1]
 *   [1 3 5 7]
 *   [1 1 4 6]
 *
 * In characteristic two, coefficient addition is XOR.  The circuit below
 * uses only four general GF(2^128) multiplications (two by tower element 2,
 * two by tower element 4), versus ten in the generic matrix multiply.
 * The constants below are the exact flat/GCM-basis images used by v1.0.3.
 */
__device__ __forceinline__
void apply_mds_full_factorized(U128 s[4])
{
    const U128 MUL2{
        0x7573da4a5f7710edULL,
        0x3d5bd35c94646a24ULL
    };

    const U128 MUL4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(gf_mul(MUL2, b), t1);
    const U128 t3 = bxor(gf_mul(MUL2, d), t0);
    const U128 t4 = bxor(gf_mul(MUL4, t1), t3);
    const U128 t5 = bxor(gf_mul(MUL4, t0), t2);

    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

/*
 * Internal/partial MDS has diag(c_i) with ones everywhere off diagonal.
 * sum + (c_i + 1)*s_i is algebraically identical and keeps the same four
 * GF multiplications while substantially reducing XOR/matrix overhead.
 */
__device__ __forceinline__
void apply_mds_partial_scalar(U128 s[4])
{
    const U128 D0{
        0xfd8ee716e990cf15ULL,
        0x486fb01f93aa169aULL
    };
    const U128 D1{
        0x3e1b361e8a1a5bbeULL,
        0x86b6a57216f08319ULL
    };
    const U128 D2{
        0x2924ed9040490831ULL,
        0xb2ef6c31981e3158ULL
    };
    const U128 D3{
        0x84cb11891ab51a3dULL,
        0xff829109128b0bd8ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 m0 = gf_mul(D0, a);
    const U128 m1 = gf_mul(D1, b);
    const U128 m2 = gf_mul(D2, c);
    const U128 m3 = gf_mul(D3, d);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_prod2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 factors01[2] = {D0, D1};
    const U128 states01[2] = {a, b};
    U128 lo01[2], hi01[2];
    gf_product_batch<2>(factors01, states01, lo01, hi01);
    const U128 m0 = reduce_gcm_256_r4_topshift(hi01[0], lo01[0]);
    const U128 m1 = reduce_gcm_256_r4_topshift(hi01[1], lo01[1]);

    const U128 factors23[2] = {D2, D3};
    const U128 states23[2] = {c, d};
    U128 lo23[2], hi23[2];
    gf_product_batch<2>(factors23, states23, lo23, hi23);
    const U128 m2 = reduce_gcm_256_r4_topshift(hi23[0], lo23[0]);
    const U128 m3 = reduce_gcm_256_r4_topshift(hi23[1], lo23[1]);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_red2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    U128 lo01[2], hi01[2], m01[2];
    gf_product_scalar(D0, a, lo01[0], hi01[0]);
    gf_product_scalar(D1, b, lo01[1], hi01[1]);
    reduce_r4top_batch<2>(hi01, lo01, m01);

    U128 lo23[2], hi23[2], m23[2];
    gf_product_scalar(D2, c, lo23[0], hi23[0]);
    gf_product_scalar(D3, d, lo23[1], hi23[1]);
    reduce_r4top_batch<2>(hi23, lo23, m23);

    s[0] = bxor(sum, m01[0]);
    s[1] = bxor(sum, m01[1]);
    s[2] = bxor(sum, m23[0]);
    s[3] = bxor(sum, m23[1]);
}

__device__ __forceinline__
void apply_mds_partial_pair2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 factors01[2] = {D0, D1};
    const U128 states01[2] = {a, b};
    U128 m01[2];
    gf_mul_batch<2>(factors01, states01, m01);

    const U128 factors23[2] = {D2, D3};
    const U128 states23[2] = {c, d};
    U128 m23[2];
    gf_mul_batch<2>(factors23, states23, m23);

    s[0] = bxor(sum, m01[0]);
    s[1] = bxor(sum, m01[1]);
    s[2] = bxor(sum, m23[0]);
    s[3] = bxor(sum, m23[1]);
}

__device__ __forceinline__
void apply_mds_partial_quad4(U128 s[4])
{
    const U128 factors[4] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };
    const U128 states[4] = {s[0], s[1], s[2], s[3]};
    const U128 sum = bxor(bxor(states[0], states[1]), bxor(states[2], states[3]));
    U128 products[4];
    gf_mul_batch<4>(factors, states, products);
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = bxor(sum, products[i]);
}

#ifdef NOID_MDS_FACTORIZED
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    apply_mds_full_factorized(s);
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
#if !defined(NOID_PARTIAL_ILP) || NOID_PARTIAL_ILP == 0
    apply_mds_partial_scalar(s);
#elif NOID_PARTIAL_ILP == 1
    apply_mds_partial_prod2(s);
#elif NOID_PARTIAL_ILP == 2
    apply_mds_partial_red2(s);
#elif NOID_PARTIAL_ILP == 3
    apply_mds_partial_pair2(s);
#elif NOID_PARTIAL_ILP == 4
    apply_mds_partial_quad4(s);
#else
#error "Unsupported NOID_PARTIAL_ILP"
#endif
}
#else
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    apply_mds_full_generic(s);
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
    apply_mds_partial_generic(s);
}
#endif


#ifdef NOID_MDS_LUT4
/*
 * Nibble lookup path for the four fixed multipliers in the 58 partial
 * Poseidon2 rounds.  Each fixed multiplier owns 32 positional nibble rows,
 * each with 16 reduced GF(2^128) products.  The table is copied once per
 * mining block from constant memory into shared memory, then reused by all
 * threads for all three nonce-dependent permutations.
 */
__device__ __forceinline__
U128 gf_mul_const_lut4_shared(
    U128 x,
    const U128 *table)
{
    U128 out{0ULL, 0ULL};

    #pragma unroll
    for (int pos = 0; pos < 16; ++pos) {
        const unsigned nib =
            (unsigned)((x.lo >> (pos * 4)) & 0xFULL);
        const U128 v = table[pos * 16 + nib];
        out.lo ^= v.lo;
        out.hi ^= v.hi;
    }

    #pragma unroll
    for (int pos = 0; pos < 16; ++pos) {
        const unsigned nib =
            (unsigned)((x.hi >> (pos * 4)) & 0xFULL);
        const U128 v = table[(pos + 16) * 16 + nib];
        out.lo ^= v.lo;
        out.hi ^= v.hi;
    }

    return out;
}

__device__ __forceinline__
void apply_mds_partial_lut4(
    U128 s[4],
    const U128 *lut)
{
    constexpr int STRIDE = 32 * 16;

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];
    const U128 sum =
        bxor(bxor(a, b), bxor(c, d));

    const U128 m0 =
        gf_mul_const_lut4_shared(a, lut + 0 * STRIDE);
    const U128 m1 =
        gf_mul_const_lut4_shared(b, lut + 1 * STRIDE);
    const U128 m2 =
        gf_mul_const_lut4_shared(c, lut + 2 * STRIDE);
    const U128 m3 =
        gf_mul_const_lut4_shared(d, lut + 3 * STRIDE);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void poseidon_permute_lut4(
    U128 s[4],
    const U128 *lut)
{
    // The full linear layer remains the proven factorized CLMAD path.
    // Only the dominant 58 partial-round fixed multiplications use LUT4.
    apply_mds_full(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            apply_full_round_sboxes(s, r);
            apply_mds_full(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);
            apply_mds_partial_lut4(s, lut);
        }
    }
}
#endif

__device__ __forceinline__
void poseidon_permute(U128 s[4])
{
    apply_mds_full(s);

#ifdef NOID_POSEIDON_PHASE_SPLIT
    // Poseidon2b has a fixed round schedule: 4 full + 58 partial + 4 full.
    // Splitting the phases removes the per-round full/partial predicate and
    // makes the full-round indices compile-time constants.
    #pragma unroll
    for (int r = 0; r < NOID_F_ROUNDS / 2; ++r) {
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            s[i] = bxor(s[i], NOID_RC[i][r]);
            s[i] = sbox_x7(s[i]);
        }
        apply_mds_full(s);
    }

    #if !defined(NOID_PARTIAL_ROUND_UNROLL) || NOID_PARTIAL_ROUND_UNROLL == 1
    #pragma unroll 1
    #elif NOID_PARTIAL_ROUND_UNROLL == 2
    #pragma unroll 2
    #elif NOID_PARTIAL_ROUND_UNROLL == 4
    #pragma unroll 4
    #elif NOID_PARTIAL_ROUND_UNROLL == 8
    #pragma unroll 8
    #else
    #error "Unsupported NOID_PARTIAL_ROUND_UNROLL"
    #endif
    for (int r = NOID_F_ROUNDS / 2;
         r < NOID_F_ROUNDS / 2 + NOID_P_ROUNDS; ++r) {
        s[0] = bxor(s[0], NOID_RC[0][r]);
        s[0] = sbox_x7(s[0]);
        apply_mds_partial(s);
    }

    #pragma unroll
    for (int r = NOID_F_ROUNDS / 2 + NOID_P_ROUNDS;
         r < NOID_N_ROUNDS; ++r) {
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            s[i] = bxor(s[i], NOID_RC[i][r]);
            s[i] = sbox_x7(s[i]);
        }
        apply_mds_full(s);
    }
#else
    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            apply_full_round_sboxes(s, r);
            apply_mds_full(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);
            apply_mds_partial(s);
        }
    }
#endif
}



/*
 * Mining-only entry points for a state whose initial external MDS has already
 * been applied.  Variant 2 also accepts round-0 constants pre-folded into the
 * state.  This lets the first nonce-dependent sponge permutation hoist the
 * job-constant portion of the initial MDS into prepare_job().
 */
__device__ __forceinline__
void poseidon_permute_after_initial_mds(U128 s[4])
{
    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            apply_full_round_sboxes(s, r);
            apply_mds_full(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);
            apply_mds_partial(s);
        }
    }
}

__device__ __forceinline__
void poseidon_permute_after_initial_mds_rc0(U128 s[4])
{
    /* Round 0 RC values are already present in s[]. */
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = sbox_x7(s[i]);
    apply_mds_full(s);

    #pragma unroll 1
    for (int r = 1; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            apply_full_round_sboxes(s, r);
            apply_mds_full(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);
            apply_mds_partial(s);
        }
    }
}

/*
 * Two independent Poseidon states advanced in lockstep.  This changes no
 * arithmetic; it only exposes independent CLMAD dependency chains to ptxas
 * so GA100 can issue useful work while the other state is waiting.
 */
__device__ __forceinline__
void poseidon_permute_dual(U128 a[4], U128 b[4])
{
    apply_mds_full(a);
    apply_mds_full(b);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                a[i] = bxor(a[i], NOID_RC[i][r]);
                b[i] = bxor(b[i], NOID_RC[i][r]);
                a[i] = sbox_x7(a[i]);
                b[i] = sbox_x7(b[i]);
            }
            apply_mds_full(a);
            apply_mds_full(b);
        } else {
            a[0] = bxor(a[0], NOID_RC[0][r]);
            b[0] = bxor(b[0], NOID_RC[0][r]);
            a[0] = sbox_x7(a[0]);
            b[0] = sbox_x7(b[0]);
            apply_mds_partial(a);
            apply_mds_partial(b);
        }
    }
}
