#include <cstdio>
#include <cuda_runtime.h>
struct U128 { unsigned long long lo, hi; };
#include "src/noid_cuda_tables.h"
#include "src/noid_runtime_params.h"
#include "src/noid_cuda_math.cuh"
#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); return 2;} } while(0)
__device__ __forceinline__ bool neq(U128 a,U128 b){return a.lo!=b.lo||a.hi!=b.hi;}
__global__ void oracle(unsigned *err){
    unsigned tid=(unsigned)(blockIdx.x*blockDim.x+threadIdx.x);
    if(tid >= (1U<<23)) return;
    U128 base{0x1234567880000000ULL,0xfedcba9876543210ULL};
    U128 n{base.lo ^ (unsigned long long)tid, base.hi};
    U128 b2=square_flat_clmad(base), b4=square_flat_clmad(b2);
    U128 t2=noid_tid_square2(tid);
    U128 t4a=noid_tid_square4_from_square2(t2);
    U128 t4b=noid_tid_square4_direct(tid);
    U128 n2a=bxor(b2,t2), n4a=bxor(b4,t4a), n4b=bxor(b4,t4b);
    U128 ref2=square_flat_clmad(n), ref4=square_flat_clmad(ref2);
    if(neq(n2a,ref2)) atomicAdd(&err[0],1U);
    if(neq(n4a,ref4)) atomicAdd(&err[1],1U);
    if(neq(n4b,ref4)) atomicAdd(&err[2],1U);
}
int main(){unsigned*d=nullptr,h[3]={};CUDA_OK(cudaMalloc(&d,sizeof(h)));CUDA_OK(cudaMemset(d,0,sizeof(h)));oracle<<<8192,256>>>(d);CUDA_OK(cudaGetLastError());CUDA_OK(cudaDeviceSynchronize());CUDA_OK(cudaMemcpy(h,d,sizeof(h),cudaMemcpyDeviceToHost));cudaFree(d);printf("LINEAR NONCE SQUARE ORACLE: %s (n2=%u n4spread=%u n4direct=%u)\n",(h[0]||h[1]||h[2])?"FAIL":"PASS",h[0],h[1],h[2]);return(h[0]||h[1]||h[2])?1:0;}
