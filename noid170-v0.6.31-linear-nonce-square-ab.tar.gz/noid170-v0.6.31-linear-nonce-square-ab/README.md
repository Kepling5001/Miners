# NOID170 v0.6.31 — share4 linear-nonce square A/B

Miner-only experiment based on confirmed v0.6.29 `share4`.

The confirmed winner still computes `nonce^2` and `nonce^4` with two full GF(2^128) square operations per hash. This package reserves a power-of-two nonce window per launch, aligns the batch base to that window, and enumerates `nonce = base XOR tid` (numerically identical to `base + tid` inside the aligned window). Since Frobenius squaring is GF(2)-linear, `nonce^2 = base^2 XOR tid^2` and `nonce^4 = base^4 XOR tid^4`. The batch-base powers are computed once on the host; only the small thread-id powers remain per thread.

Variants:
- `prod`: exact installed production daemon copied at build time.
- `share4`: exact confirmed share4 path.
- `aligned_clmad`: aligned nonce-window control, but still uses full CLMAD nonce squares.
- `linear_spread`: derives tid^2/tid^4 with spread32 bit interleaving.
- `linear_direct4`: derives tid^2 with spread32 and tid^4 directly with 4-way spreading.

No variant installs or replaces the HiveOS miner.
