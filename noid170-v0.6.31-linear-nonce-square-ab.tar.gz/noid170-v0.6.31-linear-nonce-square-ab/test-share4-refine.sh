#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in prod share4 share4_stream share4_interleave share4_stream_interleave; do [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }; done
echo "===== GPU CORRECTNESS ORACLES ====="; for v in share4 share4_stream share4_interleave share4_stream_interleave; do echo "--- GF/Poseidon $v ---"; "$ROOT/bin/test_gf_$v"; done
echo "--- first-round share4 equivalence oracle ---"; "$ROOT/bin/test_first_square_share"
echo; echo "===== STATIC SASS AUDIT ====="; python3 "$ROOT/sass-audit.py"
echo; python3 "$ROOT/benchmark_share4_refine.py"
echo; python3 "$ROOT/test-persistent.py"
echo; echo "Paste SHARE4 REFINEMENT ORACLE, STATIC SASS AUDIT, FINAL SHARE4 PRODUCTION-CONFIRM RANKING, and SHARE4 REFINEMENT WINNER PROTOCOL back into chat."; echo "This experiment did NOT install or replace the HiveOS miner. Restart normal mining when finished: miner start"
