#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in baseline fused; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done

echo "===== GPU CORRECTNESS ORACLES ====="
for v in baseline fused; do
  echo "--- $v ---"
  "$ROOT/bin/test_gf_$v"
done

echo
python3 "$ROOT/benchmark_clean.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste FINAL CLEAN FUSED-RED2 RANKING and"
echo "CLEAN FUSED-RED2 WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
