#!/usr/bin/env python3
import random
MASK=(1<<64)-1

def clmul64(a,b):
    z=0
    for i in range(64):
        if (b>>i)&1: z ^= a<<i
    return z & ((1<<128)-1)

def split(z): return z&MASK,(z>>64)&MASK

def original(a0,a1,b0,b1):
    p0l,p0h=split(clmul64(a0,b0))
    p1l,p1h=split(clmul64(a1,b1))
    pml,pmh=split(clmul64(a0^a1,b0^b1))
    pml ^= p0l ^ p1l
    pmh ^= p0h ^ p1h
    return (p0l, p0h^pml, p1l^pmh, p1h)

def fused(a0,a1,b0,b1):
    p0l,p0h=split(clmul64(a0,b0))
    p1l,p1h=split(clmul64(a1,b1))
    ml,mh=split(clmul64(a0^a1,b0^b1))
    ml ^= p0l ^ p1l ^ p0h
    mh ^= p0h ^ p1h ^ p1l
    return (p0l,ml,mh,p1h)

vectors=[(0,0,0,0),(MASK,MASK,MASK,MASK),(1,0,1,0),(0,1,0,1)]
r=random.Random(0x1700618)
for _ in range(20000):
    vectors.append(tuple(r.getrandbits(64) for _ in range(4)))
for i,v in enumerate(vectors):
    if original(*v)!=fused(*v):
        raise SystemExit(f'FUSED PRODUCT MODEL: FAIL vector={i}')
print(f'FUSED PRODUCT MODEL: PASS vectors={len(vectors)}')
