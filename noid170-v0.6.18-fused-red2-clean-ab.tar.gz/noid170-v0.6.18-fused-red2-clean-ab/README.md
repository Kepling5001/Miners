# NOID170 v0.6.18 clean fused-red2 A/B

Purpose: confirm the promising v0.6.17 fused Karatsuba result on the exact
proven v0.6.15 red2/512 baseline without the extra experimental helpers that
perturbed ptxas code generation.

## Baseline

`src_baseline/` is byte-for-byte the source tree from the v0.6.15 partial512
package. It is compiled with the exact red2/512 flags:

- NOID_PARTIAL_ILP=2 (red2)
- 512 threads
- 128 grid blocks/SM parameter
- r4top reduction
- r2lop3 square reduction
- factorized full MDS
- production four-stage x^7
- nonvolatile paired CLMAD scheduling
- 2 ms CUDA event polling

`verify-clean-source.py` checks the baseline against a SHA-256 manifest before
nvcc runs.

## Fused candidate

`src_fused/` is an identical copy except for one surgical change in
`noid_cuda_math.cuh`: the four partial-MDS calls in `apply_mds_partial_red2`
use `gf_product_fused_red2`.

The fused product still uses the same six CLMAD operations as the original
Karatsuba product. It folds p1/cross-limb XORs into the CLMAD accumulator to
shorten the dependency graph and temporary lifetimes. The v0.6.17 experiment
showed 40 registers instead of 42 and +1.25% against its matched baseline, but
that experiment's baseline itself was slower than the proven v0.6.15 kernel.
This package exists to resolve that ambiguity.

`EXPECTED_MATH_DIFF.txt` records the complete source difference.

## Correctness gates

Before benchmarking:

1. clean baseline source SHA check
2. existing offline reduction/square/fused-X7 model checks
3. fused Karatsuba algebra check (20,004 vectors)
4. GPU primitive/Poseidon oracle for baseline
5. GPU primitive/Poseidon oracle for fused

Only then are baseline and fused benchmarked forward and reverse. Default is
14 STAT samples per run, with warmup discarded. The measured winner must then
produce a live accepted share.

This package never installs or replaces the HiveOS miner.

## Run

```bash
cd /home/user/noid170-v0.6.18-fused-red2-clean-ab
chmod +x build-on-rig.sh test-clean.sh test-persistent.sh \
  verify-clean-source.py verify-fused-product.py
./build-on-rig.sh

miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-clean.sh
```

Afterward:

```bash
miner start
```

Paste back `FINAL CLEAN FUSED-RED2 RANKING` and
`CLEAN FUSED-RED2 WINNER PROTOCOL: PASS`.
