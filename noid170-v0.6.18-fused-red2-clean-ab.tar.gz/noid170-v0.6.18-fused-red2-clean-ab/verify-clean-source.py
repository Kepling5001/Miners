#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parent
baseline=ROOT/'src_baseline'
fused=ROOT/'src_fused'
manifest=json.loads((ROOT/'baseline_manifest.json').read_text())

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for rel, expected in manifest.items():
    p=baseline/rel
    if not p.is_file() or sha(p)!=expected:
        raise SystemExit(f'CLEAN SOURCE CHECK: FAIL baseline mismatch: {rel}')
base_files=sorted(p.relative_to(baseline).as_posix() for p in baseline.rglob('*') if p.is_file())
fused_files=sorted(p.relative_to(fused).as_posix() for p in fused.rglob('*') if p.is_file())
if base_files != fused_files:
    raise SystemExit('CLEAN SOURCE CHECK: FAIL source file sets differ')
for rel in base_files:
    if rel=='noid_cuda_math.cuh':
        continue
    if sha(baseline/rel)!=sha(fused/rel):
        raise SystemExit(f'CLEAN SOURCE CHECK: FAIL unexpected fused difference: {rel}')
diff_text=(ROOT/'EXPECTED_MATH_DIFF.txt').read_text()
if 'gf_product_fused_red2' not in diff_text or diff_text.count('gf_product_fused_red2') < 5:
    raise SystemExit('CLEAN SOURCE CHECK: FAIL expected math diff missing')
print(f'CLEAN SOURCE CHECK: PASS baseline_files={len(base_files)} fused_only_change=noid_cuda_math.cuh')
