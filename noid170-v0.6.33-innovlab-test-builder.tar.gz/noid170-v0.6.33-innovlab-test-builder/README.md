# NOID170 v0.6.33-test1 — InnovLab Stratum functional builder

This is an isolated test branch built from the confirmed v0.6.32 production checkpoint.
It does **not** install or replace the running HiveOS miner when built.

## What stays unchanged

The Aria HTTP/HTTPS path is carried verbatim from v0.6.32:

- `noid170_aria.py` SHA256 `05a56aab90341ea1ab076e02e54d32a42043b7e2ebae9f75fc787d7f739b06af`
- production share4 daemon SHA256 `5e0c6bf353ca09f808193284358ce71a81a254b00a613f5010e528f2a24fd2bc`
- warmup worker SHA256 `40c70611a2a7a2783044a2fbeeb051214882ef95e2836bba6301e2b8dfeb23a7`

`h-run.sh` selects the original Aria path for `http://` and `https://` URLs.

## New InnovLab path

For `stratum+ssl://` URLs, `h-run.sh` selects `noid170_stratum.py` and a separately compiled namespace-aware CUDA daemon.

Confirmed live protocol:

- TLS with normal WebPKI chain + exact hostname verification
- protocol `parano1d-stratum-v1`
- `mining.subscribe ["NOID170/0.6.33"]`
- `mining.authorize ["wallet.worker", "x"]`
- `nonce_bits = 64`
- `session_namespace` / `nonce_prefix_hex` = 8 bytes
- canonical 16-byte little-endian nonce layout:
  - bytes 0..7: miner-controlled `uint64` counter, little-endian
  - bytes 8..15: 8-byte session namespace exactly as supplied
- submit layout:
  - `mining.submit [job_id, nonce_hex, work_domain_id]`
- `clean=true` replaces old work
- `mining.pause` is honored by switching the persistent GPU daemon to a zero target until a new valid notify arrives
- `expires_in_seconds` is enforced before submission

## Namespace-aware CUDA path

The v0.6.32 kernel internally hashes the nonce in the flat GF(2^128) basis, while the pool constrains the canonical/tower nonce high 64 bits.

The test daemon preserves the existing share4/red2 Poseidon arithmetic and converts the varying lower 64-bit counter with a generated GF(2)-linear nibble LUT. The fixed upper 64-bit session namespace is transformed once per job. Successful candidates are emitted directly as:

`counter_le_8_bytes || session_namespace_8_bytes`

The original Aria daemon is not modified.

This is a **functional test branch**. The namespace mapping adds work before the existing Poseidon kernel, so its hashrate must be measured on CMP170HX before any production promotion.

## Build on OctominerTEST

```bash
cd /home/user
tar -xzf noid170-v0.6.33-innovlab-test-builder.tar.gz
cd noid170-v0.6.33-innovlab-test-builder
./build-test.sh
```

The builder:

1. verifies the exact v0.6.32 Aria checkpoint hashes,
2. compiles `noid_live_job_daemon_ns` with CUDA 13.3 and the same share4/red2 flags,
3. runs a GPU oracle comparing the fast namespace LUT mapping against the original 128-bit tower→flat transform,
4. runs a `JOBNS` daemon protocol smoke test,
5. checks Python and shell syntax,
6. packages `dist/noid170-0.6.33-test1.tar.gz`.

It does not install the package.

## Recommended first live test

Run the built archive from an extracted directory with `NOID_GPU_COUNT=1` rather than replacing `/hive/miners/custom/noid170`. See `RUN-TEST.txt`.

Production gate is a genuine GPU-found InnovLab `ACCEPTED` share with zero local namespace mismatches, followed by a rate comparison against the 160.9 MH/s v0.6.32 share4 checkpoint.
