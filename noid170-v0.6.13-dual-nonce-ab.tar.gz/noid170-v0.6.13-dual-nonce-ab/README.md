# NOID170 v0.6.13 dual-nonce ILP A/B

This experiment follows the v0.6.12 LUT4 result, where LUT4 lost ~87.6% because the proven GA100 CLMAD field multiplication is dramatically cheaper than dozens of data-dependent shared-memory lookups.

The production math is unchanged. The experimental path gives each CUDA thread two independent nonce states and advances the two Poseidon states round-for-round. The goal is to expose independent CLMAD dependency chains so ptxas/GA100 can hide arithmetic latency with instruction-level parallelism.

Variants:
- current256 / current384 / current512 / current768: single nonce per thread launch sweep
- dual256 / dual384 / dual512 / dual768: two nonces per thread, lockstep Poseidon

The grid sizes keep hashes per batch approximately equal. Benchmarking uses balanced forward/reverse ordering, warm-up discard, kernel + wall MH/s, ptxas register/spill reporting, a GPU oracle comparing dual Poseidon against two scalar Poseidon calls, and a live accepted-share protocol test of the measured winner.

It does not install or replace the HiveOS miner.

Run:
```bash
cd /home/user/noid170-v0.6.13-dual-nonce-ab
chmod +x build-on-rig.sh test-dual.sh test-persistent.sh benchmark_dual.py
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-dual.sh
```
