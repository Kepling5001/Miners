#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 { unsigned long long lo; unsigned long long hi; };
#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); exit(1);} } while(0)

__device__ __forceinline__ unsigned long long mix64_dual(unsigned long long x) {
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL;
    x ^= x >> 31; return x;
}
__device__ __forceinline__ bool neq(U128 a,U128 b){return a.lo!=b.lo||a.hi!=b.hi;}

__global__ void dual_oracle(unsigned int *errors) {
    unsigned t = blockIdx.x * blockDim.x + threadIdx.x;
    if (t >= 256) return;
    U128 a[4], b[4], ar[4], br[4];
    #pragma unroll
    for (int i=0;i<4;++i) {
        unsigned long long z0 = mix64_dual(0x123456789abcdef0ULL ^ ((unsigned long long)t<<8) ^ i);
        unsigned long long z1 = mix64_dual(0xfedcba9876543210ULL ^ ((unsigned long long)t<<9) ^ (i*17));
        a[i] = {z0, mix64_dual(z0 ^ 0x9e3779b97f4a7c15ULL)};
        b[i] = {z1, mix64_dual(z1 ^ 0xd1b54a32d192ed03ULL)};
        ar[i]=a[i]; br[i]=b[i];
    }
    poseidon_permute(ar); poseidon_permute(br);
    poseidon_permute_dual(a,b);
    unsigned local=0;
    #pragma unroll
    for(int i=0;i<4;++i){ local += neq(a[i],ar[i]); local += neq(b[i],br[i]); }
    if(local) atomicAdd(errors,local);
}

int main(){
    unsigned int *d=nullptr, h=0; CUDA_OK(cudaMalloc(&d,sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d,0,sizeof(unsigned int)));
    dual_oracle<<<1,256>>>(d); CUDA_OK(cudaGetLastError()); CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(&h,d,sizeof(h),cudaMemcpyDeviceToHost)); CUDA_OK(cudaFree(d));
    if(h){ printf("DUAL NONCE GPU ORACLE: FAIL errors=%u\n",h); return 2; }
    printf("DUAL NONCE GPU ORACLE: PASS pairs=256 permutations=512\n"); return 0;
}
