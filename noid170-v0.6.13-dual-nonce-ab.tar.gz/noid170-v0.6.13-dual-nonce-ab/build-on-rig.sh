#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1 -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000 -Xptxas=-v
)

build_daemon() {
  local name="$1" threads="$2" blocks_per_sm="$3" lanes="$4"
  local extra=()
  if [[ "$lanes" == "2" ]]; then extra+=(-DNOID_DUAL_NONCE_ILP=1); fi
  echo
  echo "===== BUILD $name | T=$threads GRID-B/SM=$blocks_per_sm NONCES/THREAD=$lanes ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_THREADS="$threads" -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" \
    2>&1 | tee "$BIN/build_$name.log"
  chmod 755 "$BIN/noid_daemon_$name"
}

python3 "$ROOT/offline_verify.py"

# Single-nonce launch sweep around the current 512-thread winner.
build_daemon current256 256 256 1
build_daemon current384 384 171 1
build_daemon current512 512 128 1
build_daemon current768 768 85 1

# Same exact PoW arithmetic, but each CUDA thread carries two independent
# nonce states and advances them round-for-round to expose CLMAD ILP.
build_daemon dual256 256 128 2
build_daemon dual384 384 85 2
build_daemon dual512 512 64 2
build_daemon dual768 768 43 2

echo
echo "===== BUILD CORRECTNESS ORACLES ====="
"$NVCC" "${COMMON[@]}" -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 \
  "$ROOT/test_gf_primitives.cu" -o "$BIN/test_gf_current" \
  2>&1 | tee "$BIN/build_oracle_current.log"
"$NVCC" "${COMMON[@]}" -DNOID_DUAL_NONCE_ILP=1 \
  -DNOID_THREADS=256 -DNOID_BLOCKS_PER_SM=128 \
  "$ROOT/test_dual.cu" -o "$BIN/test_dual" \
  2>&1 | tee "$BIN/build_oracle_dual.log"
chmod 755 "$BIN/test_gf_current" "$BIN/test_dual"

python3 -m py_compile "$ROOT/benchmark_dual.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-dual.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_*
echo
echo "Next:"
echo "  miner stop"
echo "  export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'"
echo "  ./test-dual.sh"
