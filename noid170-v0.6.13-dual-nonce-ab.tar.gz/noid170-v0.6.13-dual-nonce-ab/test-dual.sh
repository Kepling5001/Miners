#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in current256 current384 current512 current768 dual256 dual384 dual512 dual768; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done

echo "===== GPU CORRECTNESS ORACLES ====="
"$ROOT/bin/test_gf_current"
"$ROOT/bin/test_dual"

echo
python3 "$ROOT/benchmark_dual.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste the complete FINAL DUAL-NONCE ILP RANKING"
echo "and DUAL-NONCE WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
