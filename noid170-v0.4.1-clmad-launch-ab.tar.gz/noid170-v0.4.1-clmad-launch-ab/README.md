# NOID170 v0.4.1 CLMAD launch/register A/B test

This test repeats launch-geometry tuning after the CLMAD squaring rewrite.
It does not replace the installed HiveOS miner.

The matrix contains 12 CLMAD binaries:

- 256, 512, and 1024 threads per block
- native register allocation and caps of 40, 36, and 32 registers

Every variant schedules exactly 32,768 threads per SM per batch. On the
70-SM CMP 170HX this is 2,293,760 hashes, matching the current production
configuration. Each variant is tested twice in opposite orders. The first
two status samples of every run are discarded as warmup.

## Run on the test rig

```bash
tar -xzf noid170-v0.4.1-clmad-launch-ab.tar.gz
cd noid170-v0.4.1-clmad-launch-ab
./build-launch-sweep.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-launch-sweep.sh
```

The build output and final ranking report actual registers, spill stores and
spill loads, kernel MH/s, wall MH/s, and gain versus the current
1024-thread/native-register CLMAD configuration.
