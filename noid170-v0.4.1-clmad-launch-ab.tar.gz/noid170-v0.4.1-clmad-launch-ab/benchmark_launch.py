#!/usr/bin/env python3

import http.client
import json
import os
import queue
import re
import subprocess
import threading
import time
from collections import defaultdict
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
LOG = os.path.join(ROOT, "build-logs")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get(
    "NOID_RPC_URL",
    "https://pool.ariabrain.com/noid-rpc/",
)

THREADS = (256, 512, 1024)
CAPS = ("native", "40", "36", "32")
SPECS = [(threads, cap) for threads in THREADS for cap in CAPS]
BASELINE = (1024, "native")
SAMPLES_PER_RUN = 7
DISCARD_SAMPLES = 2
SCHEDULED_THREADS_PER_SM = 32768

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

for threads, cap in SPECS:
    binary = os.path.join(BIN, f"clmad_t{threads}_r{cap}")
    if not os.path.isfile(binary):
        raise SystemExit("ERROR: run ./build-launch-sweep.sh first")

u = urlsplit(URL)
Conn = (
    http.client.HTTPSConnection
    if u.scheme == "https"
    else http.client.HTTPConnection
)
path = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        })
        conn.request(
            "POST",
            path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-clmad-launch-bench/0.4.1",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(
                f"HTTP {response.status}: {data.decode(errors='replace')}"
            )
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def label_for(spec):
    threads, cap = spec
    return f"t{threads}/r{cap}"


def build_stats(spec):
    threads, cap = spec
    filename = os.path.join(LOG, f"clmad_t{threads}_r{cap}.log")
    try:
        text = open(filename, encoding="utf-8", errors="replace").read()
    except OSError:
        return ("?", "?")

    marker = re.search(
        r"Compiling entry function '[^']*mine_kernel[^']*'(?P<body>.*?)"
        r"Compiling entry function",
        text,
        flags=re.S,
    )
    body = marker.group("body") if marker else text
    regs = re.search(r"Used\s+(\d+)\s+registers", body)
    spills = re.search(
        r"(\d+) bytes spill stores, (\d+) bytes spill loads",
        body,
    )
    reg_text = regs.group(1) if regs else "?"
    if spills:
        spill_text = f"{spills.group(1)}/{spills.group(2)}"
    else:
        spill_text = "?"
    return reg_text, spill_text


def run_one(spec, job, run_number):
    threads, cap = spec
    label = label_for(spec)
    binary = os.path.join(BIN, f"clmad_t{threads}_r{cap}")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [binary, "--daemon", str(7100 + run_number)],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )
    events = queue.Queue()

    def reader():
        for line in proc.stderr:
            events.put(line.strip())

    threading.Thread(target=reader, daemon=True).start()

    def wait_for(prefix, timeout=10):
        end = time.time() + timeout
        while time.time() < end:
            try:
                line = events.get(timeout=0.5)
            except queue.Empty:
                continue
            if line.startswith(prefix):
                return line
        raise RuntimeError(f"{label}: timeout waiting for {prefix}")

    try:
        ready = wait_for("READY ")
        match = re.search(
            r"sm=(\d+) blocks=(\d+) threads=(\d+) hashes_per_batch=(\d+)",
            ready,
        )
        if not match:
            raise RuntimeError(f"{label}: malformed READY: {ready}")
        sms, blocks, actual_threads, hashes = map(int, match.groups())
        expected_blocks = sms * (SCHEDULED_THREADS_PER_SM // threads)
        expected_hashes = sms * SCHEDULED_THREADS_PER_SM
        if (blocks, actual_threads, hashes) != (
            expected_blocks,
            threads,
            expected_hashes,
        ):
            raise RuntimeError(f"{label}: unexpected launch geometry: {ready}")

        hard_target = (
            "01000000000000000000000000000000"
            "00000000000000000000000000000000"
        )
        proc.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard_target}\n")
        proc.stdin.flush()
        wait_for("JOBACK 1 ")

        samples = []
        while len(samples) < SAMPLES_PER_RUN:
            line = wait_for("STAT ", timeout=8)
            fields = line.split()
            samples.append((float(fields[1]), float(fields[5])))

        used = samples[DISCARD_SAMPLES:]
        kernel = sum(value[0] for value in used) / len(used)
        wall = sum(value[1] for value in used) / len(used)
        print(f"{label:14s} kernel={kernel:8.3f} MH/s  wall={wall:8.3f} MH/s")
        return kernel, wall
    finally:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n")
                proc.stdin.flush()
                proc.wait(timeout=3)
            except (BrokenPipeError, subprocess.TimeoutExpired):
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=3)


job = get_job()
results = defaultdict(list)
print("===== CLMAD LAUNCH/REGISTER A/B BENCHMARK | GPU0 =====")
print("height:", job["height"])
print("Each variant schedules the same number of hashes per batch.")

orders = (SPECS, tuple(reversed(SPECS)))
run_number = 0
for round_number, order in enumerate(orders, 1):
    print(f"\n===== ROUND {round_number} =====")
    for spec in order:
        run_number += 1
        results[spec].append(run_one(spec, job, run_number))

averages = {}
for spec, runs in results.items():
    averages[spec] = (
        sum(run[0] for run in runs) / len(runs),
        sum(run[1] for run in runs) / len(runs),
    )

baseline_kernel, baseline_wall = averages[BASELINE]
ranked = sorted(averages, key=lambda spec: averages[spec][1], reverse=True)

print("\n===== FINAL RANKING (SORTED BY WALL MH/s) =====")
print(
    f"{'rank':>4s}  {'variant':14s} {'regs':>4s} {'spill S/L':>9s} "
    f"{'kernel':>10s} {'wall':>10s} {'vs current':>10s}"
)
for rank, spec in enumerate(ranked, 1):
    kernel, wall = averages[spec]
    regs, spills = build_stats(spec)
    gain = (wall / baseline_wall - 1.0) * 100.0
    print(
        f"{rank:4d}  {label_for(spec):14s} {regs:>4s} {spills:>9s} "
        f"{kernel:10.3f} {wall:10.3f} {gain:+9.2f}%"
    )

winner = ranked[0]
winner_kernel, winner_wall = averages[winner]
print("\ncurrent: ", label_for(BASELINE), f"wall={baseline_wall:.3f} MH/s")
print("winner:  ", label_for(winner), f"wall={winner_wall:.3f} MH/s")
print(f"gain:     {(winner_wall / baseline_wall - 1.0) * 100.0:+.2f}%")
print(f"kernel:   {winner_kernel:.3f} MH/s")
