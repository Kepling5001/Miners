__device__ __forceinline__
U128 bxor(U128 a, U128 b)
{
    return {a.lo ^ b.lo, a.hi ^ b.hi};
}

__device__ __forceinline__
bool nonzero(U128 a)
{
    return (a.lo | a.hi) != 0ULL;
}

/*
 * Correctness-first GF(2^128) multiplication.
 *
 * Flat/GCM basis polynomial:
 *     x^128 + x^7 + x^2 + x + 1
 *
 * This version is intentionally simple.
 * We optimize it only AFTER matching the Rust oracle.
 */

__device__ __forceinline__
U128 shl128(U128 a, unsigned n)
{
    if (n == 0)
        return a;

    U128 r;
    r.lo = a.lo << n;
    r.hi = (a.hi << n) | (a.lo >> (64 - n));
    return r;
}

__device__ __forceinline__
U128 clmul64_nibble(
    unsigned long long a,
    unsigned long long b)
{
    unsigned long long lo;
    unsigned long long hi;
    const unsigned long long zero = 0ULL;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(zero)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(zero)
    );

    return {lo, hi};
}

__device__ __forceinline__
U128 reduce_gcm_256(U128 hi, U128 lo)
{
    // x^128 = x^7 + x^2 + x + 1  (0x87)
    U128 t = hi;
    t = bxor(t, shl128(hi, 1));
    t = bxor(t, shl128(hi, 2));
    t = bxor(t, shl128(hi, 7));

    unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    unsigned long long fold =
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    U128 r = bxor(lo, t);
    r.lo ^= fold;

    return r;
}

__device__ __forceinline__
U128 gf_mul(U128 a, U128 b)
{
    // Karatsuba: three 64x64 carry-less multiplies.
    U128 p0 = clmul64_nibble(a.lo, b.lo);
    U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_nibble(a.lo ^ a.hi, b.lo ^ b.hi);

    pm = bxor(pm, p0);
    pm = bxor(pm, p1);

    U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
unsigned long long spread32(unsigned x)
{
    unsigned long long v = x;

    v = (v | (v << 16)) & 0x0000FFFF0000FFFFULL;
    v = (v | (v <<  8)) & 0x00FF00FF00FF00FFULL;
    v = (v | (v <<  4)) & 0x0F0F0F0F0F0F0F0FULL;
    v = (v | (v <<  2)) & 0x3333333333333333ULL;
    v = (v | (v <<  1)) & 0x5555555555555555ULL;

    return v;
}

__device__ __forceinline__
U128 expand64(unsigned long long x)
{
    return {
        spread32((unsigned)x),
        spread32((unsigned)(x >> 32))
    };
}

__device__ __forceinline__
U128 square_flat_spread(U128 a)
{
    // Squaring in characteristic two = inserting zeros between bits,
    // followed by reduction modulo the GCM polynomial.
    U128 lo = expand64(a.lo);
    U128 hi = expand64(a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 square_flat_clmad(U128 a)
{
    /*
     * In characteristic two, cross terms cancel when a polynomial is
     * squared.  The low and high 64-bit limbs can therefore be squared
     * independently with carry-less self-multiplication, then passed to the
     * same exact GCM reduction as the spread-bit implementation.
     */
    const U128 lo = clmul64_nibble(a.lo, a.lo);
    const U128 hi = clmul64_nibble(a.hi, a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 square_flat(U128 a)
{
#ifdef NOID_SQUARE_CLMAD
    return square_flat_clmad(a);
#else
    return square_flat_spread(a);
#endif
}

__device__ __forceinline__
U128 sbox_x7_spread(U128 x)
{
    // Production Parano1d schedule:
    // x2 = square(x)
    // x4 = square(x2)
    // x6 = x * x2
    // x7 = x6 * x4
    const U128 x2 = square_flat_spread(x);
    const U128 x4 = square_flat_spread(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
U128 sbox_x7_clmad(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const U128 x4 = square_flat_clmad(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
U128 sbox_x7(U128 x)
{
#ifdef NOID_SQUARE_CLMAD
    return sbox_x7_clmad(x);
#else
    return sbox_x7_spread(x);
#endif
}

__device__ __forceinline__
void apply_mds_full_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_FULL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

__device__ __forceinline__
void apply_mds_partial_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_PARTIAL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

/*
 * Exact Poseidon2 M4 factorization for the external/full linear layer.
 *
 * Tower-basis matrix:
 *   [5 7 1 3]
 *   [4 6 1 1]
 *   [1 3 5 7]
 *   [1 1 4 6]
 *
 * In characteristic two, coefficient addition is XOR.  The circuit below
 * uses only four general GF(2^128) multiplications (two by tower element 2,
 * two by tower element 4), versus ten in the generic matrix multiply.
 * The constants below are the exact flat/GCM-basis images used by v1.0.3.
 */
__device__ __forceinline__
void apply_mds_full_factorized(U128 s[4])
{
    const U128 MUL2{
        0x7573da4a5f7710edULL,
        0x3d5bd35c94646a24ULL
    };

    const U128 MUL4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(gf_mul(MUL2, b), t1);
    const U128 t3 = bxor(gf_mul(MUL2, d), t0);
    const U128 t4 = bxor(gf_mul(MUL4, t1), t3);
    const U128 t5 = bxor(gf_mul(MUL4, t0), t2);

    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

/*
 * Internal/partial MDS has diag(c_i) with ones everywhere off diagonal.
 * sum + (c_i + 1)*s_i is algebraically identical and keeps the same four
 * GF multiplications while substantially reducing XOR/matrix overhead.
 */
__device__ __forceinline__
void apply_mds_partial_factorized(U128 s[4])
{
    const U128 D0{
        0xfd8ee716e990cf15ULL,
        0x486fb01f93aa169aULL
    };
    const U128 D1{
        0x3e1b361e8a1a5bbeULL,
        0x86b6a57216f08319ULL
    };
    const U128 D2{
        0x2924ed9040490831ULL,
        0xb2ef6c31981e3158ULL
    };
    const U128 D3{
        0x84cb11891ab51a3dULL,
        0xff829109128b0bd8ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 m0 = gf_mul(D0, a);
    const U128 m1 = gf_mul(D1, b);
    const U128 m2 = gf_mul(D2, c);
    const U128 m3 = gf_mul(D3, d);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

#ifdef NOID_MDS_FACTORIZED
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    apply_mds_full_factorized(s);
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
    apply_mds_partial_factorized(s);
}
#else
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    apply_mds_full_generic(s);
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
    apply_mds_partial_generic(s);
}
#endif

__device__ __forceinline__
void poseidon_permute(U128 s[4])
{
    apply_mds_full(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {

        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_x7(s[i]);
            }

            apply_mds_full(s);
        }
        else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);

            apply_mds_partial(s);
        }
    }
}
