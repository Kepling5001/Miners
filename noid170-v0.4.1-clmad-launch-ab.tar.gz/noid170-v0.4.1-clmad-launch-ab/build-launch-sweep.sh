#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
LOG="$ROOT/build-logs"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN" "$LOG"

COMMON=(
  -O3
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_SCHEDULED_THREADS_PER_SM=32768
  -Xptxas=-v
)

THREADS=(256 512 1024)
CAPS=(native 40 36 32)

for threads in "${THREADS[@]}"; do
  for cap in "${CAPS[@]}"; do
    name="clmad_t${threads}_r${cap}"
    extra=("-DNOID_THREADS_PER_BLOCK=${threads}")
    if [[ "$cap" != native ]]; then
      extra+=("--maxrregcount=${cap}")
    fi

    echo
    echo "===== BUILD $name ====="
    "$NVCC" "${COMMON[@]}" "${extra[@]}" \
      "$SRC/noid_live_job_daemon.cu" \
      -o "$BIN/$name" 2>&1 | tee "$LOG/$name.log"
  done
done

echo
echo "===== BUILD GPU CORRECTNESS ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_square_clmad.cu" \
  -o "$BIN/test_square_clmad" 2>&1 | tee "$LOG/oracle.log"

chmod +x "$BIN"/clmad_t*_r* "$BIN/test_square_clmad"
python3 -m py_compile "$ROOT/benchmark_launch.py" "$ROOT/offline_verify.py"
bash -n "$ROOT/build-launch-sweep.sh" "$ROOT/test-launch-sweep.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/clmad_t*_r* "$BIN/test_square_clmad"
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-launch-sweep.sh"
