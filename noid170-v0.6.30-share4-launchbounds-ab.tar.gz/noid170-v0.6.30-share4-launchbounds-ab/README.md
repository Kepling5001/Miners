# NOID170 v0.6.30 share4 launch-bounds A/B

v0.6.29 confirmed `share4` against the exact installed production daemon at about +0.90% wall / +0.92% kernel. `share4` uses 58 registers with zero local memory. At 512 threads, GA100 can sustain two blocks/SM up to 64 registers/thread, leaving six registers of unused two-block occupancy headroom.

This experiment keeps the exact `share4` algebra and tests whether telling ptxas the intended occupancy lets it spend that headroom on a better schedule:

- `prod` — byte-for-byte installed production daemon.
- `share4` — exact confirmed share4 kernel, no launch-bounds attribute.
- `lb2` — `__launch_bounds__(512,2)`, preserving the intended two blocks/SM while permitting up to the two-block register ceiling.
- `lb1` — `__launch_bounds__(512,1)`, exploratory; allows ptxas to spend more registers even if that lowers occupancy.

No arithmetic, protocol, block size, grid size, event polling, or share4 math changes between the three compiled share4 candidates.

## Run

```bash
cd /home/user/noid170-v0.6.30-share4-launchbounds-ab
./build-on-rig.sh
miner stop
set -a
source /hive/miners/custom/noid170/noid170.conf
set +a
./test-launchbounds.sh
```

Paste `STATIC SASS AUDIT`, `FINAL SHARE4 LAUNCH-BOUNDS RANKING`, and `SHARE4 LAUNCH-BOUNDS WINNER PROTOCOL` back into chat.
