#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in prod share4 lb2 lb1; do [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }; done
echo "===== SHARE4 CORRECTNESS ORACLE ====="; "$ROOT/bin/test_first_square_share"
echo; echo "===== STATIC SASS AUDIT ====="; python3 "$ROOT/sass-audit.py"
echo; python3 "$ROOT/benchmark_launchbounds.py"
echo; python3 "$ROOT/test-persistent.py"
echo; echo "Paste SHARE4 REFINEMENT ORACLE, STATIC SASS AUDIT, FINAL SHARE4 LAUNCH-BOUNDS RANKING, and SHARE4 LAUNCH-BOUNDS WINNER PROTOCOL back into chat."
echo "This experiment did NOT install or replace the HiveOS miner. Restart normal mining when finished: miner start"
