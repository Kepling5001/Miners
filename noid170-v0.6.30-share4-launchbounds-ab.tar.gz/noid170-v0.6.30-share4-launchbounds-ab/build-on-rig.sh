#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"; BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"; PROD="${NOID_PROD_DAEMON:-/hive/miners/custom/noid170/noid_live_job_daemon}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
[[ -x "$PROD" ]] || { echo "ERROR: production daemon not found at $PROD"; exit 1; }
mkdir -p "$BIN"; cp -f "$PROD" "$BIN/noid_daemon_prod"; chmod 755 "$BIN/noid_daemon_prod"
echo "===== EXACT INSTALLED PRODUCTION REFERENCE ====="; sha256sum "$BIN/noid_daemon_prod"
COMMON=(-O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC" -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1 -DNOID_SBOX_FUSE_VARIANT=0 -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41 -DNOID_PARTIAL_ILP=2 -DNOID_SQUARE_REDUCE_VARIANT=3 -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1 -DNOID_EVENT_POLL_US=2000 -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 -DNOID_FIRST_MDS_HOIST=0 -DNOID_FIRST_ROUND_SQUARE_SHARE=3 -Xptxas=-v)
build_variant(){ local name="$1" lb="$2"; echo; echo "===== BUILD $name | share4 launch_bounds=$lb ====="; "$NVCC" "${COMMON[@]}" -DNOID_LAUNCH_BOUNDS_MODE="$lb" "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"; chmod 755 "$BIN/noid_daemon_$name"; }
python3 "$ROOT/offline_verify.py"
build_variant share4 0
build_variant lb2 2
build_variant lb1 1
"$NVCC" "${COMMON[@]}" "$ROOT/test_first_square_share.cu" -o "$BIN/test_first_square_share" 2>&1 | tee "$BIN/build_test_first_square_share.log"; chmod 755 "$BIN/test_first_square_share"
python3 -m py_compile "$ROOT/benchmark_launchbounds.py" "$ROOT/test-persistent.py" "$ROOT/sass-audit.py"; bash -n "$ROOT/test-launchbounds.sh" "$ROOT/test-persistent.sh" "$ROOT/build-on-rig.sh"
echo; echo "===== BUILD COMPLETE ====="; ls -lh "$BIN"/noid_daemon_*; echo; echo "Next: miner stop && set -a && source /hive/miners/custom/noid170/noid170.conf && set +a && ./test-launchbounds.sh"
