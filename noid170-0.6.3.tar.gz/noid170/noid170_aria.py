#!/usr/bin/env python3

import concurrent.futures
import collections
import http.client
import json
import math
import os
import queue
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

VERSION = "0.6.3"
DEFAULT_RPC_URL = "https://pool.ariabrain.com/noid-rpc/"

MINING_KEY = os.environ.get("NOID_MINING_KEY", "").strip()
RPC_URL = os.environ.get("NOID_RPC_URL", DEFAULT_RPC_URL).strip() or DEFAULT_RPC_URL
CARD_MH = float(os.environ.get("NOID_CARD_MH", "143.42"))
WARMUP_CARD_MH = float(os.environ.get("NOID_WARMUP_CARD_MH", "36.24"))
MAX_TOTAL_SHARES_SEC = float(os.environ.get("NOID_MAX_TOTAL_SHARES_SEC", "50"))
SUBMIT_THREADS = max(1, int(os.environ.get("NOID_SUBMIT_THREADS", "1")))
POLL_INTERVAL = float(os.environ.get("NOID_POLL_INTERVAL", "0.20"))
GPU_STAGGER_MS = float(os.environ.get("NOID_GPU_STAGGER_MS", "5.0"))
HARD_EXPIRY_AGE = float(os.environ.get("NOID_HARD_EXPIRY_AGE", "10.5"))
SHARE_QUEUE_SIZE = max(256, int(os.environ.get("NOID_SHARE_QUEUE_SIZE", "5000")))
STATS_FILE = os.environ.get("NOID_STATS_FILE", "/run/noid170/stats.json")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WARMUP_BIN = os.environ.get("NOID_WARMUP_BIN", os.path.join(BASE_DIR, "noid_live_job_cont"))
DAEMON_BIN = os.environ.get("NOID_DAEMON_BIN", os.path.join(BASE_DIR, "noid_live_job_daemon"))
TUI = os.environ.get("NOID_TUI", "auto").lower()
ACCEPTED_WORK_WINDOW = max(30.0, float(os.environ.get("NOID_ACCEPTED_WORK_WINDOW", "120")))
CAPABILITY_REFRESH_TIMEOUT = max(
    0.25, float(os.environ.get("NOID_CAPABILITY_REFRESH_TIMEOUT", "2.5"))
)
CAPABILITY_MODE = os.environ.get("NOID_CAPABILITY_MODE", "adaptive").strip().lower()
if CAPABILITY_MODE not in ("baseline", "nonblock", "adaptive"):
    raise RuntimeError(
        "NOID_CAPABILITY_MODE must be baseline, nonblock, or adaptive"
    )


def detect_gpu_count():
    override = os.environ.get("NOID_GPU_COUNT")
    if override:
        count = int(override)
        if count < 1:
            raise RuntimeError("NOID_GPU_COUNT must be >= 1")
        return count

    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    count = len([x for x in p.stdout.splitlines() if x.strip()])
    if count < 1:
        raise RuntimeError("No NVIDIA GPUs detected")
    return count


GPU_COUNT = detect_gpu_count()
TOTAL_MH = CARD_MH * GPU_COUNT

u = urlsplit(RPC_URL)
if u.scheme not in ("http", "https"):
    raise RuntimeError(f"Unsupported RPC URL scheme: {u.scheme}")
RPC_SCHEME = u.scheme
RPC_HOST = u.hostname
RPC_PORT = u.port
RPC_PATH = u.path or "/"
if u.query:
    RPC_PATH += "?" + u.query
if not RPC_HOST:
    raise RuntimeError(f"Invalid NOID_RPC_URL: {RPC_URL}")
if not MINING_KEY:
    raise RuntimeError("NOID_MINING_KEY is not set")

running = True
lock = threading.RLock()
share_queue = queue.Queue(maxsize=SHARE_QUEUE_SIZE)
rpc_session_lock = threading.Lock()
rpc_session_conn = None
# Treat the node's opaque template_id as a submission capability, separate
# from the GPU's (height, PoW fields, target) work identity.  Polling and
# submission workflows are serialized so a newly fetched single-use
# capability cannot race a share that selected the preceding capability.
capability_flow_lock = threading.Lock()
refresh_now_event = threading.Event()
invalidated_seqs = set()
stale_logged_seqs = set()
urgent_candidate = None
capability_retry_not_before = 0.0

# Persistent worker/job state.
job_seq = 0
current_seq = 0
contexts = collections.OrderedDict()  # seq -> work context + mutable capability ID
min_submit_height = 0
seq_sent_at = {}
seq_acks = {}

gpu_rates = [0.0] * GPU_COUNT
gpu_rate_measured = [False] * GPU_COUNT
# Wall-clock rate measures real end-to-end GPU worker throughput, including
# host scheduling, result copies, command handling, and gaps between kernels.
gpu_wall_rates = [0.0] * GPU_COUNT
gpu_last_stat_wall = [0.0] * GPU_COUNT
gpu_job_seq = [0] * GPU_COUNT
ready_events = [threading.Event() for _ in range(GPU_COUNT)]

production_started_at = None
accepted_events = collections.deque()  # (monotonic_time, hashes_per_share)
found_events = collections.deque()     # every GPU candidate before local filtering
queued_events = collections.deque()    # candidates successfully handed to submit queue
active_submissions = 0

stats = {
    "accepted": 0,
    "stale": 0,
    "stale_old_height": 0,
    "stale_old_template": 0,
    "stale_current_template": 0,
    "rejected": 0,
    "http_errors": 0,
    "queue_dropped": 0,
    "old_share_discarded": 0,
    "height_regressions": 0,
    "job_updates": 0,
    "id_only_refreshes": 0,
    "capability_fetches": 0,
    "capability_rebinds": 0,
    "capability_refresh_failures": 0,
    "capability_after_accept": 0,
    "capability_work_changes": 0,
    "capability_refresh_deferred": 0,
    "capability_backoffs": 0,
    "capability_backoff_seconds": 0.0,
    "capability_waits": 0,
    "capability_wait_ms": 0.0,
    "get_template_calls": 0,
    "get_template_ms": 0.0,
    "get_template_max_ms": 0.0,
    "submit_calls": 0,
    "submit_ms": 0.0,
    "submit_max_ms": 0.0,
    "stale_responses": 0,
    "stale_retry_attempts": 0,
    "stale_recovered": 0,
    "stale_retry_failed": 0,
    "full_job_updates": 0,
    "target_updates": 0,
    "tag_updates": 0,
    "accepted_work_hashes": 0.0,
    "found_work_hashes": 0.0,
    "stale_work_hashes": 0.0,
    "rejected_work_hashes": 0.0,
    "old_discarded_work_hashes": 0.0,
    "queue_dropped_work_hashes": 0.0,
    "found": 0,
    "queued_found": 0,
    "last_job_ack_ms": 0.0,
    "max_job_ack_ms": 0.0,
}


def sig_handler(signum, frame):
    global running
    running = False


signal.signal(signal.SIGTERM, sig_handler)
signal.signal(signal.SIGINT, sig_handler)


def make_conn():
    cls = http.client.HTTPSConnection if RPC_SCHEME == "https" else http.client.HTTPConnection
    return cls(RPC_HOST, RPC_PORT, timeout=5)


def rpc(conn, method, params):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    conn.request(
        "POST",
        RPC_PATH,
        body=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {MINING_KEY}",
            "User-Agent": f"noid170/{VERSION}",
            "Accept": "*/*",
            "Connection": "keep-alive",
        },
    )
    response = conn.getresponse()
    data = response.read()
    if response.status != 200:
        raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
    return json.loads(data)


def session_rpc(method, params):
    """Serialize production RPC over one persistent connection/backend route."""
    global rpc_session_conn
    started = time.monotonic()
    with rpc_session_lock:
        try:
            if rpc_session_conn is None:
                rpc_session_conn = make_conn()
            try:
                return rpc(rpc_session_conn, method, params)
            except Exception:
                try:
                    rpc_session_conn.close()
                except Exception:
                    pass
                rpc_session_conn = None
                raise
        finally:
            elapsed_ms = (time.monotonic() - started) * 1000.0
            with lock:
                if method == "paranoid_getBlockTemplate":
                    stats["get_template_calls"] += 1
                    stats["get_template_ms"] += elapsed_ms
                    stats["get_template_max_ms"] = max(
                        stats["get_template_max_ms"], elapsed_ms
                    )
                elif method == "paranoid_submitBlock":
                    stats["submit_calls"] += 1
                    stats["submit_ms"] += elapsed_ms
                    stats["submit_max_ms"] = max(
                        stats["submit_max_ms"], elapsed_ms
                    )


def reset_rpc_session():
    """Rotate away from a connection whose submit path reported stale work."""
    global rpc_session_conn
    with rpc_session_lock:
        if rpc_session_conn is not None:
            try:
                rpc_session_conn.close()
            except Exception:
                pass
        rpc_session_conn = None


def fetch_job_once():
    j = session_rpc("paranoid_getBlockTemplate", [""])

    err = j.get("error")
    if not err:
        return j["result"], 0.0
    if isinstance(err, dict) and err.get("code") == -32011:
        retry_ms = err.get("data", {}).get("retry_in_ms", 500)
        return None, max(0.05, retry_ms / 1000.0)
    raise RuntimeError(err)


def wait_for_job(minimum_height=None, timeout=20.0):
    deadline = time.monotonic() + timeout
    while running and time.monotonic() < deadline:
        try:
            job, retry = fetch_job_once()
        except Exception as e:
            print(f"Template fetch error: {e}", flush=True)
            time.sleep(0.5)
            continue
        if job is None:
            time.sleep(retry)
            continue
        h = int(job["height"])
        if minimum_height is not None and h < minimum_height:
            with lock:
                stats["height_regressions"] += 1
            time.sleep(0.10)
            continue
        return job
    raise RuntimeError("Timed out waiting for usable Aria template")


def hashes_per_share_from_target_hex(target_hex):
    target = int.from_bytes(bytes.fromhex(target_hex), "little")
    if target <= 0:
        return 0.0
    return (1 << 256) / target


def target_metrics(job):
    hps = hashes_per_share_from_target_hex(job["difficulty_target_hex"])
    if hps <= 0:
        return float("inf"), 0.0
    return hps, TOTAL_MH * 1e6 / hps


def show_target(label, job):
    hps, total_sps = target_metrics(job)
    print(
        f"{label}: height {job['height']} | {hps:,.0f} hashes/share | "
        f"~{total_sps:,.1f} shares/s across {GPU_COUNT} GPUs",
        flush=True,
    )


# ---------------------------------------------------------------------------
# Startup vardiff warmup. This still uses the already-proven one-shot worker.
# Production uses the persistent daemon and never destroys CUDA contexts.
# ---------------------------------------------------------------------------

def mine_warmup_candidates(job, wanted=64):
    hps, _ = target_metrics(job)
    card_sps = max(WARMUP_CARD_MH * 1e6 / hps, 0.01)
    target_candidates = max(wanted + 16, 96)
    max_window = 6.5
    warm_gpus = max(1, math.ceil(target_candidates / (card_sps * max_window)))
    warm_gpus = min(GPU_COUNT, warm_gpus)
    warmup_seconds = target_candidates / (card_sps * warm_gpus)
    warmup_seconds = max(2.5, min(max_window, warmup_seconds + 0.35))

    print(
        f"Warmup: {warm_gpus} GPU(s) for ~{warmup_seconds:.2f}s "
        f"({card_sps:,.2f} expected shares/s/card)",
        flush=True,
    )

    procs = []
    salt_base = time.time_ns() & 0x7FFFFFFFFFFFFFFF
    for gpu in range(warm_gpus):
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        p = subprocess.Popen(
            [
                "timeout",
                f"{warmup_seconds:.2f}s",
                WARMUP_BIN,
                job["pow_fields_hex"],
                job["difficulty_target_hex"],
                "0",
                str(salt_base + gpu + 1),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )
        procs.append(p)

    shares = []
    seen = set()
    for p in procs:
        out, _ = p.communicate()
        for line in out.splitlines():
            if not line.startswith("SHARE "):
                continue
            parts = line.split()
            if len(parts) != 2:
                continue
            nonce = parts[1]
            if nonce in seen:
                continue
            seen.add(nonce)
            shares.append(nonce)
    print(f"Warmup produced {len(shares)} unique candidates", flush=True)
    return shares[:wanted]


def warmup_submit_chunk(template_id, nonces):
    conn = make_conn()
    accepted = stale = rejected = 0
    try:
        for nonce in nonces:
            try:
                j = rpc(conn, "paranoid_submitBlock", [template_id, nonce])
                result = str(j.get("result", ""))
                error = str(j.get("error", ""))
                text = (result + " " + error).lower()
                if result == "share accepted":
                    accepted += 1
                elif "stale" in text or "expired" in text:
                    stale += 1
                else:
                    rejected += 1
            except Exception:
                rejected += 1
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return accepted, stale, rejected


def submit_warmup(job, shares):
    # Small chunks reduce the stale burst if Aria retargets during warmup.
    chunks = [shares[i : i + 4] for i in range(0, len(shares), 4)]
    accepted = stale = rejected = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(chunks) or 1)) as ex:
        futures = [ex.submit(warmup_submit_chunk, job["template_id"], c) for c in chunks]
        for f in futures:
            a, s, r = f.result()
            accepted += a
            stale += s
            rejected += r
    return accepted, stale, rejected


def wait_for_retarget(old_job, timeout=5.0):
    deadline = time.monotonic() + timeout
    old_height = int(old_job["height"])
    old_target = old_job["difficulty_target_hex"]
    old_pow = old_job["pow_fields_hex"]
    latest = old_job
    while running and time.monotonic() < deadline:
        try:
            job, retry = fetch_job_once()
        except Exception:
            time.sleep(0.25)
            continue
        if job is None:
            time.sleep(retry)
            continue
        h = int(job["height"])
        if h < old_height:
            with lock:
                stats["height_regressions"] += 1
            continue
        latest = job
        if h > old_height:
            return job
        if job["difficulty_target_hex"] != old_target:
            return job
        if job["pow_fields_hex"] != old_pow:
            return job
        time.sleep(0.20)
    return latest


def warm_up_vardiff(job):
    print("\n===== ARIA VARDIFF WARMUP =====", flush=True)
    rounds = 0
    while running:
        _, total_sps = target_metrics(job)
        show_target("Current", job)
        if total_sps <= MAX_TOTAL_SHARES_SEC:
            print("Share rate is sane. Starting persistent GPU workers.", flush=True)
            return job
        rounds += 1
        if rounds > 12:
            raise RuntimeError("Vardiff failed to converge after 12 warmup rounds")
        print("Target is too easy; controlled warmup in progress...", flush=True)
        shares = mine_warmup_candidates(job, 64)
        if len(shares) < 64:
            print("Not enough warmup shares; fetching a fresh template.", flush=True)
            job = wait_for_job(minimum_height=int(job["height"]))
            continue
        a, s, r = submit_warmup(job, shares)
        print(f"Warmup submissions: {a} accepted | {s} stale | {r} rejected", flush=True)
        if a == 0:
            job = wait_for_job(minimum_height=int(job["height"]))
            continue
        job = wait_for_retarget(job, timeout=5.0)
        print(flush=True)
    raise RuntimeError("Miner stopped during vardiff warmup")


# ---------------------------------------------------------------------------
# Persistent CUDA worker protocol.
# ---------------------------------------------------------------------------

def register_job_context(job):
    global job_seq, current_seq
    with lock:
        job_seq += 1
        seq = job_seq
        target_hex = job["difficulty_target_hex"]
        capability_event = threading.Event()
        capability_event.set()
        ctx = {
            "seq": seq,
            "template_id": job["template_id"],
            "target_hex": target_hex,
            "hashes_per_share": hashes_per_share_from_target_hex(target_hex),
            "pow_fields_hex": job["pow_fields_hex"],
            "height": int(job["height"]),
            "created": time.monotonic(),
            "capability_valid": True,
            "capability_event": capability_event,
        }
        contexts[seq] = ctx
        current_seq = seq
        invalidated_seqs.discard(seq)
        while len(contexts) > 64:
            contexts.popitem(last=False)
        seq_sent_at[seq] = time.monotonic()
        seq_acks[seq] = set()
        for old in list(seq_sent_at):
            if old < seq - 64:
                seq_sent_at.pop(old, None)
                seq_acks.pop(old, None)
                invalidated_seqs.discard(old)
                stale_logged_seqs.discard(old)
        return seq, ctx


def get_context(seq):
    with lock:
        return contexts.get(seq)


def work_compatible(candidate, ctx):
    """Return whether a fetched capability describes the same GPU work."""
    return (
        int(candidate["height"]) == ctx["height"]
        and candidate["pow_fields_hex"] == ctx["pow_fields_hex"]
        and candidate["difficulty_target_hex"] == ctx["target_hex"]
    )


def rebind_template_capability(seq, candidate, source):
    """Attach a fresh compatible capability without issuing a GPU JOB."""
    with lock:
        ctx = contexts.get(seq)
        if ctx is None or not work_compatible(candidate, ctx):
            return False
        if candidate["template_id"] != ctx["template_id"]:
            ctx["template_id"] = candidate["template_id"]
            stats["id_only_refreshes"] += 1
            stats["capability_rebinds"] += 1
            if source == "accepted":
                stats["capability_after_accept"] += 1
        ctx["capability_valid"] = True
        ctx["capability_event"].set()
        return True


def invalidate_template_capability(seq):
    """Mark a single-use capability consumed without invalidating GPU work."""
    if CAPABILITY_MODE == "baseline":
        return
    with lock:
        ctx = contexts.get(seq)
        if ctx is not None:
            ctx["capability_valid"] = False
            ctx["capability_event"].clear()


def note_capability_backoff(retry):
    """Publish a server retry time without sleeping under the flow lock."""
    global capability_retry_not_before
    retry = max(0.02, float(retry or POLL_INTERVAL))
    with lock:
        stats["capability_refresh_deferred"] += 1
        stats["capability_backoffs"] += 1
        stats["capability_backoff_seconds"] += retry
        if CAPABILITY_MODE == "adaptive":
            capability_retry_not_before = max(
                capability_retry_not_before, time.monotonic() + retry
            )
    if CAPABILITY_MODE == "adaptive":
        refresh_now_event.set()


def clear_capability_backoff():
    global capability_retry_not_before
    with lock:
        capability_retry_not_before = 0.0


def wait_for_valid_capability(seq, height):
    """Wait without blocking the template watcher or capability flow lock."""
    if CAPABILITY_MODE == "baseline":
        return True
    started = time.monotonic()
    counted = False
    while running:
        with lock:
            ctx = contexts.get(seq)
            floor = min_submit_height
            active_seq = current_seq
            invalid = seq in invalidated_seqs
            valid = bool(ctx and ctx.get("capability_valid"))
            event = ctx.get("capability_event") if ctx else None
        if ctx is None or height < floor or seq < active_seq or invalid:
            if counted:
                with lock:
                    stats["capability_wait_ms"] += (
                        time.monotonic() - started
                    ) * 1000.0
            return False
        if valid:
            if counted:
                with lock:
                    stats["capability_wait_ms"] += (
                        time.monotonic() - started
                    ) * 1000.0
            return True
        if not counted:
            with lock:
                stats["capability_waits"] += 1
            counted = True
        if event is not None:
            event.wait(timeout=0.05)
        else:
            time.sleep(0.05)
    return False


def stage_urgent_candidate(candidate):
    """Publish changed work from a submit workflow to the main GPU loop."""
    global urgent_candidate
    with lock:
        ctx = contexts.get(current_seq)
        if ctx is not None and int(candidate["height"]) < ctx["height"]:
            stats["height_regressions"] += 1
            return False
        urgent_candidate = candidate
        if ctx is not None and not work_compatible(candidate, ctx):
            invalidated_seqs.add(current_seq)
            stats["capability_work_changes"] += 1
    refresh_now_event.set()
    return True


def take_urgent_candidate():
    global urgent_candidate
    with lock:
        candidate = urgent_candidate
        urgent_candidate = None
    return candidate


def fetch_capability_for_seq(seq, minimum_height, source, timeout=None):
    """Fetch and route a replacement capability while GPU work continues."""
    if CAPABILITY_MODE != "baseline":
        return fetch_capability_for_seq_nonblocking(
            seq, minimum_height, source
        )
    if timeout is None:
        timeout = CAPABILITY_REFRESH_TIMEOUT
    deadline = time.monotonic() + timeout
    while running and time.monotonic() < deadline:
        try:
            candidate, retry = fetch_job_once()
            with lock:
                stats["capability_fetches"] += 1
        except Exception:
            with lock:
                stats["http_errors"] += 1
            reset_rpc_session()
            time.sleep(0.05)
            continue
        if candidate is None:
            time.sleep(min(retry, max(0.0, deadline - time.monotonic())))
            continue
        if int(candidate["height"]) < minimum_height:
            with lock:
                stats["height_regressions"] += 1
            time.sleep(0.02)
            continue
        with lock:
            active = current_seq
            ctx = contexts.get(seq)
        if active == seq and ctx is not None and work_compatible(candidate, ctx):
            rebind_template_capability(seq, candidate, source)
            return True, candidate
        stage_urgent_candidate(candidate)
        return False, candidate
    with lock:
        stats["capability_refresh_failures"] += 1
    return False, None


def fetch_capability_for_seq_nonblocking(seq, minimum_height, source):
    """Attempt once; publish retry/backoff work instead of sleeping in-lock."""
    try:
        candidate, retry = fetch_job_once()
        with lock:
            stats["capability_fetches"] += 1
    except Exception:
        with lock:
            stats["http_errors"] += 1
            stats["capability_refresh_failures"] += 1
        reset_rpc_session()
        note_capability_backoff(0.05)
        return False, None

    if candidate is None:
        note_capability_backoff(retry)
        return False, None

    clear_capability_backoff()
    if int(candidate["height"]) < minimum_height:
        with lock:
            stats["height_regressions"] += 1
        note_capability_backoff(0.05)
        return False, candidate

    with lock:
        active = current_seq
        ctx = contexts.get(seq)
    if active == seq and ctx is not None and work_compatible(candidate, ctx):
        rebind_template_capability(seq, candidate, source)
        return True, candidate

    stage_urgent_candidate(candidate)
    return False, candidate


def apply_candidate(workers, job, candidate, now, source):
    """Apply fetched work; only meaningful work changes reach the GPUs."""
    if candidate is None:
        return job, False
    old_h = int(job["height"])
    new_h = int(candidate["height"])
    if new_h < old_h:
        with lock:
            stats["height_regressions"] += 1
        return job, False

    pow_changed = candidate["pow_fields_hex"] != job["pow_fields_hex"]
    target_changed = candidate["difficulty_target_hex"] != job["difficulty_target_hex"]
    if new_h > old_h or pow_changed or target_changed:
        if new_h > old_h:
            invalidate_older_heights(new_h)
            reason = "new-height"
        elif pow_changed:
            reason = "pow-refresh"
        else:
            reason = "vardiff-refresh"
        with lock:
            invalidated_seqs.add(current_seq)
        job = candidate
        send_job(workers, job, reason)
        return job, True

    # A same-work response can restore a consumed capability even when a
    # backend reuses the opaque ID, so always publish it to the active context.
    rebind_template_capability(current_seq, candidate, source)
    if candidate["template_id"] != job["template_id"]:
        # Keep status output aligned with the capability used by submitters.
        job = dict(job)
        job["template_id"] = candidate["template_id"]
    return job, False


def send_job(workers, job, reason):
    seq, ctx = register_job_context(job)
    line = f"JOB {seq} {ctx['pow_fields_hex']} {ctx['target_hex']}\n"
    do_stagger = (reason == "initial" and GPU_COUNT >= 8 and GPU_STAGGER_MS > 0.0)
    for idx, (gpu, proc, _tout, _terr) in enumerate(workers):
        if proc.poll() is not None:
            raise RuntimeError(f"GPU {gpu} daemon exited with code {proc.returncode}")
        try:
            proc.stdin.write(line)
            proc.stdin.flush()
        except Exception as e:
            raise RuntimeError(f"Failed to send job to GPU {gpu}: {e}")
        # Spread batch boundaries across the ~60 ms kernel cycle on large rigs.
        # This prevents all CUDA host threads from waking at once.
        if do_stagger and idx + 1 < len(workers):
            time.sleep(GPU_STAGGER_MS / 1000.0)
    with lock:
        stats["job_updates"] += 1
    print(
        f"JOB {seq} -> height {ctx['height']} ({reason})",
        flush=True,
    )
    return seq


def invalidate_older_heights(new_height):
    global min_submit_height
    with lock:
        if new_height > min_submit_height:
            min_submit_height = new_height


def gpu_stdout_reader(gpu, proc):
    for line in proc.stdout:
        if not running:
            break
        line = line.strip()
        if not line.startswith("SHARE "):
            continue
        parts = line.split()
        if len(parts) != 3:
            continue
        try:
            seq = int(parts[1])
        except ValueError:
            continue
        nonce = parts[2]
        ctx = get_context(seq)
        if not ctx:
            with lock:
                stats["old_share_discarded"] += 1
            continue

        now = time.monotonic()
        hps = ctx["hashes_per_share"]
        with lock:
            stats["found"] += 1
            stats["found_work_hashes"] += hps
            found_events.append((now, hps))
            floor = min_submit_height
            active_seq = current_seq
            invalid = seq in invalidated_seqs
        if ctx["height"] < floor or seq < active_seq or invalid:
            with lock:
                stats["old_share_discarded"] += 1
                stats["old_discarded_work_hashes"] += hps
            continue
        try:
            share_queue.put_nowait(
                (seq, ctx["template_id"], ctx["target_hex"], ctx["height"], nonce, now)
            )
            with lock:
                stats["queued_found"] += 1
                queued_events.append((now, hps))
        except queue.Full:
            with lock:
                stats["queue_dropped"] += 1
                stats["queue_dropped_work_hashes"] += hps


def gpu_stderr_reader(gpu, proc):
    for line in proc.stderr:
        if not running:
            break
        line = line.strip()
        if line.startswith("READY "):
            ready_events[gpu].set()
            continue
        if line.startswith("JOBACK "):
            parts = line.split()
            if len(parts) >= 3:
                try:
                    seq = int(parts[1])
                except ValueError:
                    continue
                mode = parts[2]
                now = time.monotonic()
                with lock:
                    gpu_job_seq[gpu] = seq
                    if mode == "FULL":
                        stats["full_job_updates"] += 1
                    elif mode == "TARGET":
                        stats["target_updates"] += 1
                    elif mode == "TAG":
                        stats["tag_updates"] += 1
                    acks = seq_acks.setdefault(seq, set())
                    acks.add(gpu)
                    if len(acks) == GPU_COUNT and seq in seq_sent_at:
                        ms = (now - seq_sent_at[seq]) * 1000.0
                        stats["last_job_ack_ms"] = ms
                        stats["max_job_ack_ms"] = max(stats["max_job_ack_ms"], ms)
            continue
        if not line.startswith("STAT "):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        try:
            rate = float(parts[1])
            interval_hashes = float(parts[2]) if len(parts) >= 3 else 0.0
            daemon_wall_rate = float(parts[5]) if len(parts) >= 6 else None
        except ValueError:
            continue
        now = time.monotonic()
        with lock:
            gpu_rates[gpu] = rate
            gpu_rate_measured[gpu] = True
            if daemon_wall_rate is not None:
                gpu_wall_rates[gpu] = daemon_wall_rate
            else:
                prev = gpu_last_stat_wall[gpu]
                if prev > 0.0 and interval_hashes > 0.0:
                    elapsed = now - prev
                    if elapsed > 0.001:
                        gpu_wall_rates[gpu] = interval_hashes / elapsed / 1e6
            gpu_last_stat_wall[gpu] = now


def start_daemons():
    workers = []
    with lock:
        for i in range(GPU_COUNT):
            gpu_rates[i] = CARD_MH
            gpu_rate_measured[i] = False
            gpu_wall_rates[i] = 0.0
            gpu_last_stat_wall[i] = 0.0
            gpu_job_seq[i] = 0
            ready_events[i].clear()

    salt_base = time.time_ns() & 0x7FFFFFFFFFFFFFFF
    print(f"Starting {GPU_COUNT} persistent CUDA daemon(s)...", flush=True)
    for gpu in range(GPU_COUNT):
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        proc = subprocess.Popen(
            [DAEMON_BIN, "--daemon", str(salt_base + gpu + 1)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
        tout = threading.Thread(target=gpu_stdout_reader, args=(gpu, proc), daemon=True)
        terr = threading.Thread(target=gpu_stderr_reader, args=(gpu, proc), daemon=True)
        tout.start()
        terr.start()
        workers.append((gpu, proc, tout, terr))

    deadline = time.monotonic() + 45.0
    while running and time.monotonic() < deadline:
        if all(e.is_set() for e in ready_events):
            print("All persistent CUDA contexts are READY.", flush=True)
            return workers
        for gpu, proc, _, _ in workers:
            if proc.poll() is not None:
                raise RuntimeError(f"GPU {gpu} daemon exited during startup: {proc.returncode}")
        time.sleep(0.10)

    missing = [str(i) for i, e in enumerate(ready_events) if not e.is_set()]
    raise RuntimeError("Timed out waiting for GPU daemon READY: " + ",".join(missing))


def stop_daemons(workers):
    for _, proc, _, _ in workers:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n")
                proc.stdin.flush()
            except Exception:
                pass
    deadline = time.monotonic() + 2.0
    for _, proc, _, _ in workers:
        if proc.poll() is not None:
            continue
        remain = max(0.0, deadline - time.monotonic())
        try:
            proc.wait(timeout=remain)
        except subprocess.TimeoutExpired:
            proc.terminate()
    for _, proc, _, _ in workers:
        if proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass


def submit_response(j):
    result = str(j.get("result", ""))
    error_obj = j.get("error")
    text = (result + " " + str(error_obj or "")).lower()
    if result == "share accepted":
        return "accepted", error_obj
    if "stale" in text or "expired" in text:
        return "stale", error_obj
    return "rejected", error_obj


def record_accepted(target_hex, recovered=False):
    now = time.monotonic()
    hps = hashes_per_share_from_target_hex(target_hex)
    with lock:
        stats["accepted"] += 1
        stats["accepted_work_hashes"] += hps
        if recovered:
            stats["stale_recovered"] += 1
        accepted_events.append((now, hps))


def record_final_stale(
    seq, height, error_obj, retry_failed=False, found_at=None
):
    """Count a share only when capability recovery did not accept it."""
    now = time.monotonic()
    stale_detail = None
    with lock:
        stats["stale"] += 1
        submitted_ctx = contexts.get(seq)
        if submitted_ctx is not None:
            stats["stale_work_hashes"] += submitted_ctx["hashes_per_share"]
        if retry_failed:
            stats["stale_retry_failed"] += 1
        first_stale_for_seq = seq not in stale_logged_seqs
        stale_logged_seqs.add(seq)
        current_ctx = contexts.get(current_seq)
        current_height = current_ctx["height"] if current_ctx else min_submit_height
        age_ms = (
            (now - submitted_ctx["created"]) * 1000.0
            if submitted_ctx else -1.0
        )
        share_age_ms = (
            (now - found_at) * 1000.0 if found_at is not None else -1.0
        )
        if height < current_height:
            stale_class = "old-height"
            stats["stale_old_height"] += 1
        elif seq < current_seq:
            stale_class = "old-template"
            stats["stale_old_template"] += 1
        else:
            stale_class = "current-template"
            stats["stale_current_template"] += 1
        if first_stale_for_seq:
            error_data = error_obj.get("data", {}) if isinstance(error_obj, dict) else {}
            stale_detail = (
                f"STALE-UNRECOVERED class={stale_class} seq={seq} height={height} "
                f"current_seq={current_seq} current_height={current_height} "
                f"job_age_ms={age_ms:.0f} share_age_ms={share_age_ms:.0f} "
                f"action={error_data.get('action', '-')} "
                f"reason={error_data.get('reason', '-')} "
                f"(further stales for this job suppressed)"
            )
    if stale_detail:
        print(stale_detail, flush=True)


def refresh_after_accept(seq, height):
    # The node describes template_id as a single-use capability.  Acquire its
    # replacement before the next queued share selects an ID.
    compatible, _candidate = fetch_capability_for_seq(
        seq, height, "accepted", CAPABILITY_REFRESH_TIMEOUT
    )
    return compatible


def submitter(thread_id):
    global active_submissions
    while running:
        try:
            item = share_queue.get(timeout=0.5)
        except queue.Empty:
            continue
        if item is None:
            share_queue.task_done()
            break

        seq, _queued_template_id, target_hex, height, nonce, found_at = item
        share_hps = hashes_per_share_from_target_hex(target_hex)
        with lock:
            floor = min_submit_height
            active_seq = current_seq
            invalid = seq in invalidated_seqs
        if height < floor or seq < active_seq or invalid:
            with lock:
                stats["old_share_discarded"] += 1
                stats["old_discarded_work_hashes"] += share_hps
            share_queue.task_done()
            continue

        if CAPABILITY_MODE != "baseline" and not wait_for_valid_capability(
            seq, height
        ):
            with lock:
                stats["old_share_discarded"] += 1
                stats["old_discarded_work_hashes"] += share_hps
            share_queue.task_done()
            continue

        try:
            with lock:
                active_submissions += 1
            # One workflow owns capability selection, submit, replacement, and
            # optional retry. This prevents polling from superseding the ID
            # between selecting it and sending the share.
            with capability_flow_lock:
                with lock:
                    ctx = contexts.get(seq)
                    floor = min_submit_height
                    active_seq = current_seq
                    invalid = seq in invalidated_seqs
                    template_id = ctx["template_id"] if ctx is not None else None
                    capability_valid = bool(
                        ctx and ctx.get("capability_valid", True)
                    )
                if (
                    ctx is None
                    or template_id is None
                    or height < floor
                    or seq < active_seq
                    or invalid
                    or (CAPABILITY_MODE != "baseline" and not capability_valid)
                ):
                    with lock:
                        stats["old_share_discarded"] += 1
                        stats["old_discarded_work_hashes"] += share_hps
                    continue

                j = session_rpc("paranoid_submitBlock", [template_id, nonce])
                outcome, error_obj = submit_response(j)
                if outcome == "accepted":
                    invalidate_template_capability(seq)
                    record_accepted(target_hex)
                    refresh_after_accept(seq, height)
                    continue
                if outcome == "rejected":
                    with lock:
                        stats["rejected"] += 1
                        stats["rejected_work_hashes"] += share_hps
                    continue

                # A stale capability does not necessarily mean stale GPU work.
                # Rotate the backend route, fetch a fresh capability, and retry
                # this exact nonce once when height/PoW/target are unchanged.
                with lock:
                    stats["stale_responses"] += 1
                invalidate_template_capability(seq)
                reset_rpc_session()
                compatible, _candidate = fetch_capability_for_seq(
                    seq, height, "stale", CAPABILITY_REFRESH_TIMEOUT
                )
                if not compatible:
                    record_final_stale(
                        seq, height, error_obj, found_at=found_at
                    )
                    continue

                with lock:
                    retry_ctx = contexts.get(seq)
                    retry_id = retry_ctx["template_id"] if retry_ctx is not None else None
                    retry_valid = (
                        retry_ctx is not None
                        and seq == current_seq
                        and seq not in invalidated_seqs
                    )
                    stats["stale_retry_attempts"] += 1
                if not retry_valid or retry_id is None:
                    record_final_stale(
                        seq, height, error_obj, retry_failed=True,
                        found_at=found_at
                    )
                    continue

                try:
                    retry_j = session_rpc("paranoid_submitBlock", [retry_id, nonce])
                except Exception:
                    with lock:
                        stats["http_errors"] += 1
                    record_final_stale(
                        seq, height, error_obj, retry_failed=True,
                        found_at=found_at
                    )
                    reset_rpc_session()
                    fetch_capability_for_seq(
                        seq, height, "retry-error", CAPABILITY_REFRESH_TIMEOUT
                    )
                    continue
                retry_outcome, retry_error = submit_response(retry_j)
                if retry_outcome == "accepted":
                    invalidate_template_capability(seq)
                    record_accepted(target_hex, recovered=True)
                    print(f"STALE-RECOVERED seq={seq} height={height}", flush=True)
                    refresh_after_accept(seq, height)
                elif retry_outcome == "stale":
                    invalidate_template_capability(seq)
                    with lock:
                        stats["stale_responses"] += 1
                    record_final_stale(
                        seq, height, retry_error, retry_failed=True,
                        found_at=found_at
                    )
                    reset_rpc_session()
                    fetch_capability_for_seq(
                        seq, height, "retry-failed", CAPABILITY_REFRESH_TIMEOUT
                    )
                else:
                    invalidate_template_capability(seq)
                    with lock:
                        stats["rejected"] += 1
                        stats["rejected_work_hashes"] += share_hps
                        stats["stale_retry_failed"] += 1
        except Exception:
            with lock:
                stats["http_errors"] += 1
        finally:
            with lock:
                active_submissions = max(0, active_submissions - 1)
            share_queue.task_done()

def rolling_event_rate(events, now, prod_started):
    with lock:
        while events and events[0][0] < now - ACCEPTED_WORK_WINDOW:
            events.popleft()
        work = sum(x[1] for x in events)
        count = len(events)
    rolling_start = max(prod_started, now - ACCEPTED_WORK_WINDOW)
    rolling_elapsed = max(0.001, now - rolling_start)
    return work / rolling_elapsed / 1e6, count


def accepted_work_rates(now, prod_started):
    with lock:
        while accepted_events and accepted_events[0][0] < now - ACCEPTED_WORK_WINDOW:
            accepted_events.popleft()
        rolling_work = sum(x[1] for x in accepted_events)
        lifetime_work = stats["accepted_work_hashes"]
        events_copy = list(accepted_events)

    lifetime_elapsed = max(0.001, now - prod_started)
    lifetime_mhs = lifetime_work / lifetime_elapsed / 1e6

    rolling_start = max(prod_started, now - ACCEPTED_WORK_WINDOW)
    rolling_elapsed = max(0.001, now - rolling_start)
    rolling_mhs = rolling_work / rolling_elapsed / 1e6
    return lifetime_mhs, rolling_mhs, len(events_copy)


def snapshot(start_time, job):
    now = time.monotonic()
    with lock:
        rates = gpu_rates[:]
        wall_rates = gpu_wall_rates[:]
        measured = gpu_rate_measured[:]
        acked = gpu_job_seq[:]
        s = dict(stats)
        prod_started = production_started_at if production_started_at is not None else start_time
        seq = current_seq
        active_ctx = contexts.get(seq)
        active_template_id = active_ctx["template_id"] if active_ctx else job["template_id"]
    hps, expected_sps = target_metrics(job)
    life_mhs, roll_mhs, roll_shares = accepted_work_rates(now, prod_started)
    found_roll_mhs, found_roll_shares = rolling_event_rate(found_events, now, prod_started)
    queued_roll_mhs, queued_roll_shares = rolling_event_rate(queued_events, now, prod_started)
    return {
        "version": VERSION,
        "capability_mode": CAPABILITY_MODE,
        "timestamp": int(time.time()),
        "uptime": int(now - start_time),
        "production_uptime": int(max(0.0, now - prod_started)),
        "height": int(job["height"]),
        "template_id": active_template_id,
        "job_seq": seq,
        "gpu_count": GPU_COUNT,
        "gpu_rates_mhs": rates,
        "gpu_wall_rates_mhs": wall_rates,
        "gpu_rates_measured": measured,
        "gpu_job_seq": acked,
        "total_mhs": sum(rates),
        "wall_total_mhs": sum(wall_rates),
        "hashes_per_share": hps,
        "expected_shares_per_sec": expected_sps,
        "accepted": s["accepted"],
        "accepted_work_hashes": s["accepted_work_hashes"],
        "found_work_hashes": s["found_work_hashes"],
        "stale_work_hashes": s["stale_work_hashes"],
        "rejected_work_hashes": s["rejected_work_hashes"],
        "old_discarded_work_hashes": s["old_discarded_work_hashes"],
        "queue_dropped_work_hashes": s["queue_dropped_work_hashes"],
        "accepted_work_mhs": life_mhs,
        "accepted_work_2m_mhs": roll_mhs,
        "accepted_work_2m_shares": roll_shares,
        "found_work_2m_mhs": found_roll_mhs,
        "found_work_2m_shares": found_roll_shares,
        "queued_work_2m_mhs": queued_roll_mhs,
        "queued_work_2m_shares": queued_roll_shares,
        "found": s["found"],
        "queued_found": s["queued_found"],
        "stale": s["stale"],
        "stale_old_height": s["stale_old_height"],
        "stale_old_template": s["stale_old_template"],
        "stale_current_template": s["stale_current_template"],
        "rejected": s["rejected"],
        "http_errors": s["http_errors"],
        "queue": share_queue.qsize(),
        "active_submissions": active_submissions,
        "queue_dropped": s["queue_dropped"],
        "old_share_discarded": s["old_share_discarded"],
        "height_regressions": s["height_regressions"],
        "job_updates": s["job_updates"],
        "id_only_refreshes": s["id_only_refreshes"],
        "capability_fetches": s["capability_fetches"],
        "capability_rebinds": s["capability_rebinds"],
        "capability_refresh_failures": s["capability_refresh_failures"],
        "capability_after_accept": s["capability_after_accept"],
        "capability_work_changes": s["capability_work_changes"],
        "capability_refresh_deferred": s["capability_refresh_deferred"],
        "capability_backoffs": s["capability_backoffs"],
        "capability_backoff_seconds": s["capability_backoff_seconds"],
        "capability_waits": s["capability_waits"],
        "capability_wait_ms": s["capability_wait_ms"],
        "get_template_calls": s["get_template_calls"],
        "get_template_avg_ms": (
            s["get_template_ms"] / max(1, s["get_template_calls"])
        ),
        "get_template_max_ms": s["get_template_max_ms"],
        "submit_calls": s["submit_calls"],
        "submit_avg_ms": s["submit_ms"] / max(1, s["submit_calls"]),
        "submit_max_ms": s["submit_max_ms"],
        "stale_responses": s["stale_responses"],
        "stale_retry_attempts": s["stale_retry_attempts"],
        "stale_recovered": s["stale_recovered"],
        "stale_retry_failed": s["stale_retry_failed"],
        "last_job_ack_ms": s["last_job_ack_ms"],
        "max_job_ack_ms": s["max_job_ack_ms"],
        "rpc_url": RPC_URL,
    }


def write_stats_file(data):
    try:
        directory = os.path.dirname(STATS_FILE)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp = STATS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
            f.write("\n")
        os.replace(tmp, STATS_FILE)
    except Exception:
        pass


def use_tui():
    if TUI in ("1", "yes", "true", "on"):
        return True
    if TUI in ("0", "no", "false", "off"):
        return False
    return sys.stdout.isatty()


def print_status(data, force=False):
    if use_tui():
        print("\033[2J\033[H", end="")
        print(f"NOID170 v{VERSION} | AriaPool | {GPU_COUNT}x CMP 170HX | persistent CUDA")
        print(f"Capability mode: {CAPABILITY_MODE}")
        print(f"Height {data['height']} | JobSeq {data['job_seq']} | {data['template_id']}")
        print(
            f"Vardiff {data['hashes_per_share']:,.0f} hashes/share | "
            f"expected ~{data['expected_shares_per_sec']:,.2f} shares/s"
        )
        print()
        measured = data["gpu_rates_measured"]
        for gpu, rate in enumerate(data["gpu_rates_mhs"]):
            mark = " " if measured[gpu] else "~"
            print(f"GPU{gpu:<2}{mark}{rate:7.2f} MH/s  job={data['gpu_job_seq'][gpu]}")
        print(f"KERNEL {data['total_mhs']:7.2f} MH/s")
        print(f"WALL   {data['wall_total_mhs']:7.2f} MH/s")
        print()
        print(
            f"Accepted {data['accepted']:,} | Stale {data['stale']:,} | "
            f"Rejected {data['rejected']:,} | Queue {data['queue']:,} | "
            f"In-flight {data['active_submissions']:,}"
        )
        print(
            f"Raw stale responses {data['stale_responses']:,} | "
            f"Retried {data['stale_retry_attempts']:,} | "
            f"Recovered {data['stale_recovered']:,} | "
            f"Retry failed {data['stale_retry_failed']:,}"
        )
        print(
            f"Work 2m: found {data['found_work_2m_mhs']:7.2f} | "
            f"queued {data['queued_work_2m_mhs']:7.2f} | "
            f"accepted {data['accepted_work_2m_mhs']:7.2f} MH/s"
        )
        print(
            f"Shares 2m: found {data['found_work_2m_shares']} | "
            f"queued {data['queued_work_2m_shares']} | "
            f"accepted {data['accepted_work_2m_shares']}"
        )
        print(
            f"Accepted-work lifetime {data['accepted_work_mhs']:7.2f} MH/s"
        )
        print(
            f"Job updates {data['job_updates']:,} | last ACK {data['last_job_ack_ms']:.1f} ms | "
            f"max ACK {data['max_job_ack_ms']:.1f} ms"
        )
        print(
            f"Capability fetches {data['capability_fetches']:,} | "
            f"rebinds {data['capability_rebinds']:,} | "
            f"refresh failures {data['capability_refresh_failures']:,}"
        )
        print(
            f"HTTP errors {data['http_errors']:,} | Dropped {data['queue_dropped']:,} | "
            f"Old discarded {data['old_share_discarded']:,} | "
            f"Height regressions {data['height_regressions']:,}"
        )
        u = data["uptime"]
        print(f"Uptime {u//3600:02d}:{(u%3600)//60:02d}:{u%60:02d}")
        sys.stdout.flush()
    elif force:
        print(
            f"STATUS height={data['height']} seq={data['job_seq']} "
            f"kernel={data['total_mhs']:.2f}MH/s "
            f"wall={data['wall_total_mhs']:.2f}MH/s "
            f"found2m={data['found_work_2m_mhs']:.2f}MH/s "
            f"queued2m={data['queued_work_2m_mhs']:.2f}MH/s "
            f"accepted2m={data['accepted_work_2m_mhs']:.2f}MH/s "
            f"found={data['found']} queued_found={data['queued_found']} "
            f"accepted={data['accepted']} stale={data['stale']} rejected={data['rejected']} "
            f"stale_classes={data['stale_old_height']}/{data['stale_old_template']}/{data['stale_current_template']} "
            f"queue={data['queue']} inflight={data['active_submissions']} "
            f"updates={data['job_updates']} id_churn={data['id_only_refreshes']} "
            f"stale_raw={data['stale_responses']} retry={data['stale_retry_attempts']} "
            f"recovered={data['stale_recovered']} retry_failed={data['stale_retry_failed']} "
            f"cap_fetch={data['capability_fetches']} cap_rebind={data['capability_rebinds']} "
            f"cap_defer={data['capability_refresh_deferred']} "
            f"cap_wait={data['capability_waits']} "
            f"get_ms={data['get_template_avg_ms']:.1f} "
            f"submit_ms={data['submit_avg_ms']:.1f} "
            f"ack_ms={data['last_job_ack_ms']:.1f}",
            flush=True,
        )


def main():
    global running, production_started_at

    start_time = time.monotonic()
    print(f"NOID170 v{VERSION}", flush=True)
    print(f"RPC: {RPC_URL}", flush=True)
    print(f"Detected GPUs: {GPU_COUNT}", flush=True)
    print(f"Expected CMP 170HX rate: {CARD_MH:.2f} MH/s/card", flush=True)

    job = wait_for_job()
    show_target("Initial", job)
    job = warm_up_vardiff(job)

    # Keep RPC timing comparable even when vardiff warmup takes different time.
    with lock:
        for key in (
            "get_template_calls", "get_template_ms", "get_template_max_ms",
            "submit_calls", "submit_ms", "submit_max_ms",
        ):
            stats[key] = 0 if key.endswith("calls") else 0.0

    print(f"Starting {SUBMIT_THREADS} persistent HTTP submitters...", flush=True)
    submit_threads = []
    for i in range(SUBMIT_THREADS):
        t = threading.Thread(target=submitter, args=(i,), daemon=True)
        t.start()
        submit_threads.append(t)

    workers = start_daemons()
    production_started_at = time.monotonic()
    invalidate_older_heights(int(job["height"]))
    send_job(workers, job, "initial")

    job_started = time.monotonic()
    last_poll = 0.0
    last_status = 0.0
    last_log_status = 0.0
    freshest = job

    try:
        while running:
            now = time.monotonic()

            for gpu, proc, _, _ in workers:
                if proc.poll() is not None:
                    raise RuntimeError(f"GPU {gpu} daemon exited with code {proc.returncode}")

            if now - last_status >= 1.0:
                data = snapshot(start_time, job)
                write_stats_file(data)
                log_now = (not use_tui() and now - last_log_status >= 10.0)
                print_status(data, force=log_now)
                if log_now:
                    last_log_status = now
                last_status = now

            candidate = take_urgent_candidate()
            force_refresh = refresh_now_event.is_set()
            with lock:
                retry_not_before = capability_retry_not_before
            fetch_allowed = (
                CAPABILITY_MODE != "adaptive"
                or now >= retry_not_before
            )
            if candidate is not None:
                refresh_now_event.clear()
                with capability_flow_lock:
                    job, switched = apply_candidate(
                        workers, job, candidate, now, "submission-work-change"
                    )
                freshest = candidate
                if switched:
                    job_started = now
            elif (
                force_refresh or now - last_poll >= POLL_INTERVAL
            ) and fetch_allowed:
                refresh_now_event.clear()
                last_poll = now
                with capability_flow_lock:
                    if force_refresh:
                        reset_rpc_session()
                    try:
                        candidate, _retry = fetch_job_once()
                        with lock:
                            stats["capability_fetches"] += 1
                    except Exception:
                        candidate, _retry = None, 0.05
                        with lock:
                            stats["http_errors"] += 1
                    if candidate is not None:
                        if CAPABILITY_MODE != "baseline":
                            clear_capability_backoff()
                        job, switched = apply_candidate(
                            workers, job, candidate, now, "poll"
                        )
                    else:
                        if CAPABILITY_MODE != "baseline":
                            note_capability_backoff(_retry)
                        switched = False
                if candidate is not None:
                    freshest = candidate
                if switched:
                    job_started = now

            if time.monotonic() - job_started >= HARD_EXPIRY_AGE:
                if CAPABILITY_MODE == "baseline":
                    with capability_flow_lock:
                        fresh = wait_for_job(minimum_height=int(job["height"]))
                        with lock:
                            stats["capability_fetches"] += 1
                        job, _switched = apply_candidate(
                            workers, job, fresh, time.monotonic(), "expiry"
                        )
                    job_started = time.monotonic()
                    freshest = fresh
                elif fetch_allowed:
                    with capability_flow_lock:
                        try:
                            fresh, retry = fetch_job_once()
                            with lock:
                                stats["capability_fetches"] += 1
                        except Exception:
                            fresh, retry = None, 0.05
                            with lock:
                                stats["http_errors"] += 1
                        if fresh is not None:
                            clear_capability_backoff()
                            job, _switched = apply_candidate(
                                workers, job, fresh, time.monotonic(), "expiry"
                            )
                        else:
                            note_capability_backoff(retry)
                    if fresh is not None:
                        job_started = time.monotonic()
                        freshest = fresh

            time.sleep(0.02)

    finally:
        running = False
        try:
            stop_daemons(workers)
        except Exception:
            pass
        data = snapshot(start_time, job)
        write_stats_file(data)
        for _ in submit_threads:
            try:
                share_queue.put_nowait(None)
            except queue.Full:
                break
        print("NOID170 stopped.", flush=True)


if __name__ == "__main__":
    main()
