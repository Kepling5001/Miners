#!/usr/bin/env bash
# Quanpool 6.0.0 -> HiveOS custom miner flight-sheet adapter.

[[ -t 1 ]] || exec 2>/dev/null

DIR="/hive/miners/custom/quanpool"
. "$DIR/h-manifest.conf" 2>/dev/null || true

# Hive expands %WAL% / %WORKER_NAME% before this script is called.
TOKEN="${CUSTOM_TEMPLATE:-}"
NODE="${CUSTOM_URL:-}"
EXTRA="${CUSTOM_USER_CONFIG:-}"

# Sensible mainnet defaults. Pool URL in the flight sheet can override NODE.
[[ -n "$NODE" ]] || NODE="mainnet.quanpool.com:9834"

# Quanpool expects host:port, not a stratum/http URL.
NODE="${NODE#*://}"
NODE="${NODE%%/*}"

# Current Quanpool mainnet certificate fingerprint (2026-09-10).
TLS_DEFAULT="87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6"

if [[ -z "$TOKEN" ]]; then
  echo "Quanpool: Wallet/worker template is empty. Use %WAL%.%WORKER_NAME% in the Custom Miner setup." >&2
fi

# Build an eval-safe command line. Extra config is intentionally appended verbatim
# so normal HiveOS Custom Miner extra arguments continue to work.
{
  printf 'CLI_ARGS='
  printf '%q ' serve --auth-token "$TOKEN" --node-addr "$NODE"

  case " $EXTRA " in
    *" --tls-cert-sha256 "*|*" --tls-cert-sha256="*|*" --tls-cert-sha256-file "*|*" --tls-cert-sha256-file="*) ;;
    *) printf '%q ' --tls-cert-sha256 "$TLS_DEFAULT" ;;
  esac

  case " $EXTRA " in
    *" --cpu-workers "*|*" --cpu-workers="*) ;;
    *) printf '%q ' --cpu-workers 0 ;;
  esac

  case " $EXTRA " in
    *" --metrics-port "*|*" --metrics-port="*) ;;
    *) printf '%q ' --metrics-port 9900 ;;
  esac

  printf '%s\n' "$EXTRA"
} > "$CUSTOM_CONFIG_FILENAME"
