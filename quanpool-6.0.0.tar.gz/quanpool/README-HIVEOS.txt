Quanpool 6.0.0 - HiveOS Custom Miner wrapper
=============================================

This package wraps the official Quanpool Linux x86_64 miner. The official binary
is downloaded on first launch from:
https://download.quanpool.com/quanpool-miner-6.0.0-linux-x86_64

Recommended HiveOS flight-sheet setup
-------------------------------------
Coin:              QTC / Quantus (or your Quantus wallet entry)
Wallet:            your qz... payout address
Pool:              Configure in miner
Miner:             Custom

Custom Miner fields:
Miner name:         quanpool
Installation URL:  URL where you host quanpool-6.0.0.tar.gz
Hash algorithm:     quantus
Wallet template:    %WAL%.%WORKER_NAME%
Pool URL:           mainnet.quanpool.com:9834
Pass:               x   (ignored by this wrapper)
Extra config:       leave blank initially

Defaults supplied by the wrapper:
  --cpu-workers 0
  --metrics-port 9900
  --tls-cert-sha256 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6

Useful optional Extra config examples:
  --gpu-devices 1        # first GPU only
  --gpu-retune           # force launch-geometry retune; remove after tuning
  --gpu-throttle-ms 5    # pause 5 ms between batches

Do NOT set --gpu-devices for an all-GPU production rig; Quanpool auto-detects all GPUs.

Manual install (if you copy this tarball directly to the rig):
  mkdir -p /hive/miners/custom
  tar -xzf /path/to/quanpool-6.0.0.tar.gz -C /hive/miners/custom
  chmod +x /hive/miners/custom/quanpool/h-*.sh

Stats:
  h-stats.sh queries http://127.0.0.1:9900/hive-stats and passes Quanpool's
  native Hive JSON into the Hive agent. It also tolerates several common
  total-hashrate representations when deriving Hive's required $khs variable.

CMP100-210 note:
  The volatile GV100 unlock is separate from this wrapper. Apply/verify the
  unlock before starting the flight sheet after a reboot.
