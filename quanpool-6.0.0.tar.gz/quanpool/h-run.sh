#!/usr/bin/env bash
set -uo pipefail

DIR="/hive/miners/custom/quanpool"
BIN="$DIR/quanpool-miner"
OFFICIAL_URL="https://download.quanpool.com/quanpool-miner-6.0.0-linux-x86_64"

. "$DIR/h-manifest.conf"
[[ -s "$CUSTOM_CONFIG_FILENAME" ]] || . "$DIR/h-config.sh"
. "$CUSTOM_CONFIG_FILENAME"

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"

# The wrapper archive intentionally contains only the Hive integration scripts.
# Pull the exact official Quanpool binary on first launch so we do not redistribute
# or alter the miner binary.
if [[ ! -x "$BIN" ]]; then
  TMP="$BIN.download.$$"
  rm -f "$TMP"
  echo "Quanpool: downloading official 6.0.0 binary..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --connect-timeout 15 --retry 3 "$OFFICIAL_URL" -o "$TMP"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TMP" "$OFFICIAL_URL"
  else
    echo "Quanpool: ERROR: neither curl nor wget is installed." >&2
    exit 2
  fi
  chmod 0755 "$TMP"
  mv -f "$TMP" "$BIN"
  echo "Quanpool: official binary installed: $(sha256sum "$BIN" | awk '{print $1}')"
fi

# Turn the generated CLI string into argv while preserving normal quoted Hive extras.
eval "set -- $CLI_ARGS"

# Keep a Hive miner log while retaining live screen output.
# PIPESTATUS preserves the miner's actual exit code rather than tee's.
set +e
stdbuf -oL -eL "$BIN" "$@" 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
rc=${PIPESTATUS[0]}
exit "$rc"
