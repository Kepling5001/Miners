#!/usr/bin/env python3

import http.client
import json
import os
import queue
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin", "noid_multigpu_daemon")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
GPU_COUNT = int(os.environ.get("NOID_TEST_GPU_COUNT", "0") or "0")


def detect_gpus():
    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([line for line in p.stdout.splitlines() if line.strip()])


if GPU_COUNT <= 0:
    GPU_COUNT = detect_gpus()
if not KEY:
    raise SystemExit("ERROR: NOID_MINING_KEY is not set")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        conn.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-multigpu-protocol/0.6.6",
                "Accept": "*/*",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def work_key(job):
    return int(job["height"]), job["pow_fields_hex"], job["difficulty_target_hex"]


proc = subprocess.Popen(
    [BIN, "--daemon-multi", str(GPU_COUNT), str(time.time_ns() & 0x7FFFFFFFFFFFFFFF)],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    bufsize=1,
)

events = queue.Queue()
shares = queue.Queue()


def parse_tagged(line):
    parts = line.strip().split(maxsplit=2)
    if len(parts) != 3 or parts[0] != "GPU":
        return None, line.strip()
    try:
        gpu = int(parts[1])
    except ValueError:
        return None, line.strip()
    return gpu, parts[2]


def stderr_reader():
    for raw in proc.stderr:
        gpu, line = parse_tagged(raw)
        if gpu is not None:
            events.put((gpu, line))


def stdout_reader():
    for raw in proc.stdout:
        gpu, line = parse_tagged(raw)
        if gpu is not None and line.startswith("SHARE "):
            shares.put((gpu, line))


threading.Thread(target=stderr_reader, daemon=True).start()
threading.Thread(target=stdout_reader, daemon=True).start()


def wait_all(prefix, timeout=45):
    seen = set()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(f"multi-GPU daemon exited with {proc.returncode}")
        try:
            gpu, line = events.get(timeout=0.5)
        except queue.Empty:
            continue
        if line.startswith(prefix):
            seen.add(gpu)
            if len(seen) == GPU_COUNT:
                return
    missing = sorted(set(range(GPU_COUNT)) - seen)
    raise RuntimeError(f"timeout waiting for {prefix}; missing GPUs {missing}")


def send(seq, job):
    proc.stdin.write(
        f"JOB {seq} {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"
    )
    proc.stdin.flush()


print("===== MULTI-GPU DAEMON PROTOCOL TEST =====")
print("PID:", proc.pid, "GPUs:", GPU_COUNT)
wait_all("READY ")
print("all GPU workers: READY")

job = get_job()
seq = 1
send(seq, job)
wait_all(f"JOBACK {seq} ")
print("initial work: acknowledged by every GPU")

seq += 1
send(seq, job)
wait_all(f"JOBACK {seq} TAG")
print("same-work TAG: acknowledged by every GPU")
wait_all("STAT ", timeout=15)
print("hash statistics: received from every GPU")

deadline = time.monotonic() + 90
next_poll = 0.0
accepted = False
while time.monotonic() < deadline and not accepted:
    now = time.monotonic()
    if now >= next_poll:
        fresh = get_job()
        if work_key(fresh) != work_key(job):
            job = fresh
            seq += 1
            send(seq, job)
            wait_all(f"JOBACK {seq} ")
            print("live work switch: acknowledged by every GPU")
        else:
            job["template_id"] = fresh["template_id"]
        next_poll = now + 0.35

    try:
        gpu, line = shares.get(timeout=0.10)
    except queue.Empty:
        continue
    parts = line.split()
    if len(parts) != 3 or int(parts[1]) != seq:
        continue

    fresh = get_job()
    if work_key(fresh) != work_key(job):
        job = fresh
        seq += 1
        send(seq, job)
        wait_all(f"JOBACK {seq} ")
        continue
    answer = rpc("paranoid_submitBlock", [fresh["template_id"], parts[2]])
    print(f"GPU {gpu} share submit:", json.dumps(answer, sort_keys=True))
    accepted = answer.get("result") == "share accepted"

if not accepted:
    raise RuntimeError("multi-GPU daemon produced no accepted share within 90 seconds")

proc.stdin.write("STOP\n")
proc.stdin.flush()
try:
    proc.wait(timeout=8)
except subprocess.TimeoutExpired:
    proc.terminate()
    proc.wait(timeout=5)

print("exit:", proc.returncode)
if proc.returncode != 0:
    raise RuntimeError("multi-GPU daemon did not exit cleanly")
print("MULTI-GPU DAEMON PROTOCOL: PASS")

