# NOID170 v0.6.6 multi-GPU CPU A/B

This is a non-installing feasibility test. It compares:

- `baseline`: one CUDA daemon process per GPU, matching current HiveOS operation.
- `multi`: one process containing one blocking CUDA worker thread per GPU.

Both modes use the exact same proven `all_nv`, `r2lop3`, `r4top`, `prod2`,
64-blocks-per-SM CUDA kernel. Only the host process architecture changes.

## Run on OctominerTEST

```bash
cd /home/user/noid170-v0.6.6-multigpu-cpu-ab
miner stop
./build-on-rig.sh

export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-multigpu-cpu.sh

miner start
```

The default benchmark uses every visible GPU, warms each mode for 30 seconds,
then measures it for 120 seconds. Override only when needed:

```bash
NOID_TEST_GPU_COUNT=4 NOID_CPU_WARMUP_SEC=30 NOID_CPU_SAMPLE_SEC=120 ./test-multigpu-cpu.sh
```

Paste the complete `FINAL MULTI-GPU CPU A/B` table and protocol result into chat.
Do not install the experimental binary as a HiveOS custom miner.

