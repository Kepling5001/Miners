#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

cleanup() {
  pkill -f "$ROOT/bin/noid_multigpu_daemon" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

[[ -x "$ROOT/bin/noid_multigpu_daemon" ]] || {
  echo "ERROR: run ./build-on-rig.sh first"
  exit 1
}

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Run: miner stop"
  exit 1
fi

if [[ -z "${NOID_MINING_KEY:-}" ]]; then
  echo "ERROR: export NOID_MINING_KEY='your_address.worker' first"
  exit 1
fi

echo "This A/B does not install or replace the HiveOS miner."
echo "Default duration: about 6 minutes on the 4-GPU test rig."
echo

python3 "$ROOT/offline_verify.py"
"$ROOT/bin/test_gf_all_nv"
python3 "$ROOT/test_multigpu_protocol.py"
python3 "$ROOT/benchmark_multigpu_cpu.py"

echo
echo "Restart normal HiveOS mining when finished: miner start"
