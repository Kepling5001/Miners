#!/usr/bin/env python3

import http.client
import json
import math
import os
import queue
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin", "noid_multigpu_daemon")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
GPU_COUNT = int(os.environ.get("NOID_TEST_GPU_COUNT", "0") or "0")
WARMUP = max(10, int(os.environ.get("NOID_CPU_WARMUP_SEC", "30")))
SAMPLE = max(30, int(os.environ.get("NOID_CPU_SAMPLE_SEC", "120")))
TAG_INTERVAL = max(5.0, float(os.environ.get("NOID_CPU_TAG_INTERVAL", "10")))
CLK_TCK = os.sysconf(os.sysconf_names["SC_CLK_TCK"])


def detect_gpus():
    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([line for line in p.stdout.splitlines() if line.strip()])


if GPU_COUNT <= 0:
    GPU_COUNT = detect_gpus()
if not KEY:
    raise SystemExit("ERROR: NOID_MINING_KEY is not set")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        conn.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-multigpu-cpu-ab/0.6.6",
                "Accept": "*/*",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def work_key(job):
    return int(job["height"]), job["pow_fields_hex"], job["difficulty_target_hex"]


def process_ticks(pid):
    try:
        text = open(f"/proc/{pid}/stat", "r", encoding="utf-8").read()
    except OSError:
        return 0
    rest = text[text.rfind(")") + 2:].split()
    return int(rest[11]) + int(rest[12])


def process_threads(pid):
    try:
        with open(f"/proc/{pid}/status", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("Threads:"):
                    return int(line.split()[1])
    except OSError:
        pass
    return 0


def system_counters():
    counters = {}
    with open("/proc/stat", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("cpu "):
                values = [int(x) for x in line.split()[1:]]
                counters["total"] = sum(values)
                counters["idle"] = values[3] + (values[4] if len(values) > 4 else 0)
            elif line.startswith("intr "):
                counters["intr"] = int(line.split()[1])
            elif line.startswith("ctxt "):
                counters["ctxt"] = int(line.split()[1])
    return counters


def percentile(values, fraction):
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(fraction * len(ordered)) - 1))
    return ordered[index]


class DaemonGroup:
    def __init__(self, mode):
        self.mode = mode
        self.procs = []
        self.ready = set()
        self.acks = {}
        self.send_times = {}
        self.ack_modes = {}
        self.ack_samples = {"TAG": [], "FULL": [], "TARGET": []}
        self.rate_samples = []
        self.lock = threading.Lock()
        self.cv = threading.Condition(self.lock)

    @staticmethod
    def parse_tagged(raw):
        parts = raw.strip().split(maxsplit=2)
        if len(parts) != 3 or parts[0] != "GPU":
            return None, raw.strip()
        try:
            return int(parts[1]), parts[2]
        except ValueError:
            return None, raw.strip()

    def stderr_reader(self, proc, fixed_gpu):
        for raw in proc.stderr:
            if fixed_gpu is None:
                gpu, line = self.parse_tagged(raw)
            else:
                gpu, line = fixed_gpu, raw.strip()
            if gpu is None:
                continue
            now = time.monotonic()
            with self.cv:
                if line.startswith("READY "):
                    self.ready.add(gpu)
                elif line.startswith("JOBACK "):
                    parts = line.split()
                    if len(parts) >= 3:
                        seq = int(parts[1])
                        mode = parts[2]
                        seen = self.acks.setdefault(seq, set())
                        seen.add(gpu)
                        self.ack_modes[seq] = mode
                        if len(seen) == GPU_COUNT and seq in self.send_times:
                            elapsed = (now - self.send_times[seq]) * 1000.0
                            self.ack_samples.setdefault(mode, []).append(elapsed)
                elif line.startswith("STAT "):
                    parts = line.split()
                    if len(parts) >= 6:
                        try:
                            self.rate_samples.append(
                                (now, gpu, float(parts[1]), float(parts[5]))
                            )
                        except ValueError:
                            pass
                self.cv.notify_all()

    def stdout_reader(self, proc, fixed_gpu):
        for _raw in proc.stdout:
            pass

    def start(self):
        salt = time.time_ns() & 0x7FFFFFFFFFFFFFFF
        if self.mode == "baseline":
            for gpu in range(GPU_COUNT):
                env = os.environ.copy()
                env["CUDA_VISIBLE_DEVICES"] = str(gpu)
                proc = subprocess.Popen(
                    [BIN, "--daemon", str(salt + gpu + 1)],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    env=env,
                )
                self.procs.append(proc)
                threading.Thread(
                    target=self.stderr_reader, args=(proc, gpu), daemon=True
                ).start()
                threading.Thread(
                    target=self.stdout_reader, args=(proc, gpu), daemon=True
                ).start()
        else:
            proc = subprocess.Popen(
                [BIN, "--daemon-multi", str(GPU_COUNT), str(salt)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
            self.procs.append(proc)
            threading.Thread(
                target=self.stderr_reader, args=(proc, None), daemon=True
            ).start()
            threading.Thread(
                target=self.stdout_reader, args=(proc, None), daemon=True
            ).start()

        deadline = time.monotonic() + 60
        with self.cv:
            while len(self.ready) < GPU_COUNT and time.monotonic() < deadline:
                for proc in self.procs:
                    if proc.poll() is not None:
                        raise RuntimeError(
                            f"{self.mode} daemon exited during startup: {proc.returncode}"
                        )
                self.cv.wait(timeout=0.25)
        if len(self.ready) != GPU_COUNT:
            raise RuntimeError(f"{self.mode}: not all GPUs became READY")

    def send(self, seq, job):
        line = f"JOB {seq} {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"
        with self.lock:
            self.send_times[seq] = time.monotonic()
        for proc in self.procs:
            if proc.poll() is not None:
                raise RuntimeError(f"{self.mode} daemon exited: {proc.returncode}")
            proc.stdin.write(line)
            proc.stdin.flush()

    def wait_ack(self, seq, timeout=20):
        deadline = time.monotonic() + timeout
        with self.cv:
            while len(self.acks.get(seq, set())) < GPU_COUNT and time.monotonic() < deadline:
                self.cv.wait(timeout=0.20)
        if len(self.acks.get(seq, set())) != GPU_COUNT:
            raise RuntimeError(f"{self.mode}: timeout waiting for JOBACK {seq}")

    def stop(self):
        for proc in self.procs:
            if proc.poll() is None:
                try:
                    proc.stdin.write("STOP\n")
                    proc.stdin.flush()
                except Exception:
                    pass
        deadline = time.monotonic() + 10
        for proc in self.procs:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=max(0.1, deadline - time.monotonic()))
                except subprocess.TimeoutExpired:
                    proc.terminate()
        for proc in self.procs:
            if proc.poll() is None:
                proc.kill()


def run_variant(mode):
    print(f"===== RUN {mode.upper()} =====", flush=True)
    group = DaemonGroup(mode)
    group.start()
    job = get_job()
    seq = 1
    group.send(seq, job)
    group.wait_ack(seq)

    started = time.monotonic()
    sample_start = started + WARMUP
    finish = sample_start + SAMPLE
    next_poll = 0.0
    next_tag = started + TAG_INTERVAL
    measuring = False
    p0 = None
    s0 = None
    t0 = None

    while time.monotonic() < finish:
        now = time.monotonic()
        for proc in group.procs:
            if proc.poll() is not None:
                raise RuntimeError(f"{mode} daemon exited with {proc.returncode}")

        if not measuring and now >= sample_start:
            measuring = True
            t0 = now
            p0 = sum(process_ticks(proc.pid) for proc in group.procs)
            s0 = system_counters()
            with group.lock:
                group.rate_samples.clear()
                for values in group.ack_samples.values():
                    values.clear()
            print(f"{mode}: measurement window started", flush=True)

        if now >= next_poll:
            fresh = get_job()
            if work_key(fresh) != work_key(job):
                job = fresh
                seq += 1
                group.send(seq, job)
                group.wait_ack(seq)
            else:
                job["template_id"] = fresh["template_id"]
            next_poll = now + 0.5

        if now >= next_tag:
            seq += 1
            group.send(seq, job)
            group.wait_ack(seq)
            next_tag = now + TAG_INTERVAL

        time.sleep(0.05)

    t1 = time.monotonic()
    p1 = sum(process_ticks(proc.pid) for proc in group.procs)
    s1 = system_counters()
    threads = sum(process_threads(proc.pid) for proc in group.procs)

    with group.lock:
        samples = list(group.rate_samples)
        ack_samples = {name: list(values) for name, values in group.ack_samples.items()}

    group.stop()

    elapsed = max(0.001, t1 - t0)
    daemon_cpu = (p1 - p0) / CLK_TCK / elapsed * 100.0
    total_delta = s1["total"] - s0["total"]
    idle_delta = s1["idle"] - s0["idle"]
    busy = 100.0 * (total_delta - idle_delta) / max(1, total_delta)
    irq_s = (s1["intr"] - s0["intr"]) / elapsed
    ctxt_s = (s1["ctxt"] - s0["ctxt"]) / elapsed

    per_gpu_kernel = []
    per_gpu_wall = []
    for gpu in range(GPU_COUNT):
        gpu_rows = [row for row in samples if row[1] == gpu]
        if not gpu_rows:
            raise RuntimeError(f"{mode}: no rate samples for GPU {gpu}")
        per_gpu_kernel.append(statistics.mean(row[2] for row in gpu_rows))
        per_gpu_wall.append(statistics.mean(row[3] for row in gpu_rows))

    tags = ack_samples.get("TAG", [])
    fulls = ack_samples.get("FULL", [])
    result = {
        "variant": mode,
        "processes": len(group.procs),
        "threads": threads,
        "kernel": sum(per_gpu_kernel),
        "wall": sum(per_gpu_wall),
        "daemon_cpu": daemon_cpu,
        "busy": busy,
        "irq_s": irq_s,
        "ctxt_s": ctxt_s,
        "tag_p50": statistics.median(tags) if tags else 0.0,
        "tag_p95": percentile(tags, 0.95),
        "full_p50": statistics.median(fulls) if fulls else 0.0,
    }
    print(
        f"{mode}: wall={result['wall']:.2f} MH/s daemonCPU={daemon_cpu:.1f}% "
        f"busy={busy:.1f}% irq/s={irq_s:.0f} ctxt/s={ctxt_s:.0f}",
        flush=True,
    )
    return result


print("===== MULTI-GPU CPU ARCHITECTURE A/B =====")
print(f"GPUs: {GPU_COUNT}  warmup: {WARMUP}s/mode  sample: {SAMPLE}s/mode")
print("Kernel: identical all_nv + r2lop3 + r4top + prod2, b64/stat8")

results = []
try:
    results.append(run_variant("baseline"))
    time.sleep(5)
    results.append(run_variant("multi"))
finally:
    subprocess.run(
        ["pkill", "-f", os.path.basename(BIN)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )

baseline, candidate = results
cpu_change = 100.0 * (candidate["daemon_cpu"] / baseline["daemon_cpu"] - 1.0)
wall_change = 100.0 * (candidate["wall"] / baseline["wall"] - 1.0)

print()
print("===== FINAL MULTI-GPU CPU A/B =====")
print(
    f"{'variant':<10} {'proc':>4} {'thr':>4} {'kernel':>10} {'wall MH/s':>10} "
    f"{'daemonCPU':>10} {'busy':>8} {'irq/s':>9} {'ctxt/s':>10} "
    f"{'TAG p50':>9} {'TAG p95':>9} {'FULL p50':>10}"
)
for row in results:
    print(
        f"{row['variant']:<10} {row['processes']:>4} {row['threads']:>4} "
        f"{row['kernel']:>10.2f} {row['wall']:>10.2f} {row['daemon_cpu']:>9.1f}% "
        f"{row['busy']:>7.1f}% {row['irq_s']:>9.0f} {row['ctxt_s']:>10.0f} "
        f"{row['tag_p50']:>8.1f} {row['tag_p95']:>8.1f} {row['full_p50']:>9.1f}"
    )

print()
print(f"multi daemon CPU change: {cpu_change:+.1f}%")
print(f"multi wall hashrate change: {wall_change:+.2f}%")
if cpu_change <= -15.0 and wall_change >= -0.5:
    print("decision: PASS — worthwhile production-integration candidate")
elif cpu_change < 0.0 and wall_change >= -0.5:
    print("decision: MARGINAL — CPU improved, but validate on the 12-GPU rig")
else:
    print("decision: FAIL — retain the current one-process-per-GPU architecture")
print()
print("Paste this complete result into chat. This test did not install a miner.")

