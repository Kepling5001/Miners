# NOID v0.6.4 warp-cooperative binary tensor feasibility A/B

This bundle tests whether NVIDIA single-bit tensor operations can accelerate
the real fixed linear maps in the NOID Poseidon kernel. It does **not** install
or replace the production HiveOS custom miner.

The test maps eight independent 128-bit field values onto one warp. Four lanes
hold each value. One `mma.m8n8k128.and.popc` produces eight output bits for all
eight values; parity converts the popcount result into a GF(2) dot product.
Sixteen instructions therefore evaluate one complete 128x128 binary linear
map for the warp.

The exact tested maps are:

- field squaring modulo `x^128 + x^7 + x^2 + x + 1`;
- partial-MDS multipliers D0, D1, D2, and D3;
- factorized full-MDS multipliers 2 and 4.

The GPU oracle compares every BMMA result against both the current optimized
CLMAD implementation and a separate host reference on 8,192 vectors per map.
The benchmark reports a one-pass path and a 64-map resident chain. The resident
chain includes matrix loads and parity packing, but assumes the miner remains
in the four-lanes-per-field-element layout between operations.

## Run on OctominerTEST

```bash
cd /home/user/noid170-v0.6.4-bmma-linear-ab
miner stop
./build-on-rig.sh
./test-bmma-linear.sh
miner start
```

No `NOID_MINING_KEY` is required. The test never contacts the pool.

The integration gate is intentionally strict: the weighted fixed-linear path
must beat CLMAD by more than 10%. A full miner candidate would still require a
correct and fast four-lane cooperative implementation of nonlinear GF
multiplication, followed by the normal Poseidon and persistent-worker oracles.
