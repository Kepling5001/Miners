#include <cuda_runtime.h>

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(call) do {                                                   \
    const cudaError_t error_ = (call);                                       \
    if (error_ != cudaSuccess) {                                             \
        std::fprintf(stderr, "CUDA error at %s:%d: %s\n",                  \
                     __FILE__, __LINE__, cudaGetErrorString(error_));         \
        std::exit(1);                                                        \
    }                                                                        \
} while (0)

constexpr int kTransforms = 7;
constexpr int kTiles = 16;
constexpr int kWarp = 32;
constexpr int kRowsPerWarp = 8;
constexpr int kThreads = 256;
constexpr int kChain = 64;

static const char *kNames[kTransforms] = {
    "square", "D0", "D1", "D2", "D3", "mul2", "mul4"
};

static const U128 kConstants[kTransforms] = {
    {0ULL, 0ULL},
    {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
    {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
    {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
    {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL},
    {0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL},
    {0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL}
};

/*
 * Matrix layout follows PTX mma.m8n8k128 exactly:
 *   lane >> 2 : B column inside an 8-column tile
 *   lane & 3  : 32-bit slice of the 128-row B column
 */
__device__ __align__(128)
unsigned int NOID_BMMA_MATRIX[kTransforms][kTiles][kWarp];

static inline U128 host_xor(U128 a, U128 b)
{
    return {a.lo ^ b.lo, a.hi ^ b.hi};
}

static inline U128 host_xtime(U128 a)
{
    const unsigned long long carry = a.hi >> 63;
    U128 out{a.lo << 1, (a.hi << 1) | (a.lo >> 63)};
    if (carry)
        out.lo ^= 0x87ULL;
    return out;
}

static U128 host_mul(U128 a, U128 b)
{
    U128 out{0ULL, 0ULL};
    for (int bit = 0; bit < 128; ++bit) {
        const unsigned long long selected =
            bit < 64 ? ((b.lo >> bit) & 1ULL)
                     : ((b.hi >> (bit - 64)) & 1ULL);
        if (selected)
            out = host_xor(out, a);
        a = host_xtime(a);
    }
    return out;
}

static U128 host_transform(int transform, U128 x)
{
    return transform == 0 ? host_mul(x, x)
                          : host_mul(kConstants[transform], x);
}

static inline unsigned host_bit(U128 x, int bit)
{
    return bit < 64 ? unsigned((x.lo >> bit) & 1ULL)
                    : unsigned((x.hi >> (bit - 64)) & 1ULL);
}

static std::array<unsigned int, kTransforms * kTiles * kWarp>
build_matrices()
{
    std::array<unsigned int, kTransforms * kTiles * kWarp> matrices{};
    for (int transform = 0; transform < kTransforms; ++transform) {
        for (int input_bit = 0; input_bit < 128; ++input_bit) {
            U128 basis{0ULL, 0ULL};
            if (input_bit < 64)
                basis.lo = 1ULL << input_bit;
            else
                basis.hi = 1ULL << (input_bit - 64);
            const U128 image = host_transform(transform, basis);

            for (int output_bit = 0; output_bit < 128; ++output_bit) {
                if (!host_bit(image, output_bit))
                    continue;
                const int tile = output_bit >> 3;
                const int column = output_bit & 7;
                const int slice = input_bit >> 5;
                const int lane = column * 4 + slice;
                const int offset =
                    (transform * kTiles + tile) * kWarp + lane;
                matrices[offset] |= 1U << (input_bit & 31);
            }
        }
    }
    return matrices;
}

template<int Transform>
__device__ __forceinline__ U128 scalar_transform(U128 x)
{
    if constexpr (Transform == 0) {
        return square_flat(x);
    } else if constexpr (Transform == 1) {
        return gf_mul({0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL}, x);
    } else if constexpr (Transform == 2) {
        return gf_mul({0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL}, x);
    } else if constexpr (Transform == 3) {
        return gf_mul({0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL}, x);
    } else if constexpr (Transform == 4) {
        return gf_mul({0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}, x);
    } else if constexpr (Transform == 5) {
        return gf_mul({0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL}, x);
    } else {
        return gf_mul({0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL}, x);
    }
}

__device__ __forceinline__
unsigned int bmma_transform(
    unsigned int input_slice,
    const unsigned int *matrix)
{
    const int lane = int(threadIdx.x) & 31;
    unsigned int output_slice = 0U;

    #pragma unroll
    for (int tile = 0; tile < kTiles; ++tile) {
        int d0;
        int d1;
        const int zero = 0;
        const unsigned int b = matrix[tile * kWarp + lane];
        asm volatile(
            "mma.sync.aligned.m8n8k128.row.col.s32.b1.b1.s32.and.popc "
            "{%0, %1}, {%2}, {%3}, {%4, %5};"
            : "=r"(d0), "=r"(d1)
            : "r"(input_slice), "r"(b), "r"(zero), "r"(zero));
        output_slice |= (unsigned(d0) & 1U) << (tile * 2);
        output_slice |= (unsigned(d1) & 1U) << (tile * 2 + 1);
    }
    return output_slice;
}

template<int Transform, int Rounds>
__global__ void scalar_kernel(const U128 *input, U128 *output, int count)
{
    const int index = int(blockIdx.x) * int(blockDim.x) + int(threadIdx.x);
    if (index >= count)
        return;
    U128 value = input[index];
    #pragma unroll 1
    for (int round = 0; round < Rounds; ++round)
        value = scalar_transform<Transform>(value);
    output[index] = value;
}

template<int Transform, int Rounds>
__global__ void bmma_kernel(const U128 *input, U128 *output, int count)
{
    __shared__ unsigned int matrix[kTiles * kWarp];
    const unsigned int *global_matrix = &NOID_BMMA_MATRIX[Transform][0][0];
    for (int index = int(threadIdx.x); index < kTiles * kWarp;
         index += int(blockDim.x)) {
        matrix[index] = global_matrix[index];
    }
    __syncthreads();

    const int lane = int(threadIdx.x) & 31;
    const int warp_in_block = int(threadIdx.x) >> 5;
    const int warps_per_block = int(blockDim.x) >> 5;
    const int warp_index = int(blockIdx.x) * warps_per_block + warp_in_block;
    const int base = warp_index * kRowsPerWarp;
    if (base >= count)
        return;

    const int row = lane >> 2;
    const int slice = lane & 3;
    const unsigned int *input_words =
        reinterpret_cast<const unsigned int *>(&input[base + row]);
    unsigned int value = input_words[slice];

    #pragma unroll 1
    for (int round = 0; round < Rounds; ++round)
        value = bmma_transform(value, matrix);

    unsigned int *output_words =
        reinterpret_cast<unsigned int *>(&output[base + row]);
    output_words[slice] = value;
}

template<int Rounds>
static void launch_scalar(
    int transform,
    const U128 *input,
    U128 *output,
    int count,
    cudaStream_t stream = nullptr)
{
    const int blocks = (count + kThreads - 1) / kThreads;
    switch (transform) {
    case 0: scalar_kernel<0, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 1: scalar_kernel<1, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 2: scalar_kernel<2, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 3: scalar_kernel<3, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 4: scalar_kernel<4, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 5: scalar_kernel<5, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    default: scalar_kernel<6, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    }
}

template<int Rounds>
static void launch_bmma(
    int transform,
    const U128 *input,
    U128 *output,
    int count,
    cudaStream_t stream = nullptr)
{
    constexpr int warps_per_block = kThreads / kWarp;
    const int warps = (count + kRowsPerWarp - 1) / kRowsPerWarp;
    const int blocks = (warps + warps_per_block - 1) / warps_per_block;
    switch (transform) {
    case 0: bmma_kernel<0, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 1: bmma_kernel<1, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 2: bmma_kernel<2, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 3: bmma_kernel<3, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 4: bmma_kernel<4, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    case 5: bmma_kernel<5, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    default: bmma_kernel<6, Rounds><<<blocks, kThreads, 0, stream>>>(input, output, count); break;
    }
}

template<int Rounds>
static double benchmark_variant(
    bool use_bmma,
    int transform,
    const U128 *input,
    U128 *output,
    int count,
    int launches)
{
    cudaEvent_t begin;
    cudaEvent_t end;
    CUDA_OK(cudaEventCreate(&begin));
    CUDA_OK(cudaEventCreate(&end));

    if (use_bmma)
        launch_bmma<Rounds>(transform, input, output, count);
    else
        launch_scalar<Rounds>(transform, input, output, count);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    CUDA_OK(cudaEventRecord(begin));
    for (int launch = 0; launch < launches; ++launch) {
        if (use_bmma)
            launch_bmma<Rounds>(transform, input, output, count);
        else
            launch_scalar<Rounds>(transform, input, output, count);
    }
    CUDA_OK(cudaEventRecord(end));
    CUDA_OK(cudaEventSynchronize(end));
    CUDA_OK(cudaGetLastError());

    float milliseconds = 0.0F;
    CUDA_OK(cudaEventElapsedTime(&milliseconds, begin, end));
    CUDA_OK(cudaEventDestroy(begin));
    CUDA_OK(cudaEventDestroy(end));

    const double transforms =
        double(count) * double(Rounds) * double(launches);
    return transforms / (double(milliseconds) * 1000.0);
}

static unsigned long long host_mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

static bool equal(U128 a, U128 b)
{
    return a.lo == b.lo && a.hi == b.hi;
}

int main()
{
    int device = 0;
    CUDA_OK(cudaGetDevice(&device));
    cudaDeviceProp properties{};
    CUDA_OK(cudaGetDeviceProperties(&properties, device));
    if (properties.major < 8) {
        std::fprintf(stderr,
                     "ERROR: this experiment requires sm_80+ for AND.POPC BMMA; got sm_%d%d\n",
                     properties.major, properties.minor);
        return 2;
    }

    const auto matrices = build_matrices();
    CUDA_OK(cudaMemcpyToSymbol(
        NOID_BMMA_MATRIX,
        matrices.data(),
        matrices.size() * sizeof(unsigned int)));

    constexpr int oracle_count = 8192;
    std::vector<U128> host_input(oracle_count);
    for (int index = 0; index < oracle_count; ++index) {
        host_input[index] = {
            host_mix64(0x9e3779b97f4a7c15ULL * unsigned(index + 1)),
            host_mix64(0xd1b54a32d192ed03ULL * unsigned(index + 7))
        };
    }
    host_input[0] = {0ULL, 0ULL};
    host_input[1] = {~0ULL, ~0ULL};
    host_input[2] = {1ULL, 0ULL};
    host_input[3] = {0ULL, 1ULL << 63};

    U128 *device_input = nullptr;
    U128 *device_scalar = nullptr;
    U128 *device_bmma = nullptr;
    CUDA_OK(cudaMalloc(&device_input, oracle_count * sizeof(U128)));
    CUDA_OK(cudaMalloc(&device_scalar, oracle_count * sizeof(U128)));
    CUDA_OK(cudaMalloc(&device_bmma, oracle_count * sizeof(U128)));
    CUDA_OK(cudaMemcpy(
        device_input,
        host_input.data(),
        oracle_count * sizeof(U128),
        cudaMemcpyHostToDevice));

    std::array<unsigned long long, kTransforms> errors{};
    std::vector<U128> scalar_output(oracle_count);
    std::vector<U128> bmma_output(oracle_count);
    for (int transform = 0; transform < kTransforms; ++transform) {
        launch_scalar<1>(transform, device_input, device_scalar, oracle_count);
        launch_bmma<1>(transform, device_input, device_bmma, oracle_count);
        CUDA_OK(cudaGetLastError());
        CUDA_OK(cudaDeviceSynchronize());
        CUDA_OK(cudaMemcpy(
            scalar_output.data(), device_scalar,
            oracle_count * sizeof(U128), cudaMemcpyDeviceToHost));
        CUDA_OK(cudaMemcpy(
            bmma_output.data(), device_bmma,
            oracle_count * sizeof(U128), cudaMemcpyDeviceToHost));
        for (int index = 0; index < oracle_count; ++index) {
            const U128 expected = host_transform(transform, host_input[index]);
            if (!equal(scalar_output[index], expected) ||
                !equal(bmma_output[index], expected)) {
                ++errors[transform];
            }
        }
    }

    unsigned long long total_errors = 0;
    for (const auto error : errors)
        total_errors += error;
    std::printf(
        "BMMA LINEAR ORACLE: %s "
        "(square=%llu D0=%llu D1=%llu D2=%llu D3=%llu mul2=%llu mul4=%llu total=%llu)\n",
        total_errors ? "FAIL" : "PASS",
        errors[0], errors[1], errors[2], errors[3], errors[4],
        errors[5], errors[6], total_errors);
    if (total_errors) {
        cudaFree(device_input);
        cudaFree(device_scalar);
        cudaFree(device_bmma);
        return 1;
    }

    constexpr int benchmark_count = 1 << 18;
    CUDA_OK(cudaFree(device_input));
    CUDA_OK(cudaFree(device_scalar));
    CUDA_OK(cudaFree(device_bmma));
    CUDA_OK(cudaMalloc(&device_input, benchmark_count * sizeof(U128)));
    CUDA_OK(cudaMalloc(&device_scalar, benchmark_count * sizeof(U128)));
    CUDA_OK(cudaMalloc(&device_bmma, benchmark_count * sizeof(U128)));

    std::vector<U128> benchmark_input(benchmark_count);
    for (int index = 0; index < benchmark_count; ++index) {
        benchmark_input[index] = {
            host_mix64(0xa0761d6478bd642fULL * unsigned(index + 11)),
            host_mix64(0xe7037ed1a0b428dbULL * unsigned(index + 19))
        };
    }
    CUDA_OK(cudaMemcpy(
        device_input,
        benchmark_input.data(),
        benchmark_count * sizeof(U128),
        cudaMemcpyHostToDevice));

    std::printf("===== WARP-COOPERATIVE BINARY TENSOR FEASIBILITY | GPU0 =====\n");
    std::printf("GPU: %s  sm_%d%d  inputs=%d  chain=%d\n",
                properties.name, properties.major, properties.minor,
                benchmark_count, kChain);
    std::printf("Each BMMA warp transforms 8 independent U128 values; 16 MMA instructions/value-group.\n");
    std::printf("%-8s %12s %12s %10s %12s %12s %10s\n",
                "op", "single scl", "single bmma", "single", 
                "chain scl", "chain bmma", "chain");

    std::array<double, kTransforms> scalar_chain{};
    std::array<double, kTransforms> bmma_chain{};
    for (int transform = 0; transform < kTransforms; ++transform) {
        const double scalar_single = benchmark_variant<1>(
            false, transform, device_input, device_scalar,
            benchmark_count, 30);
        const double bmma_single = benchmark_variant<1>(
            true, transform, device_input, device_bmma,
            benchmark_count, 30);
        scalar_chain[transform] = benchmark_variant<kChain>(
            false, transform, device_input, device_scalar,
            benchmark_count, 3);
        bmma_chain[transform] = benchmark_variant<kChain>(
            true, transform, device_input, device_bmma,
            benchmark_count, 3);

        std::printf("%-8s %10.2f M %10.2f M %9.2fx %10.2f M %10.2f M %9.2fx\n",
                    kNames[transform],
                    scalar_single, bmma_single,
                    bmma_single / scalar_single,
                    scalar_chain[transform], bmma_chain[transform],
                    bmma_chain[transform] / scalar_chain[transform]);
    }

    /* Three Poseidon permutations per hash: 540 squares and 804 MDS products. */
    const std::array<int, kTransforms> weights = {
        540, 174, 174, 174, 174, 54, 54
    };
    double scalar_linear_seconds = 0.0;
    double bmma_linear_seconds = 0.0;
    for (int transform = 0; transform < kTransforms; ++transform) {
        scalar_linear_seconds += double(weights[transform]) / scalar_chain[transform];
        bmma_linear_seconds += double(weights[transform]) / bmma_chain[transform];
    }
    const double linear_speedup = scalar_linear_seconds / bmma_linear_seconds;
    const double projected_whole_kernel =
        1.0 / (0.304 + 0.696 / linear_speedup);

    std::printf("\n===== BMMA FEASIBILITY DECISION =====\n");
    std::printf("weighted fixed-linear speedup: %.3fx (%+.2f%%)\n",
                linear_speedup, (linear_speedup - 1.0) * 100.0);
    std::printf("Amdahl whole-kernel ceiling:  %.3fx (%+.2f%%)\n",
                projected_whole_kernel,
                (projected_whole_kernel - 1.0) * 100.0);
    std::printf("integration gate (needs >1.10x linear): %s\n",
                linear_speedup > 1.10 ? "PASS" : "FAIL");
    std::printf("NOTE: chain numbers include matrix loads and parity packing, but assume\n");
    std::printf("      the miner remains in the four-lanes-per-U128 layout between transforms.\n");
    std::printf("      A full candidate still needs a cooperative nonlinear GF multiply.\n");

    CUDA_OK(cudaFree(device_input));
    CUDA_OK(cudaFree(device_scalar));
    CUDA_OK(cudaFree(device_bmma));
    return 0;
}
