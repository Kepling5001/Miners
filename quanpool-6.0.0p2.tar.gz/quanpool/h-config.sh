#!/usr/bin/env bash
# Quanpool 6.0.0 -> HiveOS Custom Miner adapter.

# Hive normally sources this script with CUSTOM_* variables already in scope.
# For direct/manual testing, fall back to the active Hive flight sheet.
if [[ -z "${CUSTOM_TEMPLATE:-}" && -r /hive-config/wallet.conf ]]; then
  . /hive-config/wallet.conf
fi

DIR="/hive/miners/custom/quanpool"
. "$DIR/h-manifest.conf" 2>/dev/null || true

TOKEN="${CUSTOM_TEMPLATE:-}"
NODE="${CUSTOM_URL:-}"
EXTRA="${CUSTOM_USER_CONFIG:-}"

[[ -n "$NODE" ]] || NODE="mainnet.quanpool.com:9834"
NODE="${NODE#*://}"
NODE="${NODE%%/*}"

TLS_DEFAULT="87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6"

if [[ -z "$TOKEN" ]]; then
  echo "Quanpool: ERROR: wallet/worker template is empty." >&2
  echo "Quanpool: Set Wallet and worker template to %WAL%.%WORKER_NAME% in the Hive Custom Miner flight sheet." >&2
  return 2 2>/dev/null || exit 2
fi

args=(serve --auth-token "$TOKEN" --node-addr "$NODE")

case " $EXTRA " in
  *" --tls-cert-sha256 "*|*" --tls-cert-sha256="*|*" --tls-cert-sha256-file "*|*" --tls-cert-sha256-file="*) ;;
  *) args+=(--tls-cert-sha256 "$TLS_DEFAULT") ;;
esac

case " $EXTRA " in
  *" --cpu-workers "*|*" --cpu-workers="*) ;;
  *) args+=(--cpu-workers 0) ;;
esac

case " $EXTRA " in
  *" --metrics-port "*|*" --metrics-port="*) ;;
  *) args+=(--metrics-port 9900) ;;
esac

if [[ -n "$EXTRA" ]]; then
  extra_args=()
  eval "extra_args=( $EXTRA )"
  args+=("${extra_args[@]}")
fi

mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
{
  printf 'CLI_ARGS=('
  printf ' %q' "${args[@]}"
  printf ' )\n'
} > "$CUSTOM_CONFIG_FILENAME"
