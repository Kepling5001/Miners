#!/usr/bin/env bash
set -uo pipefail

DIR="/hive/miners/custom/quanpool"
BIN="$DIR/quanpool-miner"
OFFICIAL_URL="https://download.quanpool.com/quanpool-miner-6.0.0-linux-x86_64"

. "$DIR/h-manifest.conf"

# Hive calls h-config.sh immediately before h-run.sh. If config is somehow
# missing, regenerate it using the active flight sheet rather than empty vars.
if [[ ! -s "$CUSTOM_CONFIG_FILENAME" ]]; then
  if [[ -r /hive-config/wallet.conf ]]; then
    . /hive-config/wallet.conf
  fi
  . "$DIR/h-config.sh" || exit 2
fi

declare -a CLI_ARGS=()
. "$CUSTOM_CONFIG_FILENAME"

if (( ${#CLI_ARGS[@]} == 0 )); then
  echo "Quanpool: ERROR: generated CLI_ARGS is empty." >&2
  exit 2
fi

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"

install_local_binary() {
  local src
  for src in \
    "$DIR/quanpool-miner-6.0.0-linux-x86_64" \
    "/home/user/quanpool-miner-6.0.0-linux-x86_64" \
    "/home/user/quanpool-miner-6.0.0" \
    "/home/user/quanpool-miner"; do
    [[ "$src" == "$BIN" ]] && continue
    if [[ -s "$src" ]]; then
      echo "Quanpool: using existing binary: $src"
      cp -f "$src" "$BIN"
      chmod 0755 "$BIN"
      return 0
    fi
  done
  return 1
}

download_binary() {
  local tmp="$BIN.download.$$"
  local ok=1
  rm -f "$tmp"

  echo "Quanpool: downloading official 6.0.0 binary..."

  if command -v wget >/dev/null 2>&1; then
    echo "Quanpool: downloader 1/3: wget"
    if wget --timeout=30 --tries=2 -O "$tmp" "$OFFICIAL_URL"; then
      ok=0
    else
      rm -f "$tmp"
    fi
  fi

  if (( ok != 0 )) && command -v python3 >/dev/null 2>&1; then
    echo "Quanpool: downloader 2/3: python3 urllib"
    if python3 - "$OFFICIAL_URL" "$tmp" <<'PY'
import shutil, ssl, sys, urllib.request
url, dst = sys.argv[1], sys.argv[2]
ctx = ssl.create_default_context()
with urllib.request.urlopen(url, timeout=45, context=ctx) as r, open(dst, 'wb') as f:
    shutil.copyfileobj(r, f)
PY
    then
      ok=0
    else
      rm -f "$tmp"
    fi
  fi

  if (( ok != 0 )) && command -v curl >/dev/null 2>&1; then
    echo "Quanpool: downloader 3/3: curl (TLS 1.2+)"
    if curl -fL --tlsv1.2 --connect-timeout 20 --max-time 120 --retry 2 "$OFFICIAL_URL" -o "$tmp"; then
      ok=0
    else
      rm -f "$tmp"
    fi
  fi

  if (( ok != 0 )) || [[ ! -s "$tmp" ]]; then
    echo "Quanpool: ERROR: could not download the official miner binary." >&2
    return 1
  fi

  if command -v file >/dev/null 2>&1 && ! file "$tmp" | grep -q 'ELF 64-bit'; then
    echo "Quanpool: ERROR: downloaded file is not an ELF 64-bit executable:" >&2
    file "$tmp" >&2 || true
    rm -f "$tmp"
    return 1
  fi

  chmod 0755 "$tmp"
  mv -f "$tmp" "$BIN"
  echo "Quanpool: official binary installed: $(sha256sum "$BIN" 2>/dev/null | awk '{print $1}')"
}

if [[ ! -x "$BIN" ]]; then
  install_local_binary || download_binary || exit 2
fi

stdbuf -oL -eL "$BIN" "${CLI_ARGS[@]}" 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
rc=${PIPESTATUS[0]}
exit "$rc"
