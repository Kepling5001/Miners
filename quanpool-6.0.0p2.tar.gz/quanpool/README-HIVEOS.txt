Quanpool 6.0.0 HiveOS Custom Miner wrapper

Archive naming intentionally follows HiveOS custom-get parsing:
  quanpool-6.0.0p2.tar.gz -> miner name 'quanpool', package version '6.0.0p2'
Archive contains directory:
  quanpool/

Flight sheet:
  Miner name: quanpool
  Wallet template: %WAL%.%WORKER_NAME%
  Pool URL: mainnet.quanpool.com:9834
  Extra config: blank initially

The wrapper downloads the official Quanpool 6.0.0 Linux x86_64 binary on first run.
