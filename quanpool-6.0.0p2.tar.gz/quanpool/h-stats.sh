#!/usr/bin/env bash
# Sourced by Hive agent. Must set $khs and $stats.

khs=0
stats="null"
DIR="/hive/miners/custom/quanpool"
PORT=9900

if [[ -r "$DIR/quanpool.conf" ]]; then
  p=$(grep -oE -- '--metrics-port(=|[[:space:]])[0-9]+' "$DIR/quanpool.conf" 2>/dev/null \
      | tail -1 | grep -oE '[0-9]+' | tail -1)
  [[ -n "$p" ]] && PORT="$p"
fi

API_TIMEOUT="${API_TIMEOUT:-5}"
RAW=""
if command -v curl >/dev/null 2>&1; then
  RAW=$(curl -fsS --max-time "$API_TIMEOUT" "http://127.0.0.1:${PORT}/hive-stats" 2>/dev/null || true)
elif command -v wget >/dev/null 2>&1; then
  RAW=$(timeout "$API_TIMEOUT" wget -qO- "http://127.0.0.1:${PORT}/hive-stats" 2>/dev/null || true)
fi

if [[ -n "$RAW" ]] && command -v jq >/dev/null 2>&1 && jq -e 'type == "object"' >/dev/null 2>&1 <<<"$RAW"; then
  # Quanpool may already return Hive's {khs,stats} envelope.
  if jq -e '(.stats|type)=="object" and (.khs|type)=="number"' >/dev/null 2>&1 <<<"$RAW"; then
    khs=$(jq -r '.khs' <<<"$RAW")
    stats=$(jq -c '.stats' <<<"$RAW")
  else
    stats=$(jq -c '.' <<<"$RAW")

    if jq -e '.hs | type == "array"' >/dev/null 2>&1 <<<"$RAW"; then
      SUM=$(jq '[.hs[]? | numbers] | add // 0' <<<"$RAW")
      UNIT=$(jq -r '.hs_units // "khs"' <<<"$RAW" | tr '[:upper:]' '[:lower:]')
      case "$UNIT" in
        hs|h/s)   khs=$(awk -v x="$SUM" 'BEGIN{printf "%.6f", x/1000}') ;;
        khs|kh/s) khs="$SUM" ;;
        mhs|mh/s) khs=$(awk -v x="$SUM" 'BEGIN{printf "%.6f", x*1000}') ;;
        ghs|gh/s) khs=$(awk -v x="$SUM" 'BEGIN{printf "%.6f", x*1000000}') ;;
        ths|th/s) khs=$(awk -v x="$SUM" 'BEGIN{printf "%.6f", x*1000000000}') ;;
        *)        khs="$SUM" ;;
      esac
    elif jq -e '.khs | type == "number"' >/dev/null 2>&1 <<<"$RAW"; then
      khs=$(jq -r '.khs' <<<"$RAW")
    elif jq -e '.hashrate | type == "number"' >/dev/null 2>&1 <<<"$RAW"; then
      HPS=$(jq -r '.hashrate' <<<"$RAW")
      khs=$(awk -v x="$HPS" 'BEGIN{printf "%.6f", x/1000}')
    elif jq -e '.total_hashrate | type == "number"' >/dev/null 2>&1 <<<"$RAW"; then
      HPS=$(jq -r '.total_hashrate' <<<"$RAW")
      khs=$(awk -v x="$HPS" 'BEGIN{printf "%.6f", x/1000}')
    fi
  fi
fi

[[ -n "$khs" ]] || khs=0
[[ -n "$stats" ]] || stats="null"
