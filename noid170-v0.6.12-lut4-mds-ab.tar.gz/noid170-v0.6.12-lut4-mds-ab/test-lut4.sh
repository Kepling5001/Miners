#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

VARIANTS=(
  current current512 current256
  lut4 lut4_512 lut4_256
)

for variant in "${VARIANTS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$variant" ]] || {
    echo "ERROR: missing $variant; run ./build-on-rig.sh first"
    exit 1
  }
done

[[ -x "$ROOT/bin/test_gf_current" ]] || {
  echo "ERROR: missing baseline oracle; run ./build-on-rig.sh first"
  exit 1
}
[[ -x "$ROOT/bin/test_lut4" ]] || {
  echo "ERROR: missing LUT4 oracle; run ./build-on-rig.sh first"
  exit 1
}

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining."
  echo "Stop or pause the flight sheet first: miner stop"
  exit 1
fi

python3 "$ROOT/generate_lut4.py" --check
python3 "$ROOT/offline_verify.py"

echo
echo "===== GPU CORRECTNESS ORACLES ====="
"$ROOT/bin/test_gf_current"
"$ROOT/bin/test_lut4"

echo
python3 "$ROOT/benchmark_lut4.py"

echo
env -u NOID_TEST_VARIANT -u NOID_FORCE_VARIANT \
  "$ROOT/test-persistent.sh"

echo
echo "Paste the complete FINAL PARTIAL-MDS LUT4 RANKING"
echo "and LUT4 WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished:"
echo "  miner start"
