#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_mds_lut4.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

__device__ __forceinline__
unsigned long long lut_mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__device__ __forceinline__
bool lut_different(U128 a, U128 b)
{
    return a.lo != b.lo || a.hi != b.hi;
}

__global__
void lut4_oracle(unsigned int *errors)
{
    extern __shared__ U128 lut[];

    const U128 *src = &NOID_MDS_PARTIAL_LUT4[0][0][0];
    for (int i = threadIdx.x;
         i < NOID_MDS_LUT4_ENTRIES;
         i += blockDim.x)
        lut[i] = src[i];
    __syncthreads();

    const U128 factors[4] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };

    unsigned int local_errors = 0;
    unsigned long long seed =
        0x9e3779b97f4a7c15ULL ^
        (unsigned long long)(threadIdx.x + 1) *
        0xd1b54a32d192ed03ULL;

    #pragma unroll 1
    for (int round = 0; round < 8; ++round) {
        U128 s[4];
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            seed = lut_mix64(seed + 0x9e3779b97f4a7c15ULL);
            s[i].lo = seed;
            seed = lut_mix64(seed + 0x9e3779b97f4a7c15ULL);
            s[i].hi = seed;
        }

        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const U128 via_lut =
                gf_mul_const_lut4_shared(
                    s[i],
                    lut + i * 32 * 16);
            const U128 via_math =
                gf_mul(factors[i], s[i]);
            if (lut_different(via_lut, via_math))
                ++local_errors;
        }

        U128 p_ref[4] = {s[0], s[1], s[2], s[3]};
        U128 p_lut[4] = {s[0], s[1], s[2], s[3]};
        apply_mds_partial(p_ref);
        apply_mds_partial_lut4(p_lut, lut);
        #pragma unroll
        for (int i = 0; i < 4; ++i)
            if (lut_different(p_ref[i], p_lut[i]))
                ++local_errors;

        U128 h_ref[4] = {s[0], s[1], s[2], s[3]};
        U128 h_lut[4] = {s[0], s[1], s[2], s[3]};
        poseidon_permute(h_ref);
        poseidon_permute_lut4(h_lut, lut);
        #pragma unroll
        for (int i = 0; i < 4; ++i)
            if (lut_different(h_ref[i], h_lut[i]))
                ++local_errors;
    }

    if (local_errors)
        atomicAdd(errors, local_errors);
}

int main()
{
    unsigned int *d_errors = nullptr;
    unsigned int errors = 0;
    CUDA_OK(cudaMalloc(&d_errors, sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors, 0, sizeof(unsigned int)));

    lut4_oracle<<<1, 256, NOID_MDS_LUT4_SHARED_BYTES>>>(d_errors);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(
        &errors,
        d_errors,
        sizeof(unsigned int),
        cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));

    if (errors) {
        printf("LUT4 GPU ORACLE: FAIL errors=%u\n", errors);
        return 1;
    }

    printf("LUT4 GPU ORACLE: PASS "
           "(2048 states; fixed-mul + partial-MDS + Poseidon)\n");
    return 0;
}
