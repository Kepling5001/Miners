#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}
mkdir -p "$BIN"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1 -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000 -Xptxas=-v
)

build_daemon() {
  local name="$1" threads="$2" blocks_per_sm="$3" lut="$4"
  local extra=()
  if [[ "$lut" == "1" ]]; then
    extra+=(-DNOID_MDS_LUT4=1)
  fi

  echo
  echo "===== BUILD $name | T=$threads B/SM=$blocks_per_sm LUT4=$lut ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" \
    2>&1 | tee "$BIN/build_$name.log"
  chmod 755 "$BIN/noid_daemon_$name"
}

python3 "$ROOT/generate_lut4.py" --check
python3 "$ROOT/offline_verify.py"

# Exact production math at three launch shapes.
build_daemon current     1024  64 0
build_daemon current512   512 128 0
build_daemon current256   256 256 0

# Same math except the four fixed partial-MDS multiplications use
# a 32 KiB per-block shared-memory nibble table.
build_daemon lut4        1024  64 1
build_daemon lut4_512     512 128 1
build_daemon lut4_256     256 256 1

echo
echo "===== BUILD CORRECTNESS ORACLES ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_THREADS=1024 -DNOID_BLOCKS_PER_SM=64 \
  "$ROOT/test_gf_primitives.cu" \
  -o "$BIN/test_gf_current" \
  2>&1 | tee "$BIN/build_oracle_current.log"

"$NVCC" "${COMMON[@]}" -DNOID_MDS_LUT4=1 \
  -DNOID_THREADS=1024 -DNOID_BLOCKS_PER_SM=64 \
  "$ROOT/test_lut4.cu" \
  -o "$BIN/test_lut4" \
  2>&1 | tee "$BIN/build_oracle_lut4.log"

chmod 755 "$BIN/test_gf_current" "$BIN/test_lut4"

python3 -m py_compile \
  "$ROOT/benchmark_lut4.py" \
  "$ROOT/test-persistent.py" \
  "$ROOT/generate_lut4.py"
bash -n "$ROOT/test-lut4.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_*
echo
echo "Next:"
echo "  miner stop"
echo "  export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'"
echo "  ./test-lut4.sh"
