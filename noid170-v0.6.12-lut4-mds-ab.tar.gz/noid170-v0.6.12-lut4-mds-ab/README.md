# NOID170 v0.6.12 partial-MDS LUT4 A/B

This is a **correctness-gated benchmark package** for the CMP 170HX.
It does **not** install or replace the live HiveOS miner.

Baseline math is the proven production path from the v0.6.11 source set:

- `r4top` general GF(2^128) reduction
- `prod2` partial-MDS product ILP
- `r2lop3` square-only reduction
- non-volatile paired CLMAD scheduling
- factorized full MDS
- 2 ms CUDA event polling
- production four-stage `x^7` S-box

## What this experiment changes

A source audit showed that replacing `r4top` itself with a lookup table would
target the wrong part of the kernel. `r4top` is already only a few CLMADs.

The dominant repeatable fixed arithmetic is in the **58 partial Poseidon2
rounds**. Every partial round performs four GF(2^128) multiplications by the
same four constants. That is **232 fixed-constant field multiplications per
Poseidon permutation**, and the mining path performs three nonce-dependent
permutations per hash.

`lut4` replaces only those four fixed multiplications with a nibble lookup:

- 4 fixed multipliers
- 32 nibble positions per 128-bit value
- 16 values per nibble
- 2,048 pre-reduced U128 entries
- 32 KiB table copied once per CUDA block into shared memory
- all S-box, full-MDS, target, nonce and protocol math remain unchanged

The table is generated from the exact flat/GCM polynomial

`x^128 + x^7 + x^2 + x + 1`

and is checked twice:

1. CPU algebra/header verification before build.
2. A GPU oracle comparing LUT fixed-multiply, partial-MDS and full Poseidon
   output directly against the existing CLMAD production path.

## A/B variants

The benchmark holds hashes-per-batch approximately constant while testing
launch shape separately from the LUT:

- `current` — production math, 1024 threads
- `current512` — production math, 512 threads
- `current256` — production math, 256 threads
- `lut4` — shared LUT4, 1024 threads
- `lut4_512` — shared LUT4, 512 threads
- `lut4_256` — shared LUT4, 256 threads

The benchmark runs forward and reverse to reduce temperature/order bias,
discards warm-up samples, reports kernel and wall MH/s, and writes only the
measured winner to `winner.txt`. The winner then has to produce a live
accepted share before the test is considered complete.

## Run on OctominerTEST

```bash
cd /home/user/noid170-v0.6.12-lut4-mds-ab

miner stop

chmod +x \
  build-on-rig.sh \
  test-lut4.sh \
  test-persistent.sh \
  generate_lut4.py \
  benchmark_lut4.py

./build-on-rig.sh

export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-lut4.sh

miner start
```

For a longer confirmation benchmark:

```bash
NOID_BENCH_STATS=14 ./test-lut4.sh
```

## What to paste back into chat

Paste:

- the two GPU oracle PASS lines
- `FINAL PARTIAL-MDS LUT4 RANKING`
- `LUT4 WINNER PROTOCOL: PASS`

Do not install the winner into HiveOS yet. We will only package a production
miner if the LUT wins cleanly and the accepted-share test passes.
