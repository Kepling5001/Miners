#!/usr/bin/env bash

MINER_DIR="${MINER_DIR:-/hive/miners/custom/noid170}"
export NOID_STATS_FILE="/run/noid170/stats.json"

out=$(python3 "$MINER_DIR/hive_stats.py" 2>/dev/null)
khs=$(printf '%s\n' "$out" | sed -n '1p')
stats=$(printf '%s\n' "$out" | sed -n '2p')

[[ "$khs" =~ ^[0-9]+([.][0-9]+)?$ ]] || khs=0
[[ -n "$stats" ]] || stats='{"hs":[],"hs_units":"mhs","temp":[],"fan":[],"uptime":0,"ver":"0.1.0","ar":[0,0],"algo":"noid","bus_numbers":[]}'
