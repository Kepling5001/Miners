# NOID170 v0.6.35 final-digest2 A/B

Isolated CMP170HX correctness-gated benchmark. **Nothing is installed into HiveOS.**

Baseline is the exact v0.6.34 `prodshape` InnovLab namespace kernel that measured
160.584 MH/s kernel / 160.407 MH/s wall at the user's production clocks.

## Experiment

The third/final Poseidon permutation is followed immediately by a target compare
of state lanes 0 and 1. Lanes 2 and 3 are dead.

The exact factorized external M4 computes:

- `t0 = a ^ b`
- `t1 = c ^ d`
- `t2 = 2*b ^ t1`
- `t3 = 2*d ^ t0`
- `t4 = 4*t1 ^ t3`  (used only by output lanes 2/3)
- `t5 = 4*t0 ^ t2`
- `out0 = t3 ^ t5`
- `out1 = t5`
- `out2 = t2 ^ t4`
- `out3 = t4`

`digest2` omits `t4`, eliminating one general GF(2^128) multiply on every hash.
All rounds, S-boxes, constants, partial MDS operations and digest lanes 0/1 are
otherwise identical.

Variants:

- `prodshape` — exact current winner.
- `finalsplit` — explicit final round but still computes all four MDS outputs.
- `digest2` — same final split, but final MDS materializes only outputs 0/1.

The build runs an 8,192-state randomized GPU oracle before benchmarking:

- `FINAL_SPLIT_ORACLE_PASS`
- `FINAL_DIGEST2_ORACLE_PASS`

Run on OctominerTEST:

```bash
cd /home/user/noid170-v0.6.35-final-digest2-ab-builder
./build-ab.sh
NOID_BENCH_SECONDS=30 ./run-benchmark.sh
```

Paste back the two oracle PASS lines, REGISTER SUMMARY, and FINAL DIGEST2 A/B.
