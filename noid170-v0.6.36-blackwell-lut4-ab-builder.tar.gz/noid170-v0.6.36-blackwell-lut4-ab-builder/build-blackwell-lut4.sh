#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BUILD="$ROOT/build"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
mkdir -p "$BUILD"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }

echo "===== NOID170 v0.6.36 BLACKWELL LUT4 A/B BUILD ====="
echo "GPU:  $(nvidia-smi --query-gpu=name --format=csv,noheader -i "${NOID_TEST_GPU:-0}" | head -1)"
echo "NVCC: $NVCC"
"$NVCC" --version | tail -4
"$NVCC" --list-gpu-code | grep -q '^sm_120$' || { echo "ERROR: sm_120 unavailable"; exit 1; }

python3 "$ROOT/verify_namespace_lut.py"
python3 "$ROOT/verify_namespace_block_map.py"

BASE=(
  -O3 -std=c++17 -arch=sm_120 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_FIRST_MDS_HOIST=0
  -DNOID_FIRST_ROUND_SQUARE_SHARE=3
  -DNOID_FINAL_DIGEST_MODE=2
  -Xptxas=-v
)

compile() {
  local name="$1" threads="$2" bpsm="$3" mode="$4"
  local extra=()
  [[ "$mode" == lut4 ]] && extra+=( -DNOID_MDS_LUT4=1 )
  echo
  echo "===== COMPILE $name threads=$threads blocks/sm=$bpsm mode=$mode ====="
  "$NVCC" "${BASE[@]}" "${extra[@]}" \
    -DNOID_THREADS="$threads" -DNOID_BLOCKS_PER_SM="$bpsm" \
    "$SRC/noid_live_job_daemon_ns.cu" -o "$BUILD/noid_daemon_ns_$name" \
    2>&1 | tee "$BUILD/build-$name.log"
  chmod 755 "$BUILD/noid_daemon_ns_$name"
}

# One proven launch control plus three LUT launch sizes.
compile clmad_1024 1024 32 clmad
compile lut4_256   256  64 lut4
compile lut4_512   512  64 lut4
compile lut4_1024  1024 32 lut4

echo
echo "===== COMPILE LUT4 CORRECTNESS ORACLE ====="
"$NVCC" -O3 -std=c++17 -arch=sm_120 -lineinfo -I"$ROOT" -I"$SRC" \
  "$ROOT/test_lut4.cu" -o "$BUILD/test_lut4" -Xptxas=-v \
  2>&1 | tee "$BUILD/build-test-lut4.log"
chmod 755 "$BUILD/test_lut4"

echo
echo "===== REGISTER / SHARED SUMMARY ====="
for name in clmad_1024 lut4_256 lut4_512 lut4_1024; do
  echo "--- $name ---"
  grep -A5 "Compiling entry function.*mine_kernel_ns" "$BUILD/build-$name.log" | grep -E 'Used |bytes smem|bytes cmem' | head -4 || true
done

echo
echo "===== BUILD COMPLETE ====="
echo "No benchmark has run."
