#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
GPU="${NOID_TEST_GPU:-0}"
SECS="${NOID_BENCH_SECONDS:-20}"
POW_ZERO=$(printf '0%.0s' {1..512})
TARGET_ZERO=$(printf '0%.0s' {1..64})
NS_TEST="19ea010000000200"
variants=(clmad_1024 lut4_256 lut4_512 lut4_1024)

for n in "${variants[@]}"; do [[ -x "$BUILD/noid_daemon_ns_$n" ]] || { echo "ERROR missing $n"; exit 1; }; done
[[ -x "$BUILD/test_lut4" ]] || { echo "ERROR missing test_lut4"; exit 1; }

if pgrep -af 'srbminer_custom_bin|SRBMiner|noid170_stratum.py|noid_live_job_daemon_ns' >/tmp/noid-lut4-procs.$$ 2>/dev/null; then
  echo "ERROR: another miner/NOID process is still running:"
  cat /tmp/noid-lut4-procs.$$
  rm -f /tmp/noid-lut4-procs.$$
  exit 2
fi
rm -f /tmp/noid-lut4-procs.$$

echo "===== GPU BEFORE TEST ====="
nvidia-smi --query-gpu=index,name,power.draw,power.limit,clocks.gr,clocks.sm,clocks.mem,temperature.gpu --format=csv -i "$GPU"

echo
echo "===== LUT4 CORRECTNESS GATE ====="
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_lut4"

summarize() {
  awk '$1=="STAT"{n++;if(n>1){ks+=$2;ws+=$6;m++;if(m==1||$2<mi)mi=$2;if(m==1||$2>ma)ma=$2}} END{if(m)printf("samples=%d kernel_avg=%.3f kernel_min=%.3f kernel_max=%.3f wall_avg=%.3f\n",m,ks/m,mi,ma,ws/m);else print "samples=0"}' "$1"
}
run_one() {
  local n="$1" log="$BUILD/bench-$n.log"
  rm -f "$log"
  echo
  echo "===== BENCH $n (${SECS}s) ====="
  { printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"; sleep "$SECS"; printf 'STOP\n'; } \
    | CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/noid_daemon_ns_$n" --daemon 636 >/dev/null 2>"$log"
  tail -10 "$log"
  printf '%s: ' "$n"; summarize "$log"
}

echo
echo "===== FORWARD A/B ====="
for n in "${variants[@]}"; do run_one "$n"; done

echo
echo "===== FINAL RTX 5070 LUT4 A/B ====="
for n in "${variants[@]}"; do printf '%-14s ' "$n:"; summarize "$BUILD/bench-$n.log"; done

echo
echo "===== GPU AFTER TEST ====="
nvidia-smi --query-gpu=index,name,power.draw,power.limit,clocks.gr,clocks.sm,clocks.mem,temperature.gpu --format=csv -i "$GPU"

echo
echo "Zero-target benchmark only; no pool connection or share submission."
