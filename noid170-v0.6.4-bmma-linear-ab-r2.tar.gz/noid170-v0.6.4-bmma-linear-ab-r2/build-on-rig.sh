#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
)

echo "===== BUILD CLMAD BASELINE + BMMA LINEAR FEASIBILITY ====="
"$NVCC" "${COMMON[@]}" -Xptxas=-v \
  "$ROOT/test_bmma_linear.cu" \
  -o "$BIN/test_bmma_linear" 2>&1 | tee "$BIN/build.log"

"$NVCC" "${COMMON[@]}" -ptx \
  "$ROOT/test_bmma_linear.cu" \
  -o "$BIN/test_bmma_linear.ptx"

chmod +x "$BIN/test_bmma_linear"

echo
echo "===== PTX BMMA STATIC CHECK ====="
BMMA_COUNT="$(grep -c 'mma.sync.aligned.m8n8k128.*b1.b1.*and.popc' \
  "$BIN/test_bmma_linear.ptx" || true)"
echo "binary MMA instructions in PTX: $BMMA_COUNT"
if [[ "$BMMA_COUNT" -lt 1 ]]; then
  echo "ERROR: compiler output contains no m8n8k128 b1 AND.POPC MMA"
  exit 1
fi

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN/test_bmma_linear" "$BIN/test_bmma_linear.ptx"
echo
echo "Next: miner stop && ./test-bmma-linear.sh"
