#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin/test_bmma_linear"

[[ -x "$BIN" ]] || {
  echo "ERROR: run ./build-on-rig.sh first"
  exit 1
}

if pgrep -f 'noid_live_job_daemon|noid170_aria.py' >/dev/null 2>&1; then
  echo "ERROR: a NOID miner process is still running"
  echo "Run: miner stop"
  exit 1
fi

echo "This is a primitive feasibility test only; it does not install or replace the HiveOS miner."
echo "No mining key or pool connection is required."
echo
"$BIN"
echo
echo "Paste the complete BMMA oracle, table, and decision block back into chat."
echo "Restart HiveOS mining when finished: miner start"
