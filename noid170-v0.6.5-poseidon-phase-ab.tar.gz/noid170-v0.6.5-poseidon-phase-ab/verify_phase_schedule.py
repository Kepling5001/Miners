#!/usr/bin/env python3

N_ROUNDS = 66
F_ROUNDS = 8
P_ROUNDS = 58


def production_schedule():
    return [
        "full"
        if not (F_ROUNDS // 2 <= round_index < F_ROUNDS // 2 + P_ROUNDS)
        else "partial"
        for round_index in range(N_ROUNDS)
    ]


def split_schedule():
    return (
        ["full"] * (F_ROUNDS // 2)
        + ["partial"] * P_ROUNDS
        + ["full"] * (F_ROUNDS // 2)
    )


def main():
    expected = production_schedule()
    candidate = split_schedule()
    if candidate != expected:
        raise SystemExit("POSEIDON PHASE SCHEDULE MODEL: FAIL")
    if len(candidate) != N_ROUNDS:
        raise SystemExit("POSEIDON PHASE SCHEDULE MODEL: FAIL length")
    print(
        "POSEIDON PHASE SCHEDULE MODEL: PASS "
        "(initial_mds=1 leading_full=4 partial=58 trailing_full=4 total=66)"
    )


if __name__ == "__main__":
    main()
