#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VARIANTS=(current loopni split1 split2 split4 split8 split4ni fullctni fullct)

for variant in "${VARIANTS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$variant" ]] || {
    echo "ERROR: run ./build-on-rig.sh first"
    exit 1
  }
done

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Stop or pause the flight sheet first."
  exit 1
fi

python3 "$ROOT/offline_verify.py"
python3 "$ROOT/verify_phase_schedule.py"

echo "===== GPU CORRECTNESS ORACLES ====="
for variant in "${VARIANTS[@]}"; do
  echo "--- $variant ---"
  "$ROOT/bin/test_gf_$variant"
done

python3 "$ROOT/benchmark_phase.py"
env -u NOID_TEST_VARIANT -u NOID_FORCE_VARIANT "$ROOT/test-persistent.sh"

echo
echo "Paste the complete FINAL POSEIDON PHASE RANKING and persistent-worker result back into chat."
