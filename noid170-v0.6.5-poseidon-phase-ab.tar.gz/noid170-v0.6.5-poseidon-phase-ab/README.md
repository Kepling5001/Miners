# NOID v0.6.5 Poseidon phase-specialization A/B

This bundle tests compiler/control-flow specialization on top of the proven
`all_nv + r2lop3 + prod2 + r4top` arithmetic. It is an isolated benchmark and
does not install or replace the HiveOS custom miner.

The production permutation uses one 66-round loop and classifies each round as
full or partial at runtime. The candidates split the permutation into its
actual fixed schedule:

- initial full MDS;
- four leading full rounds;
- 58 partial rounds;
- four trailing full rounds.

Variants:

- `current`: exact production mixed-round loop and inlining;
- `loopni`: production loop in one non-inlined device function;
- `split1`, `split2`, `split4`, `split8`: split phases with the named partial
  round unroll factor;
- `split4ni`: split/unroll-4 in one non-inlined device function;
- `fullctni`: every round index compile-time, non-inlined;
- `fullct`: every round index compile-time and force-inlined.

Every binary must pass reduction, multiplication, square, S-box, Poseidon, and
three-permutation chain checks. Benchmark ranking includes registers, spills,
and binary size so an apparent gain can be checked against code expansion.
The selected winner then runs the persistent worker job-switching test and
must submit a network-accepted share.

## Run on OctominerTEST

```bash
cd /home/user/noid170-v0.6.5-poseidon-phase-ab
miner stop
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-phase.sh
miner start
```

Expected duration is approximately 10–15 minutes. Mining is not restarted
automatically. If `miner start` says no miner is configured, reapply the
working production flight sheet with HiveOS's rocket button.
