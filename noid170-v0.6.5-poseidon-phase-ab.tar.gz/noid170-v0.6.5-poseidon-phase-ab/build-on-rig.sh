#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"
rm -f "$BIN"/noid_daemon_* "$BIN"/test_gf_* "$BIN"/build_*.log

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  shift

  echo
  echo "===== BUILD $name | $* ====="
  "$NVCC" "${COMMON[@]}" "$@" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" "$@" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name" 2>&1 | tee "$BIN/build_test_gf_$name.log"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

# Exact all_nv + r2lop3 production arithmetic and control flow.
build_variant current -DNOID_POSEIDON_PHASE_VARIANT=0

# Isolate the cost/benefit of keeping the compact loop out of line.
build_variant loopni \
  -DNOID_POSEIDON_PHASE_VARIANT=0 \
  -DNOID_POSEIDON_NOINLINE=1

# Split full/partial/full phases and sweep partial-round unrolling.
build_variant split1 -DNOID_POSEIDON_PHASE_VARIANT=1
build_variant split2 -DNOID_POSEIDON_PHASE_VARIANT=2
build_variant split4 -DNOID_POSEIDON_PHASE_VARIANT=4
build_variant split8 -DNOID_POSEIDON_PHASE_VARIANT=8

# Determine whether phase specialization benefits from one shared code body.
build_variant split4ni \
  -DNOID_POSEIDON_PHASE_VARIANT=4 \
  -DNOID_POSEIDON_NOINLINE=1

# Every round index and constant offset is known at compile time.
build_variant fullctni \
  -DNOID_POSEIDON_PHASE_VARIANT=100 \
  -DNOID_POSEIDON_NOINLINE=1
build_variant fullct -DNOID_POSEIDON_PHASE_VARIANT=100

python3 "$ROOT/offline_verify.py"
python3 "$ROOT/verify_phase_schedule.py"
python3 -m py_compile \
  "$ROOT/benchmark_phase.py" \
  "$ROOT/test-persistent.py" \
  "$ROOT/verify_phase_schedule.py"
bash -n "$ROOT/test-phase.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-phase.sh"
