# NOID170 v0.6.21 register / occupancy A/B

Exact red2 + 512 + current square/X7 math. No cryptographic arithmetic changes.

This experiment tests whether constraining registers can move the actual mining kernel to a higher resident-block occupancy point on GA100. The daemon has a host-only `--occupancy` mode using `cudaFuncGetAttributes()` and `cudaOccupancyMaxActiveBlocksPerMultiprocessor()` so register count and blocks/SM come from CUDA itself rather than ptxas-log parsing.

Variants:
- baseline: no register constraint
- mr48 / mr44 / mr42 / mr40 / mr38: `--maxrregcount`
- lb3: `__launch_bounds__(512,3)`

Every binary uses the same proven red2/512 math and must pass the GPU primitive/Poseidon oracle before benchmarking. The winner must then pass the persistent accepted-share test. Does not install or replace the HiveOS miner.
