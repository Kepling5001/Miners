#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"; BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"
COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3 -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1 -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128
  -Xptxas=-v
)
build_one(){
  local name="$1" cap="$2" lb="$3"
  local extra=()
  [[ "$cap" == "0" ]] || extra+=("--maxrregcount=$cap")
  [[ "$lb" == "0" ]] || extra+=("-DNOID_LAUNCH_MIN_BLOCKS=$lb")
  echo
  echo "===== BUILD $name | maxrreg=$cap launch_min_blocks=$lb ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"
  "$NVCC" "${COMMON[@]}" "${extra[@]}" "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name" 2>&1 | tee "$BIN/build_test_gf_$name.log"
  chmod 755 "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

echo "===== OFFLINE MODELS ====="
python3 "$ROOT/offline_verify.py"
build_one baseline 0 0
build_one mr48 48 0
build_one mr44 44 0
build_one mr42 42 0
build_one mr40 40 0
build_one mr38 38 0
build_one lb3 0 3

python3 -m py_compile "$ROOT/benchmark_reg.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-reg.sh" "$ROOT/test-persistent.sh"
echo
echo "===== CUDA OCCUPANCY REPORT ====="
for n in baseline mr48 mr44 mr42 mr40 mr38 lb3; do
  printf '%-9s ' "$n"
  CUDA_VISIBLE_DEVICES=0 "$BIN/noid_daemon_$n" --occupancy
done

echo
echo "===== GPU CORRECTNESS ORACLES ====="
for n in baseline mr48 mr44 mr42 mr40 mr38 lb3; do
  echo "--- $n ---"
  CUDA_VISIBLE_DEVICES=0 "$BIN/test_gf_$n"
done

echo
echo "===== BUILD COMPLETE ====="
