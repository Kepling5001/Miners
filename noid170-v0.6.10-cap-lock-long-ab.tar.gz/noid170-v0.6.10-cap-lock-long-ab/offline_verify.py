#!/usr/bin/env python3

"""Deterministic checks for the nonblocking capability state machine."""

import importlib.util
import os
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
os.environ.setdefault("NOID_MINING_KEY", "offline.worker")
os.environ["NOID_GPU_COUNT"] = "1"
os.environ["NOID_CAPABILITY_MODE"] = "adaptive"
os.environ.setdefault("NOID_STATS_FILE", "/tmp/noid170-cap-lock-offline.json")

spec = importlib.util.spec_from_file_location(
    "noid170_cap_lock_offline", ROOT / "noid170_aria_ab.py"
)
miner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = miner
spec.loader.exec_module(miner)


def candidate(template_id):
    return {
        "template_id": template_id,
        "height": 123,
        "pow_fields_hex": "11" * 32,
        "difficulty_target_hex": "22" * 16,
    }


base = candidate("cap-1")
seq, ctx = miner.register_job_context(base)

miner.invalidate_template_capability(seq)
assert not ctx["capability_valid"]
assert not ctx["capability_event"].is_set()

# A server backoff must be published immediately. The historical path slept
# while capability_flow_lock was held; this is the regression this A/B tests.
miner.fetch_job_once = lambda: (None, 0.75)
started = time.monotonic()
with miner.capability_flow_lock:
    compatible, fetched = miner.fetch_capability_for_seq(seq, 123, "offline")
elapsed = time.monotonic() - started
assert not compatible and fetched is None
assert elapsed < 0.10, f"nonblocking refresh took {elapsed:.3f}s"
assert not ctx["capability_valid"]
assert miner.stats["capability_refresh_deferred"] == 1
assert miner.stats["capability_backoffs"] == 1
assert miner.capability_retry_not_before > time.monotonic()

# A later same-work response must wake queued submitters even if only the
# opaque, single-use capability ID changed.
replacement = candidate("cap-2")
miner.fetch_job_once = lambda: (replacement, 0.0)
with miner.capability_flow_lock:
    compatible, fetched = miner.fetch_capability_for_seq(seq, 123, "offline")
assert compatible and fetched == replacement
assert ctx["template_id"] == "cap-2"
assert ctx["capability_valid"]
assert ctx["capability_event"].is_set()
assert miner.stats["capability_rebinds"] == 1

print(
    "NONBLOCKING CAPABILITY MODEL: PASS "
    f"(backoff_return_ms={elapsed * 1000.0:.2f} rebinds=1)"
)
