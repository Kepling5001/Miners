#!/usr/bin/env python3

import json
import math
import os
import signal
import statistics
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"
MINER = ROOT / "noid170_aria_ab.py"
TARGET_FOUND = max(200, int(os.environ.get("NOID_AB_FOUND_SHARES", "750")))
MAX_SECONDS = max(1800, int(os.environ.get("NOID_AB_MAX_SECONDS", "7200")))
CLK_TCK = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
VARIANTS = [
    ("baseline1", "baseline"),
    ("adaptive1", "adaptive"),
    ("adaptive2", "adaptive"),
    ("baseline2", "baseline"),
]


def detect_gpu_count():
    override = os.environ.get("NOID_TEST_GPU_COUNT", "").strip()
    if override:
        return int(override)
    result = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([line for line in result.stdout.splitlines() if line.strip()])


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def proc_info(pid):
    try:
        text = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8")
        rest = text[text.rfind(")") + 2:].split()
        return int(rest[1]), int(rest[11]) + int(rest[12])
    except (OSError, ValueError, IndexError):
        return None


def process_tree_ticks(root_pid):
    info = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        item = proc_info(int(entry.name))
        if item is not None:
            info[int(entry.name)] = item

    descendants = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, (ppid, _ticks) in info.items():
            if ppid in descendants and pid not in descendants:
                descendants.add(pid)
                changed = True
    return {pid: info[pid][1] for pid in descendants if pid in info}


def stop_process(proc):
    if proc.poll() is not None:
        return
    proc.send_signal(signal.SIGINT)
    try:
        proc.wait(timeout=15)
        return
    except subprocess.TimeoutExpired:
        proc.terminate()
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def result_row(name, mode, data, elapsed, cpu_ticks):
    accepted = int(data.get("accepted", 0))
    stale = int(data.get("stale", 0))
    rejected = int(data.get("rejected", 0))
    found = int(data.get("found", 0))
    submitted = accepted + stale + rejected
    old_drop = int(data.get("old_share_discarded", 0))
    queue_drop = int(data.get("queue_dropped", 0))
    accounted = submitted + old_drop + queue_drop
    wall = float(data.get("wall_total_mhs", 0.0))
    accepted_hashes = float(data.get("accepted_work_hashes", 0.0))
    found_hashes = float(data.get("found_work_hashes", 0.0))
    accepted_mh = accepted_hashes / max(0.001, elapsed) / 1e6
    found_mh = found_hashes / max(0.001, elapsed) / 1e6
    return {
        "variant": name,
        "mode": mode,
        "seconds": elapsed,
        "kernel": float(data.get("total_mhs", 0.0)),
        "wall": wall,
        "accepted_mh": accepted_mh,
        "found_mh": found_mh,
        "efficiency": 100.0 * accepted_hashes / found_hashes if found_hashes else 0.0,
        "accepted_hashes": accepted_hashes,
        "found_hashes": found_hashes,
        "stale_hashes": float(data.get("stale_work_hashes", 0.0)),
        "rejected_hashes": float(data.get("rejected_work_hashes", 0.0)),
        "old_hashes": float(data.get("old_discarded_work_hashes", 0.0)),
        "drop_hashes": float(data.get("queue_dropped_work_hashes", 0.0)),
        "found": found,
        "queued": int(data.get("queued_found", 0)),
        "accepted": accepted,
        "stale": stale,
        "rejected": rejected,
        "submitted": submitted,
        "submit_accept": 100.0 * accepted / submitted if submitted else 0.0,
        "found_accept": 100.0 * accepted / found if found else 0.0,
        "old_drop": old_drop,
        "queue_drop": queue_drop,
        "unresolved": max(0, found - accounted),
        "old_drop_pct": 100.0 * old_drop / found if found else 0.0,
        "cap_fail": int(data.get("capability_refresh_failures", 0)),
        "cap_defer": int(data.get("capability_refresh_deferred", 0)),
        "cap_backoff": int(data.get("capability_backoffs", 0)),
        "backoff_s": float(data.get("capability_backoff_seconds", 0.0)),
        "cap_wait": int(data.get("capability_waits", 0)),
        "cap_wait_s": float(data.get("capability_wait_ms", 0.0)) / 1000.0,
        "work_changes": int(data.get("capability_work_changes", 0)),
        "http_errors": int(data.get("http_errors", 0)),
        "get_avg": float(data.get("get_template_avg_ms", 0.0)),
        "get_max": float(data.get("get_template_max_ms", 0.0)),
        "submit_avg": float(data.get("submit_avg_ms", 0.0)),
        "submit_max": float(data.get("submit_max_ms", 0.0)),
        "ack": float(data.get("last_job_ack_ms", 0.0)),
        "max_ack": float(data.get("max_job_ack_ms", 0.0)),
        "cpu": cpu_ticks / CLK_TCK / max(0.001, elapsed) * 100.0,
    }


def run_variant(results_dir, name, mode, gpu_count):
    print(f"===== RUN {name} | mode={mode} | target={TARGET_FOUND} found shares =====", flush=True)
    stats_path = results_dir / f"{name}.json"
    log_path = results_dir / f"{name}.log"
    env = os.environ.copy()
    env.update({
        "NOID_CAPABILITY_MODE": mode,
        "NOID_GPU_COUNT": str(gpu_count),
        "NOID_SUBMIT_THREADS": "1",
        "NOID_POLL_INTERVAL": "0.20",
        "NOID_STATS_FILE": str(stats_path),
        "NOID_WARMUP_BIN": str(RUNTIME / "noid_live_job_cont"),
        "NOID_DAEMON_BIN": str(RUNTIME / "noid_live_job_daemon"),
        "NOID_TUI": "0",
    })

    started = time.monotonic()
    last_progress = 0.0
    previous_ticks = {}
    accumulated_ticks = 0
    last_data = None
    with open(log_path, "w", encoding="utf-8", buffering=1) as log:
        proc = subprocess.Popen(
            [sys.executable, "-u", str(MINER)],
            stdout=log,
            stderr=subprocess.STDOUT,
            env=env,
            cwd=str(ROOT),
        )
        try:
            while True:
                now = time.monotonic()
                if proc.poll() is not None:
                    raise RuntimeError(f"{name} exited early with code {proc.returncode}")
                current_ticks = process_tree_ticks(proc.pid)
                for pid, ticks in current_ticks.items():
                    if pid in previous_ticks and ticks >= previous_ticks[pid]:
                        accumulated_ticks += ticks - previous_ticks[pid]
                previous_ticks = current_ticks

                data = load_json(stats_path)
                if data:
                    last_data = data
                    found = int(data.get("found", 0))
                    accounted = (
                        int(data.get("accepted", 0))
                        + int(data.get("stale", 0))
                        + int(data.get("rejected", 0))
                        + int(data.get("old_share_discarded", 0))
                        + int(data.get("queue_dropped", 0))
                    )
                    pending = max(0, found - accounted)
                    if now - last_progress >= 30.0:
                        print(
                            f"{name}: found={found}/{TARGET_FOUND} pending={pending} "
                            f"A={data.get('accepted', 0)} S={data.get('stale', 0)} "
                            f"old={data.get('old_share_discarded', 0)} "
                            f"wall={data.get('wall_total_mhs', 0):.2f} MH/s",
                            flush=True,
                        )
                        last_progress = now
                    if (
                        found >= TARGET_FOUND
                        and pending == 0
                        and int(data.get("queue", 0)) == 0
                        and int(data.get("active_submissions", 0)) == 0
                    ):
                        break
                if now - started > MAX_SECONDS:
                    raise RuntimeError(f"{name} exceeded {MAX_SECONDS}s")
                time.sleep(1.0)
        finally:
            stop_process(proc)

    final_data = load_json(stats_path) or last_data
    if not final_data:
        tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-20:])
        raise RuntimeError(f"{name}: no stats produced\n{tail}")
    elapsed = max(0.001, float(final_data.get("production_uptime", time.monotonic() - started)))
    row = result_row(name, mode, final_data, elapsed, accumulated_ticks)
    print(
        f"{name}: accepted/found={row['found_accept']:.2f}% "
        f"submitted acceptance={row['submit_accept']:.2f}% "
        f"accepted={row['accepted']} stale={row['stale']} old={row['old_drop']}",
        flush=True,
    )
    return row


def mean_rows(rows, key):
    return statistics.mean(row[key] for row in rows)


def aggregate_rows(rows, mode):
    selected = [row for row in rows if row["mode"] == mode]
    found = sum(row["found"] for row in selected)
    accepted = sum(row["accepted"] for row in selected)
    found_hashes = sum(row["found_hashes"] for row in selected)
    accepted_hashes = sum(row["accepted_hashes"] for row in selected)
    return {
        "mode": mode,
        "runs": len(selected),
        "found": found,
        "accepted": accepted,
        "stale": sum(row["stale"] for row in selected),
        "old": sum(row["old_drop"] for row in selected),
        "drop": sum(row["queue_drop"] for row in selected),
        "unresolved": sum(row["unresolved"] for row in selected),
        "found_accept": 100.0 * accepted / found if found else 0.0,
        "efficiency": (
            100.0 * accepted_hashes / found_hashes if found_hashes else 0.0
        ),
        "cpu": mean_rows(selected, "cpu"),
    }


def proportion_diff_ci(candidate, baseline):
    p1 = candidate["accepted"] / max(1, candidate["found"])
    p0 = baseline["accepted"] / max(1, baseline["found"])
    standard_error = math.sqrt(
        p1 * (1.0 - p1) / max(1, candidate["found"])
        + p0 * (1.0 - p0) / max(1, baseline["found"])
    )
    difference = 100.0 * (p1 - p0)
    margin = 100.0 * 1.96 * standard_error
    return difference, difference - margin, difference + margin


def print_results(rows, results_dir):
    print()
    print("===== FINAL EQUAL-FOUND CAPABILITY A/B =====")
    print(
        f"{'variant':<10} {'wall':>9} {'found MH':>10} {'paid MH':>9} "
        f"{'paid%':>7} {'found':>6} {'A':>5} {'S':>4} {'old':>5} "
        f"{'drop':>4} {'pend':>4} {'A/found':>9} {'CPU':>7}"
    )
    for row in rows:
        print(
            f"{row['variant']:<10} {row['wall']:>9.2f} {row['found_mh']:>10.2f} "
            f"{row['accepted_mh']:>9.2f} {row['efficiency']:>6.2f}% "
            f"{row['found']:>6} {row['accepted']:>5} {row['stale']:>4} "
            f"{row['old_drop']:>5} {row['queue_drop']:>4} {row['unresolved']:>4} "
            f"{row['found_accept']:>8.2f}% {row['cpu']:>6.1f}%"
        )

    print()
    print("===== WEIGHTED LOSS BREAKDOWN =====")
    print(
        f"{'variant':<10} {'paid':>8} {'stale':>8} {'old':>8} "
        f"{'reject':>8} {'drop':>8} {'unacct':>8} {'A/sub':>8}"
    )
    for row in rows:
        denominator = max(1.0, row["found_hashes"])
        paid = row["efficiency"]
        stale = 100.0 * row["stale_hashes"] / denominator
        old = 100.0 * row["old_hashes"] / denominator
        rejected = 100.0 * row["rejected_hashes"] / denominator
        dropped = 100.0 * row["drop_hashes"] / denominator
        unaccounted = max(0.0, 100.0 - paid - stale - old - rejected - dropped)
        print(
            f"{row['variant']:<10} {paid:>7.2f}% {stale:>7.2f}% "
            f"{old:>7.2f}% {rejected:>7.2f}% {dropped:>7.2f}% "
            f"{unaccounted:>7.2f}% {row['submit_accept']:>7.2f}%"
        )

    print()
    print("===== RPC / SWITCH DETAIL =====")
    print(
        f"{'variant':<10} {'get avg':>8} {'get max':>8} {'sub avg':>8} "
        f"{'sub max':>8} {'backoff':>8} {'back s':>8} {'workchg':>8} "
        f"{'ACK':>7} {'maxACK':>7}"
    )
    for row in rows:
        print(
            f"{row['variant']:<10} {row['get_avg']:>7.1f} {row['get_max']:>7.1f} "
            f"{row['submit_avg']:>7.1f} {row['submit_max']:>7.1f} "
            f"{row['cap_backoff']:>8} {row['backoff_s']:>8.1f} "
            f"{row['work_changes']:>8} {row['ack']:>7.1f} {row['max_ack']:>7.1f}"
        )

    print()
    print("===== AGGREGATED MODE COMPARISON =====")
    print(
        f"{'mode':<10} {'runs':>4} {'found':>7} {'A':>6} {'S':>5} "
        f"{'old':>6} {'drop':>5} {'pend':>5} {'A/found':>9} "
        f"{'paid work':>10} {'CPU':>7}"
    )
    baseline = aggregate_rows(rows, "baseline")
    adaptive = aggregate_rows(rows, "adaptive")
    for summary in (baseline, adaptive):
        print(
            f"{summary['mode']:<10} {summary['runs']:>4} {summary['found']:>7} "
            f"{summary['accepted']:>6} {summary['stale']:>5} "
            f"{summary['old']:>6} {summary['drop']:>5} "
            f"{summary['unresolved']:>5} {summary['found_accept']:>8.2f}% "
            f"{summary['efficiency']:>9.2f}% {summary['cpu']:>6.1f}%"
        )

    count_delta, ci_low, ci_high = proportion_diff_ci(adaptive, baseline)
    work_delta = adaptive["efficiency"] - baseline["efficiency"]
    print()
    print(f"adaptive accepted/found change: {count_delta:+.2f} points")
    print(f"accepted/found 95% CI: [{ci_low:+.2f}, {ci_high:+.2f}] points")
    print(f"adaptive paid-work efficiency change: {work_delta:+.2f} points")
    if work_delta > 0.0 and ci_low > 0.0:
        print("decision: PASS — adaptive improved retained work with count-level confirmation")
    elif work_delta > 0.0 and ci_high >= 0.0:
        print("decision: MARGINAL — weighted work improved but count uncertainty remains")
    else:
        print("decision: FAIL — adaptive did not improve retained work")
    print(f"results and logs: {results_dir}")
    print("Paste both complete tables and the decision block into chat.")


def main():
    if not os.environ.get("NOID_MINING_KEY", "").strip():
        raise SystemExit("ERROR: NOID_MINING_KEY is not set")
    gpu_count = detect_gpu_count()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    results_dir = Path(os.environ.get("NOID_AB_RESULTS_DIR", f"/run/noid170-cap-lock-ab-{stamp}"))
    results_dir.mkdir(parents=True, exist_ok=True)
    print("===== LONG EQUAL-FOUND CAPABILITY RECOVERY A/B =====")
    print(f"GPUs: {gpu_count}  found shares/variant: {TARGET_FOUND}")
    print("Kernel: exact production v0.6.2 poll2000 daemon")
    print("Order: baseline1 -> adaptive1 -> adaptive2 -> baseline2")
    print(f"Results: {results_dir}")
    rows = []
    for index, (name, mode) in enumerate(VARIANTS):
        rows.append(run_variant(results_dir, name, mode, gpu_count))
        if index + 1 < len(VARIANTS):
            time.sleep(8.0)
    with open(results_dir / "summary.json", "w", encoding="utf-8") as handle:
        json.dump(rows, handle, indent=2)
        handle.write("\n")
    print_results(rows, results_dir)


if __name__ == "__main__":
    main()
