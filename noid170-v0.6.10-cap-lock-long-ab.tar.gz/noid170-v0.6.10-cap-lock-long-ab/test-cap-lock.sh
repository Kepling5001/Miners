#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

cleanup() {
  pkill -f "$ROOT/runtime/noid_live_job_daemon" >/dev/null 2>&1 || true
  pkill -f "$ROOT/noid170_aria_ab.py" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

if pgrep -f '/hive/miners/custom/noid170/noid170_aria.py' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Run: miner stop"
  exit 1
fi

CONF="/hive/miners/custom/noid170/noid170.conf"
if [[ -f "$CONF" ]]; then
  # Load the exact live pool, worker, vardiff and queue settings without
  # printing the credential into the benchmark output.
  # shellcheck disable=SC1090
  source "$CONF"
  export NOID_MINING_KEY NOID_RPC_URL NOID_CARD_MH NOID_MAX_TOTAL_SHARES_SEC
  export NOID_SUBMIT_THREADS NOID_POLL_INTERVAL NOID_SHARE_QUEUE_SIZE
  export NOID_HARD_EXPIRY_AGE NOID_ACCEPTED_WORK_WINDOW
  export NOID_CAPABILITY_REFRESH_TIMEOUT
fi

if [[ -z "${NOID_MINING_KEY:-}" ]]; then
  echo "ERROR: export NOID_MINING_KEY='your_address.worker' first"
  exit 1
fi

[[ -x "$ROOT/runtime/noid_live_job_daemon" ]] || {
  echo "ERROR: production poll2000 daemon is missing"
  exit 1
}

echo "This test does not install or replace the HiveOS miner."
echo "Default: 750 found shares in each of four interleaved runs."
python3 "$ROOT/offline_verify.py"
python3 -u "$ROOT/benchmark_cap_lock.py"
echo
echo "Restart normal HiveOS mining when finished: apply the flight sheet or run miner start"
