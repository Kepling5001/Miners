# NOID170 v0.6.10 equal-found capability validation

This is a non-installing stale-path experiment based on the validated
`noid170-0.6.2-poll2ms` package. It contains the exact same GPU binaries.

It compares four equal-found-share runs in a balanced order:

1. `baseline1` — current blocking capability recovery.
2. `adaptive1` — nonblocking recovery plus server-directed retry timing.
3. `adaptive2` — adaptive repeated immediately.
4. `baseline2` — control repeated after the candidates.

The rejected `nonblock` mode from v0.6.9 is intentionally gone. Queued shares
in adaptive mode wait for a valid capability without blocking the
meaningful-work watcher. Exact work weight is tracked for every found,
accepted, stale, rejected and locally discarded share. The final report also
aggregates both runs per mode and gives a 95% interval for the count result.

## Run

```bash
cd /home/user/noid170-v0.6.10-cap-lock-long-ab
miner stop
export NOID_MINING_KEY='your_address.worker'
export NOID_TEST_GPU_COUNT=12
./test-cap-lock.sh
miner start
```

If the current HiveOS custom-miner configuration exists, `test-cap-lock.sh`
loads `NOID_MINING_KEY` from it, so the explicit key export can be omitted.

The installed HiveOS miner is not modified. The default is 750 found shares
per variant: approximately one hour total on a 12-GPU rig or about three hours
on the 4-GPU OctominerTEST rig. Override it with
`NOID_AB_FOUND_SHARES=500` for a shorter preliminary run.
