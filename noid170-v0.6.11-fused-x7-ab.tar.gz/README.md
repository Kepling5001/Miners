# NOID170 v0.6.11 fused x^7 S-box A/B

This correctness-gated experiment keeps the proven production baseline:

- `r4top` general reduction
- `prod2` partial-MDS product ILP
- `r2lop3` square-only reduction
- `all_nv` non-volatile paired CLMAD scheduling
- 2 ms CUDA event-query polling

Only the `x^7` S-box implementation changes. The suite tests two distinct
ideas:

1. A single straight-line primitive that interleaves the independent `x^4`
   square and `x^3` multiplication products and their heterogeneous
   reductions.
2. A true lazy-reduction path that leaves `x^3` as a 256-bit product,
   multiplies it by `x^4`, and performs one exact 384-to-128-bit reduction.
   The identity `x^128 = 0x87` and `x^256 = 0x4015` moves the final fold from
   CLMAD to shifts/XOR or LOP3. This saves two CLMAD instructions per S-box at
   the cost of extra integer work and registers.

Both 1024- and 512-thread launch shapes are included where register pressure
could change the result. Every binary must pass offline algebra, GPU S-box,
full Poseidon, and chained-Poseidon oracles before benchmarking. The measured
winner alone receives the persistent-worker accepted-share test.

This package is an A/B experiment. It does not install or replace the HiveOS
custom miner.

```bash
cd /home/user/noid170-v0.6.11-fused-x7-ab
miner stop
chmod +x build-on-rig.sh test-fused-x7.sh test-persistent.sh
./build-on-rig.sh

export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-fused-x7.sh

miner start
```

The balanced forward/reverse benchmark uses ten STAT samples per run by
default. Set `NOID_BENCH_STATS=14` for a longer confirmation run.
