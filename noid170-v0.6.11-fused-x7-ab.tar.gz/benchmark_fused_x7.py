#!/usr/bin/env python3

import http.client
import json
import os
import queue
import re
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
SAMPLES = max(6, int(os.environ.get("NOID_BENCH_STATS", "10")))

VARIANTS = [
    ("current", "production four-stage x7"),
    ("fused", "fused x4/x3 branch schedule"),
    ("fusedpair", "fused branch paired asm"),
    ("lazy3", "lazy x3 384-bit shift reduce"),
    ("lazy3lop3", "lazy x3 384-bit lop3 reduce"),
    ("fused512", "fused branch, 512 threads"),
    ("fusedpair512", "paired fused, 512 threads"),
    ("lazy3_512", "lazy x3, 512 threads"),
]

LAUNCHES = {
    "current": (1024, 64),
    "fused": (1024, 64),
    "fusedpair": (1024, 64),
    "lazy3": (1024, 64),
    "lazy3lop3": (1024, 64),
    "fused512": (512, 128),
    "fusedpair512": (512, 128),
    "lazy3_512": (512, 128),
}

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    connection = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        connection.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-fused-x7-bench/0.6.11",
            },
        )
        response = connection.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        connection.close()


def get_job(timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def resource_info(name):
    path = os.path.join(BIN, f"build_{name}.log")
    try:
        text = open(path, "r", encoding="utf-8", errors="replace").read()
        match = re.search(
            r"Compiling entry function '_Z11mine_kernel.*?"
            r"(\d+) bytes spill stores, (\d+) bytes spill loads.*?"
            r"Used (\d+) registers",
            text,
            flags=re.S,
        )
        if match:
            return int(match.group(3)), int(match.group(1)), int(match.group(2))
    except OSError:
        pass
    return None, None, None


def run_once(name, label, job, run_number):
    binary = os.path.join(BIN, f"noid_daemon_{name}")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [binary, "--daemon", str(0x5500 + run_number)],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )
    events = queue.Queue()

    def reader():
        for line in proc.stderr:
            events.put(line.strip())

    threading.Thread(target=reader, daemon=True).start()

    def wait_for(prefix, timeout=12):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if proc.poll() is not None:
                raise RuntimeError(f"{name}: daemon exited with {proc.returncode}")
            try:
                line = events.get(timeout=0.5)
            except queue.Empty:
                continue
            if line.startswith(prefix):
                return line
        raise RuntimeError(f"{name}: timeout waiting for {prefix}")

    try:
        wait_for("READY ")
        hard_target = "01" + "00" * 31
        proc.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard_target}\n")
        proc.stdin.flush()
        wait_for("JOBACK 1 ")

        samples = []
        while len(samples) < SAMPLES:
            fields = wait_for("STAT ").split()
            samples.append((float(fields[1]), float(fields[5])))

        used = samples[3:]
        kernel = statistics.mean(item[0] for item in used)
        wall = statistics.mean(item[1] for item in used)
        print(f"{name:9s} run{run_number}  kernel={kernel:8.3f}  wall={wall:8.3f} MH/s")
        return kernel, wall
    finally:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n")
                proc.stdin.flush()
                proc.wait(timeout=4)
            except Exception:
                proc.terminate()
                proc.wait(timeout=4)


job = get_job()
print("===== FUSED X7 S-BOX A/B BENCHMARK | GPU0 =====")
print(f"height: {job['height']}  samples/run: {SAMPLES}  stat8; launch shown per row")

measurements = {name: [] for name, _ in VARIANTS}
labels = dict(VARIANTS)
order = [name for name, _ in VARIANTS] + [name for name, _ in reversed(VARIANTS)]
for index, name in enumerate(order, 1):
    measurements[name].append(run_once(name, labels[name], job, index))

results = []
for name, label in VARIANTS:
    kernel = statistics.mean(item[0] for item in measurements[name])
    wall = statistics.mean(item[1] for item in measurements[name])
    regs, spill_stores, spill_loads = resource_info(name)
    results.append({
        "name": name,
        "label": label,
        "kernel": kernel,
        "wall": wall,
        "regs": regs,
        "spill_stores": spill_stores,
        "spill_loads": spill_loads,
        "threads": LAUNCHES[name][0],
        "blocks_per_sm": LAUNCHES[name][1],
    })

baseline = next(item for item in results if item["name"] == "current")
ranked = sorted(results, key=lambda item: item["wall"], reverse=True)

print("\n===== FINAL FUSED X7 S-BOX RANKING =====")
print(f"{'rank':>4s}  {'variant':13s} {'description':34s} {'T':>4s} {'B/SM':>4s} {'regs':>4s} {'spill S/L':>10s} {'kernel':>10s} {'wall':>10s} {'vs current':>10s}")
for rank, result in enumerate(ranked, 1):
    gain = (result["wall"] / baseline["wall"] - 1.0) * 100.0
    regs = "?" if result["regs"] is None else str(result["regs"])
    spills = "?/?" if result["spill_stores"] is None else f"{result['spill_stores']}/{result['spill_loads']}"
    print(
        f"{rank:4d}  {result['name']:13s} {result['label']:34s} "
        f"{result['threads']:4d} {result['blocks_per_sm']:4d} {regs:>4s} {spills:>10s} "
        f"{result['kernel']:10.3f} {result['wall']:10.3f} {gain:+8.2f}%"
    )

winner = ranked[0]
winner_path = os.path.join(ROOT, "winner.txt")
with open(winner_path, "w", encoding="utf-8") as handle:
    handle.write(winner["name"] + "\n")

print(f"\nbaseline: current wall={baseline['wall']:.3f} MH/s")
print(f"winner:   {winner['name']} wall={winner['wall']:.3f} MH/s")
print(f"gain:     {(winner['wall'] / baseline['wall'] - 1.0) * 100.0:+.2f}%")
print(f"persistent test will use: {winner['name']}")
