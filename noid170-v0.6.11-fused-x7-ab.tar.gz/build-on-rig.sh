#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}
mkdir -p "$BIN"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1 -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000 -Xptxas=-v
)

build_variant() {
  local name="$1" fuse="$2" threads="$3" blocks_per_sm="$4" extra="${5:-}"
  local extra_flags=()
  [[ -n "$extra" ]] && extra_flags+=("$extra")

  echo
  echo "===== BUILD $name | x7=$fuse threads=$threads blocks/sm=$blocks_per_sm ====="
  "$NVCC" "${COMMON[@]}" "${extra_flags[@]}" \
    -DNOID_SBOX_FUSE_VARIANT="$fuse" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" \
    2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" "${extra_flags[@]}" \
    -DNOID_SBOX_FUSE_VARIANT="$fuse" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$ROOT/test_gf_primitives.cu" -o "$BIN/test_gf_$name" \
    2>&1 | tee "$BIN/build_oracle_$name.log"

  chmod 755 "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

# Production all_nv+r2lop3 kernel, then fused scheduling and true lazy paths.
build_variant current       0 1024  64
build_variant fused         1 1024  64
build_variant fusedpair     2 1024  64
build_variant lazy3         3 1024  64
build_variant lazy3lop3     4 1024  64 -DNOID_X7_LAZY_LOP3=1
build_variant fused512      1  512 128
build_variant fusedpair512  2  512 128
build_variant lazy3_512     3  512 128

python3 "$ROOT/offline_verify.py"
python3 -m py_compile "$ROOT/benchmark_fused_x7.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-fused-x7.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-fused-x7.sh"
