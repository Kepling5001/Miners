# noid170 v0.5.7 dual-state A/B

High-upside experiment built from the proven v0.5.6 production kernel:

- `current`: exact v0.5.6 single-state baseline (`prod2 + r4top`)
- `dual256`, `dual512`: two independent nonce states per CUDA thread
- `prod256`, `prod512`: dual state plus explicit paired CLMAD product stages
- `full256`, `full512`: dual state plus paired product and reduction stages

Every benchmark variant covers the same number of nonces per kernel launch.
The 256/512-thread dual launches avoid forcing the doubled live state into a
1024-thread block, where register limits can prevent launch or create spills.

On the CMP170HX test rig:

```bash
cd /home/user/noid170-v0.5.7-dual-state-ab
miner stop
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-dual-state.sh
miner start
```

The test performs offline verification, a GPU correctness oracle for every
variant, balanced forward/reverse A/B timing, and an accepted-share persistent
worker test using the measured winner.
