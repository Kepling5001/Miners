#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local dual_variant="$2"
  local threads="$3"
  local blocks_per_sm="$4"
  local dual_state="$5"
  local extra=()

  if [[ "$dual_state" == "1" ]]; then
    extra+=( -DNOID_DUAL_STATE=1 )
  fi

  echo
  echo "===== BUILD $name | dual=$dual_variant threads=$threads blocks/sm=$blocks_per_sm ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_DUAL_VARIANT="$dual_variant" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_DUAL_VARIANT="$dual_variant" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

# All variants cover exactly 4,587,520 nonces per kernel on a 70-SM CMP170HX.
build_variant current 1 1024 64  0
build_variant dual256 1 256 128 1
build_variant dual512 1 512 64  1
build_variant prod256 2 256 128 1
build_variant prod512 2 512 64  1
build_variant full256 3 256 128 1
build_variant full512 3 512 64  1

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_dual_state.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-dual-state.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-dual-state.sh"
