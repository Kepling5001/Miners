#!/usr/bin/env python3

import concurrent.futures
import http.client
import json
import math
import os
import queue
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

VERSION = "0.1.2"
DEFAULT_RPC_URL = "https://pool.ariabrain.com/noid-rpc/"

MINING_KEY = os.environ.get("NOID_MINING_KEY", "").strip()
RPC_URL = os.environ.get("NOID_RPC_URL", DEFAULT_RPC_URL).strip() or DEFAULT_RPC_URL
CARD_MH = float(os.environ.get("NOID_CARD_MH", "36.24"))
MAX_TOTAL_SHARES_SEC = float(os.environ.get("NOID_MAX_TOTAL_SHARES_SEC", "50"))
SUBMIT_THREADS = max(1, int(os.environ.get("NOID_SUBMIT_THREADS", "16")))
POLL_INTERVAL = float(os.environ.get("NOID_POLL_INTERVAL", "0.50"))
REFRESH_AGE = float(os.environ.get("NOID_REFRESH_AGE", "8.0"))
HARD_EXPIRY_AGE = float(os.environ.get("NOID_HARD_EXPIRY_AGE", "10.5"))
SHARE_QUEUE_SIZE = max(256, int(os.environ.get("NOID_SHARE_QUEUE_SIZE", "5000")))
STATS_FILE = os.environ.get("NOID_STATS_FILE", "/run/noid170/stats.json")
WORKER_BIN = os.environ.get(
    "NOID_WORKER_BIN",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "noid_live_job_cont"),
)
TUI = os.environ.get("NOID_TUI", "auto").lower()


def detect_gpu_count():
    override = os.environ.get("NOID_GPU_COUNT")
    if override:
        count = int(override)
        if count < 1:
            raise RuntimeError("NOID_GPU_COUNT must be >= 1")
        return count

    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    count = len([line for line in p.stdout.splitlines() if line.strip()])
    if count < 1:
        raise RuntimeError("No NVIDIA GPUs detected")
    return count


GPU_COUNT = detect_gpu_count()
TOTAL_MH = CARD_MH * GPU_COUNT

u = urlsplit(RPC_URL)
if u.scheme not in ("http", "https"):
    raise RuntimeError(f"Unsupported RPC URL scheme: {u.scheme}")
RPC_SCHEME = u.scheme
RPC_HOST = u.hostname
RPC_PORT = u.port
RPC_PATH = u.path or "/"
if u.query:
    RPC_PATH += "?" + u.query
if not RPC_HOST:
    raise RuntimeError(f"Invalid NOID_RPC_URL: {RPC_URL}")

if not MINING_KEY:
    raise RuntimeError("NOID_MINING_KEY is not set")

running = True
share_queue = queue.Queue(maxsize=SHARE_QUEUE_SIZE)
lock = threading.Lock()
generation = 0
active_template_id = None
gpu_rates = [0.0] * GPU_COUNT
gpu_rate_measured = [False] * GPU_COUNT

stats = {
    "accepted": 0,
    "stale": 0,
    "rejected": 0,
    "http_errors": 0,
    "queue_dropped": 0,
    "old_share_discarded": 0,
    "height_regressions": 0,
    "job_switches": 0,
}


def sig_handler(signum, frame):
    global running
    running = False


signal.signal(signal.SIGTERM, sig_handler)
signal.signal(signal.SIGINT, sig_handler)


def make_conn():
    cls = http.client.HTTPSConnection if RPC_SCHEME == "https" else http.client.HTTPConnection
    return cls(RPC_HOST, RPC_PORT, timeout=5)


def rpc(conn, method, params):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    conn.request(
        "POST",
        RPC_PATH,
        body=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {MINING_KEY}",
            "User-Agent": f"noid170/{VERSION}",
            "Accept": "*/*",
            "Connection": "keep-alive",
        },
    )
    response = conn.getresponse()
    data = response.read()
    if response.status != 200:
        raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
    return json.loads(data)


def fetch_job_once():
    conn = make_conn()
    try:
        j = rpc(conn, "paranoid_getBlockTemplate", [""])
    finally:
        try:
            conn.close()
        except Exception:
            pass

    err = j.get("error")
    if not err:
        return j["result"], 0.0

    if isinstance(err, dict) and err.get("code") == -32011:
        retry_ms = err.get("data", {}).get("retry_in_ms", 500)
        return None, max(0.05, retry_ms / 1000.0)

    raise RuntimeError(err)


def wait_for_job(minimum_height=None, timeout=20.0):
    deadline = time.monotonic() + timeout
    while running and time.monotonic() < deadline:
        try:
            job, retry = fetch_job_once()
        except Exception as e:
            print(f"Template fetch error: {e}", flush=True)
            time.sleep(0.5)
            continue

        if job is None:
            time.sleep(retry)
            continue

        h = int(job["height"])
        if minimum_height is not None and h < minimum_height:
            with lock:
                stats["height_regressions"] += 1
            time.sleep(0.10)
            continue
        return job

    raise RuntimeError("Timed out waiting for usable Aria template")


def target_metrics(job):
    target = int.from_bytes(bytes.fromhex(job["difficulty_target_hex"]), "little")
    if target <= 0:
        return float("inf"), 0.0
    probability = target / (1 << 256)
    hashes_per_share = 1.0 / probability
    total_shares_sec = TOTAL_MH * 1e6 / hashes_per_share
    return hashes_per_share, total_shares_sec


def show_target(label, job):
    hps, total_sps = target_metrics(job)
    print(
        f"{label}: height {job['height']} | {hps:,.0f} hashes/share | "
        f"~{total_sps:,.1f} shares/s across {GPU_COUNT} GPUs",
        flush=True,
    )


def mine_warmup_candidates(job, wanted=64):
    _, total_sps = target_metrics(job)
    card_sps = max(total_sps / GPU_COUNT, 0.01)

    # Gather ~96 expected candidates, but cap the mining window safely below
    # Aria's normal template lifetime. On larger rigs, use multiple GPUs so
    # warmup can still complete even near the handoff threshold.
    target_candidates = max(wanted + 16, 96)
    max_window = 6.5
    warm_gpus = max(1, math.ceil(target_candidates / (card_sps * max_window)))
    warm_gpus = min(GPU_COUNT, warm_gpus)
    warmup_seconds = target_candidates / (card_sps * warm_gpus)
    warmup_seconds = max(2.5, min(max_window, warmup_seconds + 0.35))

    print(
        f"Warmup: {warm_gpus} GPU(s) for ~{warmup_seconds:.2f}s "
        f"({card_sps:,.2f} expected shares/s/card)",
        flush=True,
    )

    procs = []
    salt_base = time.time_ns() & 0x7FFFFFFFFFFFFFFF
    for gpu in range(warm_gpus):
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        cmd = [
            "timeout",
            f"{warmup_seconds:.2f}s",
            WORKER_BIN,
            job["pow_fields_hex"],
            job["difficulty_target_hex"],
            "0",
            str(salt_base + gpu + 1),
        ]
        p = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )
        procs.append(p)

    shares = []
    seen = set()
    for p in procs:
        out, _ = p.communicate()
        for line in out.splitlines():
            if not line.startswith("SHARE "):
                continue
            parts = line.split()
            if len(parts) != 2:
                continue
            nonce = parts[1]
            if nonce in seen:
                continue
            seen.add(nonce)
            shares.append(nonce)

    print(f"Warmup produced {len(shares)} unique candidates", flush=True)
    return shares[:wanted]


def warmup_submit_chunk(template_id, nonces):
    conn = make_conn()
    accepted = stale = rejected = 0
    try:
        for nonce in nonces:
            try:
                j = rpc(conn, "paranoid_submitBlock", [template_id, nonce])
                result = str(j.get("result", ""))
                error = str(j.get("error", ""))
                text = (result + " " + error).lower()
                if result == "share accepted":
                    accepted += 1
                elif "stale" in text or "expired" in text:
                    stale += 1
                else:
                    rejected += 1
            except Exception:
                rejected += 1
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return accepted, stale, rejected


def submit_warmup(job, shares):
    chunks = [shares[i : i + 8] for i in range(0, len(shares), 8)]
    accepted = stale = rejected = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(chunks) or 1)) as ex:
        futures = [
            ex.submit(warmup_submit_chunk, job["template_id"], chunk) for chunk in chunks
        ]
        for f in futures:
            a, s, r = f.result()
            accepted += a
            stale += s
            rejected += r
    return accepted, stale, rejected


def wait_for_retarget(old_job, timeout=5.0):
    deadline = time.monotonic() + timeout
    old_height = int(old_job["height"])
    old_target = old_job["difficulty_target_hex"]
    old_pow = old_job["pow_fields_hex"]
    latest = old_job

    while running and time.monotonic() < deadline:
        try:
            job, retry = fetch_job_once()
        except Exception:
            time.sleep(0.25)
            continue

        if job is None:
            time.sleep(retry)
            continue

        height = int(job["height"])
        if height < old_height:
            with lock:
                stats["height_regressions"] += 1
            continue

        latest = job
        if height > old_height:
            return job
        if job["difficulty_target_hex"] != old_target:
            return job
        if job["pow_fields_hex"] != old_pow:
            return job
        time.sleep(0.20)

    return latest


def warm_up_vardiff(job):
    print("\n===== ARIA VARDIFF WARMUP =====", flush=True)
    rounds = 0
    while running:
        _, total_sps = target_metrics(job)
        show_target("Current", job)
        if total_sps <= MAX_TOTAL_SHARES_SEC:
            print("Share rate is sane. Enabling full rig.", flush=True)
            return job

        rounds += 1
        if rounds > 12:
            raise RuntimeError("Vardiff failed to converge after 12 warmup rounds")

        print("Target is too easy; controlled warmup in progress...", flush=True)
        shares = mine_warmup_candidates(job, 64)
        if len(shares) < 64:
            print("Not enough warmup shares; fetching a fresh template.", flush=True)
            job = wait_for_job(minimum_height=int(job["height"]))
            continue

        a, s, r = submit_warmup(job, shares)
        print(f"Warmup submissions: {a} accepted | {s} stale | {r} rejected", flush=True)
        if a == 0:
            job = wait_for_job(minimum_height=int(job["height"]))
            continue

        job = wait_for_retarget(job, timeout=5.0)
        print(flush=True)

    raise RuntimeError("Miner stopped during vardiff warmup")


def current_generation():
    with lock:
        return generation


def bump_generation():
    global generation
    with lock:
        generation += 1
        return generation


def set_active_template_id(template_id):
    global active_template_id
    with lock:
        active_template_id = template_id


def get_active_template_id():
    with lock:
        return active_template_id


def purge_queue():
    removed = 0
    while True:
        try:
            share_queue.get_nowait()
        except queue.Empty:
            break
        share_queue.task_done()
        removed += 1
    if removed:
        with lock:
            stats["old_share_discarded"] += removed


def gpu_stdout_reader(gpu, proc, worker_generation):
    for line in proc.stdout:
        if not running:
            break
        line = line.strip()
        if not line.startswith("SHARE "):
            continue
        parts = line.split()
        if len(parts) != 2:
            continue
        nonce = parts[1]
        try:
            share_queue.put_nowait((worker_generation, nonce))
        except queue.Full:
            with lock:
                stats["queue_dropped"] += 1


def gpu_stderr_reader(gpu, proc):
    for line in proc.stderr:
        if not running:
            break
        line = line.strip()
        if not line.startswith("STAT "):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        try:
            rate = float(parts[1])
        except ValueError:
            continue
        with lock:
            gpu_rates[gpu] = rate
            gpu_rate_measured[gpu] = True


def start_gpus(job, worker_generation):
    workers = []

    # HiveOS asks for stats immediately after a miner starts/restarts. The CUDA
    # worker's first measured STAT arrives a little later, which previously made
    # HiveOS show 0 MH/s during startup and fast job transitions. Seed each
    # active GPU with the proven expected card rate, then replace it with the
    # worker's real measured rate as soon as the first STAT line arrives.
    with lock:
        for i in range(GPU_COUNT):
            gpu_rates[i] = CARD_MH
            gpu_rate_measured[i] = False

    for gpu in range(GPU_COUNT):
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        salt = worker_generation * 4096 + gpu + 1
        proc = subprocess.Popen(
            [
                WORKER_BIN,
                job["pow_fields_hex"],
                job["difficulty_target_hex"],
                "0",
                str(salt),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
        tout = threading.Thread(
            target=gpu_stdout_reader,
            args=(gpu, proc, worker_generation),
            daemon=True,
        )
        terr = threading.Thread(target=gpu_stderr_reader, args=(gpu, proc), daemon=True)
        tout.start()
        terr.start()
        workers.append((gpu, proc, tout, terr))
    return workers


def stop_gpus(workers):
    for _, proc, _, _ in workers:
        if proc.poll() is None:
            proc.terminate()

    deadline = time.monotonic() + 1.5
    for _, proc, _, _ in workers:
        if proc.poll() is not None:
            continue
        remain = max(0.0, deadline - time.monotonic())
        try:
            proc.wait(timeout=remain)
        except subprocess.TimeoutExpired:
            proc.kill()

    with lock:
        for i in range(GPU_COUNT):
            gpu_rates[i] = 0.0
            gpu_rate_measured[i] = False


def submitter(thread_id):
    conn = make_conn()
    while running:
        try:
            item = share_queue.get(timeout=0.5)
        except queue.Empty:
            continue

        if item is None:
            share_queue.task_done()
            break

        item_generation, nonce = item
        if item_generation != current_generation():
            with lock:
                stats["old_share_discarded"] += 1
            share_queue.task_done()
            continue

        template_id = get_active_template_id()
        if not template_id:
            with lock:
                stats["old_share_discarded"] += 1
            share_queue.task_done()
            continue

        try:
            j = rpc(conn, "paranoid_submitBlock", [template_id, nonce])
            result = str(j.get("result", ""))
            error = str(j.get("error", ""))
            text = (result + " " + error).lower()
            with lock:
                if result == "share accepted":
                    stats["accepted"] += 1
                elif "stale" in text or "expired" in text:
                    stats["stale"] += 1
                else:
                    stats["rejected"] += 1
        except Exception:
            with lock:
                stats["http_errors"] += 1
            try:
                conn.close()
            except Exception:
                pass
            conn = make_conn()
        finally:
            share_queue.task_done()

    try:
        conn.close()
    except Exception:
        pass


def snapshot(start_time, job):
    with lock:
        rates = gpu_rates[:]
        measured = gpu_rate_measured[:]
        s = dict(stats)
    hps, expected_sps = target_metrics(job)
    return {
        "version": VERSION,
        "timestamp": int(time.time()),
        "uptime": int(time.monotonic() - start_time),
        "height": int(job["height"]),
        "template_id": job["template_id"],
        "gpu_count": GPU_COUNT,
        "gpu_rates_mhs": rates,
        "gpu_rates_measured": measured,
        "total_mhs": sum(rates),
        "hashes_per_share": hps,
        "expected_shares_per_sec": expected_sps,
        "accepted": s["accepted"],
        "stale": s["stale"],
        "rejected": s["rejected"],
        "http_errors": s["http_errors"],
        "queue": share_queue.qsize(),
        "queue_dropped": s["queue_dropped"],
        "old_share_discarded": s["old_share_discarded"],
        "height_regressions": s["height_regressions"],
        "job_switches": s["job_switches"],
        "rpc_url": RPC_URL,
    }


def write_stats_file(data):
    try:
        directory = os.path.dirname(STATS_FILE)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp = STATS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
            f.write("\n")
        os.replace(tmp, STATS_FILE)
    except Exception:
        pass


def use_tui():
    if TUI in ("1", "yes", "true", "on"):
        return True
    if TUI in ("0", "no", "false", "off"):
        return False
    return sys.stdout.isatty()


def print_status(data, force=False):
    if use_tui():
        print("\033[2J\033[H", end="")
        print(f"NOID170 v{VERSION} | AriaPool | {GPU_COUNT}x CMP 170HX | 0% dev fee")
        print(f"Height {data['height']} | Job {data['template_id']}")
        print(
            f"Vardiff {data['hashes_per_share']:,.0f} hashes/share | "
            f"expected ~{data['expected_shares_per_sec']:,.1f} shares/s"
        )
        print()
        measured = data.get("gpu_rates_measured", [True] * len(data["gpu_rates_mhs"]))
        for gpu, rate in enumerate(data["gpu_rates_mhs"]):
            mark = " " if gpu < len(measured) and measured[gpu] else "~"
            print(f"GPU{gpu:<2}{mark}{rate:7.2f} MH/s")
        print(f"TOTAL {data['total_mhs']:7.2f} MH/s")
        print()
        print(
            f"Accepted {data['accepted']:,} | Stale {data['stale']:,} | "
            f"Rejected {data['rejected']:,}"
        )
        print(
            f"HTTP errors {data['http_errors']:,} | Queue {data['queue']:,} | "
            f"Dropped {data['queue_dropped']:,}"
        )
        print(
            f"Old discarded {data['old_share_discarded']:,} | "
            f"Height regressions {data['height_regressions']:,} | "
            f"Job switches {data['job_switches']:,}"
        )
        u = data["uptime"]
        print(f"Uptime {u//3600:02d}:{(u%3600)//60:02d}:{u%60:02d}")
        sys.stdout.flush()
    elif force:
        print(
            f"STATUS height={data['height']} total={data['total_mhs']:.2f}MH/s "
            f"accepted={data['accepted']} stale={data['stale']} rejected={data['rejected']} "
            f"queue={data['queue']} switches={data['job_switches']}",
            flush=True,
        )


def main():
    global running

    start_time = time.monotonic()
    print(f"NOID170 v{VERSION}", flush=True)
    print(f"RPC: {RPC_URL}", flush=True)
    print(f"Detected GPUs: {GPU_COUNT}", flush=True)
    print(f"Expected CMP 170HX rate: {CARD_MH:.2f} MH/s/card", flush=True)

    job = wait_for_job()
    show_target("Initial", job)
    job = warm_up_vardiff(job)

    print(f"Starting {SUBMIT_THREADS} persistent submitters...", flush=True)
    submit_threads = []
    for i in range(SUBMIT_THREADS):
        t = threading.Thread(target=submitter, args=(i,), daemon=True)
        t.start()
        submit_threads.append(t)

    worker_generation = bump_generation()
    set_active_template_id(job["template_id"])
    workers = start_gpus(job, worker_generation)
    with lock:
        stats["job_switches"] += 1

    job_started = time.monotonic()
    last_poll = 0.0
    last_status = 0.0
    last_log_status = 0.0
    latest_usable = None

    try:
        while running:
            now = time.monotonic()

            for gpu, proc, _, _ in workers:
                rc = proc.poll()
                if rc is not None:
                    raise RuntimeError(f"GPU {gpu} worker exited with code {rc}")

            if now - last_status >= 1.0:
                data = snapshot(start_time, job)
                write_stats_file(data)
                print_status(data, force=(not use_tui() and now - last_log_status >= 10.0))
                if not use_tui() and now - last_log_status >= 10.0:
                    last_log_status = now
                last_status = now

            candidate = None
            if now - last_poll >= POLL_INTERVAL:
                last_poll = now
                try:
                    candidate, _retry = fetch_job_once()
                except Exception:
                    candidate = None
                    with lock:
                        stats["http_errors"] += 1

                if candidate is not None:
                    current_height = int(job["height"])
                    new_height = int(candidate["height"])
                    if new_height < current_height:
                        with lock:
                            stats["height_regressions"] += 1
                        candidate = None
                    else:
                        latest_usable = candidate

            # Aria often issues a fresh template ID while the actual PoW fields
            # and vardiff target are unchanged. Refresh only the submission ID;
            # do NOT kill/restart CUDA contexts in that case.
            if candidate is not None:
                same_pow = candidate["pow_fields_hex"] == job["pow_fields_hex"]
                same_target = (
                    candidate["difficulty_target_hex"] == job["difficulty_target_hex"]
                )
                if same_pow and same_target:
                    job = candidate
                    set_active_template_id(job["template_id"])
                    job_started = now
                    latest_usable = None
                    candidate = None

            switch_to = None
            if candidate is not None:
                if candidate["pow_fields_hex"] != job["pow_fields_hex"]:
                    switch_to = candidate
                elif candidate["difficulty_target_hex"] != job["difficulty_target_hex"]:
                    switch_to = candidate

            age = now - job_started
            if switch_to is None and age >= REFRESH_AGE and latest_usable is not None:
                # If latest_usable is identical, this should normally have been
                # consumed above as an ID-only refresh. Keep this as a safety path.
                switch_to = latest_usable

            if switch_to is None and age >= HARD_EXPIRY_AGE:
                bump_generation()
                stop_gpus(workers)
                purge_queue()
                job = wait_for_job(minimum_height=int(job["height"]))
                job = warm_up_vardiff(job)
                set_active_template_id(job["template_id"])
                worker_generation = bump_generation()
                workers = start_gpus(job, worker_generation)
                with lock:
                    stats["job_switches"] += 1
                job_started = time.monotonic()
                latest_usable = None
                continue

            if switch_to is not None:
                # If it is actually identical, only refresh the template ID.
                same_pow = switch_to["pow_fields_hex"] == job["pow_fields_hex"]
                same_target = (
                    switch_to["difficulty_target_hex"] == job["difficulty_target_hex"]
                )
                if same_pow and same_target:
                    job = switch_to
                    set_active_template_id(job["template_id"])
                    job_started = time.monotonic()
                    latest_usable = None
                    continue

                bump_generation()
                stop_gpus(workers)
                purge_queue()

                _, new_total_sps = target_metrics(switch_to)
                if new_total_sps > MAX_TOTAL_SHARES_SEC:
                    switch_to = warm_up_vardiff(switch_to)

                job = switch_to
                set_active_template_id(job["template_id"])
                worker_generation = bump_generation()
                workers = start_gpus(job, worker_generation)
                with lock:
                    stats["job_switches"] += 1
                job_started = time.monotonic()
                latest_usable = None

            time.sleep(0.03)

    finally:
        running = False
        try:
            stop_gpus(workers)
        except Exception:
            pass
        bump_generation()
        purge_queue()
        data = snapshot(start_time, job)
        write_stats_file(data)
        for _ in submit_threads:
            try:
                share_queue.put_nowait(None)
            except queue.Full:
                break
        print("NOID170 stopped.", flush=True)


if __name__ == "__main__":
    main()
