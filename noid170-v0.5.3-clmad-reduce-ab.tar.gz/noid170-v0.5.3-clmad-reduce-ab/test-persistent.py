#!/usr/bin/env python3
import http.client
import json
import os
import queue
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin", "noid_live_job_daemon_reduce")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
if not os.path.exists(BIN):
    raise SystemExit("ERROR: build daemon first with ./build-on-rig.sh")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
path = u.path or "/"


def rpc(method, params):
    c = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params})
        c.request("POST", path, body=body, headers={
            "Content-Type":"application/json",
            "Authorization":f"Bearer {KEY}",
            "User-Agent":"noid170-clmad-reduction-persistent-test/0.5.3",
            "Accept":"*/*",
        })
        r = c.getresponse(); data = r.read()
        if r.status != 200:
            raise RuntimeError(f"HTTP {r.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        c.close()


def get_job(timeout=15):
    end = time.time()+timeout
    while time.time()<end:
        j=rpc("paranoid_getBlockTemplate", [""])
        if not j.get("error"):
            return j["result"]
        e=j.get("error") or {}
        if isinstance(e,dict) and e.get("code")==-32011:
            time.sleep(max(.05,e.get("data",{}).get("retry_in_ms",500)/1000))
            continue
        raise RuntimeError(e)
    raise RuntimeError("template timeout")


env=os.environ.copy(); env["CUDA_VISIBLE_DEVICES"]="0"
p=subprocess.Popen([BIN,"--daemon","9001"],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
evq=queue.Queue(); shq=queue.Queue()

def re():
    for line in p.stderr:
        line=line.rstrip(); print("GPU:",line)
        evq.put(line)
def ro():
    for line in p.stdout:
        line=line.rstrip()
        if line.startswith("SHARE "):
            shq.put(line)
threading.Thread(target=re,daemon=True).start(); threading.Thread(target=ro,daemon=True).start()

def wait_prefix(prefix,timeout=30):
    end=time.time()+timeout
    while time.time()<end:
        try: line=evq.get(timeout=.5)
        except queue.Empty: continue
        if line.startswith(prefix): return line
    raise RuntimeError(f"timeout waiting for {prefix}")

def send(seq,job):
    p.stdin.write(f"JOB {seq} {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"); p.stdin.flush()

print("===== PERSISTENT WORKER TEST =====")
print("PID:",p.pid)
wait_prefix("READY ")
job1=get_job(); print("job1",job1["template_id"],"height",job1["height"])
send(1,job1); wait_prefix("JOBACK 1 ")
# Exact same GPU work with a new sequence must be a TAG-only switch.
send(2,job1); ack2=wait_prefix("JOBACK 2 "); print("same-work switch:",ack2)

# Let it hash long enough to emit a real STAT without restarting.
stat=wait_prefix("STAT ",timeout=8); print("hash stat:",stat)
print("PID still:",p.pid,"alive:",p.poll() is None)

job2=get_job(); print("job2",job2["template_id"],"height",job2["height"])
send(3,job2); ack3=wait_prefix("JOBACK 3 "); print("fresh-job switch:",ack3)
print("PID after switch:",p.pid,"alive:",p.poll() is None)

# Follow meaningful live-work changes and require one accepted share from the
# experimental CLMAD binary.  This catches an implementation that is internally
# self-consistent but does not match the network's canonical PoW.
current_job=job2
current_seq=3
deadline=time.time()+45
next_poll=0.0
accepted=False

def work_key(job):
    return (
        int(job["height"]),
        job["pow_fields_hex"],
        job["difficulty_target_hex"],
    )

while time.time()<deadline and not accepted:
    now=time.time()
    if now>=next_poll:
        fresh=get_job()
        if work_key(fresh)!=work_key(current_job):
            current_seq+=1
            current_job=fresh
            send(current_seq,current_job)
            ack=wait_prefix(f"JOBACK {current_seq} ")
            print("live-work switch:",ack,"height",current_job["height"])
        else:
            # template_id may be request-scoped while the GPU work is identical.
            current_job["template_id"]=fresh["template_id"]
        next_poll=now+0.5

    try: line=shq.get(timeout=.1)
    except queue.Empty: continue
    parts=line.split()
    if len(parts)!=3: continue
    seq=int(parts[1]); nonce=parts[2]
    if seq!=current_seq: continue
    ans=rpc("paranoid_submitBlock",[current_job["template_id"],nonce])
    print("share submit:",json.dumps(ans))
    if ans.get("result")=="share accepted":
        accepted=True

if not accepted:
    raise RuntimeError("no CLMAD-reduction share was accepted within 45 seconds")

p.stdin.write("STOP\n"); p.stdin.flush()
try: p.wait(timeout=3)
except subprocess.TimeoutExpired:
    p.terminate(); p.wait(timeout=3)
print("exit:",p.returncode)
print("PERSISTENT CUDA PROTOCOL: PASS")
