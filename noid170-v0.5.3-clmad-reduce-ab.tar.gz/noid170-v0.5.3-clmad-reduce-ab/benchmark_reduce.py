#!/usr/bin/env python3

import http.client
import json
import os
import queue
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
SHIFT = os.path.join(ROOT, "bin", "noid_live_job_daemon_shift")
REDUCE = os.path.join(ROOT, "bin", "noid_live_job_daemon_reduce")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
path = u.path or "/"


def rpc(method, params):
    connection = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        })
        connection.request(
            "POST",
            path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-clmad-reduction-bench/0.5.3",
            },
        )
        response = connection.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(
                f"HTTP {response.status}: {data.decode(errors='replace')}"
            )
        return json.loads(data)
    finally:
        connection.close()


def get_job(timeout=15):
    deadline = time.time() + timeout
    while time.time() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def run_one(label, binary, job):
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [binary, "--daemon", "7301"],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )
    events = queue.Queue()

    def reader():
        for line in proc.stderr:
            events.put(line.strip())

    threading.Thread(target=reader, daemon=True).start()

    def wait_for(prefix, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                line = events.get(timeout=0.5)
            except queue.Empty:
                continue
            if line.startswith(prefix):
                return line
        raise RuntimeError(f"{label}: timeout waiting for {prefix}")

    try:
        wait_for("READY ")
        hard_target = "01" + "00" * 31
        proc.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard_target}\n")
        proc.stdin.flush()
        wait_for("JOBACK 1 ")

        samples = []
        while len(samples) < 10:
            line = wait_for("STAT ", timeout=8)
            fields = line.split()
            samples.append((float(fields[1]), float(fields[5])))

        used = samples[3:]
        kernel = sum(x for x, _ in used) / len(used)
        wall = sum(y for _, y in used) / len(used)
        print(
            f"{label:10s} kernel={kernel:.3f} MH/s  "
            f"wall={wall:.3f} MH/s"
        )
        return kernel, wall
    finally:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n")
                proc.stdin.flush()
                proc.wait(timeout=3)
            except Exception:
                proc.terminate()
                proc.wait(timeout=3)


job = get_job()
print("===== CLMAD REDUCTION A/B BENCHMARK | GPU0 =====")
print("height:", job["height"])
shift_1 = run_one("shift#1", SHIFT, job)
reduce_1 = run_one("reduce#1", REDUCE, job)
reduce_2 = run_one("reduce#2", REDUCE, job)
shift_2 = run_one("shift#2", SHIFT, job)

shift_kernel = (shift_1[0] + shift_2[0]) / 2.0
shift_wall = (shift_1[1] + shift_2[1]) / 2.0
reduce_kernel = (reduce_1[0] + reduce_2[0]) / 2.0
reduce_wall = (reduce_1[1] + reduce_2[1]) / 2.0

print(
    f"{'shift avg':10s} kernel={shift_kernel:.3f} MH/s  "
    f"wall={shift_wall:.3f} MH/s"
)
print(
    f"{'reduce avg':10s} kernel={reduce_kernel:.3f} MH/s  "
    f"wall={reduce_wall:.3f} MH/s"
)
print(f"kernel gain: {(reduce_kernel / shift_kernel - 1.0) * 100.0:+.2f}%")
print(f"wall gain:   {(reduce_wall / shift_wall - 1.0) * 100.0:+.2f}%")
