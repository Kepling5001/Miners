#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -Xptxas=-v
)

echo "===== BUILD CURRENT SHIFT/XOR REDUCTION ====="
"$NVCC" "${COMMON[@]}" \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_shift"

echo
echo "===== BUILD EXPERIMENTAL CLMAD REDUCTION ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_REDUCE_CLMAD=1 \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_reduce"

echo
echo "===== BUILD DIRECT REDUCTION CORRECTNESS ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_clmad_reduce.cu" \
  -o "$BIN/test_clmad_reduce"

echo
echo "===== BUILD ACCUMULATOR REGRESSION ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_REDUCE_CLMAD=1 \
  "$ROOT/test_clmad_accum.cu" \
  -o "$BIN/test_clmad_accum"

echo
echo "===== BUILD CLMAD SQUARING/CHAIN REGRESSION ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_REDUCE_CLMAD=1 \
  "$ROOT/test_square_clmad.cu" \
  -o "$BIN/test_square_clmad"

chmod +x \
  "$BIN/noid_live_job_daemon_shift" \
  "$BIN/noid_live_job_daemon_reduce" \
  "$BIN/test_clmad_reduce" \
  "$BIN/test_clmad_accum" \
  "$BIN/test_square_clmad"

python3 -m py_compile \
  "$ROOT/benchmark_reduce.py" \
  "$ROOT/offline_verify.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-reduce.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh \
  "$BIN/noid_live_job_daemon_shift" \
  "$BIN/noid_live_job_daemon_reduce" \
  "$BIN/test_clmad_reduce" \
  "$BIN/test_clmad_accum" \
  "$BIN/test_square_clmad"
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-reduce.sh"
