# noid170 v0.5.3 CLMAD reduction A/B

This package compares the current accumulated-CLMAD v0.5.1 arithmetic against
an exact five-CLMAD reduction modulo `x^128 + x^7 + x^2 + x + 1`.

Both mining binaries use the same factorized MDS, CLMAD squaring, accumulated
Karatsuba multiplication, launch geometry, and persistent-worker protocol. The
only A/B variable is the final GF(2^128) reduction:

- `shift`: current shift/XOR/overflow-fold reduction
- `reduce`: experimental CLMAD-accumulated reduction

The test runs:

1. The offline model proof.
2. A direct GPU reduction oracle covering reduction, multiplication, squaring,
   S-box, one Poseidon permutation, and a three-permutation chain.
3. Existing square/chain and accumulator regression oracles.
4. A reversed-order live-job benchmark on GPU0 with an effectively impossible
   target, so the benchmark submits no shares.
5. The persistent protocol test and one network-accepted share from the
   experimental binary.

Run on the test rig with the installed HiveOS miner stopped:

```bash
cd /home/user/noid170-v0.5.3-clmad-reduce-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-reduce.sh
```

Paste the complete output back into the chat before installing anything.
