#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

__device__ __forceinline__
unsigned long long reduce_mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__device__ __forceinline__
bool reduce_different(U128 a, U128 b)
{
    return a.lo != b.lo || a.hi != b.hi;
}

template <bool ClmadReduce>
__device__ __forceinline__
U128 reduce_test(U128 hi, U128 lo)
{
    if constexpr (ClmadReduce)
        return reduce_gcm_256_clmad(hi, lo);
    return reduce_gcm_256_shift(hi, lo);
}

template <bool ClmadReduce>
__device__ __forceinline__
U128 mul_test(U128 a, U128 b)
{
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_accumulate(
        a.lo ^ a.hi,
        b.lo ^ b.hi,
        p0);
    pm = bxor(pm, p1);

    const U128 lo{p0.lo, p0.hi ^ pm.lo};
    const U128 hi{p1.lo ^ pm.hi, p1.hi};
    return reduce_test<ClmadReduce>(hi, lo);
}

template <bool ClmadReduce>
__device__ __forceinline__
U128 square_test(U128 a)
{
    const U128 lo = clmul64_nibble(a.lo, a.lo);
    const U128 hi = clmul64_nibble(a.hi, a.hi);
    return reduce_test<ClmadReduce>(hi, lo);
}

template <bool ClmadReduce>
__device__ __forceinline__
U128 sbox_test(U128 x)
{
    const U128 x2 = square_test<ClmadReduce>(x);
    const U128 x4 = square_test<ClmadReduce>(x2);
    const U128 x6 = mul_test<ClmadReduce>(x, x2);
    return mul_test<ClmadReduce>(x6, x4);
}

template <bool ClmadReduce>
__device__ __forceinline__
void full_mds_test(U128 s[4])
{
    const U128 mul2{
        0x7573da4a5f7710edULL,
        0x3d5bd35c94646a24ULL
    };
    const U128 mul4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };
    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(mul_test<ClmadReduce>(mul2, b), t1);
    const U128 t3 = bxor(mul_test<ClmadReduce>(mul2, d), t0);
    const U128 t4 = bxor(mul_test<ClmadReduce>(mul4, t1), t3);
    const U128 t5 = bxor(mul_test<ClmadReduce>(mul4, t0), t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

template <bool ClmadReduce>
__device__ __forceinline__
void partial_mds_test(U128 s[4])
{
    const U128 diagonal[4] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };
    const U128 sum = bxor(bxor(s[0], s[1]), bxor(s[2], s[3]));
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = bxor(sum, mul_test<ClmadReduce>(diagonal[i], s[i]));
}

template <bool ClmadReduce>
__device__ __forceinline__
void poseidon_test(U128 s[4])
{
    full_mds_test<ClmadReduce>(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r < NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_test<ClmadReduce>(s[i]);
            }
            full_mds_test<ClmadReduce>(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_test<ClmadReduce>(s[0]);
            partial_mds_test<ClmadReduce>(s);
        }
    }
}

__global__
void reduce_oracle_kernel(unsigned int *errors)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
    U128 seed[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        seed[i] = {
            reduce_mix64(tid * 17ULL + i + 1ULL),
            reduce_mix64(tid * 29ULL + i + 0x12345678ULL)
        };
    }

    if (tid == 0) {
        seed[0] = {0ULL, 0ULL};
        seed[1] = {~0ULL, ~0ULL};
        seed[2] = {1ULL, 1ULL << 63};
        seed[3] = {1ULL << 63, 1ULL};
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const U128 other = seed[(i + 1) & 3];
        if (reduce_different(
                reduce_test<false>(seed[i], other),
                reduce_test<true>(seed[i], other)))
            atomicAdd(&errors[0], 1U);

        if (reduce_different(
                mul_test<false>(seed[i], other),
                mul_test<true>(seed[i], other)))
            atomicAdd(&errors[1], 1U);

        if (reduce_different(
                square_test<false>(seed[i]),
                square_test<true>(seed[i])))
            atomicAdd(&errors[2], 1U);

        if (reduce_different(
                sbox_test<false>(seed[i]),
                sbox_test<true>(seed[i])))
            atomicAdd(&errors[3], 1U);
    }

    U128 shift[4], clmad[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        shift[i] = clmad[i] = seed[i];

    poseidon_test<false>(shift);
    poseidon_test<true>(clmad);
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        if (reduce_different(shift[i], clmad[i]))
            atomicAdd(&errors[4], 1U);
    }

    #pragma unroll 1
    for (int pass = 1; pass < 3; ++pass) {
        const U128 absorb0{
            reduce_mix64(tid + 0x1000ULL * pass),
            reduce_mix64(tid + 0x2000ULL * pass)
        };
        const U128 absorb1{
            reduce_mix64(tid + 0x3000ULL * pass),
            reduce_mix64(tid + 0x4000ULL * pass)
        };
        shift[0] = bxor(shift[0], absorb0);
        shift[1] = bxor(shift[1], absorb1);
        clmad[0] = bxor(clmad[0], absorb0);
        clmad[1] = bxor(clmad[1], absorb1);
        poseidon_test<false>(shift);
        poseidon_test<true>(clmad);

        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            if (reduce_different(shift[i], clmad[i]))
                atomicAdd(&errors[5], 1U);
        }
    }
}

int main()
{
    unsigned int *d_errors = nullptr;
    CUDA_OK(cudaMalloc(&d_errors, 6 * sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors, 0, 6 * sizeof(unsigned int)));
    reduce_oracle_kernel<<<16, 64>>>(d_errors);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    unsigned int errors[6] = {};
    CUDA_OK(cudaMemcpy(errors, d_errors, sizeof(errors),
                       cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));
    unsigned int total = 0;
    for (unsigned int error : errors)
        total += error;

    printf("CLMAD REDUCTION ORACLE: %s "
           "(reduce=%u mul=%u square=%u sbox=%u poseidon=%u chain=%u total=%u)\n",
           total ? "FAIL" : "PASS",
           errors[0], errors[1], errors[2], errors[3], errors[4], errors[5], total);
    return total ? 1 : 0;
}
