__device__ __forceinline__
U128 bxor(U128 a, U128 b)
{
    return {a.lo ^ b.lo, a.hi ^ b.hi};
}

__device__ __forceinline__
bool nonzero(U128 a)
{
    return (a.lo | a.hi) != 0ULL;
}

/*
 * Correctness-first GF(2^128) multiplication.
 *
 * Flat/GCM basis polynomial:
 *     x^128 + x^7 + x^2 + x + 1
 *
 * This version is intentionally simple.
 * We optimize it only AFTER matching the Rust oracle.
 */

__device__ __forceinline__
U128 shl128(U128 a, unsigned n)
{
    if (n == 0)
        return a;

    U128 r;
    r.lo = a.lo << n;
    r.hi = (a.hi << n) | (a.lo >> (64 - n));
    return r;
}

__device__ __forceinline__
U128 clmul64_nibble(
    unsigned long long a,
    unsigned long long b)
{
    unsigned long long lo;
    unsigned long long hi;
    const unsigned long long zero = 0ULL;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(zero)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(zero)
    );

    return {lo, hi};
}

__device__ __forceinline__
U128 reduce_gcm_256(U128 hi, U128 lo)
{
    // x^128 = x^7 + x^2 + x + 1  (0x87)
    U128 t = hi;
    t = bxor(t, shl128(hi, 1));
    t = bxor(t, shl128(hi, 2));
    t = bxor(t, shl128(hi, 7));

    unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    unsigned long long fold =
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    U128 r = bxor(lo, t);
    r.lo ^= fold;

    return r;
}

__device__ __forceinline__
U128 gf_mul(U128 a, U128 b)
{
    // Karatsuba: three 64x64 carry-less multiplies.
    U128 p0 = clmul64_nibble(a.lo, b.lo);
    U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_nibble(a.lo ^ a.hi, b.lo ^ b.hi);

    pm = bxor(pm, p0);
    pm = bxor(pm, p1);

    U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
unsigned long long spread32(unsigned x)
{
    unsigned long long v = x;

    v = (v | (v << 16)) & 0x0000FFFF0000FFFFULL;
    v = (v | (v <<  8)) & 0x00FF00FF00FF00FFULL;
    v = (v | (v <<  4)) & 0x0F0F0F0F0F0F0F0FULL;
    v = (v | (v <<  2)) & 0x3333333333333333ULL;
    v = (v | (v <<  1)) & 0x5555555555555555ULL;

    return v;
}

__device__ __forceinline__
U128 expand64(unsigned long long x)
{
    return {
        spread32((unsigned)x),
        spread32((unsigned)(x >> 32))
    };
}

__device__ __forceinline__
U128 square_flat(U128 a)
{
    // Squaring in characteristic two = inserting zeros between bits,
    // followed by reduction modulo the GCM polynomial.
    U128 lo = expand64(a.lo);
    U128 hi = expand64(a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 sbox_x7(U128 x)
{
    // Production Parano1d schedule:
    // x2 = square(x)
    // x4 = square(x2)
    // x6 = x * x2
    // x7 = x6 * x4
    const U128 x2 = square_flat(x);
    const U128 x4 = square_flat(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_FULL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_PARTIAL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

__device__ __forceinline__
void poseidon_permute(U128 s[4])
{
    apply_mds_full(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {

        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_x7(s[i]);
            }

            apply_mds_full(s);
        }
        else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);

            apply_mds_partial(s);
        }
    }
}

