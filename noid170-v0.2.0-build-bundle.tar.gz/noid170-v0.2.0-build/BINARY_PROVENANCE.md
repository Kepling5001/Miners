# Binary provenance

## Existing warmup worker

`noid_live_job_cont` is the exact previously proven 1024-thread sm_80 binary copied from the v0.1.x package.

SHA256:

```text
40c70611a2a7a2783044a2fbeeb051214882ef95e2836bba6301e2b8dfeb23a7
```

It remains in v0.2.0 only for startup vardiff warmup.

## Persistent production worker

`noid_live_job_daemon` is not precompiled in this build bundle. It is compiled by `build-on-rig.sh` from the uploaded exact CUDA source/header set using `/usr/local/cuda-13.3/bin/nvcc -O3 -arch=sm_80` on the known-good development rig.

This avoids representing an untested or differently-built CUDA executable as proven.
