# NOID170 v0.2.0 persistent-CUDA build bundle

This bundle is the source-side fix for the effective-hashrate loss seen when the old controller destroyed and recreated every CUDA worker at job changes.

## What changes

- `noid_live_job_daemon` initializes one CUDA context per GPU once and stays alive.
- Controller sends `JOB <seq> <pow_fields_hex> <target_hex>` over stdin.
- Worker switches between GPU batches; the 1024-thread batch is ~60-65 ms on CMP 170HX.
- Every share is tagged with the exact job sequence it was hashed against.
- Same-PoW vardiff update changes only target constants.
- Template-ID-only refresh changes only the share tag; it does not touch GPU constants.
- New PoW/header work rebuilds prefix/tail inside the already-live CUDA context.
- No production CUDA process restarts on block-height or vardiff changes.
- Hive stats remain supported.
- Accepted-work diagnostics now include a rolling 120-second difficulty-weighted rate.

The existing proven `noid_live_job_cont` binary is retained only for startup vardiff warmup.

## Build on OctominerTEST

The new daemon must be compiled on the CUDA 13.3 development rig because this bundle intentionally does not substitute an untested binary.

```bash
cd /home/user/noid170
# copy/extract this bundle here, then:
cd noid170-v0.2.0-build
./build-on-rig.sh
```

Expected ptxas result for the mining kernel should remain spill-free. After build, run:

```bash
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-persistent.sh
```

The important output is:

- `READY ...`
- `JOBACK 1 FULL`
- `JOBACK 2 TAG`
- a real `STAT ~36 MH/s`
- the PID remains unchanged across JOB 1 -> JOB 2 -> JOB 3
- `PERSISTENT CUDA PROTOCOL: PASS`

If a real target share is found during the short test, it is also submitted to Aria; if vardiff is too hard, that optional submit step may be skipped.

## HiveOS release

`./build-on-rig.sh` creates:

```text
dist/noid170-0.2.0.tar.gz
dist/noid170-0.2.0.tar.gz.sha256
```

Upload those to GitHub Release `v0.2.0` and use:

```text
https://github.com/Kepling5001/Miners/releases/download/v0.2.0/noid170-0.2.0.tar.gz
```

Flight-sheet fields remain unchanged:

- Miner name: `noid170`
- Wallet and worker template: `%WAL%.%WORKER_NAME%`
- Pool URL: `https://pool.ariabrain.com/noid-rpc/`
- Pass: blank
- Extra config: blank

## Runtime files in final tar

```text
noid170/
  h-manifest.conf
  h-config.sh
  h-run.sh
  h-stats.sh
  hive_stats.py
  noid170_aria.py
  noid_live_job_cont      # proven warmup worker
  noid_live_job_daemon    # NEW persistent production worker
```
