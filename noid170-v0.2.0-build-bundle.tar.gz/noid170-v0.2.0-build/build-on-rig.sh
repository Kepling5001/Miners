#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
PKG="$ROOT/package/noid170"
DIST="$ROOT/dist"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
[[ -f "$SRC/noid_live_job_daemon.cu" ]] || { echo "ERROR: daemon source missing"; exit 1; }
[[ -x "$PKG/noid_live_job_cont" ]] || { echo "ERROR: proven warmup binary missing"; exit 1; }

echo "===== BUILD NOID170 v0.2.0 PERSISTENT CUDA WORKER ====="
"$NVCC" \
  -O3 \
  -arch=sm_80 \
  -lineinfo \
  -I"$SRC" \
  -Xptxas=-v \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$PKG/noid_live_job_daemon"

chmod +x "$PKG/noid_live_job_daemon"

echo
echo "===== BINARY CHECK ====="
ls -lh "$PKG/noid_live_job_daemon"
sha256sum "$PKG/noid_live_job_cont" "$PKG/noid_live_job_daemon"

if ! strings "$PKG/noid_live_job_daemon" | grep -q 'JOBACK'; then
  echo "ERROR: persistent protocol marker JOBACK not found"
  exit 1
fi
if ! strings "$PKG/noid_live_job_daemon" | grep -q 'READY sm='; then
  echo "ERROR: persistent protocol marker READY not found"
  exit 1
fi

python3 -m py_compile "$PKG/noid170_aria.py"
bash -n "$PKG/h-config.sh"
bash -n "$PKG/h-run.sh"
bash -n "$PKG/h-stats.sh"

echo
echo "===== CREATE HIVEOS RELEASE ====="
rm -rf "$DIST"
mkdir -p "$DIST"
rm -rf "$PKG/__pycache__"

tar -C "$ROOT/package" -czf "$DIST/noid170-0.2.0.tar.gz" noid170
sha256sum "$DIST/noid170-0.2.0.tar.gz" > "$DIST/noid170-0.2.0.tar.gz.sha256"

ls -lh "$DIST"
echo
echo "Release contents:"
tar -tzf "$DIST/noid170-0.2.0.tar.gz"

echo
echo "BUILD COMPLETE"
echo "HiveOS release: $DIST/noid170-0.2.0.tar.gz"
echo "Before publishing, run: ./test-persistent.sh"
