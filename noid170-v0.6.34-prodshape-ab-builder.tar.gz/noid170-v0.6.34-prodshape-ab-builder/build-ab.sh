#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BUILD="$ROOT/build"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
mkdir -p "$BUILD"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512
  -DNOID_BLOCKS_PER_SM=128
  -DNOID_FIRST_MDS_HOIST=0
  -DNOID_FIRST_ROUND_SQUARE_SHARE=3
  -Xptxas=-v
)

echo "===== OFFLINE NAMESPACE GATES ====="
python3 "$ROOT/verify_namespace_lut.py"
python3 "$ROOT/verify_namespace_block_map.py"

echo
echo "===== COMPILE v0.6.32 ARIA SHARE4 REFERENCE ====="
"$NVCC" "${COMMON[@]}" "$SRC/noid_live_job_daemon.cu" \
  -o "$BUILD/noid_daemon_aria_reference" 2>&1 | tee "$BUILD/build-aria-reference.log"
chmod 755 "$BUILD/noid_daemon_aria_reference"
sha256sum "$BUILD/noid_daemon_aria_reference"

echo
echo "===== COMPILE INNOVLAB BASELINE (EXACT TEST3 SOURCE) ====="
"$NVCC" "${COMMON[@]}" "$SRC/noid_live_job_daemon_ns_baseline.cu" \
  -o "$BUILD/noid_daemon_ns_baseline" 2>&1 | tee "$BUILD/build-ns-baseline.log"
chmod 755 "$BUILD/noid_daemon_ns_baseline"
sha256sum "$BUILD/noid_daemon_ns_baseline"

echo
echo "===== COMPILE INNOVLAB PRODSHAPE ====="
"$NVCC" "${COMMON[@]}" "$SRC/noid_live_job_daemon_ns.cu" \
  -o "$BUILD/noid_daemon_ns_prodshape" 2>&1 | tee "$BUILD/build-ns-prodshape.log"
chmod 755 "$BUILD/noid_daemon_ns_prodshape"
sha256sum "$BUILD/noid_daemon_ns_prodshape"

echo
echo "===== GPU NAMESPACE GATES ====="
for t in namespace_map namespace_block_map namespace_precompute namespace_roundtrip; do
  case "$t" in
    namespace_map) src="$ROOT/test_namespace_map.cu" ;;
    namespace_block_map) src="$ROOT/test_namespace_block_map.cu" ;;
    namespace_precompute) src="$ROOT/test_namespace_precompute.cu" ;;
    namespace_roundtrip) src="$ROOT/test_namespace_roundtrip.cu" ;;
  esac
  "$NVCC" -O3 -std=c++17 -arch=sm_80 -I"$ROOT" -I"$SRC" "$src" -o "$BUILD/test_$t"
  chmod 755 "$BUILD/test_$t"
  CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/test_$t"
done

echo
echo "===== JOBNS SMOKE: BASELINE ====="
POW_ZERO=$(printf '0%.0s' {1..512})
TARGET_ZERO=$(printf '0%.0s' {1..64})
NS_TEST="19ea010000000200"
for v in baseline prodshape; do
  LOG="$BUILD/smoke-$v.log"
  set +e
  {
    printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"
    sleep 0.6
    printf 'STOP\n'
  } | CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/noid_daemon_ns_$v" --daemon 634 \
      >/dev/null 2>"$LOG"
  RC=$?
  set -e
  cat "$LOG"
  [[ "$RC" -eq 0 ]] || { echo "ERROR: $v smoke exited $RC"; exit 1; }
  grep -q '^READY ' "$LOG" || { echo "ERROR: $v no READY"; exit 1; }
  grep -q '^JOBACK 1 ' "$LOG" || { echo "ERROR: $v no JOBACK"; exit 1; }
done

echo
echo "===== REGISTER SUMMARY ====="
for f in aria-reference ns-baseline ns-prodshape; do
  printf '%-18s ' "$f"
  grep -A3 "Compiling entry function.*mine_kernel" "$BUILD/build-$f.log" | grep 'Used ' | head -1 || true
done

echo
echo "===== BUILD COMPLETE ====="
echo "Next: ./run-benchmark.sh"
echo "Nothing was installed or changed under /hive/miners/custom."
