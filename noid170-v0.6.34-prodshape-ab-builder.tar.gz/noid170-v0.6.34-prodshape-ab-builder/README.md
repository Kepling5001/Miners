# NOID170 v0.6.34 prodshape A/B

Targeted CMP170HX experiment only. It does **not** install a miner or change the current HiveOS flight sheet.

Purpose: determine whether the remaining ~1.9% InnovLab hashrate gap is caused by the namespace kernel's extra long-lived canonical nonce state / changed candidate-output codegen.

It compiles three binaries from the same v0.6.32/share4 arithmetic checkpoint:

- `aria_reference`: original unrestricted v0.6.32 share4 source, for ptxas register reference.
- `ns_baseline`: byte-for-source-equivalent test3 namespace hot path (~157.9 MH/s live previously).
- `ns_prodshape`: keeps only `flat_nonce` live across Poseidon, removes the canonical counter from the hot path, and restores the v0.6.32 candidate output operation `flat_to_tower_device(flat_nonce)` in the rare share branch. This conversion does not run per hash.

Correctness gates include tower->flat LUT, block decomposition, precompute, and a new full namespace output round-trip oracle that verifies the prodshape candidate output returns exactly `[counter LE64 || session namespace LE64]`.

## Build

```bash
cd /home/user/noid170-v0.6.34-prodshape-ab-builder
./build-ab.sh
```

## Offline A/B benchmark

```bash
cd /home/user/noid170-v0.6.34-prodshape-ab-builder
NOID_BENCH_SECONDS=30 ./run-benchmark.sh
```

The benchmark uses GPU 0 by default and a zero share target. It never connects to a pool and does not install anything. Set `NOID_TEST_GPU=N` to use another visible GPU.

Send back the `REGISTER SUMMARY` and `FINAL A/B` sections. If prodshape materially wins and passes all oracles, it can be integrated into a v0.6.33r2 production candidate for live InnovLab testing.
