#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>

struct U128 { unsigned long long lo, hi; };
#include "src/noid_t2f_nibble_lut.h"
#include "src/noid_f2t_rows.h"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

__device__ __forceinline__ int parity_mask(U128 x, U128 mask)
{
    return ((__popcll(x.lo & mask.lo) ^ __popcll(x.hi & mask.hi)) & 1);
}

__device__ __forceinline__ U128 flat_to_tower(U128 flat)
{
    U128 out{0ULL,0ULL};
    #pragma unroll 1
    for (int bit=0; bit<128; ++bit) {
        if (parity_mask(flat, NOID_F2T_ROWS[bit])) {
            if (bit < 64) out.lo |= 1ULL << bit;
            else out.hi |= 1ULL << (bit-64);
        }
    }
    return out;
}

__device__ __forceinline__ U128 tower_to_flat_lut(U128 tower)
{
    U128 out{0ULL,0ULL};
    #pragma unroll
    for (int nib=0; nib<16; ++nib) {
        unsigned v=(unsigned)((tower.lo>>(nib*4))&0xfULL);
        U128 x=NOID_T2F_LOW_NIBBLE_LUT[nib][v];
        out.lo^=x.lo; out.hi^=x.hi;
    }
    // High-half LUT is host-only in the production header, so use the exact
    // T2F row transform for the high half by applying the full row map below.
    // This oracle constructs flat from the production low LUT plus a supplied
    // preconverted namespace, matching the live Stratum daemon.
    return out;
}

__device__ __constant__ U128 NS_FLAT;

__global__ void roundtrip(U128 *out, unsigned long long base)
{
    unsigned i=(unsigned)(blockIdx.x*blockDim.x+threadIdx.x);
    unsigned long long c=base+(unsigned long long)i;
    U128 low=tower_to_flat_lut(U128{c,0ULL});
    U128 flat{low.lo^NS_FLAT.lo, low.hi^NS_FLAT.hi};
    out[i]=flat_to_tower(flat);
}

static U128 high_to_flat(unsigned long long hi)
{
    U128 out{0ULL,0ULL};
    for(int nib=0;nib<16;++nib){
        unsigned v=(unsigned)((hi>>(nib*4))&0xfULL);
        U128 x=NOID_T2F_HIGH_NIBBLE_LUT_HOST[nib][v];
        out.lo^=x.lo; out.hi^=x.hi;
    }
    return out;
}

int main()
{
    constexpr int N=4096;
    U128 *d=nullptr;
    CUDA_OK(cudaMalloc(&d,N*sizeof(U128)));
    U128 *h=(U128*)malloc(N*sizeof(U128));
    if(!h) return 2;

    const unsigned long long nsvals[]={
        0x000200000001ea19ULL,
        0x000200000001f27eULL,
        0x0123456789abcdefULL,
        0xfedcba9876543210ULL
    };
    const unsigned long long bases[]={
        0ULL, 0x100000ULL, 0x1234567800000000ULL, 0xfffffff000000000ULL
    };
    unsigned long long checks=0;
    for(auto ns:nsvals){
        U128 nsflat=high_to_flat(ns);
        CUDA_OK(cudaMemcpyToSymbol(NS_FLAT,&nsflat,sizeof(nsflat)));
        for(auto base:bases){
            roundtrip<<<N/256,256>>>(d,base);
            CUDA_OK(cudaGetLastError());
            CUDA_OK(cudaDeviceSynchronize());
            CUDA_OK(cudaMemcpy(h,d,N*sizeof(U128),cudaMemcpyDeviceToHost));
            for(int i=0;i<N;++i){
                unsigned long long want=base+(unsigned long long)i;
                if(h[i].lo!=want || h[i].hi!=ns){
                    fprintf(stderr,"ROUNDTRIP_MISMATCH ns=%016llx base=%016llx i=%d got=%016llx:%016llx want=%016llx:%016llx\n",
                        ns,base,i,h[i].hi,h[i].lo,ns,want);
                    return 1;
                }
                ++checks;
            }
        }
    }
    printf("NAMESPACE_OUTPUT_ROUNDTRIP_PASS checks=%llu\n",checks);
    cudaFree(d); free(h); return 0;
}
