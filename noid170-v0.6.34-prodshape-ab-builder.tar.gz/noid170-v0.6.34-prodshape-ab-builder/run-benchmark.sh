#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
GPU="${NOID_TEST_GPU:-0}"
SECONDS_PER_VARIANT="${NOID_BENCH_SECONDS:-30}"
POW_ZERO=$(printf '0%.0s' {1..512})
TARGET_ZERO=$(printf '0%.0s' {1..64})
NS_TEST="19ea010000000200"

for f in "$BUILD/noid_daemon_ns_baseline" "$BUILD/noid_daemon_ns_prodshape"; do
  [[ -x "$f" ]] || { echo "ERROR: missing $f -- run ./build-ab.sh first"; exit 1; }
done

summarize() {
  local log="$1"
  awk '
    $1=="STAT" {
      n++
      # Drop first STAT window to avoid startup/warmup effects.
      if (n>1) { ks+=$2; ws+=$6; m++; if(m==1||$2<kmin)kmin=$2; if(m==1||$2>kmax)kmax=$2; }
    }
    END {
      if(m>0) printf("samples=%d kernel_avg=%.3f kernel_min=%.3f kernel_max=%.3f wall_avg=%.3f\n",m,ks/m,kmin,kmax,ws/m);
      else print "samples=0";
    }
  ' "$log"
}

run_one() {
  local name="$1" bin="$2"
  local log="$BUILD/bench-$name.log"
  rm -f "$log"
  echo
  echo "===== BENCH $name (${SECONDS_PER_VARIANT}s, GPU $GPU) ====="
  set +e
  {
    printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"
    sleep "$SECONDS_PER_VARIANT"
    printf 'STOP\n'
  } | CUDA_VISIBLE_DEVICES="$GPU" "$bin" --daemon 634 >/dev/null 2>"$log"
  local rc=$?
  set -e
  tail -20 "$log"
  printf '%s: ' "$name"
  summarize "$log"
  [[ "$rc" -eq 0 ]] || echo "NOTE: daemon rc=$rc"
}

run_one baseline  "$BUILD/noid_daemon_ns_baseline"
run_one prodshape "$BUILD/noid_daemon_ns_prodshape"

echo
echo "===== FINAL A/B ====="
printf 'baseline : '; summarize "$BUILD/bench-baseline.log"
printf 'prodshape: '; summarize "$BUILD/bench-prodshape.log"
echo
echo "Interpretation: compare kernel_avg first; wall_avg is secondary."
echo "This benchmark uses a zero target, so it does not submit or find pool shares."
