# NOID170 v0.6.8 event-query CPU A/B

This experiment keeps the production `all_nv + r2lop3 + r4top + prod2` CUDA
kernel and the existing one-daemon-per-GPU architecture. It changes only the
host wait used after each batch:

- `sync`: current `cudaEventSynchronize()` control
- `poll50`, `poll250`, `poll1000`, `poll2000`: `cudaEventQuery()` followed by
  `nanosleep()` at the named interval

The two-slot pipeline remains intact. Every variant is run across all detected
GPUs, with hashrate, daemon CPU, system busy, interrupts, context switches and
job acknowledgement latency measured. This is an A/B test only; it never
installs a HiveOS miner.

```bash
cd /home/user/noid170-v0.6.8-event-poll-ab
miner stop
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-event-poll.sh
miner start
```

Default duration is about five minutes. Set `NOID_EVENT_SAMPLE_SEC=45` for a
longer measurement per variant.

