#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}
mkdir -p "$BIN"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64 -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1 -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1 -Xptxas=-v
)

build_variant() {
  local name="$1" poll_us="$2"
  echo
  echo "===== BUILD $name | event query poll ${poll_us} us ====="
  "$NVCC" "${COMMON[@]}" -DNOID_EVENT_POLL_US="$poll_us" \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" \
    2>&1 | tee "$BIN/build_$name.log"
  chmod +x "$BIN/noid_daemon_$name"
}

build_variant sync 0
build_variant poll50 50
build_variant poll250 250
build_variant poll1000 1000
build_variant poll2000 2000

echo
echo "===== BUILD GPU CORRECTNESS ORACLE ====="
"$NVCC" "${COMMON[@]}" "$ROOT/test_gf_primitives.cu" \
  -o "$BIN/test_gf_all_nv" 2>&1 | tee "$BIN/build_oracle.log"
chmod +x "$BIN/test_gf_all_nv"

python3 -m py_compile "$ROOT/benchmark_event_poll_cpu.py"
bash -n "$ROOT/test-event-poll.sh"
python3 "$ROOT/offline_verify.py"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN/test_gf_all_nv"
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-event-poll.sh"

