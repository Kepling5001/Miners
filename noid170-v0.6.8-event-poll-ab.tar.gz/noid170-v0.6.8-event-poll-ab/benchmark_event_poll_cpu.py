#!/usr/bin/env python3

import http.client
import json
import os
import queue
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN_DIR = os.path.join(ROOT, "bin")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
GPU_COUNT = int(os.environ.get("NOID_TEST_GPU_COUNT", "0") or "0")
WARMUP = max(8.0, float(os.environ.get("NOID_EVENT_WARMUP_SEC", "15")))
SAMPLE = max(15.0, float(os.environ.get("NOID_EVENT_SAMPLE_SEC", "30")))
TAG_INTERVAL = max(5.0, float(os.environ.get("NOID_EVENT_TAG_INTERVAL", "10")))
CLK_TCK = os.sysconf(os.sysconf_names["SC_CLK_TCK"])


def detect_gpus():
    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([x for x in p.stdout.splitlines() if x.strip()])


if GPU_COUNT <= 0:
    GPU_COUNT = detect_gpus()
if not KEY:
    raise SystemExit("ERROR: NOID_MINING_KEY is not set")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
RPC_PATH = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        conn.request(
            "POST", RPC_PATH, body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-event-poll-ab/0.6.8",
                "Accept": "*/*",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def work_key(job):
    return int(job["height"]), job["pow_fields_hex"], job["difficulty_target_hex"]


def proc_ticks(pid):
    text = open(f"/proc/{pid}/stat", "r", encoding="utf-8").read()
    rest = text[text.rfind(")") + 2:].split()
    return int(rest[11]) + int(rest[12])


def proc_status(pid):
    result = {"threads": 0, "voluntary": 0, "involuntary": 0}
    with open(f"/proc/{pid}/status", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("Threads:"):
                result["threads"] = int(line.split()[1])
            elif line.startswith("voluntary_ctxt_switches:"):
                result["voluntary"] = int(line.split()[1])
            elif line.startswith("nonvoluntary_ctxt_switches:"):
                result["involuntary"] = int(line.split()[1])
    return result


def system_counters():
    result = {}
    with open("/proc/stat", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("cpu "):
                fields = [int(x) for x in line.split()[1:]]
                result["total"] = sum(fields)
                result["idle"] = fields[3] + (fields[4] if len(fields) > 4 else 0)
            elif line.startswith("intr "):
                result["intr"] = int(line.split()[1])
            elif line.startswith("ctxt "):
                result["ctxt"] = int(line.split()[1])
    return result


class Group:
    def __init__(self, variant):
        self.variant = variant
        self.procs = []
        self.ready = set()
        self.acks = {}
        self.sent = {}
        self.ack_samples = {"TAG": [], "FULL": [], "TARGET": []}
        self.rates = []
        self.share_count = 0
        self.cv = threading.Condition()

    def stderr_reader(self, gpu, proc):
        for raw in proc.stderr:
            line = raw.strip()
            now = time.monotonic()
            with self.cv:
                if line.startswith("READY "):
                    self.ready.add(gpu)
                elif line.startswith("JOBACK "):
                    parts = line.split()
                    if len(parts) >= 3:
                        seq, mode = int(parts[1]), parts[2]
                        seen = self.acks.setdefault(seq, set())
                        seen.add(gpu)
                        if len(seen) == GPU_COUNT and seq in self.sent:
                            self.ack_samples.setdefault(mode, []).append(
                                (now - self.sent[seq]) * 1000.0
                            )
                elif line.startswith("STAT "):
                    parts = line.split()
                    if len(parts) >= 6:
                        try:
                            self.rates.append(
                                (now, gpu, float(parts[1]), float(parts[5]))
                            )
                        except ValueError:
                            pass
                self.cv.notify_all()

    def stdout_reader(self, gpu, proc):
        for raw in proc.stdout:
            if raw.strip().startswith("SHARE "):
                with self.cv:
                    self.share_count += 1

    def start(self):
        salt = time.time_ns() & 0x7FFFFFFFFFFFFFFF
        for gpu in range(GPU_COUNT):
            env = os.environ.copy()
            env["CUDA_VISIBLE_DEVICES"] = str(gpu)
            proc = subprocess.Popen(
                [os.path.join(BIN_DIR, f"noid_daemon_{self.variant}"), "--daemon", str(salt + gpu + 1)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, bufsize=1, env=env,
            )
            self.procs.append(proc)
            threading.Thread(target=self.stderr_reader, args=(gpu, proc), daemon=True).start()
            threading.Thread(target=self.stdout_reader, args=(gpu, proc), daemon=True).start()

        deadline = time.monotonic() + 45.0
        with self.cv:
            while len(self.ready) < GPU_COUNT and time.monotonic() < deadline:
                for proc in self.procs:
                    if proc.poll() is not None:
                        raise RuntimeError(f"{self.variant} exited during startup: {proc.returncode}")
                self.cv.wait(timeout=0.25)
        if len(self.ready) != GPU_COUNT:
            raise RuntimeError(f"{self.variant}: GPUs not READY: {sorted(self.ready)}")

    def send(self, seq, job):
        line = f"JOB {seq} {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"
        self.sent[seq] = time.monotonic()
        for proc in self.procs:
            if proc.poll() is not None:
                raise RuntimeError(f"{self.variant} exited: {proc.returncode}")
            proc.stdin.write(line)
            proc.stdin.flush()

    def wait_ack(self, seq):
        deadline = time.monotonic() + 20.0
        with self.cv:
            while len(self.acks.get(seq, set())) < GPU_COUNT and time.monotonic() < deadline:
                self.cv.wait(timeout=0.20)
        if len(self.acks.get(seq, set())) != GPU_COUNT:
            raise RuntimeError(f"{self.variant}: JOBACK {seq} timeout")

    def stop(self):
        for proc in self.procs:
            if proc.poll() is None:
                try:
                    proc.stdin.write("STOP\n")
                    proc.stdin.flush()
                except Exception:
                    pass
        deadline = time.monotonic() + 8.0
        for proc in self.procs:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=max(0.1, deadline - time.monotonic()))
                except subprocess.TimeoutExpired:
                    proc.terminate()
        for proc in self.procs:
            if proc.poll() is None:
                proc.kill()


def run_variant(variant):
    print(f"===== RUN {variant} =====", flush=True)
    group = Group(variant)
    group.start()
    job = get_job()
    seq = 1
    group.send(seq, job)
    group.wait_ack(seq)
    time.sleep(WARMUP)

    with group.cv:
        group.rates.clear()
        for values in group.ack_samples.values():
            values.clear()
        group.share_count = 0
    p0 = sum(proc_ticks(proc.pid) for proc in group.procs)
    s0 = system_counters()
    t0 = time.monotonic()
    end = t0 + SAMPLE
    next_tag = t0 + TAG_INTERVAL
    next_poll = t0 + 1.0

    while time.monotonic() < end:
        now = time.monotonic()
        for proc in group.procs:
            if proc.poll() is not None:
                raise RuntimeError(f"{variant} exited during measurement: {proc.returncode}")
        if now >= next_poll:
            fresh = get_job()
            if work_key(fresh) != work_key(job):
                job = fresh
                seq += 1
                group.send(seq, job)
                group.wait_ack(seq)
            else:
                job["template_id"] = fresh["template_id"]
            next_poll = now + 1.0
        if now >= next_tag:
            seq += 1
            group.send(seq, job)
            group.wait_ack(seq)
            next_tag = now + TAG_INTERVAL
        time.sleep(0.02)

    t1 = time.monotonic()
    p1 = sum(proc_ticks(proc.pid) for proc in group.procs)
    s1 = system_counters()
    status = [proc_status(proc.pid) for proc in group.procs]
    with group.cv:
        rows = list(group.rates)
        ack = {name: list(values) for name, values in group.ack_samples.items()}
        shares = group.share_count
    group.stop()

    elapsed = max(0.001, t1 - t0)
    total_delta = s1["total"] - s0["total"]
    idle_delta = s1["idle"] - s0["idle"]
    per_gpu = []
    for gpu in range(GPU_COUNT):
        samples = [row for row in rows if row[1] == gpu]
        if not samples:
            raise RuntimeError(f"{variant}: no STAT samples for GPU {gpu}")
        per_gpu.append((statistics.mean(row[2] for row in samples), statistics.mean(row[3] for row in samples)))

    tag = ack.get("TAG", [])
    full = ack.get("FULL", [])
    return {
        "variant": variant,
        "kernel": sum(row[0] for row in per_gpu),
        "wall": sum(row[1] for row in per_gpu),
        "cpu": (p1 - p0) / CLK_TCK / elapsed * 100.0,
        "busy": 100.0 * (total_delta - idle_delta) / max(1, total_delta),
        "irq": (s1["intr"] - s0["intr"]) / elapsed,
        "ctxt": (s1["ctxt"] - s0["ctxt"]) / elapsed,
        "proc_cs": sum(
            item["voluntary"] + item["involuntary"] for item in status
        ) / elapsed,
        "threads": sum(item["threads"] for item in status),
        "tag_p50": statistics.median(tag) if tag else 0.0,
        "tag_p95": sorted(tag)[max(0, int(len(tag) * 0.95) - 1)] if tag else 0.0,
        "full_p50": statistics.median(full) if full else 0.0,
        "shares": shares,
    }


print("===== EVENT-QUERY CPU A/B =====")
print(f"GPUs: {GPU_COUNT}  warmup/variant: {WARMUP:.0f}s  sample/variant: {SAMPLE:.0f}s")
print("Kernel: identical all_nv + r2lop3 + r4top + prod2, b64/stat8")

variants = ["sync", "poll50", "poll250", "poll1000", "poll2000"]
results = []
try:
    for variant in variants:
        results.append(run_variant(variant))
        time.sleep(3)
finally:
    subprocess.run(["pkill", "-f", os.path.join(BIN_DIR, "noid_daemon_")], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

baseline = results[0]
print()
print("===== FINAL EVENT-QUERY CPU A/B =====")
print(
    f"{'variant':<10} {'kernel':>10} {'wall MH/s':>10} {'daemonCPU':>10} "
    f"{'busy':>8} {'irq/s':>9} {'ctxt/s':>10} {'proc cs/s':>10} "
    f"{'threads':>8} {'TAG p50':>9} {'TAG p95':>9} {'FULL p50':>10}"
)
for row in results:
    print(
        f"{row['variant']:<10} {row['kernel']:>10.3f} {row['wall']:>10.3f} "
        f"{row['cpu']:>9.2f}% {row['busy']:>7.1f}% {row['irq']:>9.0f} "
        f"{row['ctxt']:>10.0f} {row['proc_cs']:>10.1f} {row['threads']:>8} "
        f"{row['tag_p50']:>8.1f} {row['tag_p95']:>8.1f} {row['full_p50']:>9.1f}"
    )

print()
for row in results:
    print(f"{row['variant']} shares observed during sample: {row['shares']}")
print()
for row in results[1:]:
    print(
        f"{row['variant']} vs sync: CPU {100.0 * (row['cpu'] / baseline['cpu'] - 1.0):+.1f}% "
        f"wall {100.0 * (row['wall'] / baseline['wall'] - 1.0):+.2f}%"
    )

eligible = [row for row in results[1:] if row["wall"] >= baseline["wall"] * 0.99]
if eligible:
    winner = min(eligible, key=lambda row: row["cpu"])
    print(f"winner by lowest CPU within 1% wall: {winner['variant']}")
    print(f"winner CPU change: {100.0 * (winner['cpu'] / baseline['cpu'] - 1.0):+.1f}%")
    print(f"winner wall change: {100.0 * (winner['wall'] / baseline['wall'] - 1.0):+.2f}%")
    if winner["cpu"] <= baseline["cpu"] * 0.75:
        print("decision: PASS — candidate is worth live protocol validation")
    else:
        print("decision: MARGINAL — CPU reduction is smaller than desired")
else:
    print("decision: FAIL — no polling variant retained 99% of wall hashrate")
print()
print("Paste this complete result into chat. This test did not install a miner.")

