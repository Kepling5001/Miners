#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="${MINER_DIR:-/hive/miners/custom/noid170}"
CONF="${CUSTOM_CONFIG_FILENAME:-$MINER_DIR/noid170.conf}"
OUTDIR="${NOID_NCU_OUTDIR:-/home/user/noid170-ncu-profile}"
DAEMON="${NOID_DAEMON_BIN:-$MINER_DIR/noid_live_job_daemon}"

find_ncu() {
  if command -v ncu >/dev/null 2>&1; then
    command -v ncu
    return 0
  fi
  for p in \
    /usr/local/cuda/bin/ncu \
    /usr/local/cuda-13.3/bin/ncu \
    /usr/local/cuda-13.2/bin/ncu \
    /usr/local/cuda-13.1/bin/ncu \
    /usr/local/cuda-13.0/bin/ncu; do
    if [[ -x "$p" ]]; then printf '%s\n' "$p"; return 0; fi
  done
  local p
  p=$(find /usr/local/cuda* -type f -name ncu -perm -111 2>/dev/null | head -n1 || true)
  [[ -n "$p" ]] && { printf '%s\n' "$p"; return 0; }
  return 1
}

NCU=$(find_ncu || true)
if [[ -z "$NCU" ]]; then
  echo "ERROR: Nsight Compute CLI (ncu) was not found." >&2
  echo "CUDA directories present:" >&2
  ls -ld /usr/local/cuda* 2>/dev/null || true
  echo >&2
  echo "Do not install anything yet. Paste this output back into chat and we will use the correct package for this HiveOS image." >&2
  exit 20
fi

[[ -f "$CONF" ]] || { echo "ERROR: missing $CONF" >&2; exit 21; }
[[ -x "$DAEMON" ]] || { echo "ERROR: missing executable $DAEMON" >&2; exit 22; }

# shellcheck disable=SC1090
source "$CONF"
export NOID_MINING_KEY NOID_RPC_URL
: "${NOID_MINING_KEY:?NOID_MINING_KEY missing in config}"
: "${NOID_RPC_URL:?NOID_RPC_URL missing in config}"

mkdir -p "$OUTDIR"
rm -f "$OUTDIR"/job.json "$OUTDIR"/job.line \
      "$OUTDIR"/overview.ncu-rep "$OUTDIR"/overview-details.txt \
      "$OUTDIR"/overview-raw.csv "$OUTDIR"/environment.txt

{
  echo "===== NOID170 NSIGHT COMPUTE ENVIRONMENT ====="
  date -Is
  echo "ncu=$NCU"
  "$NCU" --version || true
  echo
  command -v nvcc >/dev/null 2>&1 && nvcc --version || true
  echo
  nvidia-smi --query-gpu=index,name,uuid,driver_version,pstate,clocks.current.sm,clocks.current.memory,power.draw,power.limit,temperature.gpu --format=csv || true
  echo
  echo "daemon=$DAEMON"
  sha256sum "$DAEMON" || true
  echo
  echo "RmProfilingAdminOnly:"
  grep -E '^RmProfilingAdminOnly' /proc/driver/nvidia/params 2>/dev/null || true
} | tee "$OUTDIR/environment.txt"

echo
echo "===== FETCHING ONE LIVE ARIA WORK ITEM ====="
python3 - "$OUTDIR/job.json" "$OUTDIR/job.line" <<'PY'
import json, os, sys, time, urllib.request, urllib.error
from pathlib import Path

out_json = Path(sys.argv[1]); out_line = Path(sys.argv[2])
url = os.environ['NOID_RPC_URL']
key = os.environ['NOID_MINING_KEY']
body = json.dumps({'jsonrpc':'2.0','id':1,'method':'paranoid_getBlockTemplate','params':['']}).encode()
headers = {
    'Content-Type':'application/json',
    'Authorization':f'Bearer {key}',
    'User-Agent':'noid170-ncu-profile/0.6.24',
    'Accept':'*/*',
}
last = None
for _ in range(30):
    req = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            j = json.load(r)
    except Exception as e:
        last = e; time.sleep(0.25); continue
    if not j.get('error'):
        job = j['result']; break
    err = j.get('error')
    if isinstance(err, dict) and err.get('code') == -32011:
        retry_ms = err.get('data',{}).get('retry_in_ms',250)
        time.sleep(max(0.05, retry_ms/1000.0)); continue
    raise SystemExit(f'RPC error: {err}')
else:
    raise SystemExit(f'could not fetch work: {last}')
required = ('pow_fields_hex','difficulty_target_hex','height','template_id')
for k in required:
    if k not in job: raise SystemExit(f'missing job field: {k}')
out_json.write_text(json.dumps(job, indent=2) + '\n')
out_line.write_text(f"JOB 1 {job['pow_fields_hex']} {job['difficulty_target_hex']}\n")
print(f"height={job['height']} template={job['template_id']}")
print(f"powhex={len(job['pow_fields_hex'])} chars target={len(job['difficulty_target_hex'])} chars")
PY

echo
echo "===== STOPPING NORMAL HIVEOS MINING FOR CLEAN GPU0 PROFILE ====="
if command -v miner >/dev/null 2>&1; then
  miner stop || true
  sleep 2
fi

restart_miner() {
  local rc=$?
  echo
  echo "===== RESTARTING NORMAL HIVEOS MINING ====="
  if command -v miner >/dev/null 2>&1; then miner start || true; fi
  exit "$rc"
}
trap restart_miner EXIT INT TERM

# Keep stdin open long enough for warm-up launches. STOP may queue while NCU
# replays the selected launch; the daemon processes it after profiling and exits cleanly.
echo
echo "===== PROFILING ONE WARMED mine_kernel LAUNCH ON GPU0 ====="
echo "This can take a while because Nsight Compute replays the selected kernel to collect counters."

set +e
{
  cat "$OUTDIR/job.line"
  sleep 20
  printf 'STOP\n'
} | CUDA_VISIBLE_DEVICES=0 "$NCU" \
      --devices 0 \
      --kernel-name-base function \
      --kernel-name 'regex:.*mine_kernel.*' \
      --launch-skip 3 \
      --launch-count 1 \
      --replay-mode kernel \
      --cache-control none \
      --set detailed \
      --page details \
      --print-details all \
      --force-overwrite \
      --export "$OUTDIR/overview.ncu-rep" \
      "$DAEMON" --daemon 240624 \
      2>&1 | tee "$OUTDIR/overview-details.txt"
NCU_RC=${PIPESTATUS[1]}
set -e

if [[ "$NCU_RC" -ne 0 ]]; then
  echo >&2
  echo "ERROR: ncu exited with code $NCU_RC" >&2
  echo "Paste $OUTDIR/overview-details.txt back into chat." >&2
  exit "$NCU_RC"
fi

if [[ ! -s "$OUTDIR/overview.ncu-rep" ]]; then
  echo "ERROR: profile report was not created: $OUTDIR/overview.ncu-rep" >&2
  exit 23
fi

echo
echo "===== EXPORTING RAW METRICS ====="
"$NCU" --import "$OUTDIR/overview.ncu-rep" --page raw --csv > "$OUTDIR/overview-raw.csv"

# Re-render details from the finished report. This makes the output independent
# of any target-process chatter mixed into the live collection log.
"$NCU" --import "$OUTDIR/overview.ncu-rep" --page details --print-details all > "$OUTDIR/overview-report.txt"

echo
echo "===== PROFILE COMPLETE ====="
ls -lh "$OUTDIR/overview.ncu-rep" "$OUTDIR/overview-report.txt" "$OUTDIR/overview-raw.csv" "$OUTDIR/environment.txt"
echo
echo "Paste overview-report.txt into chat first."
echo "If convenient, also upload overview-raw.csv and overview.ncu-rep."
