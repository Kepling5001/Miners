# NOID170 v0.6.24 Nsight Compute profiler

Profiles the exact installed production `noid_live_job_daemon` on GPU0. It does not replace or modify the miner.

What it does:

- detects `ncu`
- records CUDA/driver/GPU environment
- fetches one live Aria work item using the installed `noid170.conf`
- stops normal HiveOS mining
- runs the installed daemon directly on GPU0
- skips 3 matching `mine_kernel` launches
- profiles exactly 1 warmed launch with Nsight Compute's `detailed` set
- uses `--cache-control none`
- exports `overview.ncu-rep`, a readable details report, and raw CSV
- restarts normal HiveOS mining via an EXIT trap

Run:

```bash
cd /home/user/noid170-v0.6.24-ncu-profile
./profile-noid170.sh
```

If `ncu` is not installed, the script stops without installing anything. Paste its diagnostic output back into chat.
