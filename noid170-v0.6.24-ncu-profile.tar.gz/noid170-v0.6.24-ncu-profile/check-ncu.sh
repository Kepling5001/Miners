#!/usr/bin/env bash
set -u
echo "===== NSIGHT COMPUTE CHECK ====="
command -v ncu || true
for p in /usr/local/cuda/bin/ncu /usr/local/cuda-13.3/bin/ncu; do [[ -x "$p" ]] && echo "$p"; done
find /usr/local/cuda* -type f -name ncu -perm -111 2>/dev/null | head -10 || true
echo
echo "===== CUDA ====="
command -v nvcc && nvcc --version || true
echo
echo "===== NVIDIA ====="
nvidia-smi --query-gpu=index,name,driver_version --format=csv || true
echo
echo "===== PROFILING POLICY ====="
grep -E '^RmProfilingAdminOnly' /proc/driver/nvidia/params 2>/dev/null || true
