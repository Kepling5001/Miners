#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 { unsigned long long lo; unsigned long long hi; };
#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); exit(1);} } while(0)

__device__ __forceinline__ unsigned long long mix64_phase(unsigned long long x) {
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL;
    x ^= x >> 31; return x;
}

__device__ __forceinline__ void poseidon_reference(U128 s[4]) {
    apply_mds_full(s);
    #pragma unroll 1
    for (int r=0; r<NOID_N_ROUNDS; ++r) {
        const bool full = !(r >= NOID_F_ROUNDS/2 &&
                            r < NOID_F_ROUNDS/2 + NOID_P_ROUNDS);
        if (full) {
            #pragma unroll
            for (int i=0;i<4;++i) {
                s[i]=bxor(s[i],NOID_RC[i][r]);
                s[i]=sbox_x7(s[i]);
            }
            apply_mds_full(s);
        } else {
            s[0]=bxor(s[0],NOID_RC[0][r]);
            s[0]=sbox_x7(s[0]);
            apply_mds_partial(s);
        }
    }
}

__global__ void phase_oracle(unsigned int *errors) {
    unsigned t=blockIdx.x*blockDim.x+threadIdx.x;
    if(t>=256) return;
    U128 a[4], b[4];
    #pragma unroll
    for(int i=0;i<4;++i){
        unsigned long long z=mix64_phase(0x243f6a8885a308d3ULL ^ ((unsigned long long)t<<9) ^ (i*0x9e37ULL));
        a[i]={z,mix64_phase(z^0x13198a2e03707344ULL)};
        b[i]=a[i];
    }
    poseidon_reference(a);
    poseidon_permute(b);
    unsigned local=0;
    #pragma unroll
    for(int i=0;i<4;++i) local += (a[i].lo!=b[i].lo || a[i].hi!=b[i].hi);
    if(local) atomicAdd(errors,local);
}

int main(){
    unsigned int *d=nullptr,h=0;
    CUDA_OK(cudaMalloc(&d,sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d,0,sizeof(unsigned int)));
    phase_oracle<<<1,256>>>(d);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(&h,d,sizeof(h),cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d));
    if(h){
        printf("PHASE-SPLIT GPU ORACLE: FAIL errors=%u\n",h);
        return 2;
    }
    printf("PHASE-SPLIT GPU ORACLE: PASS states=256 permutations=256\n");
    return 0;
}
