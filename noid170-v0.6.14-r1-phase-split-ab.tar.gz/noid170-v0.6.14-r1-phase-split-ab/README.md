# NOID170 v0.6.14-r1 Poseidon phase-split A/B

Tests current512 against the same arithmetic with Poseidon2b's fixed 4-full / 58-partial / 4-full round schedule split into separate loops. Partial-loop unroll factors 1, 2, 4, and 8 are benchmarked. No live miner is installed or replaced.


r1 fix: corrected test_phase.cu packaging so it contains real newlines rather than literal \n sequences. Miner phase-split kernels are unchanged from v0.6.14.
