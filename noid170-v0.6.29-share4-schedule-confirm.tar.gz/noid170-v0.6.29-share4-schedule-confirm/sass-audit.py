#!/usr/bin/env python3
import os,re,subprocess,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent; BIN=ROOT/'bin'
cu=os.environ.get('CUOBJDUMP','/usr/local/cuda-13.3/bin/cuobjdump')
env=os.environ.copy(); env.setdefault('NVDISASM_PATH','/usr/local/cuda-13.3/bin/nvdisasm'); env['PATH']='/usr/local/cuda-13.3/bin:'+env.get('PATH','')
for name in ('prod','share4','share4_stream','share4_interleave','share4_stream_interleave'):
    exe=BIN/f'noid_daemon_{name}'
    text=subprocess.check_output([cu,'--dump-sass',str(exe)],text=True,stderr=subprocess.STDOUT,env=env)
    parts=re.split(r'(?m)^\s*Function\s*:\s*',text); body=''
    for p in parts[1:]:
        lines=p.splitlines(); fn=lines[0].strip() if lines else ''
        if 'mine_kernel' in fn: body='\n'.join(lines[1:]); break
    if not body: print(name,'mine_kernel not found'); continue
    c=collections.Counter()
    for line in body.splitlines():
        if not re.search(r'/\*[0-9a-fA-F]+\*/',line): continue
        a=re.sub(r'^.*?/\*[0-9a-fA-F]+\*/\s*','',line,count=1); a=re.sub(r'^@!?P\d+\s+','',a); m=re.match(r'([A-Z][A-Z0-9_.]*)\b',a)
        if m: c[m.group(1).split('.')[0]]+=1
    ru=subprocess.check_output([cu,'--dump-resource-usage',str(exe)],text=True,stderr=subprocess.STDOUT,env=env)
    m=re.search(r'Function\s+_Z11mine_kernel[^:]*:\s*\n\s*REG:(\d+)\s+STACK:(\d+)\s+SHARED:(\d+)\s+LOCAL:(\d+)',ru)
    regs=m.group(1) if m else '?'; local=m.group(4) if m else '?'
    print(f"{name:16s} total={sum(c.values()):4d} CLMAD={c['CLMAD']:4d} LOP3={c['LOP3']+c['ULOP3']:4d} SHF={c['SHF']:4d} IMAD={c['IMAD']:4d} REG={regs} LOCAL={local}")
