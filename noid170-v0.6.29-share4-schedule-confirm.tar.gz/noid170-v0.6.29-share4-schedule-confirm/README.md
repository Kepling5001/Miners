# NOID170 v0.6.29 share4 production confirmation + schedule refinement

Isolated CMP170HX A/B; does not install or replace the HiveOS miner.

v0.6.28 found a real first-round Frobenius-sharing win (~160.89 MH/s), but its recompiled baseline was lower than the known installed production kernel. v0.6.29 therefore benchmarks against a byte-for-byte copy of the exact installed daemon, then tests the exact `share4` winner plus three algebra-identical scheduling forms.

- `prod`: exact installed production daemon copied at build time.
- `share4`: exact v0.6.28 winner.
- `share4_stream`: materialize derived x2/x4 values only when consumed, shortening live ranges.
- `share4_interleave`: expose the two independent square chains as n2, x1², n4, x1⁴.
- `share4_stream_interleave`: both changes.

Run:
```bash
cd /home/user/noid170-v0.6.29-share4-schedule-confirm
./build-on-rig.sh
miner stop
set -a
source /hive/miners/custom/noid170/noid170.conf
set +a
./test-share4-refine.sh
```

Paste `SHARE4 REFINEMENT ORACLE`, `STATIC SASS AUDIT`, `FINAL SHARE4 PRODUCTION-CONFIRM RANKING`, and `SHARE4 REFINEMENT WINNER PROTOCOL`.
