#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in baseline hoist_mds hoist_rc0; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done
echo "===== GPU CORRECTNESS ORACLES ====="
for v in baseline hoist_mds hoist_rc0; do echo "--- GF/Poseidon $v ---"; "$ROOT/bin/test_gf_$v"; done
echo "--- first-MDS algebra + full permutation ---"
"$ROOT/bin/test_first_hoist"
echo
echo "===== STATIC SASS AUDIT ====="
python3 "$ROOT/sass-audit.py"
echo
python3 "$ROOT/benchmark_hoist.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste STATIC SASS AUDIT, FINAL RED2/512 FIRST-MDS HOIST RANKING, and FIRST-MDS HOIST WINNER PROTOCOL back into chat."
echo "This experiment did NOT install or replace the HiveOS miner. Restart normal mining when finished: miner start"
