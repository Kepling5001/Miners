#include <cstdio>
#include <cuda_runtime.h>
struct U128 { unsigned long long lo, hi; };
#include "src/noid_cuda_tables.h"
#include "src/noid_runtime_params.h"
#include "src/noid_cuda_math.cuh"
#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); return 2;} } while(0)
__device__ __forceinline__ unsigned long long mix64(unsigned long long x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
__device__ __forceinline__ bool neq(U128 a,U128 b){return a.lo!=b.lo||a.hi!=b.hi;}
__global__ void oracle(unsigned *err){
 unsigned long long id=(unsigned long long)blockIdx.x*blockDim.x+threadIdx.x;
 U128 base[4];
 #pragma unroll
 for(int i=0;i<4;i++) base[i]={mix64(id+17ULL*i),mix64(id+0x10000ULL+29ULL*i)};
 U128 n{mix64(id+0x7777),mix64(id+0xaaaa)};
 U128 std0[4], h1[4], h2[4];
 #pragma unroll
 for(int i=0;i<4;i++) std0[i]=h1[i]=h2[i]=base[i];
 std0[0]=bxor(std0[0],n);
 poseidon_permute(std0);
 apply_mds_full(h1);
 const U128 MUL4{0x5e2f716f4ede412fULL,0xa72ec17764d7ced5ULL};
 U128 n4=gf_mul(MUL4,n);
 h1[0]=bxor(h1[0],bxor(n4,n)); h1[1]=bxor(h1[1],n4); h1[2]=bxor(h1[2],n); h1[3]=bxor(h1[3],n);
 #pragma unroll
 for(int i=0;i<4;i++) h2[i]=bxor(h1[i],NOID_RC[i][0]);
 poseidon_permute_after_initial_mds(h1);
 poseidon_permute_after_initial_mds_rc0(h2);
 #pragma unroll
 for(int i=0;i<4;i++){ if(neq(std0[i],h1[i])) atomicAdd(&err[0],1U); if(neq(std0[i],h2[i])) atomicAdd(&err[1],1U); }
}
int main(){unsigned *d=nullptr,h[2]={};CUDA_OK(cudaMalloc(&d,sizeof(h)));CUDA_OK(cudaMemset(d,0,sizeof(h)));oracle<<<16,64>>>(d);CUDA_OK(cudaGetLastError());CUDA_OK(cudaDeviceSynchronize());CUDA_OK(cudaMemcpy(h,d,sizeof(h),cudaMemcpyDeviceToHost));cudaFree(d);printf("FIRST-MDS HOIST ORACLE: %s (hoist=%u rc0=%u)\n",(h[0]||h[1])?"FAIL":"PASS",h[0],h[1]);return (h[0]||h[1])?1:0;}
