#!/usr/bin/env python3
import http.client,json,os,queue,subprocess,threading,time
from urllib.parse import urlsplit
ROOT=os.path.dirname(os.path.abspath(__file__)); KEY=os.environ.get('NOID_MINING_KEY','').strip(); URL=os.environ.get('NOID_RPC_URL','https://pool.ariabrain.com/noid-rpc/')
variant=os.environ.get('NOID_FORCE_VARIANT','').strip()
if not variant:
    try: variant=open(os.path.join(ROOT,'winner.txt')).read().strip()
    except OSError: raise SystemExit('ERROR: benchmark first or set NOID_FORCE_VARIANT')
BIN=os.path.join(ROOT,'bin',f'noid_daemon_{variant}')
if not KEY: raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
u=urlsplit(URL); Conn=http.client.HTTPSConnection if u.scheme=='https' else http.client.HTTPConnection; path=u.path or '/'
def rpc(method,params):
    c=Conn(u.hostname,u.port,timeout=10)
    try:
        body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}); c.request('POST',path,body=body,headers={'Content-Type':'application/json','Authorization':f'Bearer {KEY}','User-Agent':'noid170-first-mds-hoist-persistent/0.6.27'})
        r=c.getresponse(); data=r.read()
        if r.status!=200: raise RuntimeError(f'HTTP {r.status}: {data.decode(errors="replace")}')
        return json.loads(data)
    finally:c.close()
def get_job(timeout=20):
    end=time.time()+timeout
    while time.time()<end:
        a=rpc('paranoid_getBlockTemplate',[''])
        if not a.get('error'): return a['result']
        e=a.get('error') or {}
        if isinstance(e,dict) and e.get('code')==-32011: time.sleep(max(.05,e.get('data',{}).get('retry_in_ms',500)/1000)); continue
        raise RuntimeError(e)
    raise RuntimeError('template timeout')
def key(j): return int(j['height']),j['pow_fields_hex'],j['difficulty_target_hex']
env=os.environ.copy(); env['CUDA_VISIBLE_DEVICES']='0'; p=subprocess.Popen([BIN,'--daemon','56001'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
ev=queue.Queue(); sh=queue.Queue()
def er():
    for l in p.stderr: l=l.rstrip(); print('GPU:',l); ev.put(l)
def ou():
    for l in p.stdout:
        l=l.rstrip()
        if l.startswith('SHARE '): sh.put(l)
threading.Thread(target=er,daemon=True).start(); threading.Thread(target=ou,daemon=True).start()
def wait(pre,to=30):
    end=time.time()+to
    while time.time()<end:
        if p.poll() is not None: raise RuntimeError(f'daemon exited {p.returncode}')
        try:l=ev.get(timeout=.5)
        except queue.Empty: continue
        if l.startswith(pre): return l
    raise RuntimeError(f'timeout {pre}')
def send(seq,j): p.stdin.write(f"JOB {seq} {j['pow_fields_hex']} {j['difficulty_target_hex']}\n"); p.stdin.flush()
print('===== FIRST-MDS HOIST WINNER PERSISTENT TEST ====='); print('variant:',variant); print('PID:',p.pid); wait('READY ')
j1=get_job(); print('job1',j1['template_id'],'height',j1['height']); send(1,j1); wait('JOBACK 1 '); send(2,j1); print('same-work switch:',wait('JOBACK 2 ')); print('hash stat:',wait('STAT ',10)); print('PID still:',p.pid,'alive:',p.poll() is None)
j2=get_job(); print('job2',j2['template_id'],'height',j2['height']); send(3,j2); print('fresh-job switch:',wait('JOBACK 3 ')); cur=j2; seq=3; end=time.time()+60; nxt=0; ok=False
while time.time()<end and not ok:
    now=time.time()
    if now>=nxt:
        fresh=get_job()
        if key(fresh)!=key(cur): seq+=1; cur=fresh; send(seq,cur); print('live-work switch:',wait(f'JOBACK {seq} '),'height',cur['height'])
        else: cur['template_id']=fresh['template_id']
        nxt=now+.5
    try:l=sh.get(timeout=.1)
    except queue.Empty: continue
    z=l.split()
    if len(z)!=3 or int(z[1])!=seq: continue
    a=rpc('paranoid_submitBlock',[cur['template_id'],z[2]]); print('share submit:',json.dumps(a)); ok=a.get('result')=='share accepted'
if not ok: raise RuntimeError('winner produced no accepted share within 60 seconds')
p.stdin.write('STOP\n'); p.stdin.flush()
try:p.wait(timeout=4)
except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=4)
print('exit:',p.returncode); print('FIRST-MDS HOIST WINNER PROTOCOL: PASS')
