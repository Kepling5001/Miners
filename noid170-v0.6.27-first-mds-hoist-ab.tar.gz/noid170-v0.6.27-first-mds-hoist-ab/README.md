# NOID170 v0.6.27 — first-permutation initial-MDS hoist A/B

Correctness-gated CMP170HX benchmark. It does **not** install or replace the live HiveOS miner.

## Why this is different
The first mining permutation begins from a job-constant prefix with only the nonce varying in state lane 0. Poseidon2 begins with the external MDS. Because the MDS is linear, its job-constant part can be moved into `prepare_job()`. The nonce contributes only MDS column 0 = `[5,4,1,1]`. In characteristic two, `5*n = 4*n XOR n`, so the dynamic initial MDS needs only **one** general GF multiply by 4 instead of the production factorized MDS's four general GF multiplies.

Variants:
- `baseline` — exact current red2/512 production math.
- `hoist_mds` — precompute the constant part of the first initial MDS; dynamically compute only `4*nonce`.
- `hoist_rc0` — same, and pre-fold the first round constants into the prepared base.

The second and third sponge permutations are unchanged. All partial/full-round math after the first initial MDS is unchanged.

## Run
```bash
cd /home/user/noid170-v0.6.27-first-mds-hoist-ab
./build-on-rig.sh
miner stop
set -a
source /hive/miners/custom/noid170/noid170.conf
set +a
./test-hoist.sh
```

Paste back `STATIC SASS AUDIT`, `FINAL RED2/512 FIRST-MDS HOIST RANKING`, and `FIRST-MDS HOIST WINNER PROTOCOL: PASS`.
