#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"
COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_SQUARE_REDUCE_VARIANT=3 -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1 -DNOID_EVENT_POLL_US=2000
  -DNOID_PARTIAL_ILP=2 -Xptxas=-v
)
build_variant(){
  local name="$1" threads="$2" grid="$3"
  echo
  echo "===== BUILD $name | T=$threads GRID-B/SM=$grid PARTIAL_ILP=2(red2) ====="
  "$NVCC" "${COMMON[@]}" -DNOID_THREADS="$threads" -DNOID_BLOCKS_PER_SM="$grid" \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"
  chmod 755 "$BIN/noid_daemon_$name"
}
python3 "$ROOT/offline_verify.py"
build_variant t384 384 171
build_variant t416 416 158
build_variant t448 448 146
build_variant t480 480 137
build_variant t512 512 128
build_variant t544 544 120
build_variant t576 576 114
build_variant t608 608 108
build_variant t640 640 102
build_variant t672 672 98
build_variant t704 704 93
build_variant t736 736 89
build_variant t768 768 85

echo
echo "===== BUILD RED2 GPU ORACLE ====="
"$NVCC" "${COMMON[@]}" -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 \
  "$ROOT/test_gf_primitives.cu" -o "$BIN/test_gf_red2" 2>&1 | tee "$BIN/build_test_gf_red2.log"
chmod 755 "$BIN/test_gf_red2"
python3 -m py_compile "$ROOT/benchmark_red2_launch.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-red2-launch.sh" "$ROOT/test-persistent.sh"
echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_red2
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-red2-launch.sh"
