# NOID170 v0.6.16 red2 thread-launch A/B

Correctness-gated CMP 170HX benchmark. It does **not** install or replace the live HiveOS miner.

## Why this test

The v0.6.15 512-thread partial-MDS sweep found `red2` (`NOID_PARTIAL_ILP=2`) at about +0.73% versus the previous `prod2` schedule, with 42 registers, no spills, and a live accepted share.

The 512-thread launch itself had been selected while using `prod2`, so this test re-sweeps block size with the new `red2` winner fixed. No cryptographic math changes.

## Variants

384 through 768 threads per block in 32-thread steps. Grid blocks are adjusted so hashes per batch remain approximately equal to the current 512 x 128 launch.

## Run

```bash
cd /home/user/noid170-v0.6.16-red2-launch-ab
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-red2-launch.sh
miner start
```

Paste `FINAL RED2 THREAD-LAUNCH RANKING` and `RED2 LAUNCH WINNER PROTOCOL: PASS` back into chat.
