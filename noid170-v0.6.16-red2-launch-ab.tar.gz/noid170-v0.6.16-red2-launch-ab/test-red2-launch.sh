#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in t384 t416 t448 t480 t512 t544 t576 t608 t640 t672 t704 t736 t768; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done
[[ -x "$ROOT/bin/test_gf_red2" ]] || { echo "ERROR: missing GPU oracle; run ./build-on-rig.sh"; exit 1; }
echo "===== GPU CORRECTNESS ORACLE ====="
"$ROOT/bin/test_gf_red2"
echo
python3 "$ROOT/benchmark_red2_launch.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste the complete FINAL RED2 THREAD-LAUNCH RANKING"
echo "and RED2 LAUNCH WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
