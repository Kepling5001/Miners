#!/usr/bin/env python3
import http.client
import json
import os
import queue
import re
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
SAMPLES = max(6, int(os.environ.get("NOID_BENCH_STATS", "10")))

LAUNCHES = {
    "t384": (384, 171),
    "t416": (416, 158),
    "t448": (448, 146),
    "t480": (480, 137),
    "t512": (512, 128),
    "t544": (544, 120),
    "t576": (576, 114),
    "t608": (608, 108),
    "t640": (640, 102),
    "t672": (672, 98),
    "t704": (704, 93),
    "t736": (736, 89),
    "t768": (768, 85),
}
VARIANTS = list(LAUNCHES)

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"

def rpc(method, params):
    connection = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params})
        connection.request(
            "POST", rpc_path, body=body,
            headers={
                "Content-Type":"application/json",
                "Authorization":f"Bearer {KEY}",
                "User-Agent":"noid170-red2-launch-bench/0.6.16",
            },
        )
        response = connection.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        connection.close()

def get_job(timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")

def resource_info(name):
    path = os.path.join(BIN, f"build_{name}.log")
    try:
        text = open(path, "r", encoding="utf-8", errors="replace").read()
    except OSError:
        return None, None, None
    regs_all = re.findall(r"Used\s+(\d+)\s+registers", text)
    spills_all = re.findall(r"(\d+)\s+bytes spill stores,\s*(\d+)\s+bytes spill loads", text)
    regs = int(regs_all[-1]) if regs_all else None
    if spills_all:
        stores, loads = map(int, spills_all[-1])
    else:
        stores = loads = None
    return regs, stores, loads

def run_once(name, job, run_number):
    binary = os.path.join(BIN, f"noid_daemon_{name}")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [binary, "--daemon", str(0x5A00 + run_number)],
        stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        text=True, bufsize=1, env=env,
    )
    events = queue.Queue()
    def reader():
        for line in proc.stderr:
            events.put(line.strip())
    threading.Thread(target=reader, daemon=True).start()
    def wait_for(prefix, timeout=15):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if proc.poll() is not None:
                raise RuntimeError(f"{name}: daemon exited with {proc.returncode}")
            try:
                line = events.get(timeout=0.5)
            except queue.Empty:
                continue
            if line.startswith(prefix):
                return line
        raise RuntimeError(f"{name}: timeout waiting for {prefix}")
    try:
        wait_for("READY ")
        hard_target = "01" + "00" * 31
        proc.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard_target}\n")
        proc.stdin.flush()
        wait_for("JOBACK 1 ")
        samples=[]
        while len(samples) < SAMPLES:
            fields=wait_for("STAT ").split()
            samples.append((float(fields[1]), float(fields[5])))
        used=samples[3:]
        kernel=statistics.mean(x[0] for x in used)
        wall=statistics.mean(x[1] for x in used)
        print(f"{name:5s} run{run_number:02d}  kernel={kernel:8.3f}  wall={wall:8.3f} MH/s")
        return kernel, wall
    finally:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n"); proc.stdin.flush(); proc.wait(timeout=4)
            except Exception:
                proc.terminate(); proc.wait(timeout=4)

job=get_job()
print("===== RED2 THREAD-LAUNCH A/B BENCHMARK | GPU0 =====")
print(f"height: {job['height']}  samples/run: {SAMPLES}  balanced forward/reverse")
print("math fixed: PARTIAL_ILP=2 (red2); hashes/batch held approximately constant")

measurements={name:[] for name in VARIANTS}
order=VARIANTS + list(reversed(VARIANTS))
for index,name in enumerate(order,1):
    measurements[name].append(run_once(name,job,index))

results=[]
for name in VARIANTS:
    kernel=statistics.mean(x[0] for x in measurements[name])
    wall=statistics.mean(x[1] for x in measurements[name])
    regs,ss,sl=resource_info(name)
    threads,grid=LAUNCHES[name]
    results.append({"name":name,"threads":threads,"grid":grid,"kernel":kernel,"wall":wall,"regs":regs,"ss":ss,"sl":sl})

baseline=next(x for x in results if x["name"]=="t512")
ranked=sorted(results,key=lambda x:x["wall"],reverse=True)
print("\n===== FINAL RED2 THREAD-LAUNCH RANKING =====")
print(f"{'rank':>4s}  {'variant':7s} {'T':>4s} {'grid':>4s} {'regs':>4s} {'spill S/L':>10s} {'kernel':>10s} {'wall':>10s} {'vs t512':>9s}")
for rank,r in enumerate(ranked,1):
    gain=(r['wall']/baseline['wall']-1.0)*100.0
    regs='?' if r['regs'] is None else str(r['regs'])
    spills='?/?' if r['ss'] is None else f"{r['ss']}/{r['sl']}"
    print(f"{rank:4d}  {r['name']:7s} {r['threads']:4d} {r['grid']:4d} {regs:>4s} {spills:>10s} {r['kernel']:10.3f} {r['wall']:10.3f} {gain:+8.2f}%")

winner=ranked[0]
with open(os.path.join(ROOT,"winner.txt"),"w",encoding="utf-8") as f:
    f.write(winner['name']+"\n")
print(f"\nbaseline: t512 red2 wall={baseline['wall']:.3f} MH/s")
print(f"winner:   {winner['name']} wall={winner['wall']:.3f} MH/s")
print(f"gain:     {(winner['wall']/baseline['wall']-1.0)*100.0:+.2f}%")
print(f"persistent accepted-share test: {winner['name']}")
