NOID170 v0.6.33 production — HiveOS custom miner

Backends
--------
https:// / http://
  Aria HTTP backend. The v0.6.32 production Aria wrapper and CUDA daemon are
  preserved byte-for-byte.

stratum+ssl://
  InnovLab parano1d-stratum-v1 over system WebPKI TLS verification.
  The production InnovLab CUDA path is the live-tested test3-precompute-r1
  namespace-aware share4 build.

InnovLab flight-sheet settings
------------------------------
Pool URL:
  stratum+ssl://us.innovlab.cc:19601

Wallet and worker template:
  Your bare NOID wallet address is supported by this miner and is sent exactly
  as entered. The miner does NOT append a worker name. If the pool account
  later requires a worker suffix, use address.worker instead.

Password:
  x is used automatically by the Stratum backend.

Extra config:
  Leave blank for normal operation.

Important
---------
For Aria, continue using a unique .worker suffix per rig because that produced
materially better accepted-share behavior in prior testing.

For InnovLab, worker names are optional from the miner's perspective: the
CUSTOM_TEMPLATE string is authorized verbatim.

Measured live InnovLab behavior before promotion:
  - genuine GPU-found shares accepted
  - 0 protocol rejects in repeated tests
  - 0 local namespace mismatches
  - mining.pause / clean new-job handling verified
  - test3-precompute-r1 was the fastest fully tested namespace build (~157.9 MH/s
    on the one-CMP170HX test card versus ~160.9 MH/s Aria production checkpoint)

No dev fee is implemented by NOID170.
