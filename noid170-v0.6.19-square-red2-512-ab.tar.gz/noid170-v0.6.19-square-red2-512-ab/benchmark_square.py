#!/usr/bin/env python3
import http.client, json, os, queue, re, statistics, subprocess, threading, time
from urllib.parse import urlsplit

ROOT=os.path.dirname(os.path.abspath(__file__))
BIN=os.path.join(ROOT,"bin")
KEY=os.environ.get("NOID_MINING_KEY","").strip()
URL=os.environ.get("NOID_RPC_URL","https://pool.ariabrain.com/noid-rpc/")
SAMPLES=max(7,int(os.environ.get("NOID_BENCH_STATS","10")))
VARIANTS=[
 ("gcm_r4top",0,0,"generic r4top square reduction"),
 ("generic_r3",1,0,"generic r3 hybrid square reduction"),
 ("r3even_lop3",2,1,"3-CLMAD square-specialized + LOP3"),
 ("r3even_xor",2,0,"3-CLMAD square-specialized + XOR"),
 ("current",3,1,"CURRENT: 2-CLMAD square-specialized + LOP3"),
 ("r2even_xor",3,0,"2-CLMAD square-specialized + XOR"),
 ("r1low_lop3",4,1,"1-CLMAD low + LOP3"),
 ("r1low_xor",4,0,"1-CLMAD low + XOR"),
 ("r1high_lop3",5,1,"1-CLMAD high + LOP3"),
 ("r1high_xor",5,0,"1-CLMAD high + XOR"),
 ("r0shift_lop3",6,1,"0-CLMAD shift reduction + LOP3"),
 ("r0shift_xor",6,0,"0-CLMAD shift reduction + XOR"),
]
if not KEY: raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
u=urlsplit(URL); Conn=http.client.HTTPSConnection if u.scheme=="https" else http.client.HTTPConnection; rpc_path=u.path or "/"
def rpc(method,params):
 c=Conn(u.hostname,u.port,timeout=10)
 try:
  body=json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params})
  c.request("POST",rpc_path,body=body,headers={"Content-Type":"application/json","Authorization":f"Bearer {KEY}","User-Agent":"noid170-square-red2-bench/0.6.19"})
  r=c.getresponse(); data=r.read()
  if r.status!=200: raise RuntimeError(f"HTTP {r.status}: {data.decode(errors='replace')}")
  return json.loads(data)
 finally: c.close()
def get_job(timeout=20):
 end=time.time()+timeout
 while time.time()<end:
  a=rpc("paranoid_getBlockTemplate",[""])
  if not a.get("error"): return a["result"]
  e=a.get("error") or {}
  if isinstance(e,dict) and e.get("code")==-32011:
   time.sleep(max(.05,e.get("data",{}).get("retry_in_ms",500)/1000)); continue
  raise RuntimeError(e)
 raise RuntimeError("template timeout")
def resource_info(name):
 try: text=open(os.path.join(BIN,f"build_{name}.log"),encoding="utf-8",errors="replace").read()
 except OSError: return None,None,None
 # Restrict register extraction to mine_kernel's ptxas section.
 m=re.search(r"Compiling entry function '_Z11mine_kernel.*?Function properties for _Z11mine_kernel.*?Used\s+(\d+)\s+registers",text,re.S)
 regs=int(m.group(1)) if m else None
 m2=re.search(r"Function properties for _Z11mine_kernel.*?(\d+)\s+bytes spill stores,\s*(\d+)\s+bytes spill loads",text,re.S)
 return (regs,int(m2.group(1)),int(m2.group(2))) if m2 else (regs,None,None)
def run_once(name,job,n):
 env=os.environ.copy(); env["CUDA_VISIBLE_DEVICES"]="0"
 p=subprocess.Popen([os.path.join(BIN,f"noid_daemon_{name}"),"--daemon",str(0x5A00+n)],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
 q=queue.Queue()
 def reader():
  for line in p.stderr: q.put(line.strip())
 threading.Thread(target=reader,daemon=True).start()
 def wait(prefix,timeout=15):
  end=time.time()+timeout
  while time.time()<end:
   if p.poll() is not None: raise RuntimeError(f"{name}: exited {p.returncode}")
   try: line=q.get(timeout=.5)
   except queue.Empty: continue
   if line.startswith(prefix): return line
  raise RuntimeError(f"{name}: timeout waiting for {prefix}")
 try:
  wait("READY "); hard="01"+"00"*31
  p.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard}\n"); p.stdin.flush(); wait("JOBACK 1 ")
  vals=[]
  while len(vals)<SAMPLES:
   f=wait("STAT ").split(); vals.append((float(f[1]),float(f[5])))
  used=vals[3:]; k=statistics.mean(x[0] for x in used); w=statistics.mean(x[1] for x in used)
  print(f"{name:13s} run{n:02d} kernel={k:8.3f} wall={w:8.3f} MH/s"); return k,w
 finally:
  if p.poll() is None:
   try: p.stdin.write("STOP\n"); p.stdin.flush(); p.wait(timeout=4)
   except Exception: p.terminate(); p.wait(timeout=4)
job=get_job()
print("===== RED2/512 SQUARE-REDUCTION A/B BENCHMARK | GPU0 =====")
print(f"height: {job['height']} samples/run: {SAMPLES} balanced forward/reverse")
meas={n:[] for n,_,_,_ in VARIANTS}; order=[x[0] for x in VARIANTS]+[x[0] for x in reversed(VARIANTS)]
for i,n in enumerate(order,1): meas[n].append(run_once(n,job,i))
results=[]
for n,sq,lop,label in VARIANTS:
 k=statistics.mean(x[0] for x in meas[n]); w=statistics.mean(x[1] for x in meas[n]); regs,ss,sl=resource_info(n)
 results.append(dict(name=n,sq=sq,lop=lop,label=label,kernel=k,wall=w,regs=regs,ss=ss,sl=sl))
base=next(x for x in results if x['name']=='current'); ranked=sorted(results,key=lambda x:x['wall'],reverse=True)
print("\n===== FINAL RED2/512 SQUARE-REDUCTION RANKING =====")
print(f"{'rank':>4}  {'variant':13} {'SQ':>2} {'L3':>2} {'regs':>4} {'spill S/L':>10} {'kernel':>10} {'wall':>10} {'vs current':>11}")
for i,r in enumerate(ranked,1):
 gain=(r['wall']/base['wall']-1)*100; regs='?' if r['regs'] is None else str(r['regs']); spills='?/?' if r['ss'] is None else f"{r['ss']}/{r['sl']}"
 print(f"{i:4d}  {r['name']:13s} {r['sq']:2d} {r['lop']:2d} {regs:>4s} {spills:>10s} {r['kernel']:10.3f} {r['wall']:10.3f} {gain:+9.2f}%")
w=ranked[0]
open(os.path.join(ROOT,'winner.txt'),'w').write(w['name']+'\n')
print(f"\nbaseline: current wall={base['wall']:.3f} MH/s")
print(f"winner:   {w['name']} wall={w['wall']:.3f} MH/s")
print(f"gain:     {(w['wall']/base['wall']-1)*100:+.2f}%")
print(f"persistent accepted-share test: {w['name']}")
