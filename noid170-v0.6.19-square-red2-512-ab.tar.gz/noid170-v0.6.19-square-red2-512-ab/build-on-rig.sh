#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin"
SRC="$ROOT/src"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1 -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 -DNOID_PARTIAL_ILP=2
  -Xptxas=-v
)

build_one() {
  local name="$1" sq="$2" lop3="$3"
  local extra=("-DNOID_SQUARE_REDUCE_VARIANT=$sq")
  if [[ "$lop3" == "1" ]]; then
    extra+=("-DNOID_SQUARE_FOLD_LOP3=1")
  fi
  echo
  echo "===== BUILD $name | SQ=$sq LOP3=$lop3 red2/512 ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" -I"$SRC" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"
  "$NVCC" "${COMMON[@]}" "${extra[@]}" -I"$SRC" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name" 2>&1 | tee "$BIN/build_test_gf_$name.log"
  chmod 755 "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

echo "===== OFFLINE MODELS ====="
python3 "$ROOT/offline_verify.py"

# Generic paths (LOP3 flag is irrelevant here).
build_one gcm_r4top 0 0
build_one generic_r3 1 0

# Square-specialized paths. Test both explicit LOP3 and compiler XOR folding.
build_one r3even_lop3 2 1
build_one r3even_xor  2 0
build_one current      3 1
build_one r2even_xor   3 0
build_one r1low_lop3   4 1
build_one r1low_xor    4 0
build_one r1high_lop3  5 1
build_one r1high_xor   5 0
build_one r0shift_lop3 6 1
build_one r0shift_xor  6 0

python3 -m py_compile "$ROOT/benchmark_square.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-square.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-square.sh"
