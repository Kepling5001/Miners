#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
VARS=(gcm_r4top generic_r3 r3even_lop3 r3even_xor current r2even_xor r1low_lop3 r1low_xor r1high_lop3 r1high_xor r0shift_lop3 r0shift_xor)
for v in "${VARS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done

echo "===== GPU CORRECTNESS ORACLES ====="
for v in "${VARS[@]}"; do
  echo "--- $v ---"
  "$ROOT/bin/test_gf_$v"
done

echo
python3 "$ROOT/benchmark_square.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste FINAL RED2/512 SQUARE-REDUCTION RANKING and"
echo "SQUARE-RED2 WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
