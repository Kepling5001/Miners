# NOID170 v0.6.19 — red2/512 square-reduction re-sweep

Correctness-gated benchmark package for CMP 170HX. It does not install or replace the live HiveOS miner.

Baseline is the reproduced v0.6.15 winner:
- 512 threads
- 128 grid blocks/SM
- `NOID_PARTIAL_ILP=2` (`red2`)
- `NOID_REDUCE_VARIANT=41` (`r4top`)
- current square path = `NOID_SQUARE_REDUCE_VARIANT=3` + `NOID_SQUARE_FOLD_LOP3=1`
- factorized full MDS, CLMAD square, paired CLMAD, nonvolatile PTX scheduling, 2 ms event polling.

This experiment changes only the square-only reduction reached by the x^7 S-box. It tests generic r4top/r3 plus specialized 3-, 2-, 1-, and 0-CLMAD reducers, and compares explicit LOP3 folding against compiler-generated XOR folding where relevant.

Run:
```bash
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='address.worker'
./test-square.sh
```

Every variant must pass the GPU GF/square/S-box/full-Poseidon oracle before benchmarking. The measured winner must then produce a live accepted share.
