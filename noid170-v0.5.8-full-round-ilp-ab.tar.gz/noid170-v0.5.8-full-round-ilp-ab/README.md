# noid170 v0.5.8 full-round ILP A/B

Single-nonce follow-up to the v0.5.7 dual-state experiment. It preserves the
v0.5.6 `prod2 + r4top` kernel and applies two-way CLMAD scheduling only where
one Poseidon state already contains independent work:

- the four S-boxes in each full round, processed as two pairs;
- the two independent multiplication pairs in the factorized full MDS.

Variants independently test product-stage pairing, product plus reduction
pairing, and both locations together. A 512-thread combined variant provides a
register-pressure escape hatch. All variants cover 4,587,520 hashes per kernel
on the 70-SM CMP170HX.

```bash
cd /home/user/noid170-v0.5.8-full-round-ilp-ab
miner stop
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-full-round-ilp.sh
```

The script runs offline verification, a GPU oracle for every variant, balanced
forward/reverse timing, and an accepted-share persistent test with the winner.
