#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_DUAL_VARIANT=1
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local sbox_ilp="$2"
  local mds_ilp="$3"
  local threads="$4"
  local blocks_per_sm="$5"

  echo
  echo "===== BUILD $name | full-sbox=$sbox_ilp full-mds=$mds_ilp threads=$threads blocks/sm=$blocks_per_sm ====="
  "$NVCC" "${COMMON[@]}" \
    -DNOID_FULL_SBOX_ILP="$sbox_ilp" \
    -DNOID_FULL_MDS_ILP="$mds_ilp" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" \
    -DNOID_FULL_SBOX_ILP="$sbox_ilp" \
    -DNOID_FULL_MDS_ILP="$mds_ilp" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

build_variant current   0 0 1024 64
build_variant sboxprod  1 0 1024 64
build_variant sboxfull  2 0 1024 64
build_variant mdsprod   0 1 1024 64
build_variant mdsfull   0 2 1024 64
build_variant bothprod  1 1 1024 64
build_variant bothfull  2 2 1024 64
build_variant bothp512  1 1  512 128

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_full_round_ilp.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-full-round-ilp.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-full-round-ilp.sh"
