#!/usr/bin/env bash
# Quanpool 6.0.0 -> HiveOS custom miner flight-sheet adapter.

[[ -t 1 ]] || exec 2>/dev/null

DIR="/hive/miners/custom/quanpool"
. "$DIR/h-manifest.conf" 2>/dev/null || true

TOKEN="${CUSTOM_TEMPLATE:-}"
NODE="${CUSTOM_URL:-}"
EXTRA="${CUSTOM_USER_CONFIG:-}"

[[ -n "$NODE" ]] || NODE="mainnet.quanpool.com:9834"
NODE="${NODE#*://}"
NODE="${NODE%%/*}"

TLS_DEFAULT="87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6"

if [[ -z "$TOKEN" ]]; then
  echo "Quanpool: Wallet/worker template is empty. Use %WAL%.%WORKER_NAME%." >&2
fi

args=(serve --auth-token "$TOKEN" --node-addr "$NODE")

case " $EXTRA " in
  *" --tls-cert-sha256 "*|*" --tls-cert-sha256="*|*" --tls-cert-sha256-file "*|*" --tls-cert-sha256-file="*) ;;
  *) args+=(--tls-cert-sha256 "$TLS_DEFAULT") ;;
esac

case " $EXTRA " in
  *" --cpu-workers "*|*" --cpu-workers="*) ;;
  *) args+=(--cpu-workers 0) ;;
esac

case " $EXTRA " in
  *" --metrics-port "*|*" --metrics-port="*) ;;
  *) args+=(--metrics-port 9900) ;;
esac

# Parse Hive's free-form Extra Config as normal shell-style argv, then serialize
# the final argument vector as a Bash array. This avoids sourcing a line that
# begins with "--auth-token" (the bug in fixed0).
if [[ -n "$EXTRA" ]]; then
  extra_args=()
  eval "extra_args=( $EXTRA )"
  args+=("${extra_args[@]}")
fi

{
  printf 'CLI_ARGS=('
  printf ' %q' "${args[@]}"
  printf ' )\n'
} > "$CUSTOM_CONFIG_FILENAME"
