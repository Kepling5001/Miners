Quanpool 6.0.0 HiveOS Custom Miner wrapper - fixed1

Flight sheet / Custom Miner fields:
  Miner name: quanpool
  Hash algorithm: quantus
  Wallet and worker template: %WAL%.%WORKER_NAME%
  Pool URL: mainnet.quanpool.com:9834
  Extra config: blank for normal GPU-only mining

Wrapper defaults:
  --cpu-workers 0
  --metrics-port 9900
  --tls-cert-sha256 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6

The wrapper uses Quanpool's /hive-stats endpoint for HiveOS agent stats.
If the rig cannot download the official binary because its TLS stack is too old,
place the official file named quanpool-miner-6.0.0-linux-x86_64 in:
  /hive/miners/custom/quanpool/
then restart the custom miner. h-run.sh will adopt it automatically.
