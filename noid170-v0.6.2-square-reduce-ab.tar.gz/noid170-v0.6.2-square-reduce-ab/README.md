# noid170 v0.6.2 square-only reduction A/B

This package tests reduction specializations used only by flat-basis CLMAD
squaring. Multiplication remains on the proven production r4top reduction;
only `square_flat_clmad()` changes. It branches from the v0.5.6 GPU winner and
keeps the b64/stat8 launch used by production.

Each 256-bit square intermediate has alternating zero bits. That removes one
term from the high-limb overflow expression and permits reduction variants
using three, two, one, or zero CLMAD instructions instead of the normal four.

Variants:

- `current`: production r4top reduction for squares
- `r3generic`: generic three-CLMAD reduction, square-only control
- `r3even`: three-CLMAD reduction using the square even-bit invariant
- `r2even`: two-CLMAD reduction using the invariant
- `r1low`: one CLMAD for the low fold, shifted high fold
- `r1high`: one CLMAD for the high fold, shifted low fold
- `r0shift`: pure shift/XOR square reduction
- `r2lop3`: r2even with explicit `lop3` XOR folding
- `r0lop3`: r0shift with explicit `lop3` XOR folding

The oracle compares every candidate against independent generic square
reduction, S-box, Poseidon, and chained-Poseidon calculations. The benchmark
then uses temperature-balanced passes, ranks by wall MH/s, and validates the
winner through persistent job switching and a network-accepted share.

Run only while the installed HiveOS miner is stopped:

```bash
cd /home/user/noid170-v0.6.2-square-reduce-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-square-reduce.sh
```

The build and A/B normally take about 8–10 minutes. Mining is not restarted
automatically; run `miner start` after the test.
