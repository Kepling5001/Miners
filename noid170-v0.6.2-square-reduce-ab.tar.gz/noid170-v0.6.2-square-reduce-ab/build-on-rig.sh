#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local square_variant="$2"
  shift 2

  echo
  echo "===== BUILD $name | square-reduce=$square_variant $* ====="
  "$NVCC" "${COMMON[@]}" \
    -DNOID_REDUCE_VARIANT=41 \
    -DNOID_PARTIAL_ILP=1 \
    -DNOID_SQUARE_REDUCE_VARIANT="$square_variant" \
    "$@" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" \
    -DNOID_REDUCE_VARIANT=41 \
    -DNOID_PARTIAL_ILP=1 \
    -DNOID_SQUARE_REDUCE_VARIANT="$square_variant" \
    "$@" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

build_variant current    0
build_variant r3generic 1
build_variant r3even    2
build_variant r2even    3
build_variant r1low     4
build_variant r1high    5
build_variant r0shift   6
build_variant r2lop3    3 -DNOID_SQUARE_FOLD_LOP3=1
build_variant r0lop3    6 -DNOID_SQUARE_FOLD_LOP3=1

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_square_reduce.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-square-reduce.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-square-reduce.sh"
