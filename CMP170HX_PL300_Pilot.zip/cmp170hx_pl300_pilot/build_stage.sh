#!/usr/bin/env bash
# Build, stage (but never automatically boot), and inspect an experimental 1-GPU PL300 trial.
set -Eeuo pipefail
MODE="${1:-}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC=/home/user/vf-build-only-native_vf_candidate-20261004-110244/open-gpu-kernel-modules-610.43.03
WORK=/home/user/vf-pl300-pilot-20261004
NEW="$WORK/open-gpu-kernel-modules-610.43.03"
OUT="$WORK/modules"
CUR=/lib/modules/6.6.0-hiveos/updates/cmpunlocker
BACK=/home/user/vf-pl300-known-good-20261004
EXPECTED=8f6d032edff7a88573800db950275d45d8fb86229554f867d8c7bfd5d63db0a7
MODULES=(nvidia nvidia-uvm nvidia-modeset nvidia-drm nvidia-peermem)
[ "$(id -u)" = 0 ] || { echo 'ERROR: run as root'; exit 1; }
[ "$(uname -r)" = 6.6.0-hiveos ] || { echo 'ERROR: wrong kernel'; exit 1; }
case "$MODE" in
build)
  [ ! -e "$WORK" ] || { echo "ERROR: build dir already exists: $WORK"; exit 1; }
  [ -s "$SRC/kernel-open/nvidia.ko" ] || { echo 'ERROR: compiled source missing'; exit 1; }
  [ -f "$SRC/src/nvidia/src/kernel/gpu/gsp/cmp_vbios_image.h" ] || { echo 'ERROR: source image missing'; exit 1; }
  printf '%s  %s\n' "$EXPECTED" "$CUR/nvidia.ko" | sha256sum -c -
  printf '%s  %s\n' "$EXPECTED" "$SRC/kernel-open/nvidia.ko" | sha256sum -c -
  echo 'Copying successful auto-detect source; not changing live source or modules.'
  mkdir -p "$WORK"
  cp -a "$SRC" "$NEW"
  python3 "$HERE/apply_pl.py" "$NEW"
  echo 'Building candidate without installing. May take several minutes.'
  make -C "$NEW/src/nvidia" -j2
  make -C "$NEW" -j2 modules SYSSRC=/lib/modules/6.6.0-hiveos/build CC=gcc
  mkdir -p "$OUT"
  for m in "${MODULES[@]}"; do
    f="$NEW/kernel-open/$m.ko"
    [ -s "$f" ] || exit 1
    [ "$(modinfo -F version "$f")" = 610.43.03 ] || exit 1
    [ "$(modinfo -F vermagic "$f")" = '6.6.0-hiveos SMP preempt mod_unload modversions ' ] || exit 1
    install -m 0644 "$f" "$OUT/$m.ko"
  done
  [ "$(sha256sum "$OUT/nvidia.ko" | cut -d' ' -f1)" != "$EXPECTED" ] || { echo 'ERROR: unchanged module';exit 1; }
  sha256sum "$OUT/nvidia.ko"
  echo 'BUILD COMPLETE — NO INSTALLATION, NO REBOOT.'
  ;;
stage)
  [ -s "$OUT/nvidia.ko" ] || { echo 'ERROR: build first';exit 1; }
  printf '%s  %s\n' "$EXPECTED" "$CUR/nvidia.ko" | sha256sum -c -
  [ ! -e "$BACK" ] || { echo "ERROR: backup already exists: $BACK";exit 1; }
  [ "$(lspci -Dnn | grep -Ec '\[10de:2082\]')" = 3 ] || { echo 'ERROR: expected 3x 10GB cards; stop';exit 1; }
  grep -q 'NVreg_RegistryDwords=' /etc/modprobe.d/cmp-vf-experimental.conf
  grep -q 'RMCmpVbiosTargetBus=0xffffffff' /etc/modprobe.d/cmp-vf-experimental.conf
  ! grep -q 'RMCmpPowerTargetBus' /etc/modprobe.d/cmp-vf-experimental.conf || { echo 'ERROR: PL parameter already exists';exit 1; }
  [ "$(systemctl is-enabled cmp-vf-autorestore.timer 2>/dev/null || true)" != enabled ] || { echo 'ERROR: previous rollback timer enabled; inspect before proceeding';exit 1; }
  mkdir -p "$BACK/modules"
  for m in "${MODULES[@]}"; do
    [ "$(modinfo -F version "$OUT/$m.ko")" = 610.43.03 ] || exit 1
    [ "$(modinfo -F vermagic "$OUT/$m.ko")" = '6.6.0-hiveos SMP preempt mod_unload modversions ' ] || exit 1
    cp -a "$CUR/$m.ko" "$BACK/modules/$m.ko"
  done
  cp -a /etc/modprobe.d "$BACK/modprobe.d"
  # Atomic configuration replacement, preserving other driver options exactly.
  python3 - <<'PYCONF'
from pathlib import Path
p=Path('/etc/modprobe.d/cmp-vf-experimental.conf')
s=p.read_text()
assert s.count('RMCmpVbiosTargetBus=0xffffffff')==1
assert s.count('"')==2, 'unexpected modprobe config'
s=s.replace('RMCmpVbiosTargetBus=0xffffffff','RMCmpVbiosTargetBus=0xffffffff;RMCmpPowerTargetBus=2')
p.write_text(s)
PYCONF
  for m in "${MODULES[@]}"; do install -m 0644 "$OUT/$m.ko" "$CUR/$m.ko"; done
  depmod -a 6.6.0-hiveos
  echo '=== NEXT BOOT MODULE ==='
  sha256sum "$CUR/nvidia.ko"
  echo '=== NEXT BOOT SETTINGS ==='
  modprobe -D nvidia | grep -E 'nvidia.ko|RMCmpPower' | head -5
  echo 'STAGED — NO AUTOMATIC ROLLBACK OR REBOOT. Only bus 02 gets experimental 300W cap.'
  ;;
*) echo "Usage: sudo bash $0 build | stage"; exit 2;;
esac
