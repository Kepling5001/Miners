#!/usr/bin/env python3
"""Patch copied (never live) 610.43.03 VF-autodetect source with a single-bus 300W cap experiment."""
from pathlib import Path
import sys, hashlib, re, struct
if len(sys.argv)!=2: sys.exit('Usage: python3 apply_pl.py /path/to/copied-source')
src=Path(sys.argv[1])/'src/nvidia/src/kernel/gpu/gsp'
h=src/'cmp_vbios_image.h'; c=src/'kernel_gsp.c'; q=src/'message_queue_cpu.c'
text=h.read_text(); code=c.read_text(); queue=q.read_text()
assert 'static NvU8 cmpVbiosImage[]' in text
hexbytes=re.findall(r'0x([0-9a-fA-F]{2})\b',text)
original=bytes(int(x,16) for x in hexbytes)
assert len(original)==0x41800, 'Unexpected embedded VBIOS length'
assert hashlib.sha256(original).hexdigest()=='6a5e61c29b942eb290df83801f9fab4e44370ee29177c6319cfc24cc9a51d11c', 'Not the proven VF VBIOS image'
assert original[0x40045:0x40049]==struct.pack('<I',250000), 'Unexpected PL maximum field'
assert original[0x40041:0x40045]==struct.pack('<I',250000), 'Unexpected PL default field'
assert original[0x4003d:0x40041]==struct.pack('<I',100000), 'Unexpected PL minimum field'
assert original[0x41177:0x4117b]==bytes.fromhex('18fce803'), 'VF unlock missing'
assert code.count('#include "cmp_vbios_image.h"')==1
assert code.count('cmpVbiosImage, sizeof(cmpVbiosImage)')==1
assert code.count('NvU32 targetBus = 0xFFFFFFFFU;')==1
assert code.count('(targetBus != 0xFFFFFFFFU && gpuGetBus(pGpu) != targetBus)')==1, 'Not autodetect source'
assert 'cmpVbiosImagePL' not in code
assert 'cmpBus == 0xFFFFFFFFU' in queue, 'Other GSP selector is not auto-detect'
patched=bytearray(original)
patched[0x40045:0x40049]=struct.pack('<I',300000)
assert sum(a!=b for a,b in zip(patched,original))<=4
hdr='/* EXPERIMENTAL: 250W default, 300W upper cap; no SPI writes. */\nstatic NvU8 cmpVbiosImagePL[] = {\n'
for i in range(0,len(patched),16):
    hdr+='    '+','.join('0x%02x'%v for v in patched[i:i+16])+',\n'
hdr+='};\n'
assert hdr.count('0x')==len(original)
# The firmware image remains unchanged for GPU 2 and GPU 6; only the selected bus gets the PL candidate.
code=code.replace('#include "cmp_vbios_image.h"','#include "cmp_vbios_image.h"\n#include "cmp_vbios_image_pl.h"',1)
marker='    NvU32 targetBus = 0xFFFFFFFFU;'
code=code.replace(marker, marker+'''\n    NvU32 powerTargetBus = 0xFFFFFFFFU;
    NvU8 *cmpVbiosSelected = cmpVbiosImage;''',1)
marker='    /* Never silently overwrite another supplied image. */'
code=code.replace(marker,'''    /* EXPERIMENT: only one explicitly selected PCI bus receives the 300W cap.
     * Other 10GB GPUs retain the already-proven VF-only image.
     * The GPU default remains 250W even on the selected card. */
    if (osReadRegistryDword(pGpu, "RMCmpPowerTargetBus", &powerTargetBus) == NV_OK &&
        powerTargetBus != 0xFFFFFFFFU &&
        gpuGetBus(pGpu) == powerTargetBus)
        cmpVbiosSelected = cmpVbiosImagePL;
'''+marker,1)
code=code.replace('cmpVbiosImage, sizeof(cmpVbiosImage)', 'cmpVbiosSelected, sizeof(cmpVbiosImage)',1)
# Confirm all old sizes remain constant (both firmware images equal size).
assert code.count('sizeof(cmpVbiosImage)')==5
assert code.count('cmpVbiosSelected, sizeof(cmpVbiosImage)')==1
c.write_text(code)
(src/'cmp_vbios_image_pl.h').write_text(hdr)
print('SOURCE PATCH PASS')
print('VF-only SHA256: ',hashlib.sha256(original).hexdigest())
print('VF+PL SHA256:  ',hashlib.sha256(patched).hexdigest())
print('Default 250W unchanged; candidate PL maximum 300W; changed native offset 0x40045')
print('No card ROM, system module, or running driver modified')
