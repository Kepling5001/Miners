CMP170HX VF+300W maximum PL experiment (Oct 2026)

STATUS: SOURCE PATCH VERIFIED OFFLINE. NOT BUILT/BOOT-TESTED ON HARDWARE.

TARGET: Original known-working 10GB automatic-VF driver source used on Octo170HX-02.
DRIVER 610.43.03, KERNEL 6.6.0-hiveos.

EXPERIMENT:
- Keep existing VF-only image for every compatible 10GB CMP 170HX card.
- Only PCI bus 02 (one 10GB test card) receives a second image with its
  version-0x30 POWER BUDGET table's cap-entry 2 peak/maximum changed
  from 250000 to 300000 milliwatts.
- Default stays at 250000 mW, minimum at 100000 mW.
- VF +/-1000 MHz limits unchanged. The nine 8GB cards remain unchanged.
- No changes to physical SPI ROM. No enforced draw increase, no -pl command.
- If successful, nvidia-smi -i 1 -q -d POWER should report 300W Max, 250W Default.
- This does not prove the physical regulator or thermal headroom supports 300W.

Installation procedure:
1. Transfer this directory to /home/user/cmp170hx_pl300_pilot on the same HiveOS rig.
2. As root: bash /home/user/cmp170hx_pl300_pilot/build_stage.sh build
3. Ensure BUILD COMPLETE. Build doesn't alter the live driver or reboot.
4. Only after independently reviewing results and ensuring local recovery access:
   bash /home/user/cmp170hx_pl300_pilot/build_stage.sh stage
5. Stage makes an inert backup under /home/user/vf-pl300-known-good-20261004,
   installs modules for NEXT boot, and sets RMCmpPowerTargetBus=2.
6. Reboot MANUALLY only when ready. No rollback timer or automatic reboot.

If the new driver fails to start, you may need a local console/recovery boot to
restore the saved modules and modprobe configuration. DO NOT flash any .rom.

The pilot is meant for bus 02 only; it is deliberately not yet generalizable.
If this safely boots and reports 300W max, test other 10GB cards separately.
