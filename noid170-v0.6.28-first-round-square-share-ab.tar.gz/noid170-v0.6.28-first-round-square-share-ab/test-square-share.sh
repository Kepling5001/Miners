#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in baseline split_control share23 share4; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done
echo "===== GPU CORRECTNESS ORACLES ====="
for v in baseline split_control share23 share4; do echo "--- GF/Poseidon $v ---"; "$ROOT/bin/test_gf_$v"; done
echo "--- first-round shared-Frobenius oracle ---"
"$ROOT/bin/test_first_square_share"
echo
echo "===== STATIC SASS AUDIT ====="
python3 "$ROOT/sass-audit.py"
echo
python3 "$ROOT/benchmark_square_share.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste FIRST-ROUND SQUARE-SHARE ORACLE, STATIC SASS AUDIT, FINAL RED2/512 FIRST-ROUND SQUARE-SHARE RANKING, and FIRST-ROUND SQUARE-SHARE WINNER PROTOCOL back into chat."
echo "This experiment did NOT install or replace the HiveOS miner. Restart normal mining when finished: miner start"
