#include <cstdio>
#include <cuda_runtime.h>
struct U128 { unsigned long long lo, hi; };
#include "src/noid_cuda_tables.h"
#include "src/noid_runtime_params.h"
#include "src/noid_cuda_math.cuh"
#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); return 2;} } while(0)
__device__ __forceinline__ unsigned long long mix64(unsigned long long x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
__device__ __forceinline__ bool neq(U128 a,U128 b){return a.lo!=b.lo||a.hi!=b.hi;}

__device__ __forceinline__ void finish_from_round1(U128 s[4]) {
    #pragma unroll 1
    for (int r=1; r<NOID_N_ROUNDS; ++r) {
        const bool full=!(r>=NOID_F_ROUNDS/2 && r<NOID_F_ROUNDS/2+NOID_P_ROUNDS);
        if (full) { apply_full_round_sboxes(s,r); apply_mds_full(s); }
        else { s[0]=bxor(s[0],NOID_RC[0][r]); s[0]=sbox_x7(s[0]); apply_mds_partial(s); }
    }
}

__device__ __forceinline__ void make_b(const U128 base[4], U128 b[4]) {
    #pragma unroll
    for(int i=0;i<4;i++) b[i]=base[i];
    apply_mds_full(b);
    #pragma unroll
    for(int i=0;i<4;i++) b[i]=bxor(b[i],NOID_RC[i][0]);
}

__device__ __forceinline__ void split_control(U128 s[4]) {
    apply_mds_full(s);
    apply_full_round_sboxes(s,0);
    apply_mds_full(s);
    finish_from_round1(s);
}

__device__ __forceinline__ void share23_perm(U128 s[4], U128 n, const U128 base[4]) {
    U128 b[4]; make_b(base,b);
    const U128 b2_2=square_flat_clmad(b[2]); const U128 b2_4=square_flat_clmad(b2_2);
    const U128 b3_2=square_flat_clmad(b[3]); const U128 b3_4=square_flat_clmad(b3_2);
    apply_mds_full(s);
    #pragma unroll
    for(int i=0;i<4;i++) s[i]=bxor(s[i],NOID_RC[i][0]);
    const U128 n2=square_flat_clmad(n); const U128 n4=square_flat_clmad(n2);
    s[0]=sbox_x7(s[0]); s[1]=sbox_x7(s[1]);
    s[2]=sbox_x7_from_powers(s[2],bxor(n2,b2_2),bxor(n4,b2_4));
    s[3]=sbox_x7_from_powers(s[3],bxor(n2,b3_2),bxor(n4,b3_4));
    apply_mds_full(s); finish_from_round1(s);
}

__device__ __forceinline__ void share4_perm(U128 s[4], U128 n, const U128 base[4]) {
    U128 b[4]; make_b(base,b);
    const U128 b01=bxor(b[0],b[1]); const U128 b01_2=square_flat_clmad(b01); const U128 b01_4=square_flat_clmad(b01_2);
    const U128 b2_2=square_flat_clmad(b[2]); const U128 b2_4=square_flat_clmad(b2_2);
    const U128 b3_2=square_flat_clmad(b[3]); const U128 b3_4=square_flat_clmad(b3_2);
    apply_mds_full(s);
    #pragma unroll
    for(int i=0;i<4;i++) s[i]=bxor(s[i],NOID_RC[i][0]);
    const U128 n2=square_flat_clmad(n); const U128 n4=square_flat_clmad(n2);
    const U128 x1_2=square_flat_clmad(s[1]); const U128 x1_4=square_flat_clmad(x1_2);
    const U128 x0_2=bxor(x1_2,bxor(n2,b01_2)); const U128 x0_4=bxor(x1_4,bxor(n4,b01_4));
    const U128 x2_2=bxor(n2,b2_2), x2_4=bxor(n4,b2_4);
    const U128 x3_2=bxor(n2,b3_2), x3_4=bxor(n4,b3_4);
    s[0]=sbox_x7_from_powers(s[0],x0_2,x0_4);
    s[1]=sbox_x7_from_powers(s[1],x1_2,x1_4);
    s[2]=sbox_x7_from_powers(s[2],x2_2,x2_4);
    s[3]=sbox_x7_from_powers(s[3],x3_2,x3_4);
    apply_mds_full(s); finish_from_round1(s);
}

__global__ void oracle(unsigned *err){
    unsigned long long id=(unsigned long long)blockIdx.x*blockDim.x+threadIdx.x;
    U128 base[4];
    #pragma unroll
    for(int i=0;i<4;i++) base[i]={mix64(id+17ULL*i),mix64(id+0x10000ULL+29ULL*i)};
    U128 n{mix64(id+0x7777),mix64(id+0xaaaa)};
    U128 ref[4],ctl[4],s23[4],s4[4];
    #pragma unroll
    for(int i=0;i<4;i++) ref[i]=ctl[i]=s23[i]=s4[i]=base[i];
    ref[0]=bxor(ref[0],n); ctl[0]=bxor(ctl[0],n); s23[0]=bxor(s23[0],n); s4[0]=bxor(s4[0],n);
    poseidon_permute(ref); split_control(ctl); share23_perm(s23,n,base); share4_perm(s4,n,base);
    #pragma unroll
    for(int i=0;i<4;i++){
        if(neq(ref[i],ctl[i])) atomicAdd(&err[0],1U);
        if(neq(ref[i],s23[i])) atomicAdd(&err[1],1U);
        if(neq(ref[i],s4[i])) atomicAdd(&err[2],1U);
    }
}
int main(){unsigned *d=nullptr,h[3]={};CUDA_OK(cudaMalloc(&d,sizeof(h)));CUDA_OK(cudaMemset(d,0,sizeof(h)));oracle<<<16,64>>>(d);CUDA_OK(cudaGetLastError());CUDA_OK(cudaDeviceSynchronize());CUDA_OK(cudaMemcpy(h,d,sizeof(h),cudaMemcpyDeviceToHost));cudaFree(d);printf("FIRST-ROUND SQUARE-SHARE ORACLE: %s (split=%u share23=%u share4=%u)\n",(h[0]||h[1]||h[2])?"FAIL":"PASS",h[0],h[1],h[2]);return (h[0]||h[1]||h[2])?1:0;}
