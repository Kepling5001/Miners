# NOID170 v0.6.28 first-round shared-Frobenius A/B

Correctness-gated CMP170HX benchmark. This package does **not** install or replace the live HiveOS miner.

## Baseline held fixed

- 512 threads / 128 blocks-per-SM launch setting
- partial MDS `red2` (`NOID_PARTIAL_ILP=2`)
- `r4top` general reduction
- square reducer variant 3 + explicit LOP3 fold
- original four-stage X^7 S-box
- factorized full MDS
- paired, non-volatile CLMAD scheduling
- 2 ms event polling
- no register cap / no launch-bounds occupancy forcing

## Why this experiment

Only the first nonce-dependent Poseidon permutation starts from a state where all four inputs to round 0 are affine functions of the same nonce after the external MDS. The nonce coefficients are `[5,4,1,1]`.

In characteristic two, squaring is linear. Let the round-0 S-box inputs be `x_i = B_i + c_i*n`.

- lanes 2 and 3 have coefficient 1, so both `x^2` and `x^4` can reuse `n^2` / `n^4` plus job-precomputed constants;
- `c0 + c1 = 5 + 4 = 1`, so `x0 + x1 = (B0+B1)+n`; therefore mode `share4` can derive lane-0 `x^2/x^4` from lane 1 and the shared nonce powers.

The initial external MDS itself remains the exact production path. Only the first full-round Frobenius square work changes.

## Variants

- `baseline` — exact current production behavior.
- `split_control` — round 0 split from the loop but identical arithmetic; measures control/code-layout cost by itself.
- `share23` — reuse `n^2/n^4` for lanes 2 and 3. Saves two field-square operations in the first nonce-dependent full round.
- `share4` — additionally derive lane 0 from lane 1 plus nonce powers. Saves four field-square operations in that round.

All variants retain the same x^3 and x^7 multiplications and all later rounds.

## Run

```bash
cd /home/user/noid170-v0.6.28-first-round-square-share-ab
./build-on-rig.sh

miner stop
set -a
source /hive/miners/custom/noid170/noid170.conf
set +a

./test-square-share.sh
```

Paste back:

1. `FIRST-ROUND SQUARE-SHARE ORACLE: PASS`
2. `STATIC SASS AUDIT`
3. `FINAL RED2/512 FIRST-ROUND SQUARE-SHARE RANKING`
4. `FIRST-ROUND SQUARE-SHARE WINNER PROTOCOL: PASS`

Restart normal mining afterward with `miner start` if Hive does not already have it running.
