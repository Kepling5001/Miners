#!/usr/bin/env bash
set -uo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
RUN_SECONDS=${NOID_AB_SECONDS:-900}
RESULT_DIR=${NOID_AB_RESULT_DIR:-/run/noid170-capability-ab}

if [[ -z "${NOID_MINING_KEY:-}" ]]; then
  echo "ERROR: export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST' first"
  exit 1
fi
if ! [[ "$RUN_SECONDS" =~ ^[0-9]+$ ]] || (( RUN_SECONDS < 120 )); then
  echo "ERROR: NOID_AB_SECONDS must be an integer >= 120"
  exit 1
fi
if pgrep -f 'noid170_aria.py|noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: a NOID miner is still running. Run: miner stop"
  exit 1
fi

mkdir -p "$RESULT_DIR"
rm -f "$RESULT_DIR"/baseline.json "$RESULT_DIR"/candidate.json

export NOID_RPC_URL=${NOID_RPC_URL:-https://pool.ariabrain.com/noid-rpc/}
export NOID_CARD_MH=${NOID_CARD_MH:-143.42}
export NOID_POLL_INTERVAL=${NOID_POLL_INTERVAL:-0.20}
export NOID_SUBMIT_THREADS=1
export NOID_TUI=0
export NOID_WARMUP_BIN="$ROOT/candidate/noid170/noid_live_job_cont"
export NOID_DAEMON_BIN="$ROOT/candidate/noid170/noid_live_job_daemon"

run_variant() {
  local name=$1
  local controller=$2
  local stats_file="$RESULT_DIR/$name.json"
  local log_file="$RESULT_DIR/$name.log"
  export NOID_STATS_FILE="$stats_file"
  echo
  echo "===== RUN $name FOR ${RUN_SECONDS}s ====="
  timeout --signal=TERM "$RUN_SECONDS" python3 -u "$controller" 2>&1 | tee "$log_file"
  local rc=${PIPESTATUS[0]}
  if [[ $rc -ne 0 && $rc -ne 124 && $rc -ne 143 ]]; then
    echo "ERROR: $name exited with status $rc"
    exit "$rc"
  fi
  if [[ ! -s "$stats_file" ]]; then
    echo "ERROR: $name did not produce $stats_file"
    exit 1
  fi
}

run_variant baseline "$ROOT/baseline/noid170_aria.py"
sleep 2
run_variant candidate "$ROOT/candidate/noid170/noid170_aria.py"

python3 "$ROOT/summarize_ab.py" \
  "$RESULT_DIR/baseline.json" "$RESULT_DIR/candidate.json"

echo
echo "Results and logs: $RESULT_DIR"
echo "Restart HiveOS mining when finished: miner start"
