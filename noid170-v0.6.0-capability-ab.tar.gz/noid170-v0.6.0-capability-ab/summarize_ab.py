#!/usr/bin/env python3

import json
import sys


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def pct(numerator, denominator):
    return 100.0 * numerator / denominator if denominator else 0.0


def row(name, data):
    accepted = int(data.get("accepted", 0))
    stale = int(data.get("stale", 0))
    rejected = int(data.get("rejected", 0))
    found = int(data.get("found", 0))
    raw_stale = int(data.get("stale_responses", stale))
    terminal = accepted + stale + rejected
    return {
        "name": name,
        "accepted": accepted,
        "stale": stale,
        "raw_stale": raw_stale,
        "recovered": int(data.get("stale_recovered", 0)),
        "acceptance": pct(accepted, terminal),
        "found_yield": pct(accepted, found),
        "discarded": int(data.get("old_share_discarded", 0)),
        "wall": float(data.get("wall_total_mhs", 0.0)),
        "accepted_work": float(data.get("accepted_work_mhs", 0.0)),
        "rebinds": int(data.get("capability_rebinds", 0)),
        "refresh_failures": int(data.get("capability_refresh_failures", 0)),
    }


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: summarize_ab.py BASELINE.json CANDIDATE.json")
    rows = [row("baseline", load(sys.argv[1])), row("candidate", load(sys.argv[2]))]
    print("===== CAPABILITY RECOVERY A/B RESULT =====")
    print(
        f"{'variant':<10} {'accept':>8} {'stale':>7} {'raw':>7} "
        f"{'recovered':>10} {'accept%':>9} {'accepted/found':>15} "
        f"{'old-drop':>9} {'wall MH/s':>11} {'accepted MH/s':>14}"
    )
    for r in rows:
        print(
            f"{r['name']:<10} {r['accepted']:>8} {r['stale']:>7} "
            f"{r['raw_stale']:>7} {r['recovered']:>10} "
            f"{r['acceptance']:>8.2f}% {r['found_yield']:>14.2f}% "
            f"{r['discarded']:>9} {r['wall']:>11.2f} {r['accepted_work']:>14.2f}"
        )
    base, candidate = rows
    print()
    print(f"acceptance change: {candidate['acceptance'] - base['acceptance']:+.2f} points")
    print(f"accepted/found change: {candidate['found_yield'] - base['found_yield']:+.2f} points")
    print(f"candidate capability rebinds: {candidate['rebinds']}")
    print(f"candidate capability refresh failures: {candidate['refresh_failures']}")
    print()
    print("Paste this complete result plus the final candidate STATUS line into chat.")


if __name__ == "__main__":
    main()
