#!/usr/bin/env python3

import os
import queue
import runpy
import subprocess
import threading
import time


ROOT = os.path.dirname(os.path.abspath(__file__))
CONTROLLER = os.path.join(ROOT, "candidate", "noid170", "noid170_aria.py")


class FakeRunResult:
    stdout = "0\n"


def load_controller():
    original_run = subprocess.run
    original_key = os.environ.get("NOID_MINING_KEY")
    os.environ["NOID_MINING_KEY"] = "o1selftest.worker"
    subprocess.run = lambda *args, **kwargs: FakeRunResult()
    try:
        loaded = runpy.run_path(CONTROLLER, run_name="noid170_capability_selftest")
        # runpy may return a copy rather than the exact function globals dict.
        return loaded["submitter"].__globals__
    finally:
        subprocess.run = original_run
        if original_key is None:
            os.environ.pop("NOID_MINING_KEY", None)
        else:
            os.environ["NOID_MINING_KEY"] = original_key


def candidate(template_id, height=100, pow_hex="11" * 80, target_hex="22" * 32):
    return {
        "template_id": template_id,
        "height": height,
        "pow_fields_hex": pow_hex,
        "difficulty_target_hex": target_hex,
    }


def reset(ns):
    ns["running"] = True
    ns["share_queue"] = queue.Queue()
    ns["contexts"].clear()
    ns["invalidated_seqs"].clear()
    ns["stale_logged_seqs"].clear()
    ns["accepted_events"].clear()
    ns["found_events"].clear()
    ns["queued_events"].clear()
    ns["current_seq"] = 1
    ns["min_submit_height"] = 100
    ns["urgent_candidate"] = None
    for key in ns["stats"]:
        ns["stats"][key] = 0.0 if key == "accepted_work_hashes" else 0
    job = candidate("cap-1")
    ns["contexts"][1] = {
        "seq": 1,
        "template_id": job["template_id"],
        "target_hex": job["difficulty_target_hex"],
        "hashes_per_share": ns["hashes_per_share_from_target_hex"](
            job["difficulty_target_hex"]
        ),
        "pow_fields_hex": job["pow_fields_hex"],
        "height": job["height"],
        "created": time.monotonic(),
    }
    return job


def run_one_share(ns, item):
    worker = threading.Thread(target=ns["submitter"], args=(0,))
    worker.start()
    ns["share_queue"].put(item)
    ns["share_queue"].join()
    ns["running"] = False
    worker.join(timeout=2.0)
    assert not worker.is_alive(), "submitter did not stop"


def test_compatible_recovery(ns):
    job = reset(ns)
    submits = iter(
        [
            {
                "error": {
                    "code": -32010,
                    "message": "stale job: template superseded",
                    "data": {"action": "refetch-now", "reason": "superseded"},
                }
            },
            {"result": "share accepted"},
        ]
    )
    fetches = iter([(candidate("cap-2"), 0.0), (candidate("cap-3"), 0.0)])
    ns["session_rpc"] = lambda method, params: next(submits)
    ns["fetch_job_once"] = lambda: next(fetches)
    ns["reset_rpc_session"] = lambda: None
    run_one_share(
        ns,
        (1, "cap-1", job["difficulty_target_hex"], job["height"], "00" * 8),
    )
    assert ns["stats"]["accepted"] == 1
    assert ns["stats"]["stale"] == 0
    assert ns["stats"]["stale_responses"] == 1
    assert ns["stats"]["stale_retry_attempts"] == 1
    assert ns["stats"]["stale_recovered"] == 1
    assert 1 not in ns["invalidated_seqs"]
    assert ns["contexts"][1]["template_id"] == "cap-3"


def test_changed_work_is_not_retried(ns):
    job = reset(ns)
    ns["session_rpc"] = lambda method, params: {
        "error": {
            "code": -32010,
            "message": "stale job: template superseded",
            "data": {"action": "refetch-now", "reason": "superseded"},
        }
    }
    changed = candidate("cap-new", height=101, pow_hex="33" * 80)
    ns["fetch_job_once"] = lambda: (changed, 0.0)
    ns["reset_rpc_session"] = lambda: None
    run_one_share(
        ns,
        (1, "cap-1", job["difficulty_target_hex"], job["height"], "00" * 8),
    )
    assert ns["stats"]["accepted"] == 0
    assert ns["stats"]["stale"] == 1
    assert ns["stats"]["stale_retry_attempts"] == 0
    assert 1 in ns["invalidated_seqs"]
    assert ns["urgent_candidate"] == changed


def main():
    ns = load_controller()
    test_compatible_recovery(ns)
    test_changed_work_is_not_retried(ns)
    print("CAPABILITY CONTROLLER SELF-TEST: PASS")


if __name__ == "__main__":
    main()
