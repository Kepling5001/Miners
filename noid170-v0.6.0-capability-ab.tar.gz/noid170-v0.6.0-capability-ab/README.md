# NOID170 v0.6.0 capability-recovery A/B

This experiment changes only the Python controller. The production v0.5.6
partial-MDS ILP CUDA binaries are included unchanged.

The candidate treats `template_id` as a single-use submission capability that
is separate from GPU work identity. Compatible ID changes are rebound on the
host, successful submissions fetch the next capability, and a `superseded`
stale is retried once with a fresh capability when height, PoW fields, and
target are unchanged. GPUs receive a new job only for a real work change.

## Run the live A/B on OctominerTEST

Use the same wallet/worker key for both halves. Fifteen minutes per variant is
the default; 30 minutes per variant gives a stronger acceptance measurement.

```bash
cd /home/user/noid170-v0.6.0-capability-ab
miner stop

export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
export NOID_AB_SECONDS=900
./test-capability-ab.sh
```

Paste the final comparison and final candidate `STATUS` line into chat, then
restart the configured HiveOS miner with `miner start`.

The package also includes an offline controller state-machine check:

```bash
python3 ./selftest_controller.py
```

## Candidate-only HiveOS package

`noid170-0.6.0-capab.tar.gz` is the installable custom-miner archive. It is for
the test rig until the live A/B proves that recovered stales improve actual
accepted/found yield. Rollback is the existing v0.5.6 install URL.

New candidate counters in `/run/noid170/stats.json`:

- `stale_responses`: raw stale RPC responses, including recovered ones
- `stale_retry_attempts`: compatible nonces retried once
- `stale_recovered`: retries accepted by the pool
- `stale`: terminal, unrecovered stale shares used by HiveOS acceptance
- `capability_rebinds`: host-only ID changes with no GPU switch
- `capability_refresh_failures`: timed-out replacement-capability fetches
