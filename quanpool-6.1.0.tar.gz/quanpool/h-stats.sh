#!/usr/bin/env bash
# Quanpool exposes native Hive JSON at /hive-stats. Hive sources this file;
# it MUST define $khs (total kH/s) and $stats (JSON object/string).

khs=0
stats="null"
PORT=9900
RAW=""

# Fetch quickly; the agent calls this repeatedly.
if command -v curl >/dev/null 2>&1; then
  RAW=$(curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/hive-stats" 2>/dev/null || true)
elif command -v wget >/dev/null 2>&1; then
  RAW=$(timeout 2 wget -qO- "http://127.0.0.1:${PORT}/hive-stats" 2>/dev/null || true)
fi

if [[ -n "$RAW" ]] && command -v jq >/dev/null 2>&1 && \
   jq -e 'type == "object"' >/dev/null 2>&1 <<<"$RAW"; then
  stats=$(jq -c '.' <<<"$RAW")

  sum=$(jq '[.hs[]? | numbers] | add // 0' <<<"$RAW" 2>/dev/null || echo 0)
  unit=$(jq -r '.hs_units // "khs"' <<<"$RAW" 2>/dev/null | tr '[:upper:]' '[:lower:]')

  case "$unit" in
    hs|h/s)    khs=$(awk -v x="$sum" 'BEGIN { printf "%.6f", x/1000 }') ;;
    khs|kh/s)  khs="$sum" ;;
    mhs|mh/s)  khs=$(awk -v x="$sum" 'BEGIN { printf "%.6f", x*1000 }') ;;
    ghs|gh/s)  khs=$(awk -v x="$sum" 'BEGIN { printf "%.6f", x*1000000 }') ;;
    ths|th/s)  khs=$(awk -v x="$sum" 'BEGIN { printf "%.6f", x*1000000000 }') ;;
    *)         khs="$sum" ;;
  esac
fi
