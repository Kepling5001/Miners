#!/usr/bin/env bash
# Quanpool 6.1.0 -> HiveOS Custom Miner configuration adapter.
# Hive sources this on every start with CUSTOM_* flight-sheet values in scope.

DIR="/hive/miners/custom/quanpool"
[[ -r "$DIR/h-manifest.conf" ]] && . "$DIR/h-manifest.conf"

# Also works when invoked by h-run.sh directly.
if [[ -z "${CUSTOM_TEMPLATE:-}" && -r /hive-config/wallet.conf ]]; then
  . /hive-config/wallet.conf
fi

TOKEN="${CUSTOM_TEMPLATE:-}"
NODE="${CUSTOM_URL:-mainnet.quanpool.com:9834}"
EXTRA="${CUSTOM_USER_CONFIG:-}"

# Quanpool expects host:port, not a stratum/http URL.
NODE="${NODE#*://}"
NODE="${NODE%%/*}"

if [[ -z "$TOKEN" ]]; then
  echo "Quanpool: wallet/worker template is empty" >&2
  return 2 2>/dev/null || exit 2
fi

TLS_MAINNET="87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6"
args=(serve --auth-token "$TOKEN" --node-addr "$NODE")

# Supply Quanpool mainnet's pinned certificate unless the user overrides it.
case " $EXTRA " in
  *" --tls-cert-sha256 "*|*" --tls-cert-sha256="*|*" --tls-cert-sha256-file "*|*" --tls-cert-sha256-file="*) ;;
  *)
    case "$NODE" in
      mainnet.quanpool.com:9834|37.187.143.115:9834)
        args+=(--tls-cert-sha256 "$TLS_MAINNET")
        ;;
    esac
    ;;
esac

# GPU rigs should not waste CPU power unless explicitly requested.
case " $EXTRA " in
  *" --cpu-workers "*|*" --cpu-workers="*) ;;
  *) args+=(--cpu-workers 0) ;;
esac

# Keep the native Quanpool Hive endpoint on the expected port unless overridden.
case " $EXTRA " in
  *" --metrics-port "*|*" --metrics-port="*) ;;
  *) args+=(--metrics-port 9900) ;;
esac

# Forward Hive's Extra config arguments.
if [[ -n "$EXTRA" ]]; then
  extra_args=()
  eval "extra_args=( $EXTRA )"
  args+=("${extra_args[@]}")
fi

mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
{
  printf 'CLI_ARGS=(' 
  printf ' %q' "${args[@]}"
  printf ' )\n'
} > "$CUSTOM_CONFIG_FILENAME"
