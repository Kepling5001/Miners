Quanpool 6.1.0 - HiveOS Custom Miner wrapper
=============================================

This package does not redistribute the Quanpool executable. On first launch it
fetches the official Linux x86_64 binary from:
https://download.quanpool.com/quanpool-miner-6.1.0-linux-x86_64

HiveOS Custom Miner fields:
  Miner name:                 quanpool
  Installation URL:          URL hosting quanpool-6.1.0.tar.gz
  Hash algorithm:            may be left blank (Quantus/QPoW)
  Wallet and worker template:%WAL%.%WORKER_NAME%
  Pool URL:                  mainnet.quanpool.com:9834
  Pass:                      blank
  Extra config arguments:    blank initially

Defaults added by wrapper:
  --cpu-workers 0
  --metrics-port 9900
  --tls-cert-sha256 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6

Stats source:
  http://127.0.0.1:9900/hive-stats

The wrapper executes quanpool-miner directly in the foreground so Hive's miner
screen supervises the actual miner process rather than a logging pipeline.
