#!/usr/bin/env bash
# Quanpool 6.1.0 HiveOS launcher.
# IMPORTANT: Hive SOURCES h-run.sh from its miner-run subshell, so the final
# exec below intentionally replaces that subshell with quanpool-miner. This
# keeps the miner attached to Hive's miner screen and avoids a tee/pipeline
# becoming the process Hive supervises.

DIR="/hive/miners/custom/quanpool"
BIN="$DIR/quanpool-miner"
OFFICIAL_URL="https://download.quanpool.com/quanpool-miner-6.1.0-linux-x86_64"

cd "$DIR" || exit 2
. "$DIR/h-manifest.conf"

# Regenerate from the ACTIVE flight sheet every launch. Hive normally already
# ran h-config.sh, but doing it here makes the package deterministic even if a
# stale/missing quanpool.conf exists.
if [[ -r /hive-config/wallet.conf ]]; then
  . /hive-config/wallet.conf
fi
. "$DIR/h-config.sh" || exit 2

declare -a CLI_ARGS=()
. "$CUSTOM_CONFIG_FILENAME" || exit 2
if (( ${#CLI_ARGS[@]} == 0 )); then
  echo "Quanpool: generated command line is empty" >&2
  exit 2
fi

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"

verify_binary() {
  local f="$1" v
  [[ -s "$f" ]] || return 1
  chmod 0755 "$f" 2>/dev/null || return 1
  if command -v file >/dev/null 2>&1; then
    file "$f" 2>/dev/null | grep -q 'ELF 64-bit' || return 1
  fi
  v=$("$f" --version 2>&1 || true)
  grep -qE '(^|[^0-9])6\.1\.0([^0-9]|$)' <<<"$v"
}

install_existing_610() {
  local src
  for src in \
    "$DIR/quanpool-miner-6.1.0-linux-x86_64" \
    "/home/user/quanpool-miner-6.1.0-linux-x86_64" \
    "/home/user/quanpool-miner-6.1.0"; do
    [[ -s "$src" ]] || continue
    cp -f "$src" "$BIN" || continue
    chmod 0755 "$BIN"
    if verify_binary "$BIN"; then
      echo "Quanpool: using existing 6.1.0 binary from $src"
      return 0
    fi
    rm -f "$BIN"
  done
  return 1
}

download_610() {
  local tmp="$BIN.download.$$"
  rm -f "$tmp"
  echo "Quanpool: downloading official 6.1.0 binary"

  if command -v wget >/dev/null 2>&1 && \
     wget -q --timeout=30 --tries=2 -O "$tmp" "$OFFICIAL_URL"; then
    :
  elif command -v python3 >/dev/null 2>&1 && \
       python3 - "$OFFICIAL_URL" "$tmp" <<'PY'
import shutil, ssl, sys, urllib.request
url, dst = sys.argv[1], sys.argv[2]
ctx = ssl.create_default_context()
with urllib.request.urlopen(url, timeout=45, context=ctx) as r, open(dst, 'wb') as f:
    shutil.copyfileobj(r, f)
PY
  then
    :
  elif command -v curl >/dev/null 2>&1 && \
       curl -fsSL --tlsv1.2 --connect-timeout 20 --max-time 120 --retry 2 \
         "$OFFICIAL_URL" -o "$tmp"; then
    :
  else
    rm -f "$tmp"
    echo "Quanpool: failed to download $OFFICIAL_URL" >&2
    return 1
  fi

  if ! verify_binary "$tmp"; then
    echo "Quanpool: downloaded file failed ELF/version verification" >&2
    rm -f "$tmp"
    return 1
  fi

  mv -f "$tmp" "$BIN"
  chmod 0755 "$BIN"
  echo "Quanpool: official 6.1.0 binary installed"
  return 0
}

# Never silently keep using a 6.0.0 binary after this wrapper is installed.
if ! verify_binary "$BIN"; then
  rm -f "$BIN"
  install_existing_610 || download_610 || exit 2
fi

# Hive may leave compatibility preload variables behind for other miners.
# Quanpool is self-contained and should bind the system NVIDIA driver itself.
unset LD_PRELOAD
export HOME=/home/user
export CUDA_DEVICE_ORDER=PCI_BUS_ID

# Foreground execution is deliberate: Hive's miner-run supervises this process
# and its screen receives Quanpool's native stdout/stderr directly.
exec "$BIN" "${CLI_ARGS[@]}" "$@"
