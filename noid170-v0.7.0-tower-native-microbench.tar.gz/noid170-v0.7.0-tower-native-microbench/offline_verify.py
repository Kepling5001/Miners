#!/usr/bin/env python3
"""Independent CPU proof for the tower construction shipped in this package."""

from __future__ import annotations

import pathlib
import random
import re


ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / "src"
MASK128 = (1 << 128) - 1


def parse_rows(path: pathlib.Path, symbol: str) -> list[int]:
    body = path.read_text().split(symbol, 1)[1].split("};", 1)[0]
    out = [
        int(lo, 16) | (int(hi, 16) << 64)
        for lo, hi in re.findall(
            r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", body
        )
    ]
    assert len(out) == 128, (symbol, len(out))
    return out


def linear(value: int, rows: list[int]) -> int:
    return sum(((value & row).bit_count() & 1) << bit for bit, row in enumerate(rows))


def flat_mul(a: int, b: int) -> int:
    out = 0
    for _ in range(128):
        out ^= a * (b & 1)
        b >>= 1
        carry = a >> 127
        a = (a << 1) & MASK128
        a ^= 0x87 * carry
    return out


def aes_mul(a: int, b: int) -> int:
    out = 0
    for _ in range(8):
        out ^= a * (b & 1)
        b >>= 1
        carry = a >> 7
        a = ((a << 1) & 0xff) ^ (0x1b * carry)
    return out


def mul_beta(value: int, width: int) -> int:
    if width == 8:
        return aes_mul(value, 0x20)
    half = width // 2
    mask = (1 << half) - 1
    a0, a1 = value & mask, value >> half
    t0, t1 = mul_beta(a0, half), mul_beta(a1, half)
    return mul_beta(t1, half) | ((t0 ^ t1) << half)


def tower_mul(a: int, b: int, width: int = 128) -> int:
    if width == 8:
        return aes_mul(a, b)
    half = width // 2
    mask = (1 << half) - 1
    a0, a1 = a & mask, a >> half
    b0, b1 = b & mask, b >> half
    p0 = tower_mul(a0, b0, half)
    p1 = tower_mul(a1, b1, half)
    pm = tower_mul(a0 ^ a1, b0 ^ b1, half)
    return (p0 ^ mul_beta(p1, half)) | ((pm ^ p0) << half)


def parse_section(name: str, end_name: str) -> list[int]:
    text = (SRC / "noid_cuda_tables.h").read_text()
    body = text.split(name, 1)[1].split(end_name, 1)[0]
    return [
        int(lo, 16) | (int(hi, 16) << 64)
        for lo, hi in re.findall(
            r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", body
        )
    ]


def main() -> None:
    t2f = parse_rows(SRC / "noid_runtime_params.h", "NOID_T2F_ROWS[128]")
    f2t = parse_rows(SRC / "noid_f2t_rows.h", "NOID_F2T_ROWS[128]")
    for bit in range(128):
        x = 1 << bit
        assert linear(linear(x, t2f), f2t) == x
    print("OFFLINE_BASIS_PASS vectors=128")

    rng = random.Random(0x1701700635)
    for vector in range(2048):
        a, b = rng.getrandbits(128), rng.getrandbits(128)
        expected = linear(flat_mul(linear(a, t2f), linear(b, t2f)), f2t)
        actual = tower_mul(a, b)
        assert actual == expected, f"tower multiply mismatch at {vector}"
    print("OFFLINE_MULTIPLY_PASS vectors=2048")

    betas = {}
    for width in (16, 32, 64, 128):
        x = 1 << (width // 2)
        x2 = linear(flat_mul(linear(x, t2f), linear(x, t2f)), f2t)
        betas[width] = (x2 ^ x) & ((1 << width) - 1)
    assert betas == {
        16: 0x20,
        32: 0x2000,
        64: 0x20000000,
        128: 0x2000000000000000,
    }
    print("OFFLINE_EXTENSION_PASS " + " ".join(
        f"beta{width}=0x{value:x}" for width, value in betas.items()))

    full = parse_section("NOID_MDS_FULL", "NOID_MDS_PARTIAL")
    partial = parse_section("NOID_MDS_PARTIAL", "NOID_PREFIX")
    full_tower = [linear(x, f2t) for x in full]
    partial_tower = [linear(x, f2t) for x in partial]
    assert full_tower == [5, 7, 1, 3, 4, 6, 1, 1, 1, 3, 5, 7, 1, 1, 4, 6]
    assert partial_tower == [
        0x20, 1, 1, 1,
        1, 0x2000, 1, 1,
        1, 1, 0x200, 1,
        1, 1, 1, 0x800,
    ]
    print("OFFLINE_MDS_CONSTANTS_PASS full=16 partial=16")
    print("OFFLINE_VERIFY_PASS")


if __name__ == "__main__":
    main()
