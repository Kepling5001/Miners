#include <cuda_runtime.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <vector>

struct U128 { unsigned long long lo, hi; };

#include "src/noid_cuda_tables.h"
#include "src/noid_runtime_params.h"
#include "src/noid_f2t_rows.h"
#include "src/noid_cuda_math.cuh"
#include "src/tower_constants.h"
#include "src/tower_native.cuh"

#define CUDA_OK(call) do {                                                   \
    cudaError_t _e = (call);                                                 \
    if (_e != cudaSuccess) {                                                 \
        std::fprintf(stderr, "CUDA error %s:%d: %s\n", __FILE__, __LINE__,  \
                     cudaGetErrorString(_e));                                \
        std::exit(1);                                                        \
    }                                                                        \
} while (0)

__device__ __forceinline__ int basis_parity(U128 x, U128 mask)
{
    return ((__popcll(x.lo & mask.lo) ^ __popcll(x.hi & mask.hi)) & 1);
}

__device__ __forceinline__ U128 basis_tower_to_flat(U128 tower)
{
    U128 out{0ULL, 0ULL};
    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (basis_parity(tower, NOID_T2F_ROWS[bit])) {
            if (bit < 64) out.lo |= 1ULL << bit;
            else out.hi |= 1ULL << (bit - 64);
        }
    }
    return out;
}

__device__ __forceinline__ U128 basis_flat_to_tower(U128 flat)
{
    U128 out{0ULL, 0ULL};
    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (basis_parity(flat, NOID_F2T_ROWS[bit])) {
            if (bit < 64) out.lo |= 1ULL << bit;
            else out.hi |= 1ULL << (bit - 64);
        }
    }
    return out;
}

struct PrimitiveOut {
    U128 mul_ref, mul_tower;
    U128 square_ref, square_tower;
    U128 x7_ref, x7_tower;
};

struct PermutationOut {
    U128 flat_ref[4];
    U128 tower_native[4];
};

__global__ void primitive_oracle_kernel(
    const U128 *a, const U128 *b, PrimitiveOut *out, int n)
{
    const int i = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    if (i >= n) return;
    const U128 af = basis_tower_to_flat(a[i]);
    const U128 bf = basis_tower_to_flat(b[i]);
    PrimitiveOut o;
    o.mul_ref = basis_flat_to_tower(gf_mul(af, bf));
    o.mul_tower = tw_mul128(a[i], b[i]);
    o.square_ref = basis_flat_to_tower(square_flat(af));
    o.square_tower = tw_square128(a[i]);
    o.x7_ref = basis_flat_to_tower(sbox_x7(af));
    o.x7_tower = tw_x7(a[i]);
    out[i] = o;
}

__global__ void permutation_oracle_kernel(
    const U128 *tower_states, PermutationOut *out, int n)
{
    const int i = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    if (i >= n) return;
    U128 flat[4], tower[4];
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane) {
        tower[lane] = tower_states[(size_t)i * 4 + lane];
        flat[lane] = basis_tower_to_flat(tower[lane]);
    }
    poseidon_permute(flat);
    tower_poseidon_permute(tower);
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane) {
        out[i].flat_ref[lane] = basis_flat_to_tower(flat[lane]);
        out[i].tower_native[lane] = tower[lane];
    }
}

__global__ void convert_states_kernel(const U128 *tower, U128 *flat, int n)
{
    const int i = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    if (i >= n * 4) return;
    flat[i] = basis_tower_to_flat(tower[i]);
}

__global__ void flat_bench_kernel(U128 *states, int n, int inner)
{
    const int i = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    if (i >= n) return;
    U128 s[4];
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane)
        s[lane] = states[(size_t)i * 4 + lane];
    for (int k = 0; k < inner; ++k)
        poseidon_permute(s);
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane)
        states[(size_t)i * 4 + lane] = s[lane];
}

__global__ void tower_bench_kernel(U128 *states, int n, int inner)
{
    const int i = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    if (i >= n) return;
    U128 s[4];
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane)
        s[lane] = states[(size_t)i * 4 + lane];
    for (int k = 0; k < inner; ++k)
        tower_poseidon_permute(s);
    #pragma unroll
    for (int lane = 0; lane < 4; ++lane)
        states[(size_t)i * 4 + lane] = s[lane];
}

static unsigned long long next64(unsigned long long &x)
{
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    return x;
}

static bool equal(U128 a, U128 b)
{
    return a.lo == b.lo && a.hi == b.hi;
}

static float median(std::vector<float> values)
{
    std::sort(values.begin(), values.end());
    const size_t n = values.size();
    return n & 1 ? values[n / 2] : 0.5f * (values[n / 2 - 1] + values[n / 2]);
}

static float time_kernel(bool tower, U128 *states, int n, int inner)
{
    cudaEvent_t start, stop;
    CUDA_OK(cudaEventCreate(&start));
    CUDA_OK(cudaEventCreate(&stop));
    CUDA_OK(cudaEventRecord(start));
    if (tower)
        tower_bench_kernel<<<(n + 255) / 256, 256>>>(states, n, inner);
    else
        flat_bench_kernel<<<(n + 255) / 256, 256>>>(states, n, inner);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaEventRecord(stop));
    CUDA_OK(cudaEventSynchronize(stop));
    float ms = 0.0f;
    CUDA_OK(cudaEventElapsedTime(&ms, start, stop));
    CUDA_OK(cudaEventDestroy(start));
    CUDA_OK(cudaEventDestroy(stop));
    return ms;
}

static void print_attributes(const char *name, const void *kernel)
{
    cudaFuncAttributes a{};
    CUDA_OK(cudaFuncGetAttributes(&a, kernel));
    int active_blocks = 0;
    CUDA_OK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
        &active_blocks, kernel, 256, 0));
    std::printf(
        "KERNEL_RESOURCE name=%s regs=%d local_bytes=%zu static_shared=%zu "
        "active_blocks_per_sm=%d occupancy_threads_pct=%.1f\n",
        name, a.numRegs, a.localSizeBytes, a.sharedSizeBytes, active_blocks,
        100.0 * active_blocks * 256.0 / 2048.0);
}

int main(int argc, char **argv)
{
    int states = 16384;
    int inner = 1;
    int samples = 5;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--states") && i + 1 < argc) states = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--inner") && i + 1 < argc) inner = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--samples") && i + 1 < argc) samples = std::atoi(argv[++i]);
        else {
            std::fprintf(stderr, "usage: %s [--states N] [--inner N] [--samples N]\n", argv[0]);
            return 2;
        }
    }
    if (states < 1024 || inner < 1 || samples < 3) {
        std::fprintf(stderr, "states>=1024, inner>=1, and samples>=3 required\n");
        return 2;
    }

    cudaDeviceProp prop{};
    CUDA_OK(cudaGetDeviceProperties(&prop, 0));
    std::printf("DEVICE name=%s sm=%d.%d sms=%d clock_khz=%d\n",
                prop.name, prop.major, prop.minor, prop.multiProcessorCount,
                prop.clockRate);
    if (prop.major != 8 || prop.minor != 0) {
        std::fprintf(stderr, "WARNING: benchmark was designed for sm_80 / CMP 170HX\n");
    }

    constexpr int oracle_n = 8192;
    unsigned long long seed = 0x6a09e667f3bcc909ULL;
    std::vector<U128> h_a(oracle_n), h_b(oracle_n);
    for (int i = 0; i < oracle_n; ++i) {
        h_a[i] = U128{next64(seed), next64(seed)};
        h_b[i] = U128{next64(seed), next64(seed)};
    }
    U128 *d_a = nullptr, *d_b = nullptr;
    PrimitiveOut *d_primitive = nullptr;
    std::vector<PrimitiveOut> h_primitive(oracle_n);
    CUDA_OK(cudaMalloc(&d_a, h_a.size() * sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_b, h_b.size() * sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_primitive, h_primitive.size() * sizeof(PrimitiveOut)));
    CUDA_OK(cudaMemcpy(d_a, h_a.data(), h_a.size() * sizeof(U128), cudaMemcpyHostToDevice));
    CUDA_OK(cudaMemcpy(d_b, h_b.data(), h_b.size() * sizeof(U128), cudaMemcpyHostToDevice));
    primitive_oracle_kernel<<<(oracle_n + 255) / 256, 256>>>(d_a, d_b, d_primitive, oracle_n);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(h_primitive.data(), d_primitive,
                       h_primitive.size() * sizeof(PrimitiveOut), cudaMemcpyDeviceToHost));
    for (int i = 0; i < oracle_n; ++i) {
        const PrimitiveOut &o = h_primitive[i];
        if (!equal(o.mul_ref, o.mul_tower) ||
            !equal(o.square_ref, o.square_tower) ||
            !equal(o.x7_ref, o.x7_tower)) {
            std::fprintf(stderr,
                "PRIMITIVE_ORACLE_FAIL vector=%d mul=%d square=%d x7=%d\n", i,
                (int)equal(o.mul_ref, o.mul_tower),
                (int)equal(o.square_ref, o.square_tower),
                (int)equal(o.x7_ref, o.x7_tower));
            return 1;
        }
    }
    std::printf("PRIMITIVE_ORACLE_PASS vectors=%d checks=%d\n", oracle_n, oracle_n * 3);

    std::vector<U128> h_oracle_states((size_t)oracle_n * 4);
    for (U128 &x : h_oracle_states) x = U128{next64(seed), next64(seed)};
    U128 *d_oracle_states = nullptr;
    PermutationOut *d_perm = nullptr;
    std::vector<PermutationOut> h_perm(oracle_n);
    CUDA_OK(cudaMalloc(&d_oracle_states, h_oracle_states.size() * sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_perm, h_perm.size() * sizeof(PermutationOut)));
    CUDA_OK(cudaMemcpy(d_oracle_states, h_oracle_states.data(),
                       h_oracle_states.size() * sizeof(U128), cudaMemcpyHostToDevice));
    permutation_oracle_kernel<<<(oracle_n + 255) / 256, 256>>>(
        d_oracle_states, d_perm, oracle_n);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(h_perm.data(), d_perm,
                       h_perm.size() * sizeof(PermutationOut), cudaMemcpyDeviceToHost));
    for (int i = 0; i < oracle_n; ++i) {
        for (int lane = 0; lane < 4; ++lane) {
            if (!equal(h_perm[i].flat_ref[lane], h_perm[i].tower_native[lane])) {
                std::fprintf(stderr, "PERMUTATION_ORACLE_FAIL vector=%d lane=%d\n", i, lane);
                return 1;
            }
        }
    }
    std::printf("PERMUTATION_ORACLE_PASS vectors=%d lane_checks=%d\n",
                oracle_n, oracle_n * 4);

    std::vector<U128> h_states((size_t)states * 4);
    for (U128 &x : h_states) x = U128{next64(seed), next64(seed)};
    U128 *d_tower = nullptr, *d_flat = nullptr;
    CUDA_OK(cudaMalloc(&d_tower, h_states.size() * sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_flat, h_states.size() * sizeof(U128)));
    CUDA_OK(cudaMemcpy(d_tower, h_states.data(), h_states.size() * sizeof(U128),
                       cudaMemcpyHostToDevice));
    convert_states_kernel<<<((states * 4) + 255) / 256, 256>>>(d_tower, d_flat, states);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    print_attributes("flat_v0.6.35", (const void *)flat_bench_kernel);
    print_attributes("tower_native", (const void *)tower_bench_kernel);

    // Equal untimed warmup, followed by balanced AB/BA timing order.
    (void)time_kernel(false, d_flat, states, inner);
    (void)time_kernel(true, d_tower, states, inner);
    std::vector<float> flat_ms, tower_ms;
    for (int sample = 0; sample < samples; ++sample) {
        float f, t;
        if ((sample & 1) == 0) {
            f = time_kernel(false, d_flat, states, inner);
            t = time_kernel(true, d_tower, states, inner);
        } else {
            t = time_kernel(true, d_tower, states, inner);
            f = time_kernel(false, d_flat, states, inner);
        }
        flat_ms.push_back(f);
        tower_ms.push_back(t);
        std::printf("SAMPLE n=%d order=%s flat_ms=%.3f tower_ms=%.3f ratio=%.5f\n",
                    sample + 1, (sample & 1) ? "BA" : "AB", f, t, f / t);
    }
    const float fmed = median(flat_ms);
    const float tmed = median(tower_ms);
    const double permutations = (double)states * inner;
    const double flat_mpps = permutations / ((double)fmed * 1000.0);
    const double tower_mpps = permutations / ((double)tmed * 1000.0);
    const double speedup = (double)fmed / tmed;
    std::printf(
        "RESULT states=%d inner=%d samples=%d flat_median_ms=%.3f "
        "tower_median_ms=%.3f flat_Mperm_s=%.3f tower_Mperm_s=%.3f "
        "tower_speedup=%.5f\n",
        states, inner, samples, fmed, tmed, flat_mpps, tower_mpps, speedup);

    cudaFuncAttributes tower_attr{};
    CUDA_OK(cudaFuncGetAttributes(&tower_attr, (const void *)tower_bench_kernel));
    const bool performance_pass = speedup >= 1.05;
    const bool resource_pass = tower_attr.numRegs <= 64 && tower_attr.localSizeBytes == 0;
    std::printf("DECISION %s performance_gate=%s resource_gate=%s "
                "required_speedup=1.05 max_regs=64 no_local_memory=1\n",
                performance_pass && resource_pass ? "GO" : "NO_GO",
                performance_pass ? "PASS" : "FAIL",
                resource_pass ? "PASS" : "FAIL");

    CUDA_OK(cudaFree(d_a));
    CUDA_OK(cudaFree(d_b));
    CUDA_OK(cudaFree(d_primitive));
    CUDA_OK(cudaFree(d_oracle_states));
    CUDA_OK(cudaFree(d_perm));
    CUDA_OK(cudaFree(d_tower));
    CUDA_OK(cudaFree(d_flat));
    return 0;
}
