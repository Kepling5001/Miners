#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BUILD"

check_source() {
  local expected="$1"
  local path="$2"
  local actual
  actual="$(sha256sum "$path" | awk '{print $1}')"
  [[ "$actual" == "$expected" ]] || {
    echo "ERROR: baseline source hash mismatch: $path"
    echo "expected=$expected actual=$actual"
    exit 1
  }
}

check_source ac6912803b922af0e4b8fc0f65d676852c7dc041c96b990edd1ed119336dfc62 \
  "$ROOT/src/noid_cuda_math.cuh"
check_source 82fe89d8c7c962fc50a122a6d1d9353a6d5d195f2ed3b803be6393d1610502d3 \
  "$ROOT/src/noid_cuda_tables.h"

echo "===== OFFLINE FIELD GATES ====="
python3 "$ROOT/generate_tower_constants.py"
python3 "$ROOT/offline_verify.py"

echo
echo "===== BUILD EXACT v0.6.35 FLAT VS FULLY TOWER-NATIVE MICROBENCH ====="
"$NVCC" \
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$ROOT/src" \
  -DNOID_MDS_FACTORIZED=1 \
  -DNOID_SQUARE_CLMAD=1 \
  -DNOID_CLMAD_ACCUM=1 \
  -DNOID_SBOX_FUSE_VARIANT=0 \
  -DNOID_REDUCE_VARIANT=41 \
  -DNOID_PARTIAL_ILP=2 \
  -DNOID_SQUARE_REDUCE_VARIANT=3 \
  -DNOID_SQUARE_FOLD_LOP3=1 \
  -DNOID_CLMAD_PAIR_OUTPUTS=1 \
  -DNOID_CLMAD_PAIR_REDUCE=1 \
  -DNOID_CLMAD_NONVOLATILE=1 \
  -Xptxas=-v \
  "$ROOT/tower_native_bench.cu" \
  -o "$BUILD/tower_native_bench" \
  2>&1 | tee "$BUILD/build.log"

chmod 755 "$BUILD/tower_native_bench"
sha256sum "$BUILD/tower_native_bench"

echo
echo "===== KERNEL RESOURCE SUMMARY ====="
grep -A4 -E "Compiling entry function.*(flat_bench_kernel|tower_bench_kernel)" \
  "$BUILD/build.log" || true

echo
echo "BUILD_PASS"
echo "Next: ./run-microbench.sh"
echo "Nothing was installed or changed under /hive/miners/custom."
