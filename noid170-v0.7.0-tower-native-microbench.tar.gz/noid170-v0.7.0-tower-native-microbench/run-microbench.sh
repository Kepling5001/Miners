#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/build/tower_native_bench"
GPU="${NOID_TEST_GPU:-0}"
STATES="${NOID_BENCH_STATES:-16384}"
INNER="${NOID_BENCH_INNER:-1}"
SAMPLES="${NOID_BENCH_SAMPLES:-5}"

[[ -x "$BIN" ]] || {
  echo "ERROR: benchmark is not built; run ./build-on-rig.sh first"
  exit 1
}

if pgrep -f '/hive/miners/custom/noid170/.+noid_live_job|noid_live_job_daemon_ns --daemon' \
    >/dev/null 2>&1; then
  echo "ERROR: a noid170 GPU daemon is still running. Stop the miner before benchmarking."
  exit 1
fi

echo "===== FULLY TOWER-NATIVE POSEIDON2b MICROBENCH ====="
echo "GPU=$GPU states=$STATES inner=$INNER samples=$SAMPLES"
echo "This is isolated: it does not install or replace the HiveOS miner."

CUDA_VISIBLE_DEVICES="$GPU" "$BIN" \
  --states "$STATES" --inner "$INNER" --samples "$SAMPLES" \
  | tee "$ROOT/build/result.log"

echo
echo "Paste build/build.log and build/result.log back into the chat."
