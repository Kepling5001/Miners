# noid170 v0.7.0 fully tower-native Poseidon2b microbenchmark

This is an isolated feasibility test for the largest untried arithmetic
change in the CMP 170HX miner. It does **not** install, replace, or modify the
working HiveOS miner.

## What is different

The current v0.6.35 kernel converts canonical/tower inputs to the flat/GCM
basis and keeps all three Poseidon2b permutations there because GA100
`clmad` makes flat GF(2^128) multiplication fast.

This candidate keeps the complete Poseidon2b state in the protocol's AES
tower basis:

- native recursive tower multiplication and squaring
- native tower `x^7`
- tower round constants (`0..7`)
- byte-parallel full MDS multipliers (`2` and `4`)
- byte-parallel partial MDS diagonal multipliers
- no basis conversion inside the timed permutation

The extension relations are derived from the exact v0.6.35 basis tables. The
four recovered constants are `0x20`, `0x2000`, `0x20000000`, and
`0x2000000000000000`; no field definition is guessed.

## Gates

Before timing, the executable checks 8,192 randomized inputs for:

1. tower multiplication against flat GF(2^128) plus exact basis conversion
2. tower squaring and `x^7` against the current implementation
3. the complete 66-round, four-lane permutation against v0.6.35

Timing uses equal warmups and balanced AB/BA sample ordering. `GO` requires:

- at least `1.05x` full-permutation speed versus v0.6.35
- no local-memory allocation/spills reported for the tower kernel
- at most 64 registers per thread

This first implementation is deliberately direct and auditable. A `NO_GO`
rules out this recursive AES-leaf realization; it does not prove that every
possible bitsliced or multi-state tower implementation is slow.

## Run on the 170HX test rig

Stop the miner first, then:

```bash
tar -xzf noid170-v0.7.0-tower-native-microbench.tar.gz
cd noid170-v0.7.0-tower-native-microbench
chmod +x build-on-rig.sh run-microbench.sh generate_tower_constants.py offline_verify.py
./build-on-rig.sh
./run-microbench.sh
```

Defaults use visible GPU 0, 16,384 states, one permutation per state, and five
balanced samples. Overrides are optional:

```bash
NOID_TEST_GPU=0 NOID_BENCH_STATES=32768 NOID_BENCH_INNER=2 \
  NOID_BENCH_SAMPLES=7 ./run-microbench.sh
```

Return both `build/build.log` and `build/result.log`. Do not install this code
as a flight sheet miner even if it passes; a separate live-miner A/B package
would be the next step.
