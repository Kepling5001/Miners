#pragma once

/*
 * Correctness-first, fully tower-resident GF(2^128) implementation.
 *
 * The representation is the protocol's 16-byte AES tower.  Each quadratic
 * extension is K[X]/(X^2 + X + beta), so X^2 = X + beta.  The exact beta
 * values are derived from the v0.6.35 basis tables, not assumed.
 */

__device__ __forceinline__ unsigned char tw_xtime8(unsigned char x)
{
    const unsigned carry = (unsigned)x >> 7;
    return (unsigned char)(((unsigned)x << 1) ^ (0x1bU & (0U - carry)));
}

__device__ __forceinline__ unsigned char tw_mul8(unsigned char a, unsigned char b)
{
    unsigned r = 0;
    unsigned x = a;
    unsigned y = b;
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
        r ^= x & (0U - (y & 1U));
        const unsigned carry = x >> 7;
        x = ((x << 1) & 0xffU) ^ (0x1bU & (0U - carry));
        y >>= 1;
    }
    return (unsigned char)r;
}

__device__ __forceinline__ unsigned char tw_square8(unsigned char x)
{
    unsigned z = x;
    z = (z | (z << 4)) & 0x0f0fU;
    z = (z | (z << 2)) & 0x3333U;
    z = (z | (z << 1)) & 0x5555U;
    #pragma unroll
    for (int bit = 14; bit >= 8; --bit) {
        const unsigned mask = 0U - ((z >> bit) & 1U);
        z ^= (0x11bU << (bit - 8)) & mask;
    }
    return (unsigned char)z;
}

__device__ __forceinline__ unsigned char tw_mul_beta8(unsigned char x)
{
    // beta_8 = 0x20 in AES GF(2^8).
    #pragma unroll
    for (int i = 0; i < 5; ++i)
        x = tw_xtime8(x);
    return x;
}

__device__ __forceinline__ unsigned short tw_mul_beta16(unsigned short x)
{
    const unsigned char a0 = (unsigned char)x;
    const unsigned char a1 = (unsigned char)(x >> 8);
    const unsigned char t0 = tw_mul_beta8(a0);
    const unsigned char t1 = tw_mul_beta8(a1);
    const unsigned char lo = tw_mul_beta8(t1);
    const unsigned char hi = t0 ^ t1;
    return (unsigned short)lo | ((unsigned short)hi << 8);
}

__device__ __forceinline__ unsigned tw_mul_beta32(unsigned x)
{
    const unsigned short a0 = (unsigned short)x;
    const unsigned short a1 = (unsigned short)(x >> 16);
    const unsigned short t0 = tw_mul_beta16(a0);
    const unsigned short t1 = tw_mul_beta16(a1);
    const unsigned short lo = tw_mul_beta16(t1);
    const unsigned short hi = t0 ^ t1;
    return (unsigned)lo | ((unsigned)hi << 16);
}

__device__ __forceinline__ unsigned long long tw_mul_beta64(unsigned long long x)
{
    const unsigned a0 = (unsigned)x;
    const unsigned a1 = (unsigned)(x >> 32);
    const unsigned t0 = tw_mul_beta32(a0);
    const unsigned t1 = tw_mul_beta32(a1);
    const unsigned lo = tw_mul_beta32(t1);
    const unsigned hi = t0 ^ t1;
    return (unsigned long long)lo | ((unsigned long long)hi << 32);
}

__device__ __forceinline__ unsigned short tw_mul16(unsigned short a, unsigned short b)
{
    const unsigned char a0 = (unsigned char)a;
    const unsigned char a1 = (unsigned char)(a >> 8);
    const unsigned char b0 = (unsigned char)b;
    const unsigned char b1 = (unsigned char)(b >> 8);
    const unsigned char p0 = tw_mul8(a0, b0);
    const unsigned char p1 = tw_mul8(a1, b1);
    const unsigned char pm = tw_mul8(a0 ^ a1, b0 ^ b1);
    const unsigned char lo = p0 ^ tw_mul_beta8(p1);
    const unsigned char hi = pm ^ p0;
    return (unsigned short)lo | ((unsigned short)hi << 8);
}

__device__ __forceinline__ unsigned tw_mul32(unsigned a, unsigned b)
{
    const unsigned short a0 = (unsigned short)a;
    const unsigned short a1 = (unsigned short)(a >> 16);
    const unsigned short b0 = (unsigned short)b;
    const unsigned short b1 = (unsigned short)(b >> 16);
    const unsigned short p0 = tw_mul16(a0, b0);
    const unsigned short p1 = tw_mul16(a1, b1);
    const unsigned short pm = tw_mul16(a0 ^ a1, b0 ^ b1);
    const unsigned short lo = p0 ^ tw_mul_beta16(p1);
    const unsigned short hi = pm ^ p0;
    return (unsigned)lo | ((unsigned)hi << 16);
}

__device__ __forceinline__ unsigned long long tw_mul64(
    unsigned long long a, unsigned long long b)
{
    const unsigned a0 = (unsigned)a;
    const unsigned a1 = (unsigned)(a >> 32);
    const unsigned b0 = (unsigned)b;
    const unsigned b1 = (unsigned)(b >> 32);
    const unsigned p0 = tw_mul32(a0, b0);
    const unsigned p1 = tw_mul32(a1, b1);
    const unsigned pm = tw_mul32(a0 ^ a1, b0 ^ b1);
    const unsigned lo = p0 ^ tw_mul_beta32(p1);
    const unsigned hi = pm ^ p0;
    return (unsigned long long)lo | ((unsigned long long)hi << 32);
}

__device__ __forceinline__ U128 tw_mul128(U128 a, U128 b)
{
    const unsigned long long p0 = tw_mul64(a.lo, b.lo);
    const unsigned long long p1 = tw_mul64(a.hi, b.hi);
    const unsigned long long pm = tw_mul64(a.lo ^ a.hi, b.lo ^ b.hi);
    return U128{p0 ^ tw_mul_beta64(p1), pm ^ p0};
}

__device__ __forceinline__ unsigned short tw_square16(unsigned short a)
{
    const unsigned char q0 = tw_square8((unsigned char)a);
    const unsigned char q1 = tw_square8((unsigned char)(a >> 8));
    return (unsigned short)(q0 ^ tw_mul_beta8(q1)) |
           ((unsigned short)q1 << 8);
}

__device__ __forceinline__ unsigned tw_square32(unsigned a)
{
    const unsigned short q0 = tw_square16((unsigned short)a);
    const unsigned short q1 = tw_square16((unsigned short)(a >> 16));
    return (unsigned)(q0 ^ tw_mul_beta16(q1)) | ((unsigned)q1 << 16);
}

__device__ __forceinline__ unsigned long long tw_square64(unsigned long long a)
{
    const unsigned q0 = tw_square32((unsigned)a);
    const unsigned q1 = tw_square32((unsigned)(a >> 32));
    return (unsigned long long)(q0 ^ tw_mul_beta32(q1)) |
           ((unsigned long long)q1 << 32);
}

__device__ __forceinline__ U128 tw_square128(U128 a)
{
    const unsigned long long q0 = tw_square64(a.lo);
    const unsigned long long q1 = tw_square64(a.hi);
    return U128{q0 ^ tw_mul_beta64(q1), q1};
}

__device__ __forceinline__ U128 tw_x7(U128 x)
{
    const U128 x2 = tw_square128(x);
    const U128 x4 = tw_square128(x2);
    const U128 x6 = tw_mul128(x, x2);
    return tw_mul128(x6, x4);
}

// Byte-parallel fixed multipliers for the sparse Poseidon2b matrices.
__device__ __forceinline__ unsigned long long tw_xtime_bytes(unsigned long long x)
{
    const unsigned long long high = x & 0x8080808080808080ULL;
    return ((x & 0x7f7f7f7f7f7f7f7fULL) << 1) ^ ((high >> 7) * 0x1bULL);
}

__device__ __forceinline__ unsigned long long tw_mul20_bytes(unsigned long long x)
{
    #pragma unroll
    for (int i = 0; i < 5; ++i)
        x = tw_xtime_bytes(x);
    return x;
}

__device__ __forceinline__ U128 tw_mul_byte02(U128 x)
{
    return U128{tw_xtime_bytes(x.lo), tw_xtime_bytes(x.hi)};
}

__device__ __forceinline__ U128 tw_mul_byte04(U128 x)
{
    return tw_mul_byte02(tw_mul_byte02(x));
}

template <int Which>
__device__ __forceinline__ unsigned long long tw_mul_diag_word(unsigned long long x)
{
    const unsigned long long lanes = 0x00ff00ff00ff00ffULL;
    const unsigned long long a0 = x & lanes;
    const unsigned long long a1 = (x >> 8) & lanes;
    if constexpr (Which == 0)
        return x ^ tw_mul20_bytes(x); // 0x0021

    unsigned long long z2;
    unsigned long long high;
    if constexpr (Which == 1) {
        z2 = tw_mul20_bytes(a1);      // 0x2001
        high = tw_mul20_bytes(a0) ^ a1 ^ z2;
    } else if constexpr (Which == 2) {
        z2 = tw_xtime_bytes(a1);      // 0x0201
        high = tw_xtime_bytes(a0) ^ a1 ^ z2;
    } else {
        z2 = tw_xtime_bytes(tw_xtime_bytes(tw_xtime_bytes(a1))); // 0x0801
        unsigned long long a0x8 =
            tw_xtime_bytes(tw_xtime_bytes(tw_xtime_bytes(a0)));
        high = a0x8 ^ a1 ^ z2;
    }
    const unsigned long long low = a0 ^ tw_mul20_bytes(z2);
    return low ^ (high << 8);
}

template <int Which>
__device__ __forceinline__ U128 tw_mul_diag(U128 x)
{
    return U128{tw_mul_diag_word<Which>(x.lo), tw_mul_diag_word<Which>(x.hi)};
}

__device__ __forceinline__ void tw_mds_full(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(tw_mul_byte02(b), t1);
    const U128 t3 = bxor(tw_mul_byte02(d), t0);
    const U128 t4 = bxor(tw_mul_byte04(t1), t3);
    const U128 t5 = bxor(tw_mul_byte04(t0), t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

__device__ __forceinline__ void tw_mds_partial(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));
    s[0] = bxor(sum, tw_mul_diag<0>(a));
    s[1] = bxor(sum, tw_mul_diag<1>(b));
    s[2] = bxor(sum, tw_mul_diag<2>(c));
    s[3] = bxor(sum, tw_mul_diag<3>(d));
}

__device__ __forceinline__ void tower_poseidon_permute(U128 s[4])
{
    tw_mds_full(s);
    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full = !(r >= NOID_F_ROUNDS / 2 &&
                            r < NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);
        if (full) {
            #pragma unroll
            for (int lane = 0; lane < 4; ++lane) {
                s[lane].lo ^= (unsigned long long)TW_RC[lane][r];
                s[lane] = tw_x7(s[lane]);
            }
            tw_mds_full(s);
        } else {
            s[0].lo ^= (unsigned long long)TW_RC[0][r];
            s[0] = tw_x7(s[0]);
            tw_mds_partial(s);
        }
    }
}
