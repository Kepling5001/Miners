#!/usr/bin/env python3
"""Derive tower round constants and extension constants from v0.6.35 tables."""

from __future__ import annotations

import pathlib
import re


ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / "src"


def parse_rows(path: pathlib.Path, symbol: str) -> list[int]:
    text = path.read_text()
    body = text.split(symbol, 1)[1].split("};", 1)[0]
    values = [
        int(lo, 16) | (int(hi, 16) << 64)
        for lo, hi in re.findall(
            r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", body
        )
    ]
    if len(values) != 128:
        raise RuntimeError(f"{symbol}: expected 128 rows, found {len(values)}")
    return values


def linear_map(value: int, rows: list[int]) -> int:
    out = 0
    for bit, row in enumerate(rows):
        out |= ((value & row).bit_count() & 1) << bit
    return out


def gf128_mul(a: int, b: int) -> int:
    mask = (1 << 128) - 1
    out = 0
    for _ in range(128):
        if b & 1:
            out ^= a
        b >>= 1
        carry = a >> 127
        a = (a << 1) & mask
        if carry:
            a ^= 0x87
    return out


def parse_round_constants() -> list[int]:
    text = (SRC / "noid_cuda_tables.h").read_text()
    body = text.split("NOID_RC[NOID_STATE_SIZE][NOID_N_ROUNDS]", 1)[1]
    body = body.split("__device__ __constant__ U128 NOID_MDS_FULL", 1)[0]
    values = [
        int(lo, 16) | (int(hi, 16) << 64)
        for lo, hi in re.findall(
            r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", body
        )
    ]
    if len(values) != 4 * 66:
        raise RuntimeError(f"NOID_RC: expected 264 values, found {len(values)}")
    return values


def main() -> None:
    t2f = parse_rows(SRC / "noid_runtime_params.h", "NOID_T2F_ROWS[128]")
    f2t = parse_rows(SRC / "noid_f2t_rows.h", "NOID_F2T_ROWS[128]")

    # Prove that the supplied transforms are inverses on every basis vector.
    for bit in range(128):
        x = 1 << bit
        if linear_map(linear_map(x, t2f), f2t) != x:
            raise RuntimeError(f"basis roundtrip failed at bit {bit}")

    betas: dict[int, int] = {}
    for width in (16, 32, 64, 128):
        generator = 1 << (width // 2)
        flat = linear_map(generator, t2f)
        squared = linear_map(gf128_mul(flat, flat), f2t)
        squared &= (1 << width) - 1
        beta = squared ^ generator
        if beta >= 1 << (width // 2):
            raise RuntimeError(f"width {width}: beta escaped lower subfield")
        betas[width] = beta

    expected = {
        16: 0x20,
        32: 0x2000,
        64: 0x20000000,
        128: 0x2000000000000000,
    }
    if betas != expected:
        raise RuntimeError(f"unexpected extension constants: {betas!r}")

    tower_rc = [linear_map(x, f2t) for x in parse_round_constants()]
    if any(x > 7 for x in tower_rc):
        raise RuntimeError("Poseidon round constant did not reduce to tower byte 0..7")

    lines = [
        "#pragma once",
        "// Generated from the exact v0.6.35 basis and Poseidon tables.",
        "// Do not edit by hand; run generate_tower_constants.py.",
        "static constexpr unsigned TW_BETA16 = 0x00000020U;",
        "static constexpr unsigned TW_BETA32 = 0x00002000U;",
        "static constexpr unsigned long long TW_BETA64 = 0x0000000020000000ULL;",
        "static constexpr unsigned long long TW_BETA128 = 0x2000000000000000ULL;",
        "__device__ __constant__ unsigned char TW_RC[4][66] = {",
    ]
    for lane in range(4):
        row = tower_rc[lane * 66 : (lane + 1) * 66]
        lines.append("    {" + ",".join(str(x) for x in row) + "},")
    lines.extend(["};", ""])
    out = ROOT / "src" / "tower_constants.h"
    rendered = "\n".join(lines)
    out.write_text(rendered)
    print("BASIS_ROUNDTRIP_PASS vectors=128")
    for width, beta in betas.items():
        digits = width // 4
        print(f"TOWER_RELATION width={width} beta=0x{beta:0{digits}x}")
    print(f"ROUND_CONSTANT_CONVERSION_PASS values={len(tower_rc)} max={max(tower_rc)}")
    print(f"WROTE {out}")


if __name__ == "__main__":
    main()
