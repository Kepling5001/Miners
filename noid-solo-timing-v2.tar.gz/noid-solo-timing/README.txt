NOID Aria vs Local Template Timing Test v2
==========================================

This is a read-only timing test. It leaves HiveOS mining, the Parano1d node,
and PeakPool running. It does not request a template from the local node; it
observes the node container's existing "template proved" log events.

Run from the Parano1d node host:

  cd /hive/peakpool/deployments/parano1d
  tar -xzf /path/to/noid-solo-timing-v1.tar.gz
  cd noid-solo-timing
  export NOID_MINING_KEY='your_NOID_address.timing'
  ./run-timing.sh

Defaults:

  50 matched heights (usually about 15-25 minutes)
  60-minute safety timeout
  results under /run/noid-solo-timing

For a shorter preliminary run:

  ./run-timing.sh --matches 20

Ctrl+C is safe and prints/saves partial results once at least a few matching
heights have been observed.
