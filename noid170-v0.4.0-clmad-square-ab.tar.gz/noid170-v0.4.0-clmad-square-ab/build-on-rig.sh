#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -Xptxas=-v
)

echo "===== BUILD CURRENT SPREAD-BIT SQUARING ====="
"$NVCC" "${COMMON[@]}" \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_spread"

echo
echo "===== BUILD EXPERIMENTAL CLMAD SQUARING ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_SQUARE_CLMAD=1 \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_clmad"

echo
echo "===== BUILD GPU CORRECTNESS ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_square_clmad.cu" \
  -o "$BIN/test_square_clmad"

chmod +x \
  "$BIN/noid_live_job_daemon_spread" \
  "$BIN/noid_live_job_daemon_clmad" \
  "$BIN/test_square_clmad"

python3 -m py_compile \
  "$ROOT/benchmark_square.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-square.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh \
  "$BIN/noid_live_job_daemon_spread" \
  "$BIN/noid_live_job_daemon_clmad" \
  "$BIN/test_square_clmad"
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-square.sh"
