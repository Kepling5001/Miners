# NOID170 v0.4.0 CLMAD squaring A/B experiment

This is a rig-side correctness and performance experiment. It is **not** a
HiveOS release package.

Both benchmark binaries use the proven v0.3.0 factorized MDS kernel. The only
production-kernel difference is the GF(2^128) squaring implementation:

- `spread`: current shift/mask bit expansion
- `clmad`: carry-less self-multiplication of the two 64-bit limbs

All launch geometry, pipeline behavior, compiler optimization flags, Poseidon
rounds, MDS functions, and target handling are otherwise identical.

## Copy to the test rig

Place the archive in `/home/user`, then run:

```bash
cd /home/user
tar -xzf noid170-v0.4.0-clmad-square-ab.tar.gz
cd noid170-v0.4.0-clmad-square-ab
chmod +x build-on-rig.sh test-square.sh test-persistent.sh
```

## Build

```bash
./build-on-rig.sh
```

The build prints ptxas register and spill information for both mining kernels.
Keep that output when sending the results back.

## Test

Use the same mining address/worker format used by the existing NOID miner:

```bash
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-square.sh
```

The test sequence is:

1. Offline mathematical equivalence over 10,006 vectors.
2. GPU oracle over 1,024 independent states, comparing individual squarings,
   x^7 S-boxes, full Poseidon permutations, and a three-permutation chain.
3. GPU0 A/B benchmark using one live template and a hard target.
4. Persistent CUDA protocol test using the experimental CLMAD binary.

Do not deploy the experimental binary unless all oracles and the persistent
protocol test report `PASS`. Paste the complete build and test output back for
review even if CLMAD loses the benchmark.

## Expected benchmark format

```text
===== CLMAD SQUARING A/B BENCHMARK | GPU0 =====
height: ...
spread#1   kernel=... MH/s  wall=... MH/s
clmad#1    kernel=... MH/s  wall=... MH/s
clmad#2    kernel=... MH/s  wall=... MH/s
spread#2   kernel=... MH/s  wall=... MH/s
spread avg kernel=... MH/s  wall=... MH/s
clmad avg  kernel=... MH/s  wall=... MH/s
kernel gain: ...%
wall gain:   ...%
```
