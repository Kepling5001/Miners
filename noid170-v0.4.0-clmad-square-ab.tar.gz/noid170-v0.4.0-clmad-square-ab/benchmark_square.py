#!/usr/bin/env python3

import http.client
import json
import os
import queue
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
SPREAD = os.path.join(ROOT, "bin", "noid_live_job_daemon_spread")
CLMAD = os.path.join(ROOT, "bin", "noid_live_job_daemon_clmad")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get(
    "NOID_RPC_URL",
    "https://pool.ariabrain.com/noid-rpc/",
)

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u = urlsplit(URL)
Conn = (
    http.client.HTTPSConnection
    if u.scheme == "https"
    else http.client.HTTPConnection
)
path = u.path or "/"


def rpc(method, params):
    c = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        })
        c.request(
            "POST",
            path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-square-bench/0.4.0",
            },
        )
        response = c.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(
                f"HTTP {response.status}: {data.decode(errors='replace')}"
            )
        return json.loads(data)
    finally:
        c.close()


def get_job(timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def run_one(label, binary, job):
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [binary, "--daemon", "7001"],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )
    events = queue.Queue()

    def reader():
        for line in proc.stderr:
            events.put(line.strip())

    threading.Thread(target=reader, daemon=True).start()

    def wait_for(prefix, timeout=10):
        end = time.time() + timeout
        while time.time() < end:
            try:
                line = events.get(timeout=0.5)
            except queue.Empty:
                continue
            if line.startswith(prefix):
                return line
        raise RuntimeError(f"{label}: timeout waiting for {prefix}")

    wait_for("READY ")
    hard_target = (
        "01000000000000000000000000000000"
        "00000000000000000000000000000000"
    )
    proc.stdin.write(
        f"JOB 1 {job['pow_fields_hex']} {hard_target}\n"
    )
    proc.stdin.flush()
    wait_for("JOBACK 1 ")

    samples = []
    while len(samples) < 9:
        line = wait_for("STAT ", timeout=8)
        fields = line.split()
        samples.append((float(fields[1]), float(fields[5])))

    proc.stdin.write("STOP\n")
    proc.stdin.flush()
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.terminate()
        proc.wait(timeout=3)

    # Discard the first two reports to remove launch/clock warmup effects.
    used = samples[2:]
    kernel = sum(x for x, _ in used) / len(used)
    wall = sum(y for _, y in used) / len(used)
    print(
        f"{label:10s} kernel={kernel:.3f} MH/s  "
        f"wall={wall:.3f} MH/s"
    )
    return kernel, wall


job = get_job()
print("===== CLMAD SQUARING A/B BENCHMARK | GPU0 =====")
print("height:", job["height"])
spread_1 = run_one("spread#1", SPREAD, job)
clmad_1 = run_one("clmad#1", CLMAD, job)
clmad_2 = run_one("clmad#2", CLMAD, job)
spread_2 = run_one("spread#2", SPREAD, job)

spread_kernel = (spread_1[0] + spread_2[0]) / 2
spread_wall = (spread_1[1] + spread_2[1]) / 2
clmad_kernel = (clmad_1[0] + clmad_2[0]) / 2
clmad_wall = (clmad_1[1] + clmad_2[1]) / 2

print(
    f"{'spread avg':10s} kernel={spread_kernel:.3f} MH/s  "
    f"wall={spread_wall:.3f} MH/s"
)
print(
    f"{'clmad avg':10s} kernel={clmad_kernel:.3f} MH/s  "
    f"wall={clmad_wall:.3f} MH/s"
)
print(f"kernel gain: {(clmad_kernel / spread_kernel - 1) * 100:+.2f}%")
print(f"wall gain:   {(clmad_wall / spread_wall - 1) * 100:+.2f}%")
