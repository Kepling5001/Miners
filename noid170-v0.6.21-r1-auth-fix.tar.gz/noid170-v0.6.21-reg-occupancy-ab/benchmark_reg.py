#!/usr/bin/env python3
import json, os, queue, re, statistics, subprocess, threading, time, urllib.request
ROOT=os.path.dirname(os.path.abspath(__file__)); BIN=os.path.join(ROOT,'bin')
VARIANTS=['baseline','mr48','mr44','mr42','mr40','mr38','lb3']
SAMPLES=int(os.environ.get('NOID_BENCH_STATS','10'))
RPC=os.environ.get('NOID_RPC_URL','https://pool.ariabrain.com/noid-rpc/')
KEY=os.environ.get('NOID_MINING_KEY','').strip()
if not KEY: raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
def rpc(method,params):
 d=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode()
 req=urllib.request.Request(RPC,d,{
  'Content-Type':'application/json',
  'Authorization':f'Bearer {KEY}',
  'User-Agent':'noid170-reg-occupancy-bench/0.6.21-r1',
  'Accept':'*/*',
 })
 return json.load(urllib.request.urlopen(req,timeout=20))
def get_job():
 end=time.time()+30
 while time.time()<end:
  a=rpc('paranoid_getBlockTemplate',[''])
  if not a.get('error'): return a['result']
  e=a.get('error') or {}
  if isinstance(e,dict) and e.get('code')==-32011:
   time.sleep(max(.05,e.get('data',{}).get('retry_in_ms',500)/1000)); continue
  raise RuntimeError(e)
 raise RuntimeError('template timeout')
def ptxas_info(name):
 try: text=open(os.path.join(BIN,f'build_{name}.log'),encoding='utf-8',errors='replace').read()
 except OSError: return None,None,None
 m=re.search(r"Compiling entry function '_Z11mine_kernel.*?Function properties for _Z11mine_kernel.*?(\d+) bytes spill stores, (\d+) bytes spill loads.*?Used (\d+) registers",text,re.S)
 if not m: return None,None,None
 return int(m.group(3)),int(m.group(1)),int(m.group(2))
def occ_info(name):
 out=subprocess.check_output([os.path.join(BIN,f'noid_daemon_{name}'),'--occupancy'],env={**os.environ,'CUDA_VISIBLE_DEVICES':'0'},text=True,stderr=subprocess.STDOUT)
 vals=dict(re.findall(r'(\w+)=([^ ]+)',out.strip()))
 return int(vals['regs']),int(vals['blocks_per_sm']),int(vals['active_warps']),float(vals['thread_occ'])
def run_once(name,job,n):
 env=os.environ.copy(); env['CUDA_VISIBLE_DEVICES']='0'
 p=subprocess.Popen([os.path.join(BIN,f'noid_daemon_{name}'),'--daemon',str(0x6900+n)],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
 q=queue.Queue()
 def reader():
  for line in p.stderr: q.put(line.strip())
 threading.Thread(target=reader,daemon=True).start()
 def wait(prefix,timeout=15):
  end=time.time()+timeout
  while time.time()<end:
   if p.poll() is not None: raise RuntimeError(f'{name}: exited {p.returncode}')
   try: line=q.get(timeout=.5)
   except queue.Empty: continue
   if line.startswith(prefix): return line
  raise RuntimeError(f'{name}: timeout waiting for {prefix}')
 try:
  wait('READY '); hard='01'+'00'*31
  p.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard}\n"); p.stdin.flush(); wait('JOBACK 1 ')
  vals=[]
  while len(vals)<SAMPLES:
   f=wait('STAT ').split(); vals.append((float(f[1]),float(f[5])))
  used=vals[3:]
  k=statistics.mean(x[0] for x in used); w=statistics.mean(x[1] for x in used)
  print(f'{name:9s} run{n:02d} kernel={k:8.3f} wall={w:8.3f} MH/s')
  return k,w
 finally:
  if p.poll() is None:
   try: p.stdin.write('STOP\n'); p.stdin.flush(); p.wait(timeout=4)
   except Exception: p.terminate(); p.wait(timeout=4)
job=get_job(); print('===== REGISTER/OCCUPANCY A/B BENCHMARK | GPU0 ====='); print(f"height: {job['height']} samples/run: {SAMPLES} balanced forward/reverse")
meas={n:[] for n in VARIANTS}; order=VARIANTS+list(reversed(VARIANTS))
for i,n in enumerate(order,1): meas[n].append(run_once(n,job,i))
results=[]
for n in VARIANTS:
 k=statistics.mean(x[0] for x in meas[n]); w=statistics.mean(x[1] for x in meas[n]); preg,ss,sl=ptxas_info(n); areg,bpsm,warps,occ=occ_info(n)
 results.append(dict(name=n,kernel=k,wall=w,preg=preg,areg=areg,ss=ss,sl=sl,bpsm=bpsm,warps=warps,occ=occ))
base=next(x for x in results if x['name']=='baseline'); ranked=sorted(results,key=lambda x:x['wall'],reverse=True)
print('\n===== FINAL REGISTER/OCCUPANCY RANKING =====')
print(f"{'rank':>4}  {'variant':9} {'attrR':>5} {'ptxR':>4} {'blk/SM':>6} {'warps':>5} {'spill S/L':>10} {'kernel':>10} {'wall':>10} {'vs base':>9}")
for i,r in enumerate(ranked,1):
 gain=(r['wall']/base['wall']-1)*100; spills='?/?' if r['ss'] is None else f"{r['ss']}/{r['sl']}"; pr='?' if r['preg'] is None else str(r['preg'])
 print(f"{i:4d}  {r['name']:9s} {r['areg']:5d} {pr:>4s} {r['bpsm']:6d} {r['warps']:5d} {spills:>10s} {r['kernel']:10.3f} {r['wall']:10.3f} {gain:+8.2f}%")
w=ranked[0]; open(os.path.join(ROOT,'winner.txt'),'w').write(w['name']+'\n')
print(f"\nbaseline: baseline wall={base['wall']:.3f} MH/s")
print(f"winner:   {w['name']} wall={w['wall']:.3f} MH/s")
print(f"gain:     {(w['wall']/base['wall']-1)*100:+.2f}%")
print(f"persistent accepted-share test: {w['name']}")
