NOID170 v0.6.34 production — HiveOS custom miner

Backends
========

https:// / http://
  Aria HTTP backend.

  The existing production Aria wrapper, warmup worker and CUDA daemon are
  preserved unchanged from the v0.6.33 production package.

stratum+ssl://
  InnovLab parano1d-stratum-v1 over verified system WebPKI TLS.

  v0.6.34 uses the namespace-aware share4/red2/512 prodshape CUDA path.

  The prodshape optimization removes the redundant canonical nonce
  representation from the hot Poseidon hashing path. The flat nonce remains
  live during hashing and canonical nonce construction is deferred to the rare
  share-found path.

  Protocol math, namespace mapping, submitted nonce representation and pool
  protocol remain unchanged.

Measured CMP170HX A/B
=====================

Production clocks:

  baseline:
    kernel_avg = 157.774 MH/s
    wall_avg   = 157.603 MH/s

  v0.6.34 prodshape:
    kernel_avg = 160.584 MH/s
    wall_avg   = 160.407 MH/s

  gain:
    +2.810 MH/s
    +1.78%

The namespace LUT, block-map, precompute and nonce round-trip GPU correctness
gates passed before the winning binary was benchmarked.

InnovLab Flight Sheet
=====================

Miner:
  Custom

Pool URL:
  stratum+ssl://us.innovlab.cc:19601

Wallet template:
  NOID wallet address

The wallet/template is sent exactly as entered. A .worker suffix may also be
used if desired.

Password:
  x is supplied automatically by the miner.

Extra config:
  Leave blank for normal operation.

Optional:
  NOID_CARD_MH=160.9
  NOID_SUBMIT_THREADS=1
  NOID_GPU_COUNT=<count>
  NOID_SHARE_QUEUE_SIZE=5000

Aria Flight Sheet
=================

Pool URL:
  https://pool.ariabrain.com/noid-rpc/

Wallet template:
  ADDRESS.UNIQUEWORKER

Continue using a unique worker suffix per rig on Aria.

Important
=========

The InnovLab daemon is compiled specifically for NVIDIA sm_80 / CMP170HX.

No dev fee is implemented by NOID170.
