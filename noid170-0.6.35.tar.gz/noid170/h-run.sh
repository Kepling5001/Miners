#!/usr/bin/env bash
set -o pipefail

MINER_DIR="${MINER_DIR:-/hive/miners/custom/noid170}"
CONF="${CUSTOM_CONFIG_FILENAME:-$MINER_DIR/noid170.conf}"
LOG_BASE="${CUSTOM_LOG_BASENAME:-/var/log/miner/noid170/noid170}"
LOG_FILE="${LOG_BASE}.log"

[[ -f "$CONF" ]] || { echo "NOID170: config missing: $CONF"; exit 1; }
# shellcheck disable=SC1090
source "$CONF"

command -v python3 >/dev/null 2>&1 || { echo "NOID170: python3 is required"; exit 1; }
command -v nvidia-smi >/dev/null 2>&1 || { echo "NOID170: nvidia-smi is required"; exit 1; }
[[ -x "$MINER_DIR/noid_live_job_cont" ]] || { echo "NOID170: warmup worker missing"; exit 1; }
[[ -x "$MINER_DIR/noid_live_job_daemon" ]] || { echo "NOID170: production Aria daemon missing"; exit 1; }

GPU_COUNT_DETECTED=$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | awk 'NF{n++} END{print n+0}')
[[ "$GPU_COUNT_DETECTED" -gt 0 ]] || { echo "NOID170: no NVIDIA GPUs detected"; exit 1; }

DRIVER=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -n1)
DRIVER_MAJOR=${DRIVER%%.*}
if [[ "$DRIVER_MAJOR" =~ ^[0-9]+$ ]] && (( DRIVER_MAJOR < 580 )); then
  echo "NOID170: NVIDIA driver $DRIVER is too old for this CUDA 13.x build (need 580+)."
  exit 1
fi

mkdir -p "$(dirname "$LOG_FILE")" /run/noid170
: > "$LOG_FILE"

export NOID_MINING_KEY NOID_RPC_URL NOID_CARD_MH NOID_MAX_TOTAL_SHARES_SEC
export NOID_SUBMIT_THREADS NOID_GPU_COUNT NOID_POLL_INTERVAL NOID_GPU_STAGGER_MS NOID_SHARE_QUEUE_SIZE
export NOID_HARD_EXPIRY_AGE NOID_ACCEPTED_WORK_WINDOW
export NOID_CAPABILITY_REFRESH_TIMEOUT
export NOID_CAPABILITY_MODE="adaptive"
export NOID_STATS_FILE="/run/noid170/stats.json"
export NOID_WARMUP_BIN="$MINER_DIR/noid_live_job_cont"
export NOID_DAEMON_BIN="$MINER_DIR/noid_live_job_daemon"
export NOID_DAEMON_NS_BIN="$MINER_DIR/noid_live_job_daemon_ns"
export NOID_TUI="0"

if [[ -z "${NOID_GPU_COUNT:-}" ]]; then
  unset NOID_GPU_COUNT
fi

echo "NOID170 v0.6.35 share4/red2/512 dual-backend HiveOS wrapper"
echo "GPUs: $GPU_COUNT_DETECTED"
echo "Endpoint: $NOID_RPC_URL"
echo "Driver: $DRIVER"
echo "Aria HTTP backend: exact v0.6.32 production wrapper + exact production daemon"
echo "InnovLab TLS backend: namespace-aware share4 prodshape production"

case "$NOID_RPC_URL" in
  stratum+ssl://*)
    [[ -x "$MINER_DIR/noid_live_job_daemon_ns" ]] || {
      echo "NOID170: namespace-aware Stratum daemon missing: $MINER_DIR/noid_live_job_daemon_ns"
      exit 1
    }
    echo "Backend selected: parano1d-stratum-v1 over verified TLS"
    echo "Nonce layout: 64-bit counter LE || 8-byte session namespace"
    echo "Submit layout: [job_id, nonce, work_domain_id]"
    python3 -u "$MINER_DIR/noid170_stratum.py" 2>&1 | tee -a "$LOG_FILE"
    exit ${PIPESTATUS[0]}
    ;;
  http://*|https://*)
    echo "Backend selected: Aria HTTP/HTTPS adaptive capability-recovery"
    python3 -u "$MINER_DIR/noid170_aria.py" 2>&1 | tee -a "$LOG_FILE"
    exit ${PIPESTATUS[0]}
    ;;
  *)
    echo "NOID170: unsupported endpoint scheme: $NOID_RPC_URL"
    exit 1
    ;;
esac
