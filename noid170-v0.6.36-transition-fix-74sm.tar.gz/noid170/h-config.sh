#!/usr/bin/env bash

MINER_DIR="${MINER_DIR:-/hive/miners/custom/noid170}"
CONF="${CUSTOM_CONFIG_FILENAME:-$MINER_DIR/noid170.conf}"

mining_key="${CUSTOM_TEMPLATE:-}"
rpc_url="${CUSTOM_URL:-https://pool.ariabrain.com/noid-rpc/}"

if [[ -z "$mining_key" ]]; then
  echo "NOID170: Wallet/mining-key template is empty" >&2
  return 1 2>/dev/null || exit 1
fi

card_mh="160.9"
max_sps="50"
submit_threads="1"
gpu_count=""
poll_interval="0.20"
queue_size="5000"
hard_expiry_age="10.5"
accepted_window="120"
capability_refresh_timeout="2.5"

for token in ${CUSTOM_USER_CONFIG:-}; do
  case "$token" in
    NOID_CARD_MH=*) card_mh="${token#*=}" ;;
    NOID_MAX_TOTAL_SHARES_SEC=*) max_sps="${token#*=}" ;;
    NOID_SUBMIT_THREADS=*) submit_threads="${token#*=}" ;;
    NOID_GPU_COUNT=*) gpu_count="${token#*=}" ;;
    NOID_POLL_INTERVAL=*) poll_interval="${token#*=}" ;;
    NOID_SHARE_QUEUE_SIZE=*) queue_size="${token#*=}" ;;
    NOID_HARD_EXPIRY_AGE=*) hard_expiry_age="${token#*=}" ;;
    NOID_ACCEPTED_WORK_WINDOW=*) accepted_window="${token#*=}" ;;
    NOID_CAPABILITY_REFRESH_TIMEOUT=*) capability_refresh_timeout="${token#*=}" ;;
  esac
done

mkdir -p "$(dirname "$CONF")"
{
  printf 'NOID_MINING_KEY=%q\n' "$mining_key"
  printf 'NOID_RPC_URL=%q\n' "$rpc_url"
  printf 'NOID_CARD_MH=%q\n' "$card_mh"
  printf 'NOID_MAX_TOTAL_SHARES_SEC=%q\n' "$max_sps"
  printf 'NOID_SUBMIT_THREADS=%q\n' "$submit_threads"
  printf 'NOID_POLL_INTERVAL=%q\n' "$poll_interval"
  printf 'NOID_SHARE_QUEUE_SIZE=%q\n' "$queue_size"
  printf 'NOID_HARD_EXPIRY_AGE=%q\n' "$hard_expiry_age"
  printf 'NOID_ACCEPTED_WORK_WINDOW=%q\n' "$accepted_window"
  printf 'NOID_CAPABILITY_REFRESH_TIMEOUT=%q\n' "$capability_refresh_timeout"
  if [[ -n "$gpu_count" ]]; then
    printf 'NOID_GPU_COUNT=%q\n' "$gpu_count"
  fi
} > "$CONF"
