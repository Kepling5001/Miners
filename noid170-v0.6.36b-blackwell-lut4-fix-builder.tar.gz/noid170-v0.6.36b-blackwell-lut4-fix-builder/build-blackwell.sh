#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BUILD="$ROOT/build"
NVCC="${NVCC:-/usr/local/cuda-12.8/bin/nvcc}"
mkdir -p "$BUILD"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 12.8 nvcc not found at $NVCC"; exit 1; }

GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader -i "${NOID_TEST_GPU:-0}" 2>/dev/null | head -1 || true)"
echo "===== NOID170 v0.6.35 BLACKWELL BUILD ====="
echo "GPU:  ${GPU_NAME:-unknown}"
echo "NVCC: $NVCC"
"$NVCC" --version | tail -4

echo
echo "===== VERIFY SM_120 COMPILER SUPPORT ====="
"$NVCC" --list-gpu-code | grep -q '^sm_120$' || {
  echo "ERROR: this nvcc does not advertise sm_120"
  exit 1
}
echo "SM_120 COMPILER SUPPORT: PASS"

echo
echo "===== OFFLINE NAMESPACE GATES ====="
python3 "$ROOT/verify_namespace_lut.py"
python3 "$ROOT/verify_namespace_block_map.py"

BASE=(
  -O3 -std=c++17 -arch=sm_120 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_FIRST_MDS_HOIST=0
  -DNOID_FIRST_ROUND_SQUARE_SHARE=3
  -DNOID_FINAL_DIGEST_MODE=2
  -Xptxas=-v
)

build_variant() {
  local name="$1" threads="$2" bpsm="$3"
  echo
  echo "===== COMPILE $name | threads=$threads blocks/sm=$bpsm ====="
  "$NVCC" "${BASE[@]}" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$bpsm" \
    "$SRC/noid_live_job_daemon_ns.cu" \
    -o "$BUILD/noid_daemon_ns_$name" \
    2>&1 | tee "$BUILD/build-$name.log"
  chmod 755 "$BUILD/noid_daemon_ns_$name"
}

# Broad first-pass launch sweep. All six binaries use identical v0.6.35 digest2 math.
build_variant t256_b64   256 64
build_variant t256_b128  256 128
build_variant t512_b64   512 64
build_variant t512_b128  512 128
build_variant t1024_b32  1024 32
build_variant t1024_b64  1024 64

echo
echo "===== COMPILE CORRECTNESS ORACLES ====="
"$NVCC" "${BASE[@]}" "$ROOT/test_digest2.cu" -o "$BUILD/test_digest2"
chmod 755 "$BUILD/test_digest2"

for t in namespace_map namespace_block_map namespace_precompute namespace_roundtrip; do
  case "$t" in
    namespace_map) src="$ROOT/test_namespace_map.cu" ;;
    namespace_block_map) src="$ROOT/test_namespace_block_map.cu" ;;
    namespace_precompute) src="$ROOT/test_namespace_precompute.cu" ;;
    namespace_roundtrip) src="$ROOT/test_namespace_roundtrip.cu" ;;
  esac
  "$NVCC" -O3 -std=c++17 -arch=sm_120 -I"$ROOT" -I"$SRC" "$src" -o "$BUILD/test_$t"
  chmod 755 "$BUILD/test_$t"
done

echo
echo "===== REGISTER SUMMARY ====="
for name in t256_b64 t256_b128 t512_b64 t512_b128 t1024_b32 t1024_b64; do
  printf '%-12s ' "$name"
  grep -A3 "Compiling entry function.*mine_kernel" "$BUILD/build-$name.log" | grep 'Used ' | head -1 || true
done

echo
echo "===== BUILD COMPLETE ====="
echo "No GPU benchmark was run. Your existing miner was not stopped or changed."
echo "Next: stop the existing HiveOS miner, then run ./verify-and-benchmark.sh"
