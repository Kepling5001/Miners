NOID170 v0.6.36b Blackwell LUT4 fix A/B

Fixes two issues in the first v0.6.36 test builder:
1. prepare_job also uses Poseidon under NOID_MDS_LUT4, so it now gets/populates the 32 KiB dynamic shared LUT.
2. Namespace thread-low table has 512 entries; all 1024-thread variants are removed.

A/B variants: clmad_256, clmad_512, lut4_256, lut4_512.
The LUT4 correctness oracle is retained.
