# NOID170 v0.6.35 — RTX 5070 / Blackwell sm_120 launch sweep

Isolated benchmark package. It does not install or replace the HiveOS miner.

Math is the exact v0.6.35 CMP170HX digest2 winner:

- factorized full MDS
- CLMAD square/multiply path
- r4top general reduction
- partial-MDS red2 / ILP2
- square reducer variant 3 + LOP3 fold
- paired non-volatile CLMAD scheduling
- first-round shared-Frobenius mode 3
- prodshape namespace nonce representation
- final digest specialization (`NOID_FINAL_DIGEST_MODE=2`)

The only intended architecture/launch differences are:

- native `-arch=sm_120`
- CUDA 12.8+
- six launch geometries: 256/512/1024 threads with two grid depths each

## Workflow

1. Keep the current miner running and compile:

   `./build-blackwell.sh`

2. Stop the HiveOS miner separately.
3. Run correctness gates and benchmark:

   `NOID_BENCH_SECONDS=20 ./verify-and-benchmark.sh`

The benchmark script refuses to run if SRBMiner or a NOID process is still active.
It uses a zero target and does not connect to a pool or submit shares.
