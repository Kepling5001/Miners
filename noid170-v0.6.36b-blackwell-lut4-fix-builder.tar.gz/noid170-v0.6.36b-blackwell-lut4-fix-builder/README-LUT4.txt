NOID170 v0.6.36 Blackwell LUT4 A/B

Purpose:
- Control: exact v0.6.35 digest2/share4/prodshape arithmetic using CLMAD partial MDS.
- LUT4: replace ONLY the four fixed multiplications in each partial Poseidon round
  with the existing exact 32 KiB nibble lookup table staged into shared memory.
- Full MDS, X^7, first-round share4, namespace/prodshape, and final digest2 remain unchanged.
- Target: RTX 5070 / Blackwell sm_120, CUDA 13.3.

Build:
  NVCC=/usr/local/cuda-13.3/bin/nvcc ./build-blackwell-lut4.sh

Benchmark (only after stopping other GPU miners):
  NOID_BENCH_SECONDS=20 ./verify-and-benchmark-lut4.sh
