#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>

struct U128 { unsigned long long lo, hi; };
#include "src/noid_cuda_tables.h"
#include "src/noid_cuda_math.cuh"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

struct Out {
    U128 ref[4];
    U128 split[4];
    U128 digest[2];
};

__global__ void oracle(const U128 *in, Out *out, int n)
{
    int i=(int)(blockIdx.x*blockDim.x+threadIdx.x);
    if(i>=n) return;
    U128 a[4],b[4],c[4];
    #pragma unroll
    for(int j=0;j<4;++j){ a[j]=in[i*4+j]; b[j]=a[j]; c[j]=a[j]; }
    poseidon_permute(a);
    poseidon_permute_finalsplit_full(b);
    poseidon_permute_digest2(c);
    #pragma unroll
    for(int j=0;j<4;++j){ out[i].ref[j]=a[j]; out[i].split[j]=b[j]; }
    out[i].digest[0]=c[0];
    out[i].digest[1]=c[1];
}

static unsigned long long next64(unsigned long long &x)
{
    x ^= x << 13; x ^= x >> 7; x ^= x << 17; return x;
}

static bool eq(U128 a,U128 b){ return a.lo==b.lo && a.hi==b.hi; }

int main()
{
    constexpr int N=8192;
    std::vector<U128> h_in((size_t)N*4);
    unsigned long long seed=0x9e3779b97f4a7c15ULL;
    for(auto &x:h_in){ x.lo=next64(seed); x.hi=next64(seed); }

    U128 *d_in=nullptr; Out *d_out=nullptr;
    std::vector<Out> h_out(N);
    CUDA_OK(cudaMalloc(&d_in,h_in.size()*sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_out,h_out.size()*sizeof(Out)));
    CUDA_OK(cudaMemcpy(d_in,h_in.data(),h_in.size()*sizeof(U128),cudaMemcpyHostToDevice));
    oracle<<<(N+255)/256,256>>>(d_in,d_out,N);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(h_out.data(),d_out,h_out.size()*sizeof(Out),cudaMemcpyDeviceToHost));

    unsigned long long split_checks=0,digest_checks=0;
    for(int i=0;i<N;++i){
        for(int j=0;j<4;++j){
            if(!eq(h_out[i].ref[j],h_out[i].split[j])){
                fprintf(stderr,"FINALSPLIT_MISMATCH i=%d lane=%d\n",i,j); return 1;
            }
            ++split_checks;
        }
        for(int j=0;j<2;++j){
            if(!eq(h_out[i].ref[j],h_out[i].digest[j])){
                fprintf(stderr,"DIGEST2_MISMATCH i=%d lane=%d\n",i,j); return 1;
            }
            ++digest_checks;
        }
    }
    printf("FINAL_SPLIT_ORACLE_PASS states=%d lane_checks=%llu\n",N,split_checks);
    printf("FINAL_DIGEST2_ORACLE_PASS states=%d digest_lane_checks=%llu\n",N,digest_checks);
    CUDA_OK(cudaFree(d_in)); CUDA_OK(cudaFree(d_out));
    return 0;
}
