#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
GPU="${NOID_TEST_GPU:-0}"
SECONDS_PER_VARIANT="${NOID_BENCH_SECONDS:-20}"
POW_ZERO=$(printf '0%.0s' {1..512})
TARGET_ZERO=$(printf '0%.0s' {1..64})
NS_TEST="19ea010000000200"

variants=(t256_b64 t256_b128 t512_b64 t512_b128 t1024_b32 t1024_b64)

for name in "${variants[@]}"; do
  [[ -x "$BUILD/noid_daemon_ns_$name" ]] || {
    echo "ERROR: missing $BUILD/noid_daemon_ns_$name -- run ./build-blackwell.sh first"
    exit 1
  }
done

# Refuse to benchmark while another compute miner is active. This prevents
# accidentally benchmarking on top of SRBMiner or a restored flight sheet.
if pgrep -af 'srbminer_custom_bin|SRBMiner|noid170_stratum.py|noid_live_job_daemon_ns' >/tmp/noid5070-other-procs.$$ 2>/dev/null; then
  echo "ERROR: another miner/NOID process is still running:"
  cat /tmp/noid5070-other-procs.$$
  rm -f /tmp/noid5070-other-procs.$$
  echo
  echo "Stop the HiveOS miner first, then rerun this script."
  exit 2
fi
rm -f /tmp/noid5070-other-procs.$$

echo "===== GPU BEFORE TEST ====="
nvidia-smi --query-gpu=index,name,power.draw,power.limit,clocks.gr,clocks.sm,clocks.mem,temperature.gpu --format=csv -i "$GPU"

echo
echo "===== BLACKWELL CORRECTNESS GATES ====="
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_digest2"
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_namespace_map"
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_namespace_block_map"
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_namespace_precompute"
CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/test_namespace_roundtrip"

echo
echo "===== JOBNS SMOKE ====="
for name in "${variants[@]}"; do
  LOG="$BUILD/smoke-$name.log"
  {
    printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"
    sleep 0.8
    printf 'STOP\n'
  } | CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/noid_daemon_ns_$name" --daemon 635 >/dev/null 2>"$LOG"
  grep -q '^READY ' "$LOG" || { cat "$LOG"; echo "ERROR: $name no READY"; exit 1; }
  grep -q '^JOBACK 1 ' "$LOG" || { cat "$LOG"; echo "ERROR: $name no JOBACK"; exit 1; }
  printf '%-12s ' "$name"
  grep '^READY ' "$LOG" | head -1
 done

summarize() {
  local log="$1"
  awk '
    $1=="STAT" {
      n++
      if (n>1) {
        ks+=$2; ws+=$6; m++;
        if(m==1||$2<kmin)kmin=$2;
        if(m==1||$2>kmax)kmax=$2;
      }
    }
    END {
      if(m>0) printf("samples=%d kernel_avg=%.3f kernel_min=%.3f kernel_max=%.3f wall_avg=%.3f\n",m,ks/m,kmin,kmax,ws/m);
      else print "samples=0";
    }
  ' "$log"
}

run_one() {
  local name="$1"
  local log="$BUILD/bench-$name.log"
  rm -f "$log"
  echo
  echo "===== BENCH $name (${SECONDS_PER_VARIANT}s, GPU $GPU) ====="
  {
    printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"
    sleep "$SECONDS_PER_VARIANT"
    printf 'STOP\n'
  } | CUDA_VISIBLE_DEVICES="$GPU" "$BUILD/noid_daemon_ns_$name" --daemon 635 >/dev/null 2>"$log"
  tail -12 "$log"
  printf '%s: ' "$name"
  summarize "$log"
}

echo
echo "===== BLACKWELL FORWARD SWEEP ====="
for name in "${variants[@]}"; do run_one "$name"; done

echo
echo "===== FINAL RTX 5070 SM_120 SWEEP ====="
for name in "${variants[@]}"; do
  printf '%-12s ' "$name:"
  summarize "$BUILD/bench-$name.log"
done

echo
echo "===== GPU AFTER TEST ====="
nvidia-smi --query-gpu=index,name,power.draw,power.limit,clocks.gr,clocks.sm,clocks.mem,temperature.gpu --format=csv -i "$GPU"

echo
echo "This is zero-target benchmarking: no pool connection and no share submissions."
echo "Leave the HiveOS flight sheet stopped until you paste the FINAL RTX 5070 SM_120 SWEEP results back."
