#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>

struct U128 { unsigned long long lo, hi; };
#define NOID_MDS_FACTORIZED 1
#define NOID_MDS_LUT4 1
#define NOID_SQUARE_CLMAD 1
#define NOID_CLMAD_ACCUM 1
#define NOID_REDUCE_VARIANT 41
#define NOID_PARTIAL_ILP 2
#define NOID_SQUARE_REDUCE_VARIANT 3
#define NOID_SQUARE_FOLD_LOP3 1
#define NOID_CLMAD_PAIR_OUTPUTS 1
#define NOID_CLMAD_PAIR_REDUCE 1
#define NOID_CLMAD_NONVOLATILE 1
#include "src/noid_cuda_tables.h"
#include "src/noid_mds_lut4.h"
#include "src/noid_cuda_math.cuh"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

struct Out { U128 ref[4]; U128 lut[4]; };

__global__ void lut_oracle(const U128 *in, Out *out, int n)
{
    extern __shared__ U128 sh[];
    const U128 *src = &NOID_MDS_PARTIAL_LUT4[0][0][0];
    for (int k=threadIdx.x; k<NOID_MDS_LUT4_ENTRIES; k+=blockDim.x) sh[k]=src[k];
    __syncthreads();

    int i=(int)(blockIdx.x*blockDim.x+threadIdx.x);
    if(i>=n) return;
    U128 a[4],b[4];
    #pragma unroll
    for(int j=0;j<4;++j){ a[j]=in[i*4+j]; b[j]=a[j]; }
    apply_mds_partial_red2(a);
    apply_mds_partial_lut4(b, sh);
    #pragma unroll
    for(int j=0;j<4;++j){ out[i].ref[j]=a[j]; out[i].lut[j]=b[j]; }
}

static unsigned long long next64(unsigned long long &x)
{ x ^= x << 13; x ^= x >> 7; x ^= x << 17; return x; }
static bool eq(U128 a,U128 b){ return a.lo==b.lo && a.hi==b.hi; }

int main()
{
    constexpr int N=8192;
    constexpr int T=256;
    std::vector<U128> h_in((size_t)N*4);
    std::vector<Out> h_out(N);
    unsigned long long seed=0x5070b1ac6b1acULL;
    for(auto &x:h_in){ x.lo=next64(seed); x.hi=next64(seed); }
    U128 *d_in=nullptr; Out *d_out=nullptr;
    CUDA_OK(cudaMalloc(&d_in,h_in.size()*sizeof(U128)));
    CUDA_OK(cudaMalloc(&d_out,h_out.size()*sizeof(Out)));
    CUDA_OK(cudaMemcpy(d_in,h_in.data(),h_in.size()*sizeof(U128),cudaMemcpyHostToDevice));
    lut_oracle<<<(N+T-1)/T,T,NOID_MDS_LUT4_SHARED_BYTES>>>(d_in,d_out,N);
    CUDA_OK(cudaGetLastError()); CUDA_OK(cudaDeviceSynchronize());
    CUDA_OK(cudaMemcpy(h_out.data(),d_out,h_out.size()*sizeof(Out),cudaMemcpyDeviceToHost));
    unsigned long long checks=0;
    for(int i=0;i<N;++i) for(int j=0;j<4;++j){
        if(!eq(h_out[i].ref[j],h_out[i].lut[j])){
            fprintf(stderr,"LUT4_MISMATCH state=%d lane=%d\n",i,j); return 1;
        }
        ++checks;
    }
    printf("LUT4_PARTIAL_MDS_ORACLE_PASS states=%d lane_checks=%llu shared_bytes=%u\n",
           N,checks,(unsigned)NOID_MDS_LUT4_SHARED_BYTES);
    CUDA_OK(cudaFree(d_in)); CUDA_OK(cudaFree(d_out));
    return 0;
}
