# NOID170 v0.6.7 persistent-kernel CPU feasibility A/B

This non-installing, one-GPU experiment compares the current host-dispatched
two-slot kernel pipeline with a residency-sized persistent kernel.

Both variants use the exact same proven `all_nv`, `r2lop3`, `r4top`, `prod2`,
64-blocks-per-SM mining math. The persistent variant launches only enough
blocks to fill the GPU, advances nonce streams inside the kernel, and checks a
coherent device stop word once per hash. A separate copy-engine stream requests
exit and the harness measures the actual exit latency.

## Run on OctominerTEST

```bash
cd /home/user/noid170-v0.6.7-persistent-cpu-ab
miner stop
./build-on-rig.sh

export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-persistent-cpu.sh

miner start
```

The default paired schedule is baseline, persistent, persistent, baseline at
30 seconds per run, plus short smoke tests. Override with:

```bash
NOID_PERSIST_SAMPLE_SEC=45 ./test-persistent-cpu.sh
```

Paste the complete `FINAL PERSISTENT-KERNEL CPU A/B` table and decision block
into chat. Do not install the benchmark binary as a HiveOS custom miner.

