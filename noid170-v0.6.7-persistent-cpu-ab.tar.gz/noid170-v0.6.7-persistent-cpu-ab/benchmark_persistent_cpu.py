#!/usr/bin/env python3

import http.client
import json
import math
import os
import queue
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin", "noid_persistent_bench")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
SAMPLE = max(15.0, float(os.environ.get("NOID_PERSIST_SAMPLE_SEC", "30")))
CLK_TCK = os.sysconf(os.sysconf_names["SC_CLK_TCK"])

if not KEY:
    raise SystemExit("ERROR: NOID_MINING_KEY is not set")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        conn.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-persistent-cpu-ab/0.6.7",
                "Accept": "*/*",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def process_ticks(pid):
    text = open(f"/proc/{pid}/stat", "r", encoding="utf-8").read()
    rest = text[text.rfind(")") + 2:].split()
    return int(rest[11]) + int(rest[12])


def process_status(pid):
    values = {"threads": 0, "voluntary": 0, "involuntary": 0}
    with open(f"/proc/{pid}/status", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("Threads:"):
                values["threads"] = int(line.split()[1])
            elif line.startswith("voluntary_ctxt_switches:"):
                values["voluntary"] = int(line.split()[1])
            elif line.startswith("nonvoluntary_ctxt_switches:"):
                values["involuntary"] = int(line.split()[1])
    return values


def system_counters():
    result = {}
    with open("/proc/stat", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("cpu "):
                fields = [int(x) for x in line.split()[1:]]
                result["total"] = sum(fields)
                result["idle"] = fields[3] + (fields[4] if len(fields) > 4 else 0)
            elif line.startswith("intr "):
                result["intr"] = int(line.split()[1])
            elif line.startswith("ctxt "):
                result["ctxt"] = int(line.split()[1])
    return result


def parse_result(line):
    values = {}
    for item in line.split()[1:]:
        if "=" in item:
            key, value = item.split("=", 1)
            values[key] = value
    return values


def run_once(variant, seconds, label, display=True):
    job = get_job()
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    proc = subprocess.Popen(
        [BIN, "--bench", variant, str(seconds), str(time.time_ns() & 0x7FFFFFFFFFFFFFFF)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=env,
    )
    events = queue.Queue()

    def read_stdout():
        for raw in proc.stdout:
            line = raw.strip()
            if line.startswith("BENCH_RESULT "):
                events.put(("result", line))

    def read_stderr():
        for raw in proc.stderr:
            line = raw.strip()
            if line.startswith("BENCH_READY "):
                events.put(("ready", line))
            elif line.startswith("PERSISTENT_CONFIG "):
                events.put(("config", line))

    threading.Thread(target=read_stdout, daemon=True).start()
    threading.Thread(target=read_stderr, daemon=True).start()

    proc.stdin.write(
        f"JOB 1 {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"
    )
    proc.stdin.flush()

    config = ""
    deadline = time.monotonic() + 45
    while True:
        if proc.poll() is not None:
            raise RuntimeError(f"{label} exited during setup with {proc.returncode}")
        timeout = deadline - time.monotonic()
        if timeout <= 0:
            raise RuntimeError(f"{label} timed out waiting for BENCH_READY")
        try:
            kind, line = events.get(timeout=min(0.5, timeout))
        except queue.Empty:
            continue
        if kind == "config":
            config = line
        elif kind == "ready":
            break

    p0 = process_ticks(proc.pid)
    status0 = process_status(proc.pid)
    system0 = system_counters()
    t0 = time.monotonic()
    proc.stdin.write("GO\n")
    proc.stdin.flush()

    result_line = None
    deadline = time.monotonic() + seconds + 30
    while result_line is None:
        if proc.poll() is not None:
            raise RuntimeError(f"{label} exited during run with {proc.returncode}")
        timeout = deadline - time.monotonic()
        if timeout <= 0:
            raise RuntimeError(f"{label} timed out waiting for BENCH_RESULT")
        try:
            kind, line = events.get(timeout=min(0.5, timeout))
        except queue.Empty:
            continue
        if kind == "config":
            config = line
        elif kind == "result":
            result_line = line

    t1 = time.monotonic()
    p1 = process_ticks(proc.pid)
    status1 = process_status(proc.pid)
    system1 = system_counters()

    proc.stdin.write("DONE\n")
    proc.stdin.flush()
    proc.wait(timeout=15)
    if proc.returncode != 0:
        raise RuntimeError(f"{label} exited with {proc.returncode}")

    elapsed = max(0.001, t1 - t0)
    total_delta = system1["total"] - system0["total"]
    idle_delta = system1["idle"] - system0["idle"]
    values = parse_result(result_line)
    row = {
        "label": label,
        "variant": variant,
        "kernel": float(values["kernel"]),
        "wall": float(values["wall"]),
        "exit_ms": float(values["exit_ms"]),
        "cpu": (p1 - p0) / CLK_TCK / elapsed * 100.0,
        "busy": 100.0 * (total_delta - idle_delta) / max(1, total_delta),
        "irq_s": (system1["intr"] - system0["intr"]) / elapsed,
        "ctxt_s": (system1["ctxt"] - system0["ctxt"]) / elapsed,
        "proc_ctxt_s": (
            status1["voluntary"] + status1["involuntary"]
            - status0["voluntary"] - status0["involuntary"]
        ) / elapsed,
        "threads": status1["threads"],
        "config": config,
    }
    if display:
        print(
            f"{label:<12} kernel={row['kernel']:.3f} wall={row['wall']:.3f} "
            f"CPU={row['cpu']:.2f}% exit={row['exit_ms']:.3f}ms",
            flush=True,
        )
        if config:
            print(config, flush=True)
    return row


def mean_rows(rows, variant):
    selected = [row for row in rows if row["variant"] == variant]
    return {
        "variant": variant,
        "kernel": statistics.mean(row["kernel"] for row in selected),
        "wall": statistics.mean(row["wall"] for row in selected),
        "cpu": statistics.mean(row["cpu"] for row in selected),
        "busy": statistics.mean(row["busy"] for row in selected),
        "irq_s": statistics.mean(row["irq_s"] for row in selected),
        "ctxt_s": statistics.mean(row["ctxt_s"] for row in selected),
        "proc_ctxt_s": statistics.mean(row["proc_ctxt_s"] for row in selected),
        "threads": round(statistics.mean(row["threads"] for row in selected)),
        "exit_ms": statistics.mean(row["exit_ms"] for row in selected),
    }


print("===== PERSISTENT-KERNEL CPU FEASIBILITY | GPU0 =====")
print(f"paired order: baseline, persistent, persistent, baseline  sample/run: {SAMPLE:.0f}s")
print("kernel math: identical all_nv + r2lop3 + r4top + prod2")

print("short smoke tests...", flush=True)
run_once("baseline", 3.0, "smoke-base", display=False)
smoke = run_once("persistent", 3.0, "smoke-persist", display=False)
if smoke["exit_ms"] < 0 or smoke["exit_ms"] > 1000:
    raise RuntimeError(f"persistent stop-path failed: exit_ms={smoke['exit_ms']}")
print("smoke tests: PASS", flush=True)

rows = []
schedule = [
    ("baseline", "baseline#1"),
    ("persistent", "persist#1"),
    ("persistent", "persist#2"),
    ("baseline", "baseline#2"),
]
for variant, label in schedule:
    rows.append(run_once(variant, SAMPLE, label))
    time.sleep(2)

baseline = mean_rows(rows, "baseline")
candidate = mean_rows(rows, "persistent")
cpu_change = 100.0 * (candidate["cpu"] / baseline["cpu"] - 1.0)
wall_change = 100.0 * (candidate["wall"] / baseline["wall"] - 1.0)

print()
print("===== FINAL PERSISTENT-KERNEL CPU A/B =====")
print(
    f"{'variant':<11} {'kernel':>10} {'wall MH/s':>10} {'daemonCPU':>10} "
    f"{'busy':>8} {'irq/s':>9} {'ctxt/s':>10} {'proc cs/s':>10} "
    f"{'threads':>8} {'exit ms':>9}"
)
for row in (baseline, candidate):
    print(
        f"{row['variant']:<11} {row['kernel']:>10.3f} {row['wall']:>10.3f} "
        f"{row['cpu']:>9.2f}% {row['busy']:>7.1f}% {row['irq_s']:>9.0f} "
        f"{row['ctxt_s']:>10.0f} {row['proc_ctxt_s']:>10.1f} "
        f"{row['threads']:>8} {row['exit_ms']:>9.3f}"
    )

print()
print(f"persistent daemon CPU change: {cpu_change:+.1f}%")
print(f"persistent wall hashrate change: {wall_change:+.2f}%")
print(f"persistent mean exit latency: {candidate['exit_ms']:.3f} ms")
if cpu_change <= -50.0 and wall_change >= -2.0 and candidate["exit_ms"] <= 10.0:
    print("decision: PASS — proceed to a live job/share prototype")
elif cpu_change <= -20.0 and wall_change >= -3.0 and candidate["exit_ms"] <= 20.0:
    print("decision: MARGINAL — optimize the stop check before live integration")
else:
    print("decision: FAIL — resident-loop overhead outweighs the host savings")
print()
print("Paste this complete result into chat. This test did not install a miner.")
