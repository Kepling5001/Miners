#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VARIANTS=(r5 r4top r4fold r3 r3fused)

for variant in "${VARIANTS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$variant" ]] || {
    echo "ERROR: run ./build-on-rig.sh first"
    exit 1
  }
done

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Stop or pause the flight sheet first."
  exit 1
fi

python3 "$ROOT/offline_verify.py"

echo "===== GPU CORRECTNESS ORACLES ====="
for variant in "${VARIANTS[@]}"; do
  echo "--- $variant ---"
  "$ROOT/bin/test_gf_$variant"
done

python3 "$ROOT/benchmark_gf_primitives.py"
"$ROOT/test-persistent.sh"

echo
echo "Paste the complete FINAL GF PRIMITIVE RANKING and persistent-worker result back into chat."
