#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local reduce_variant="$2"
  local fused="$3"
  local extra=()
  if [[ "$fused" == "yes" ]]; then
    extra+=( -DNOID_GF_FUSED=1 )
  fi

  echo
  echo "===== BUILD $name | reduction=$reduce_variant fused=$fused ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_REDUCE_VARIANT="$reduce_variant" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" "${extra[@]}" \
    -DNOID_REDUCE_VARIANT="$reduce_variant" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

build_variant r5       5  no
build_variant r4top    41 no
build_variant r4fold   42 no
build_variant r3       3  no
build_variant r3fused  3  yes

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_gf_primitives.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-gf-primitives.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-gf-primitives.sh"
