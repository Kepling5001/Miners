# noid170 v0.5.5 GF primitive A/B

This package tests exact GF(2^128) reduction and multiplication schedules on
the production v0.5.4 factorized-MDS, CLMAD-square, accumulated-Karatsuba
kernel. Every mining variant uses the proven b64 launch geometry.

Variants:

- `r5`: current production five-CLMAD reduction
- `r4top`: shift-derived top overflow plus CLMAD final fold
- `r4fold`: CLMAD top overflow plus shift-derived final fold
- `r3`: three-CLMAD reduction with both tiny folds done by shifts
- `r3fused`: `r3` plus fused Karatsuba limb accumulation

The GPU oracle compares every candidate with the independent shift-reduction
reference at reduction, multiplication, square, S-box, Poseidon, and chained
Poseidon levels. The benchmark uses two temperature-balanced passes, ranks by
wall MH/s, writes the winner to `winner.txt`, and then tests that exact binary
through persistent job switching and a network-accepted share.

Run only while the installed HiveOS miner is stopped:

```bash
cd /home/user/noid170-v0.5.5-gf-primitive-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-gf-primitives.sh
```

Paste the complete final ranking and persistent-worker result back into chat.
