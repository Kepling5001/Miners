#!/usr/bin/env python3
import json
import os
import subprocess
import time

STATS = os.environ.get("NOID_STATS_FILE", "/run/noid170/stats.json")
VERSION = "0.5.1"


def gpu_telemetry(n):
    temps = [0] * n
    fans = [0] * n
    buses = list(range(n))
    try:
        p = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=temperature.gpu,fan.speed,pci.bus_id",
                "--format=csv,noheader,nounits",
            ],
            text=True,
            capture_output=True,
            timeout=3,
            check=True,
        )
        lines = [x.strip() for x in p.stdout.splitlines() if x.strip()]
        for i, line in enumerate(lines[:n]):
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 1:
                try: temps[i] = int(float(parts[0]))
                except Exception: pass
            if len(parts) >= 2:
                try: fans[i] = int(float(parts[1]))
                except Exception: pass
            if len(parts) >= 3:
                try:
                    # 00000000:0A:00.0 -> decimal bus 10
                    buses[i] = int(parts[2].split(":")[-2], 16)
                except Exception:
                    pass
    except Exception:
        pass
    return temps, fans, buses


def main():
    try:
        st = os.stat(STATS)
        if time.time() - st.st_mtime > 20:
            raise RuntimeError("stale stats")
        with open(STATS, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        print("0")
        print(json.dumps({
            "hs": [], "hs_units": "khs", "temp": [], "fan": [],
            "uptime": 0, "ver": VERSION, "ar": [0, 0], "algo": "noid",
            "bus_numbers": []
        }, separators=(",", ":")))
        return

    rates = [float(x) for x in d.get("gpu_rates_mhs", [])]
    n = len(rates)
    temps, fans, buses = gpu_telemetry(n)
    accepted = int(d.get("accepted", 0))
    rejected = int(d.get("rejected", 0)) + int(d.get("stale", 0))

    hive = {
        # Hive custom-miner integrations are most compatible when the
        # per-GPU array uses kH/s, matching the legacy total $khs field.
        "hs": [int(round(x * 1000.0)) for x in rates],
        "hs_units": "khs",
        "temp": temps,
        "fan": fans,
        "uptime": int(d.get("uptime", 0)),
        "ver": str(d.get("version", VERSION)),
        "ar": [accepted, rejected],
        "algo": "noid",
        "bus_numbers": buses,
    }

    # Hive's legacy $khs field is total kH/s.
    print(str(int(round(sum(rates) * 1000.0))))
    print(json.dumps(hive, separators=(",", ":")))


if __name__ == "__main__":
    main()
