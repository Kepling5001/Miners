#!/usr/bin/env bash
set -uo pipefail
BIN="${NOID_BIN:-/hive/miners/custom/noid170/noid_live_job_daemon}"
OUT="${NOID_SASS_OUT:-/home/user/noid170-sass-profile}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
CUOBJDUMP="${CUOBJDUMP:-/usr/local/cuda-12.8/bin/cuobjdump}"

if [[ ! -x "$CUOBJDUMP" ]]; then
  CUOBJDUMP="$(command -v cuobjdump 2>/dev/null || true)"
fi
if [[ -z "$CUOBJDUMP" || ! -x "$CUOBJDUMP" ]]; then
  echo "ERROR: cuobjdump not found"
  exit 1
fi
if [[ ! -f "$BIN" ]]; then
  echo "ERROR: production daemon not found: $BIN"
  exit 1
fi
mkdir -p "$OUT"

echo "===== NOID170 STATIC SASS PROFILE ====="
echo "Binary: $BIN"
echo "cuobjdump: $CUOBJDUMP"
echo "Output: $OUT"
echo "Normal mining does NOT need to be stopped."
echo

{
  date -Is
  uname -a
  echo
  "$CUOBJDUMP" --version 2>&1
  echo
  sha256sum "$BIN"
  file "$BIN"
  echo
  nvidia-smi --query-gpu=index,name,driver_version,pstate,clocks.sm,clocks.mem,power.draw,temperature.gpu,utilization.gpu,utilization.memory --format=csv 2>&1
} > "$OUT/environment.txt"

# Resource metadata. Keep going if a particular option is not supported by this build.
"$CUOBJDUMP" --dump-resource-usage "$BIN" > "$OUT/resource-usage.txt" 2>&1 || true
"$CUOBJDUMP" --list-elf "$BIN" > "$OUT/elf-list.txt" 2>&1 || true

# Full actual machine-code disassembly from the installed binary.
if ! "$CUOBJDUMP" --dump-sass "$BIN" > "$OUT/full-sass.txt" 2> "$OUT/cuobjdump-sass.stderr"; then
  echo "ERROR: cuobjdump --dump-sass failed"
  cat "$OUT/cuobjdump-sass.stderr"
  exit 1
fi

python3 "$ROOT/analyze_sass.py" "$OUT/full-sass.txt" "$OUT" || true

# Live GPU0 telemetry while normal miner remains running.
echo "timestamp,index,pstate,sm_clock_MHz,mem_clock_MHz,power_W,temp_C,gpu_util_pct,mem_util_pct" > "$OUT/gpu0-telemetry.csv"
for i in $(seq 1 30); do
  nvidia-smi -i 0 \
    --query-gpu=timestamp,index,pstate,clocks.sm,clocks.mem,power.draw,temperature.gpu,utilization.gpu,utilization.memory \
    --format=csv,noheader,nounits 2>/dev/null >> "$OUT/gpu0-telemetry.csv" || true
  sleep 1
done

# Summarize telemetry using stdlib Python only.
python3 - "$OUT/gpu0-telemetry.csv" "$OUT/telemetry-summary.txt" <<'PY'
import csv,sys,statistics
src,dst=sys.argv[1:]
rows=[]
with open(src,newline='') as f:
    r=csv.reader(f)
    next(r,None)
    for row in r:
        if len(row) < 9: continue
        try:
            rows.append({
                'sm':float(row[3]),'mem':float(row[4]),'power':float(row[5]),
                'temp':float(row[6]),'gpu':float(row[7]),'memu':float(row[8])})
        except Exception: pass
lines=['===== GPU0 30-SECOND TELEMETRY =====',f'Samples: {len(rows)}']
for k,label in [('sm','SM clock MHz'),('mem','Memory clock MHz'),('power','Power W'),('temp','Temperature C'),('gpu','GPU util %'),('memu','Memory util %')]:
    vals=[x[k] for x in rows]
    if vals:
        lines.append(f'{label:18s} avg={statistics.mean(vals):.2f} min={min(vals):.2f} max={max(vals):.2f}')
open(dst,'w').write('\n'.join(lines)+'\n')
print('\n'.join(lines))
PY

echo
echo "===== STATIC ANALYSIS ====="
cat "$OUT/analysis.txt" 2>/dev/null || true
echo
echo "===== RESOURCE USAGE (mine_kernel context) ====="
grep -i -B4 -A16 'mine_kernel' "$OUT/resource-usage.txt" 2>/dev/null | head -80 || true
echo
echo "===== PROFILE COMPLETE ====="
echo "Paste these three files/results back into chat:"
echo "  $OUT/analysis.txt"
echo "  $OUT/resource-usage.txt"
echo "  $OUT/telemetry-summary.txt"
