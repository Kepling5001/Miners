# NOID170 v0.6.24b CMP SASS profiler

Static profiling fallback for CMP170HX, where NVIDIA Nsight Compute hardware counters are intentionally unsupported.

This package does **not** install, modify, stop, or restart the miner. It analyzes the currently installed `/hive/miners/custom/noid170/noid_live_job_daemon` with CUDA 12.8 `cuobjdump`, extracts the `mine_kernel` SASS/opcode mix/resource metadata, and records 30 seconds of GPU0 clock/power/utilization telemetry while mining normally.

Run:

```bash
cd /home/user
tar -xzf noid170-v0.6.24b-sass-profile.tar.gz
cd noid170-v0.6.24b-sass-profile
chmod +x profile-sass.sh analyze_sass.py
./profile-sass.sh
```

Outputs are written under `/home/user/noid170-sass-profile/`.
