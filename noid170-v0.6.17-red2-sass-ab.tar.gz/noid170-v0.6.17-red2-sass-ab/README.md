# NOID170 v0.6.17 red2 SASS / fixed-multiply A/B

Correctness-gated CMP 170HX benchmark. It does **not** install or replace the live HiveOS miner.

## Baseline

The proven current winner:

- 512 threads / 128 grid blocks per SM
- partial MDS `red2`
- 42 registers, zero spills in the last A/B
- r4top general reduction
- r2lop3 square reduction
- paired, non-volatile CLMAD scheduling

## What this tests

The hot partial MDS performs four fixed GF(2^128) multiplications in each of 58 partial Poseidon rounds. The baseline raw product is six CLMAD instructions and the r4top reduction is four more.

Variants:

- `baseline` — exact current red2/r4top path
- `fusedprod` — same six CLMAD Karatsuba product, but final product limbs are formed directly through CLMAD accumulators
- `constfused` — same fused product with the four MDS constants encoded as C++ template constants
- `r4fold` — four-CLMAD reduction that extracts overflow with CLMAD and shift-folds the tiny result
- `r3` — three-CLMAD batched reduction; removes one CLMAD per fixed multiply
- `r3lop3` — same three-CLMAD reduction with an explicit LOP3 XOR fold
- `fused_r3` — fused product plus three-CLMAD reduction
- `const_r3` — fixed-template fused product plus three-CLMAD reduction

A dedicated `partial_micro` cubin isolates one partial-MDS layer so `sass-audit.sh` can count CLMAD/LOP3/shift/total SASS instructions without the rest of Poseidon obscuring the result. Every full miner candidate also has to match the GPU reference oracle before benchmarking. The measured winner must then pass persistent job switching and a network-accepted share.

## Run

```bash
cd /home/user/noid170-v0.6.17-red2-sass-ab
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-red2-sass.sh
miner start
```

Paste back:

1. `PARTIAL-MDS MICROKERNEL SASS AUDIT`
2. `FINAL RED2 SASS/ARITHMETIC RANKING`
3. `RED2 SASS WINNER PROTOCOL: PASS`
