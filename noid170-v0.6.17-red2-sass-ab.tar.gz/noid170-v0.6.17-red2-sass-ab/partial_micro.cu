#include <cuda_runtime.h>
struct U128 { unsigned long long lo; unsigned long long hi; };
#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

extern "C" __global__
void partial_micro(const U128 *in, U128 *out)
{
    const unsigned tid = blockIdx.x * blockDim.x + threadIdx.x;
    U128 s[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = in[(tid * 4u + (unsigned)i) & 1023u];
    apply_mds_partial(s);
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        out[(tid * 4u + (unsigned)i) & 1023u] = s[i];
}
