#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in scalar prod2 red2 pair2 quad4; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done

echo "===== GPU CORRECTNESS ORACLES ====="
for v in scalar prod2 red2 pair2 quad4; do
  echo "--- $v ---"
  "$ROOT/bin/test_gf_$v"
done

echo
python3 "$ROOT/benchmark_partial512.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste the complete FINAL 512-THREAD PARTIAL-MDS ILP RANKING"
echo "and PARTIAL512 WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
