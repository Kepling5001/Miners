#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
VARIANTS=(baseline fusedprod constfused r4fold r3 r3lop3 fused_r3 const_r3)
for v in "${VARIANTS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done
echo "===== GPU CORRECTNESS ORACLES ====="
for v in "${VARIANTS[@]}"; do
  echo "--- $v ---"
  "$ROOT/bin/test_gf_$v"
done
echo
"$ROOT/sass-audit.sh"
echo
python3 "$ROOT/benchmark_red2_sass.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste the PARTIAL-MDS MICROKERNEL SASS AUDIT,"
echo "FINAL RED2 SASS/ARITHMETIC RANKING, and"
echo "RED2 SASS WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
