#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin"
VARIANTS=(baseline fusedprod constfused r4fold r3 r3lop3 fused_r3 const_r3)
NVDISASM="${NVDISASM:-/usr/local/cuda-13.3/bin/nvdisasm}"
if [[ ! -x "$NVDISASM" ]]; then
  NVDISASM="$(command -v nvdisasm || true)"
fi
if [[ -z "$NVDISASM" ]]; then
  echo "SASS audit unavailable: nvdisasm not found"
  exit 0
fi
mkdir -p "$BIN/sass"
echo "===== PARTIAL-MDS MICROKERNEL SASS AUDIT ====="
printf '%-12s %7s %7s %7s %7s %7s %7s %9s\n' variant CLMAD LOP3 SHF SHR SHL IADD3 TOTAL
for v in "${VARIANTS[@]}"; do
  in="$BIN/partial_$v.cubin"
  out="$BIN/sass/$v.sass"
  "$NVDISASM" "$in" > "$out"
  count(){ grep -Eic "$1" "$out" || true; }
  clmad=$(count 'CLMAD\.')
  lop3=$(count 'LOP3\.')
  shf=$(count 'SHF\.')
  shr=$(count 'SHR\.')
  shl=$(count 'SHL\.')
  iadd3=$(count 'IADD3')
  total=$(grep -Ec '^\s*/\*[0-9a-fA-F]+\*/' "$out" || true)
  printf '%-12s %7s %7s %7s %7s %7s %7s %9s\n' "$v" "$clmad" "$lop3" "$shf" "$shr" "$shl" "$iadd3" "$total"
done
echo
echo "SASS files saved under: $BIN/sass/"
