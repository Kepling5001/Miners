# NOID170 v0.6.9 nonblocking capability A/B

This is a non-installing stale-path experiment based on the validated
`noid170-0.6.2-poll2ms` package. It contains the exact same GPU binaries.

It compares four equal-share runs:

1. `baseline1` — current blocking capability recovery.
2. `nonblock` — one refresh attempt; server backoff never sleeps in the flow lock.
3. `adaptive` — nonblocking recovery plus server-directed retry timing.
4. `baseline2` — control repeated after the candidates.

Queued shares in candidate modes wait for a valid capability without blocking
the meaningful-work watcher. The test records accepted-work efficiency, stale
and local-discard counts, RPC latency, backoff time, job ACK latency and CPU.

## Run

```bash
cd /home/user/noid170-v0.6.9-cap-lock-ab
miner stop
export NOID_MINING_KEY='your_address.worker'
export NOID_TEST_GPU_COUNT=12
./test-cap-lock.sh
miner start
```

If the current HiveOS custom-miner configuration exists, `test-cap-lock.sh`
loads `NOID_MINING_KEY` from it, so the explicit key export can be omitted.

The installed HiveOS miner is not modified. On a 12-GPU rig, the default 150
finalized shares per variant should take roughly 45–60 minutes total. A 4-GPU
rig will take much longer. Override the sample size with
`NOID_AB_FINAL_SHARES=200` if a more precise second run is needed.
