#!/usr/bin/env python3

import json
import os
import signal
import statistics
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"
MINER = ROOT / "noid170_aria_ab.py"
TARGET = max(50, int(os.environ.get("NOID_AB_FINAL_SHARES", "150")))
MAX_SECONDS = max(900, int(os.environ.get("NOID_AB_MAX_SECONDS", "5400")))
CLK_TCK = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
VARIANTS = [
    ("baseline1", "baseline"),
    ("nonblock", "nonblock"),
    ("adaptive", "adaptive"),
    ("baseline2", "baseline"),
]


def detect_gpu_count():
    override = os.environ.get("NOID_TEST_GPU_COUNT", "").strip()
    if override:
        return int(override)
    result = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([line for line in result.stdout.splitlines() if line.strip()])


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def proc_info(pid):
    try:
        text = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8")
        rest = text[text.rfind(")") + 2:].split()
        return int(rest[1]), int(rest[11]) + int(rest[12])
    except (OSError, ValueError, IndexError):
        return None


def process_tree_ticks(root_pid):
    info = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        item = proc_info(int(entry.name))
        if item is not None:
            info[int(entry.name)] = item

    descendants = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, (ppid, _ticks) in info.items():
            if ppid in descendants and pid not in descendants:
                descendants.add(pid)
                changed = True
    return {pid: info[pid][1] for pid in descendants if pid in info}


def stop_process(proc):
    if proc.poll() is not None:
        return
    proc.send_signal(signal.SIGINT)
    try:
        proc.wait(timeout=15)
        return
    except subprocess.TimeoutExpired:
        proc.terminate()
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def result_row(name, mode, data, elapsed, cpu_ticks):
    accepted = int(data.get("accepted", 0))
    stale = int(data.get("stale", 0))
    rejected = int(data.get("rejected", 0))
    found = int(data.get("found", 0))
    submitted = accepted + stale + rejected
    wall = float(data.get("wall_total_mhs", 0.0))
    accepted_mh = float(data.get("accepted_work_mhs", 0.0))
    return {
        "variant": name,
        "mode": mode,
        "seconds": elapsed,
        "kernel": float(data.get("total_mhs", 0.0)),
        "wall": wall,
        "accepted_mh": accepted_mh,
        "efficiency": 100.0 * accepted_mh / wall if wall > 0 else 0.0,
        "found": found,
        "queued": int(data.get("queued_found", 0)),
        "accepted": accepted,
        "stale": stale,
        "rejected": rejected,
        "submitted": submitted,
        "submit_accept": 100.0 * accepted / submitted if submitted else 0.0,
        "found_accept": 100.0 * accepted / found if found else 0.0,
        "old_drop": int(data.get("old_share_discarded", 0)),
        "old_drop_pct": 100.0 * int(data.get("old_share_discarded", 0)) / found if found else 0.0,
        "cap_fail": int(data.get("capability_refresh_failures", 0)),
        "cap_defer": int(data.get("capability_refresh_deferred", 0)),
        "cap_backoff": int(data.get("capability_backoffs", 0)),
        "backoff_s": float(data.get("capability_backoff_seconds", 0.0)),
        "cap_wait": int(data.get("capability_waits", 0)),
        "cap_wait_s": float(data.get("capability_wait_ms", 0.0)) / 1000.0,
        "work_changes": int(data.get("capability_work_changes", 0)),
        "http_errors": int(data.get("http_errors", 0)),
        "get_avg": float(data.get("get_template_avg_ms", 0.0)),
        "get_max": float(data.get("get_template_max_ms", 0.0)),
        "submit_avg": float(data.get("submit_avg_ms", 0.0)),
        "submit_max": float(data.get("submit_max_ms", 0.0)),
        "ack": float(data.get("last_job_ack_ms", 0.0)),
        "max_ack": float(data.get("max_job_ack_ms", 0.0)),
        "cpu": cpu_ticks / CLK_TCK / max(0.001, elapsed) * 100.0,
    }


def run_variant(results_dir, name, mode, gpu_count):
    print(f"===== RUN {name} | mode={mode} | target={TARGET} finalized shares =====", flush=True)
    stats_path = results_dir / f"{name}.json"
    log_path = results_dir / f"{name}.log"
    env = os.environ.copy()
    env.update({
        "NOID_CAPABILITY_MODE": mode,
        "NOID_GPU_COUNT": str(gpu_count),
        "NOID_SUBMIT_THREADS": "1",
        "NOID_POLL_INTERVAL": "0.20",
        "NOID_STATS_FILE": str(stats_path),
        "NOID_WARMUP_BIN": str(RUNTIME / "noid_live_job_cont"),
        "NOID_DAEMON_BIN": str(RUNTIME / "noid_live_job_daemon"),
        "NOID_TUI": "0",
    })

    started = time.monotonic()
    last_progress = 0.0
    previous_ticks = {}
    accumulated_ticks = 0
    last_data = None
    with open(log_path, "w", encoding="utf-8", buffering=1) as log:
        proc = subprocess.Popen(
            [sys.executable, "-u", str(MINER)],
            stdout=log,
            stderr=subprocess.STDOUT,
            env=env,
            cwd=str(ROOT),
        )
        try:
            while True:
                now = time.monotonic()
                if proc.poll() is not None:
                    raise RuntimeError(f"{name} exited early with code {proc.returncode}")
                current_ticks = process_tree_ticks(proc.pid)
                for pid, ticks in current_ticks.items():
                    if pid in previous_ticks and ticks >= previous_ticks[pid]:
                        accumulated_ticks += ticks - previous_ticks[pid]
                previous_ticks = current_ticks

                data = load_json(stats_path)
                if data:
                    last_data = data
                    finalized = (
                        int(data.get("accepted", 0))
                        + int(data.get("stale", 0))
                        + int(data.get("rejected", 0))
                    )
                    if now - last_progress >= 30.0:
                        print(
                            f"{name}: finalized={finalized}/{TARGET} "
                            f"A={data.get('accepted', 0)} S={data.get('stale', 0)} "
                            f"old={data.get('old_share_discarded', 0)} "
                            f"wall={data.get('wall_total_mhs', 0):.2f} MH/s",
                            flush=True,
                        )
                        last_progress = now
                    if finalized >= TARGET:
                        break
                if now - started > MAX_SECONDS:
                    raise RuntimeError(f"{name} exceeded {MAX_SECONDS}s")
                time.sleep(1.0)
        finally:
            stop_process(proc)

    final_data = load_json(stats_path) or last_data
    if not final_data:
        tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-20:])
        raise RuntimeError(f"{name}: no stats produced\n{tail}")
    elapsed = max(0.001, float(final_data.get("production_uptime", time.monotonic() - started)))
    row = result_row(name, mode, final_data, elapsed, accumulated_ticks)
    print(
        f"{name}: accepted/found={row['found_accept']:.2f}% "
        f"submitted acceptance={row['submit_accept']:.2f}% "
        f"accepted={row['accepted']} stale={row['stale']} old={row['old_drop']}",
        flush=True,
    )
    return row


def mean_rows(rows, key):
    return statistics.mean(row[key] for row in rows)


def print_results(rows, results_dir):
    print()
    print("===== FINAL NONBLOCKING CAPABILITY A/B =====")
    print(
        f"{'variant':<10} {'wall':>9} {'acc MH/s':>10} {'eff':>7} "
        f"{'found':>6} {'A':>5} {'S':>4} {'old':>5} {'A/found':>9} "
        f"{'A/sub':>7} {'capfail':>7} {'defer':>6} {'wait s':>7} {'CPU':>7}"
    )
    for row in rows:
        print(
            f"{row['variant']:<10} {row['wall']:>9.2f} {row['accepted_mh']:>10.2f} "
            f"{row['efficiency']:>6.2f}% {row['found']:>6} {row['accepted']:>5} "
            f"{row['stale']:>4} {row['old_drop']:>5} {row['found_accept']:>8.2f}% "
            f"{row['submit_accept']:>6.2f}% {row['cap_fail']:>7} "
            f"{row['cap_defer']:>6} {row['cap_wait_s']:>7.2f} {row['cpu']:>6.1f}%"
        )

    print()
    print("===== RPC / SWITCH DETAIL =====")
    print(
        f"{'variant':<10} {'get avg':>8} {'get max':>8} {'sub avg':>8} "
        f"{'sub max':>8} {'backoff':>8} {'back s':>8} {'workchg':>8} "
        f"{'ACK':>7} {'maxACK':>7}"
    )
    for row in rows:
        print(
            f"{row['variant']:<10} {row['get_avg']:>7.1f} {row['get_max']:>7.1f} "
            f"{row['submit_avg']:>7.1f} {row['submit_max']:>7.1f} "
            f"{row['cap_backoff']:>8} {row['backoff_s']:>8.1f} "
            f"{row['work_changes']:>8} {row['ack']:>7.1f} {row['max_ack']:>7.1f}"
        )

    baselines = [row for row in rows if row["mode"] == "baseline"]
    baseline_af = mean_rows(baselines, "found_accept")
    baseline_eff = mean_rows(baselines, "efficiency")
    print()
    for row in rows:
        if row["mode"] == "baseline":
            continue
        print(
            f"{row['variant']} vs baseline mean: accepted/found "
            f"{row['found_accept'] - baseline_af:+.2f} points; "
            f"accepted-work efficiency {row['efficiency'] - baseline_eff:+.2f} points"
        )

    winner = max(
        [row for row in rows if row["mode"] != "baseline"],
        key=lambda row: (row["efficiency"], row["found_accept"]),
    )
    print(f"candidate winner: {winner['variant']}")
    if winner["efficiency"] >= baseline_eff + 1.5:
        print("decision: PASS — candidate deserves a longer live validation")
    elif winner["efficiency"] >= baseline_eff:
        print("decision: MARGINAL — repeat with a larger share target")
    else:
        print("decision: FAIL — blocking recovery was not the stale source")
    print(f"results and logs: {results_dir}")
    print("Paste both complete tables and the decision block into chat.")


def main():
    if not os.environ.get("NOID_MINING_KEY", "").strip():
        raise SystemExit("ERROR: NOID_MINING_KEY is not set")
    gpu_count = detect_gpu_count()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    results_dir = Path(os.environ.get("NOID_AB_RESULTS_DIR", f"/run/noid170-cap-lock-ab-{stamp}"))
    results_dir.mkdir(parents=True, exist_ok=True)
    print("===== NONBLOCKING CAPABILITY RECOVERY A/B =====")
    print(f"GPUs: {gpu_count}  finalized shares/variant: {TARGET}")
    print("Kernel: exact production v0.6.2 poll2000 daemon")
    print("Order: baseline1 -> nonblock -> adaptive -> baseline2")
    print(f"Results: {results_dir}")
    rows = []
    for index, (name, mode) in enumerate(VARIANTS):
        rows.append(run_variant(results_dir, name, mode, gpu_count))
        if index + 1 < len(VARIANTS):
            time.sleep(8.0)
    with open(results_dir / "summary.json", "w", encoding="utf-8") as handle:
        json.dump(rows, handle, indent=2)
        handle.write("\n")
    print_results(rows, results_dir)


if __name__ == "__main__":
    main()
