#!/usr/bin/env bash

# h-stats.sh is sourced by the Hive agent, not executed as a standalone script.
# Resolve our own directory instead of trusting MINER_DIR from the caller.
NOID170_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NOID_STATS_FILE="/run/noid170/stats.json"

out=$(NOID_STATS_FILE="$NOID_STATS_FILE" python3 "$NOID170_DIR/hive_stats.py" 2>/dev/null)
khs=$(printf '%s\n' "$out" | sed -n '1p')
stats=$(printf '%s\n' "$out" | sed -n '2p')

# Hive requires these two shell variables when this file is sourced.
[[ "$khs" =~ ^[0-9]+([.][0-9]+)?$ ]] || khs=0
[[ -n "$stats" ]] || stats='{"hs":[],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"0.1.3","ar":[0,0],"algo":"noid","bus_numbers":[]}'
