# NOID170 v0.2.5 pipelined large-rig build

This build keeps the exact proven sm_80 PoW math and the persistent-job protocol.

The CUDA daemon now uses a two-slot asynchronous pipeline with pinned host buffers. While the CPU consumes the completed batch from slot A, slot B is already executing on the GPU. This is intended to hide the 12-GPU host wake/copy/launch gap seen in v0.2.3/v0.2.4, while preserving the same 1024-thread, 32-blocks/SM kernel and job sequence tagging.

On a job update, the daemon drains the one already-queued old-job batch before changing constant-memory job data, so shares remain tagged to the exact sequence they were computed against.

Build on the CUDA 13.3 test rig with `./build-on-rig.sh`.
