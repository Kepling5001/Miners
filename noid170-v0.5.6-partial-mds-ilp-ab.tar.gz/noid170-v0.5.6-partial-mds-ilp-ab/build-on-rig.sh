#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local partial_ilp="$2"

  echo
  echo "===== BUILD $name | partial-ILP=$partial_ilp ====="
  "$NVCC" "${COMMON[@]}" \
    -DNOID_REDUCE_VARIANT=41 \
    -DNOID_PARTIAL_ILP="$partial_ilp" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" \
    -DNOID_REDUCE_VARIANT=41 \
    -DNOID_PARTIAL_ILP="$partial_ilp" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

build_variant scalar 0
build_variant prod2  1
build_variant red2   2
build_variant pair2  3
build_variant quad4  4

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_partial_ilp.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-partial-ilp.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-partial-ilp.sh"
