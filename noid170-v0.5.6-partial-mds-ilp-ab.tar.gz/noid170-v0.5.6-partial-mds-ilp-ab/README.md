# noid170 v0.5.6 partial-MDS ILP A/B

This package keeps the production v0.5.5 r4top GF arithmetic fixed and tests
explicit instruction-level parallelism across the four independent field
multiplications in each of Poseidon2's 58 partial MDS rounds. Every mining
variant uses the proven b64 launch geometry.

Variants:

- `scalar`: current production schedule
- `prod2`: interleave product stages for two multiplications
- `red2`: interleave reduction stages for two multiplications
- `pair2`: interleave complete products and reductions two at a time
- `quad4`: interleave all four complete multiplications

The GPU oracle compares every candidate with the independent shift-reduction
reference at reduction, multiplication, square, S-box, Poseidon, and chained
Poseidon levels. The benchmark uses two temperature-balanced passes, ranks by
wall MH/s, writes the winner to `winner.txt`, and tests that exact binary
through persistent job switching and a network-accepted share.

Run only while the installed HiveOS miner is stopped:

```bash
cd /home/user/noid170-v0.5.6-partial-mds-ilp-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-partial-ilp.sh
```

Paste the complete final ranking and persistent-worker result back into chat.
