#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

[[ -x "$ROOT/bin/noid_daemon_b32s8" ]] || {
  echo "ERROR: run ./build-on-rig.sh first"
  exit 1
}

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Stop or pause the flight sheet first."
  exit 1
fi

python3 "$ROOT/offline_verify.py"
"$ROOT/bin/test_clmad_reduce"
"$ROOT/bin/test_square_clmad"
"$ROOT/bin/test_clmad_accum"
python3 "$ROOT/benchmark_cpu_batches.py"
