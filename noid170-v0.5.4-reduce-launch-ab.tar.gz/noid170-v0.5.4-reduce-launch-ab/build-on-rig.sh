#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_REDUCE_CLMAD=1
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local blocks="$2"
  local stat_batches="$3"
  echo
  echo "===== BUILD $name | blocks/SM=$blocks stat_batches=$stat_batches ====="
  "$NVCC" "${COMMON[@]}" \
    -DNOID_BLOCKS_PER_SM="$blocks" \
    -DNOID_STAT_BATCHES="$stat_batches" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name"
  chmod +x "$BIN/noid_daemon_$name"
}

build_variant b32s8    32   8
build_variant b32s32   32  32
build_variant b64s32   64  32
build_variant b96s32   96  32
build_variant b128s32 128  32

echo
echo "===== BUILD DIRECT REDUCTION CORRECTNESS ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_clmad_reduce.cu" \
  -o "$BIN/test_clmad_reduce"

echo
echo "===== BUILD ACCUMULATOR REGRESSION ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_clmad_accum.cu" \
  -o "$BIN/test_clmad_accum"

echo
echo "===== BUILD CLMAD SQUARING/CHAIN REGRESSION ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  "$ROOT/test_square_clmad.cu" \
  -o "$BIN/test_square_clmad"

chmod +x "$BIN/test_clmad_reduce" "$BIN/test_clmad_accum" "$BIN/test_square_clmad"

python3 -m py_compile \
  "$ROOT/benchmark_cpu_batches.py" \
  "$ROOT/offline_verify.py"
bash -n "$ROOT/test-launch-sweep.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_clmad_reduce \
  "$BIN"/test_clmad_accum "$BIN"/test_square_clmad
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-launch-sweep.sh"
