# noid170 v0.5.4 CLMAD-reduction launch sweep

This isolated package retunes GPU batch size after the v0.5.3 five-CLMAD field
reduction increased one-card throughput from about 75.3 to 133.4 MH/s.

Every variant uses identical factorized MDS, CLMAD squaring, accumulated CLMAD
Karatsuba, and CLMAD field reduction. Only blocks per SM and status frequency
change:

- `b32s8`: current 32 blocks/SM, STAT every 8 batches
- `b32s32`: 32 blocks/SM, quieter STAT output
- `b64s32`: 64 blocks/SM
- `b96s32`: 96 blocks/SM
- `b128s32`: 128 blocks/SM

The benchmark starts one daemon per detected GPU, uses an effectively
impossible target so it submits no shares, and measures aggregate kernel/wall
MH/s, daemon CPU, system busy percentage, interrupts, context switches, and
TAG/FULL job acknowledgement latency.

Run with the installed HiveOS miner stopped:

```bash
cd /home/user/noid170-v0.5.4-reduce-launch-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-launch-sweep.sh
```

Paste the complete final comparison into the chat before packaging production.
