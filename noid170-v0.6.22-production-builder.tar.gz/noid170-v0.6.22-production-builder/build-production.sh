#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BUILD="$ROOT/build"
STAGE="$ROOT/stage"
DIST="$ROOT/dist"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
VERSION="0.6.22"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
command -v nvidia-smi >/dev/null 2>&1 || { echo "ERROR: nvidia-smi not found"; exit 1; }

rm -rf "$BUILD" "$STAGE" "$DIST"
mkdir -p "$BUILD" "$STAGE" "$DIST"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512
  -DNOID_BLOCKS_PER_SM=128
  -Xptxas=-v
)

echo "===== NOID170 v$VERSION PRODUCTION BUILD ====="
echo "Winner: red2 + 512 threads + r4top + square3/LOP3 + original X^7"
echo

echo "===== OFFLINE ALGEBRA MODELS ====="
python3 "$ROOT/offline_verify.py"

echo
echo "===== BUILD PRODUCTION DAEMON ====="
"$NVCC" "${COMMON[@]}" -I"$SRC" \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BUILD/noid_live_job_daemon" 2>&1 | tee "$BUILD/build_daemon.log"

echo
echo "===== BUILD GPU ORACLE ====="
"$NVCC" "${COMMON[@]}" -I"$SRC" \
  "$ROOT/test_gf_primitives.cu" \
  -o "$BUILD/test_gf_production" 2>&1 | tee "$BUILD/build_oracle.log"
chmod 755 "$BUILD/noid_live_job_daemon" "$BUILD/test_gf_production"

echo
echo "===== GPU CORRECTNESS ORACLE ====="
"$BUILD/test_gf_production"

echo
echo "===== STAGE HIVEOS PACKAGE ====="
cp -a "$ROOT/template/noid170" "$STAGE/noid170"
cp "$BUILD/noid_live_job_daemon" "$STAGE/noid170/noid_live_job_daemon"
chmod 755 "$STAGE/noid170/noid_live_job_daemon" \
  "$STAGE/noid170/noid_live_job_cont" \
  "$STAGE/noid170/h-config.sh" "$STAGE/noid170/h-run.sh" "$STAGE/noid170/h-stats.sh"

python3 -m py_compile "$STAGE/noid170/noid170_aria.py" "$STAGE/noid170/hive_stats.py"
bash -n "$STAGE/noid170/h-config.sh" "$STAGE/noid170/h-run.sh" "$STAGE/noid170/h-stats.sh"

grep -q 'CUSTOM_VERSION="0.6.22"' "$STAGE/noid170/h-manifest.conf"
grep -q 'VERSION = "0.6.22"' "$STAGE/noid170/noid170_aria.py"

PKG="$DIST/noid170-$VERSION.tar.gz"
tar -czf "$PKG" -C "$STAGE" noid170
sha256sum "$PKG" | tee "$PKG.sha256"
sha256sum "$STAGE/noid170/noid_live_job_daemon" | tee "$DIST/noid_live_job_daemon.sha256"

echo
echo "===== PRODUCTION PACKAGE READY ====="
ls -lh "$PKG" "$PKG.sha256"
echo "Package: $PKG"
echo "This build did NOT install or replace the active HiveOS miner."
echo "To install on this rig after reviewing the package: ./install-local.sh"
