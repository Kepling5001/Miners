#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VERSION="0.6.22"
PKG="$ROOT/dist/noid170-$VERSION.tar.gz"
TARGET="/hive/miners/custom/noid170"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/home/user/noid170-pre-$VERSION-$STAMP"
TMP="$(mktemp -d /tmp/noid170-install.XXXXXX)"
trap 'rm -rf "$TMP"' EXIT

[[ -f "$PKG" ]] || { echo "ERROR: $PKG missing. Run ./build-production.sh first."; exit 1; }

tar -xzf "$PKG" -C "$TMP"
[[ -x "$TMP/noid170/noid_live_job_daemon" ]] || { echo "ERROR: packaged daemon missing/not executable"; exit 1; }
grep -q 'CUSTOM_VERSION="0.6.22"' "$TMP/noid170/h-manifest.conf" || { echo "ERROR: wrong manifest version"; exit 1; }

CONF_SAVE="$TMP/noid170.conf.saved"
if [[ -f "$TARGET/noid170.conf" ]]; then
  cp -a "$TARGET/noid170.conf" "$CONF_SAVE"
fi

if [[ -d "$TARGET" ]]; then
  echo "Backing up current miner to $BACKUP"
  cp -a "$TARGET" "$BACKUP"
fi

echo "Stopping HiveOS miner..."
miner stop || true
sleep 2

NEW="${TARGET}.new-$STAMP"
rm -rf "$NEW"
mkdir -p "$(dirname "$TARGET")"
cp -a "$TMP/noid170" "$NEW"
if [[ -f "$CONF_SAVE" ]]; then
  cp -a "$CONF_SAVE" "$NEW/noid170.conf"
  echo "Preserved existing noid170.conf"
fi

OLD="${TARGET}.old-$STAMP"
if [[ -d "$TARGET" ]]; then
  mv "$TARGET" "$OLD"
fi
if mv "$NEW" "$TARGET"; then
  rm -rf "$OLD"
else
  echo "ERROR: activation failed; restoring previous miner" >&2
  [[ -d "$OLD" ]] && mv "$OLD" "$TARGET"
  exit 1
fi

python3 -m py_compile "$TARGET/noid170_aria.py" "$TARGET/hive_stats.py"
bash -n "$TARGET/h-config.sh" "$TARGET/h-run.sh" "$TARGET/h-stats.sh"

echo
echo "===== INSTALLED ====="
cat "$TARGET/h-manifest.conf"
sha256sum "$TARGET/noid_live_job_daemon"
echo "Backup: $BACKUP"
echo
echo "Starting HiveOS miner..."
miner start
