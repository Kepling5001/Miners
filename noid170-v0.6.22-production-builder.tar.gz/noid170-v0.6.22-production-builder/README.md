# NOID170 v0.6.22 production checkpoint

This builder freezes the proven CMP 170HX winner as of the red2/512 optimization series.

Production CUDA configuration:

- `NOID_THREADS=512`
- `NOID_BLOCKS_PER_SM=128`
- `NOID_PARTIAL_ILP=2` (`red2` winner)
- `NOID_REDUCE_VARIANT=41` (`r4top`)
- `NOID_SQUARE_REDUCE_VARIANT=3`
- `NOID_SQUARE_FOLD_LOP3=1`
- original four-stage X^7 (`NOID_SBOX_FUSE_VARIANT=0`)
- paired non-volatile CLMAD scheduling
- factorized full MDS
- 2 ms CUDA-event polling
- no register cap / no launch-bounds forcing

The current benchmark repeatedly reproduced about 159.4 MH/s kernel per CMP 170HX on OctominerTEST and passed persistent job switching plus a network-accepted share.

## Build the farm-ready HiveOS tarball

```bash
cd /home/user/noid170-v0.6.22-production-builder
chmod +x build-production.sh install-local.sh verify-current.sh
./build-production.sh
```

The build runs offline algebra checks, compiles the production CUDA daemon, runs the GPU correctness oracle, and produces:

`dist/noid170-0.6.22.tar.gz`

It does not install anything automatically.

## Install on OctominerTEST

```bash
./install-local.sh
```

The installer backs up the existing `/hive/miners/custom/noid170`, preserves `noid170.conf`, installs v0.6.22, and restarts the miner.

## Verify

```bash
./verify-current.sh
```

The generated `dist/noid170-0.6.22.tar.gz` is the compiled farm-ready package to reuse on the other CMP 170HX rigs.
