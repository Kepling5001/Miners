#!/usr/bin/env bash
set -euo pipefail
TARGET="/hive/miners/custom/noid170"
echo "===== MANIFEST ====="
cat "$TARGET/h-manifest.conf"
echo
echo "===== DAEMON SHA256 ====="
sha256sum "$TARGET/noid_live_job_daemon"
echo
echo "===== CONFIG (secrets hidden) ====="
if [[ -f "$TARGET/noid170.conf" ]]; then
  sed -E 's/^(NOID_MINING_KEY=).*/\1<hidden>/' "$TARGET/noid170.conf"
else
  echo "no config found"
fi
echo
echo "===== STATS ====="
cat /run/noid170/stats.json 2>/dev/null || true
