#!/usr/bin/env python3

import http.client
import json
import os
import queue
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
WINNER_FILE = os.path.join(ROOT, "winner.txt")

variant = os.environ.get("NOID_FORCE_VARIANT", "").strip()
if not variant:
    try:
        variant = open(WINNER_FILE, "r", encoding="utf-8").read().strip()
    except OSError:
        raise SystemExit("ERROR: benchmark first or set NOID_FORCE_VARIANT")

BIN = os.path.join(ROOT, "bin", f"noid_daemon_{variant}")
if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
if not os.path.exists(BIN):
    raise SystemExit(f"ERROR: missing winner binary: {BIN}")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    connection = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        connection.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-sass-schedule-persistent/0.6.3",
                "Accept": "*/*",
            },
        )
        response = connection.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        connection.close()


def get_job(timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


env = os.environ.copy()
env["CUDA_VISIBLE_DEVICES"] = "0"
proc = subprocess.Popen(
    [BIN, "--daemon", "55001"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    bufsize=1,
    env=env,
)
events = queue.Queue()
shares = queue.Queue()


def stderr_reader():
    for line in proc.stderr:
        line = line.rstrip()
        print("GPU:", line)
        events.put(line)


def stdout_reader():
    for line in proc.stdout:
        line = line.rstrip()
        if line.startswith("SHARE "):
            shares.put(line)


threading.Thread(target=stderr_reader, daemon=True).start()
threading.Thread(target=stdout_reader, daemon=True).start()


def wait_prefix(prefix, timeout=30):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(f"winner daemon exited with {proc.returncode}")
        try:
            line = events.get(timeout=0.5)
        except queue.Empty:
            continue
        if line.startswith(prefix):
            return line
    raise RuntimeError(f"timeout waiting for {prefix}")


def send(seq, job):
    proc.stdin.write(
        f"JOB {seq} {job['pow_fields_hex']} {job['difficulty_target_hex']}\n"
    )
    proc.stdin.flush()


def work_key(job):
    return int(job["height"]), job["pow_fields_hex"], job["difficulty_target_hex"]


print("===== CLMAD SCHEDULING WINNER PERSISTENT TEST =====")
print("variant:", variant)
print("PID:", proc.pid)
wait_prefix("READY ")

job1 = get_job()
print("job1", job1["template_id"], "height", job1["height"])
send(1, job1)
wait_prefix("JOBACK 1 ")
send(2, job1)
ack2 = wait_prefix("JOBACK 2 ")
print("same-work switch:", ack2)
stat = wait_prefix("STAT ", timeout=10)
print("hash stat:", stat)
print("PID still:", proc.pid, "alive:", proc.poll() is None)

job2 = get_job()
print("job2", job2["template_id"], "height", job2["height"])
send(3, job2)
ack3 = wait_prefix("JOBACK 3 ")
print("fresh-job switch:", ack3)
print("PID after switch:", proc.pid, "alive:", proc.poll() is None)

current_job = job2
current_seq = 3
deadline = time.time() + 60
next_poll = 0.0
accepted = False

while time.time() < deadline and not accepted:
    now = time.time()
    if now >= next_poll:
        fresh = get_job()
        if work_key(fresh) != work_key(current_job):
            current_seq += 1
            current_job = fresh
            send(current_seq, current_job)
            ack = wait_prefix(f"JOBACK {current_seq} ")
            print("live-work switch:", ack, "height", current_job["height"])
        else:
            current_job["template_id"] = fresh["template_id"]
        next_poll = now + 0.5

    try:
        line = shares.get(timeout=0.1)
    except queue.Empty:
        continue
    parts = line.split()
    if len(parts) != 3 or int(parts[1]) != current_seq:
        continue
    answer = rpc(
        "paranoid_submitBlock",
        [current_job["template_id"], parts[2]],
    )
    print("share submit:", json.dumps(answer))
    if answer.get("result") == "share accepted":
        accepted = True

if not accepted:
    raise RuntimeError("winner produced no accepted share within 60 seconds")

proc.stdin.write("STOP\n")
proc.stdin.flush()
try:
    proc.wait(timeout=4)
except subprocess.TimeoutExpired:
    proc.terminate()
    proc.wait(timeout=4)

print("exit:", proc.returncode)
print("CLMAD SCHEDULING WINNER PROTOCOL: PASS")
