# noid170 v0.6.3 CLMAD compiler/SASS scheduling A/B

This package audits the proven `r2lop3` square path without changing its
arithmetic. It compares separate volatile CLMAD statements with non-volatile
statements and selected multi-output low/high pairings. The launch remains
b64/stat8, with 64 blocks per SM and the current two-way partial-MDS schedule.

Variants:

- `current`: volatile, separate low/high outputs (baseline)
- `nonvolatile`: non-volatile separate outputs, allowing ptxas movement
- `pair`: volatile paired product outputs
- `pair_nv`: non-volatile paired product outputs
- `reducepair`: paired outputs for the two independent first reduction folds
- `all_nv`: non-volatile paired product and reduction outputs

Every candidate is checked by the existing reduction, multiplication, square,
S-box, Poseidon, and chained-Poseidon GPU oracle. The benchmark ranks by wall
MH/s and the selected winner must pass persistent job switching plus a
network-accepted share. `sass-audit.sh` records static CLMAD/LOP3/SHF counts
with `cuobjdump` (or `nvdisasm`); `ncu-audit.sh` can collect the full
driver-specific Nsight Compute section set when `ncu` is installed.

Run only while the installed HiveOS miner is stopped:

```bash
cd /home/user/noid170-v0.6.3-sass-schedule-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-schedule.sh
```

The build and A/B normally take about 8–12 minutes. Mining is not restarted
automatically; run `miner start` after the test. The Nsight Compute wrapper
requires a valid `JOB ...` line and `STOP` in `NOID_NCU_STDIN` if you choose to
profile a real daemon launch.
