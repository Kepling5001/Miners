#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_BLOCKS_PER_SM=64
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  shift

  echo
  echo "===== BUILD $name | $* ====="
  "$NVCC" "${COMMON[@]}" "$@" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" "$@" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name" 2>&1 | tee "$BIN/build_test_gf_$name.log"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

# Baseline: volatile, separate low/high outputs (the current r2lop3 winner).
build_variant current

# Let ptxas move independent CLMAD statements across ordinary C++ operations.
build_variant nonvolatile -DNOID_CLMAD_NONVOLATILE=1

# Keep volatility but expose each low/high product as one multi-output block.
build_variant pair -DNOID_CLMAD_PAIR_OUTPUTS=1

# Combine both scheduling freedoms.
build_variant pair_nv -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_NONVOLATILE=1

# Pair only the two independent first reduction folds.
build_variant reducepair -DNOID_CLMAD_PAIR_REDUCE=1

# Pair product and reduction outputs, while allowing ptxas movement.
build_variant all_nv -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_schedule.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-schedule.sh" "$ROOT/test-persistent.sh" "$ROOT/sass-audit.sh" "$ROOT/ncu-audit.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-schedule.sh"
