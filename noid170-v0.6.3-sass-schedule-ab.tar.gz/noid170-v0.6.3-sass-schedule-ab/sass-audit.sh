#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin"
VARIANTS=(current nonvolatile pair pair_nv reducepair all_nv)

mkdir -p "$BIN/sass"

CUOBJDUMP="${CUOBJDUMP:-/usr/local/cuda-13.3/bin/cuobjdump}"
if [[ -x "$CUOBJDUMP" ]]; then
  DISASSEMBLER="$CUOBJDUMP"
elif command -v nvdisasm >/dev/null 2>&1; then
  DISASSEMBLER="$(command -v nvdisasm)"
else
  echo "SASS audit unavailable: cuobjdump/nvdisasm not found"
  exit 0
fi

echo "===== SASS STATIC AUDIT ($DISASSEMBLER) ====="
for variant in "${VARIANTS[@]}"; do
  binary="$BIN/noid_daemon_$variant"
  [[ -x "$binary" ]] || { echo "missing $binary"; exit 1; }
  out="$BIN/sass/$variant.sass"
  if [[ "$(basename "$DISASSEMBLER")" == cuobjdump ]]; then
    "$DISASSEMBLER" --dump-sass "$binary" > "$out"
  else
    nvdisasm "$binary" > "$out"
  fi
  clmad=$(grep -Eic 'CLMAD\.' "$out" || true)
  lop3=$(grep -Eic 'LOP3\.' "$out" || true)
  shf=$(grep -Eic 'SHF\.' "$out" || true)
  regs=$(grep -m1 -Eo 'Used [0-9]+ registers' "$BIN/build_$variant.log" || true)
  printf '%-12s CLMAD=%-5s LOP3=%-5s SHF=%-5s %s\n' \
    "$variant" "$clmad" "$lop3" "$shf" "${regs:-resource log unavailable}"
done

NCU="${NCU:-/usr/local/cuda-13.3/bin/ncu}"
if [[ -x "$NCU" ]] || command -v ncu >/dev/null 2>&1; then
  cat <<'NOTE'

Nsight Compute is installed. To profile one real daemon launch, set:
  NOID_NCU_VARIANT=nonvolatile
  NOID_NCU_STDIN=$'JOB ...\nSTOP\n'
  ./ncu-audit.sh

The wrapper records a full report and uses Nsight Compute's section set so
metric names stay driver-version specific. The stdin must contain one valid
JOB line from the benchmark plus STOP.
NOTE
else
  echo "Nsight Compute (ncu) not installed; static SASS audit completed."
fi
