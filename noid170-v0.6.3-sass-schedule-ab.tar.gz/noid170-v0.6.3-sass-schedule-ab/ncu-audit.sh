#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin"
VARIANT="${NOID_NCU_VARIANT:-current}"
STDIN_DATA="${NOID_NCU_STDIN:-}"

NCU="${NCU:-/usr/local/cuda-13.3/bin/ncu}"
if [[ ! -x "$NCU" ]]; then
  NCU="$(command -v ncu || true)"
fi
[[ -n "$NCU" ]] || {
  echo "ERROR: ncu not found"
  exit 1
}
[[ -x "$BIN/noid_daemon_$VARIANT" ]] || {
  echo "ERROR: missing $BIN/noid_daemon_$VARIANT"
  exit 1
}
[[ -n "$STDIN_DATA" ]] || {
  echo "ERROR: set NOID_NCU_STDIN to a valid JOB line plus STOP"
  exit 1
}

mkdir -p "$BIN/ncu"
REPORT="$BIN/ncu/${VARIANT}.ncu-rep"
LOG="$BIN/ncu/${VARIANT}.log"

printf '%b' "$STDIN_DATA" | timeout --signal=INT 45s "$NCU" \
  --target-processes all \
  --set full \
  --launch-count 1 \
  --export "$REPORT" \
  "$BIN/noid_daemon_$VARIANT" --daemon 55001 2>&1 | tee "$LOG"

echo
echo "Nsight Compute report: $REPORT"
