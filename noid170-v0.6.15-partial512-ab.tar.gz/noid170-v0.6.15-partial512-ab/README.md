# NOID170 v0.6.15 — 512-thread partial-MDS ILP re-sweep

Correctness-gated CMP 170HX A/B benchmark. It does **not** install or replace
the HiveOS miner.

The current winner is the proven production math at 512 threads/block and
128 grid blocks per SM. The only variable in this package is the already-
implemented `NOID_PARTIAL_ILP` scheduling mode used by the 58 Poseidon partial
rounds:

- `scalar` = 0 — four scalar GF products/reductions
- `prod2`  = 1 — current production two-way product scheduling (baseline)
- `red2`   = 2 — scalar products, paired reduction scheduling
- `pair2`  = 3 — two complete GF multiplies batched at a time
- `quad4`  = 4 — all four complete GF multiplies batched together

All variants retain r4top reduction, r2lop3 square reduction, factorized full
MDS, paired/non-volatile CLMAD scheduling, 2 ms event polling, and the normal
Poseidon control flow.

Run:

```bash
cd /home/user/noid170-v0.6.15-partial512-ab
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-partial512.sh
```

Paste back `FINAL 512-THREAD PARTIAL-MDS ILP RANKING` and
`PARTIAL512 WINNER PROTOCOL: PASS`.
