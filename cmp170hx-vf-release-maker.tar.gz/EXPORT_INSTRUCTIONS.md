# Build the shareable binary-installer bundle

This small archive is an **exporter**, not the actual driver binaries. Run it on the rig already using the working auto-detect driver (`nvidia.ko` SHA256 `8f6d032edff7a88573800db950275d45d8fb86229554f867d8c7bfd5d63db0a7`). It copies the installed five NVIDIA modules into a standalone installer tarball.

```
tar -xzf cmp170hx-vf-release-maker.tar.gz -C /home/user
sudo bash /home/user/make_cmp170hx_vf_release.sh
```

The output file is:

`/home/user/cmp170hx-vf-autodetect-610.43.03-6.6.0-hiveos.tar.gz`

To install on a different **compatible** HiveOS CMPUnlocker rig:

```
tar -xzf cmp170hx-vf-autodetect-610.43.03-6.6.0-hiveos.tar.gz
cd cmp170hx-vf-autodetect
sudo bash install.sh
sudo reboot
```

There is **no automatic rollback and no automatic reboot**. The installer makes a passive backup of replaced files. Exact driver, kernel, and GPU compatibility checks are enforced. Read the full packaged README including proprietary VBIOS redistribution concerns before sharing publicly.
