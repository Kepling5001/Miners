#!/usr/bin/env bash
# Run on the validated reference HiveOS machine after all three 10GB cards work.
# Creates shareable precompiled installer tarball. No rollback, no install, no reboot.
set -Eeuo pipefail
[ "$(id -u)" -eq 0 ] || { echo 'ERROR: run as root'; exit 1; }
K='6.6.0-hiveos'; V='610.43.03'
[ "$(uname -r)" = "$K" ] || { echo 'ERROR: wrong kernel'; exit 1; }
MODS=(nvidia nvidia-uvm nvidia-modeset nvidia-drm nvidia-peermem)
SRC="/lib/modules/$K/updates/cmpunlocker"
EXPECTED='8f6d032edff7a88573800db950275d45d8fb86229554f867d8c7bfd5d63db0a7'
[ -f "$SRC/nvidia.ko" ] || { echo 'ERROR: CMPUnlocker module missing'; exit 1; }
[ "$(sha256sum "$SRC/nvidia.ko" | awk '{print $1}')" = "$EXPECTED" ] || { echo 'ERROR: not the verified three-card auto-detect build'; exit 1; }
# Bundled release payload is installed alongside the script; no external network needed.
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$HERE/cmp170hx_vf_release_payload.tar.gz" ] || { echo 'ERROR: release payload tar missing next to builder'; exit 1; }
STAGE="$(mktemp -d /home/user/.cmp170hx-release-XXXXXXXX)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/cmp170hx-vf-autodetect/modules"
tar -xzf "$HERE/cmp170hx_vf_release_payload.tar.gz" -C "$STAGE/cmp170hx-vf-autodetect" --no-same-owner
for m in "${MODS[@]}"; do
 [ -s "$SRC/$m.ko" ] || { echo "ERROR: missing $m"; exit 1; }
 [ "$(modinfo -F version "$SRC/$m.ko")" = "$V" ] || { echo "ERROR: wrong version $m"; exit 1; }
 [ "$(modinfo -F vermagic "$SRC/$m.ko")" = '6.6.0-hiveos SMP preempt mod_unload modversions ' ] || { echo "ERROR: ABI mismatch $m"; exit 1; }
 cp -a "$SRC/$m.ko" "$STAGE/cmp170hx-vf-autodetect/modules/$m.ko"
done
(cd "$STAGE/cmp170hx-vf-autodetect/modules" && sha256sum "${MODS[@]/%/.ko}" > SHA256SUMS)
OUT=/home/user/cmp170hx-vf-autodetect-610.43.03-6.6.0-hiveos.tar.gz
tar -czf "$OUT" -C "$STAGE" cmp170hx-vf-autodetect
ls -lh "$OUT"
sha256sum "$OUT"
echo 'RELEASE CREATED. No modules changed; no rollback; no reboot.'
