#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/bin/test_mds_factor"
python3 "$ROOT/benchmark_mds.py"
"$ROOT/test-persistent.sh"
