#!/usr/bin/env python3
import http.client, json, os, queue, subprocess, threading, time
from urllib.parse import urlsplit

ROOT=os.path.dirname(os.path.abspath(__file__))
BASE=os.path.join(ROOT,'bin','noid_live_job_daemon_baseline')
FACT=os.path.join(ROOT,'package','noid170','noid_live_job_daemon')
KEY=os.environ.get('NOID_MINING_KEY','').strip()
URL=os.environ.get('NOID_RPC_URL','https://pool.ariabrain.com/noid-rpc/')
if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u=urlsplit(URL); Conn=http.client.HTTPSConnection if u.scheme=='https' else http.client.HTTPConnection; path=u.path or '/'
def rpc(method,params):
    c=Conn(u.hostname,u.port,timeout=10)
    try:
        body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})
        c.request('POST',path,body=body,headers={'Content-Type':'application/json','Authorization':f'Bearer {KEY}','User-Agent':'noid170-mds-bench/0.3.0'})
        r=c.getresponse(); data=r.read()
        if r.status!=200: raise RuntimeError(f'HTTP {r.status}: {data.decode(errors="replace")}')
        return json.loads(data)
    finally: c.close()

def get_job(timeout=15):
    end=time.time()+timeout
    while time.time()<end:
        j=rpc('paranoid_getBlockTemplate',[''])
        if not j.get('error'): return j['result']
        e=j.get('error') or {}
        if isinstance(e,dict) and e.get('code')==-32011:
            time.sleep(max(.05,e.get('data',{}).get('retry_in_ms',500)/1000)); continue
        raise RuntimeError(e)
    raise RuntimeError('template timeout')

def run_one(label,binary,job):
    env=os.environ.copy(); env['CUDA_VISIBLE_DEVICES']='0'
    p=subprocess.Popen([binary,'--daemon','7001'],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
    q=queue.Queue()
    def rd():
        for line in p.stderr: q.put(line.strip())
    threading.Thread(target=rd,daemon=True).start()
    def wait(prefix,timeout=10):
        end=time.time()+timeout
        while time.time()<end:
            try: line=q.get(timeout=.5)
            except queue.Empty: continue
            if line.startswith(prefix): return line
        raise RuntimeError(f'{label}: timeout waiting for {prefix}')
    wait('READY ')
    hard='0100000000000000000000000000000000000000000000000000000000000000'
    p.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard}\n"); p.stdin.flush(); wait('JOBACK 1 ')
    stats=[]
    while len(stats)<7:
        line=wait('STAT ',timeout=8)
        parts=line.split()
        # STAT kernel hashes batch seq wall
        stats.append((float(parts[1]),float(parts[5])))
    p.stdin.write('STOP\n'); p.stdin.flush()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=3)
    use=stats[1:] # discard first warm sample
    k=sum(x for x,_ in use)/len(use); w=sum(y for _,y in use)/len(use)
    print(f'{label:10s} kernel={k:.3f} MH/s  wall={w:.3f} MH/s')
    return k,w

job=get_job()
print('===== MDS A/B BENCHMARK | GPU0 =====')
print('height:',job['height'])
bk,bw=run_one('baseline',BASE,job)
fk,fw=run_one('factorized',FACT,job)
print(f'kernel gain: {(fk/bk-1)*100:+.2f}%')
print(f'wall gain:   {(fw/bw-1)*100:+.2f}%')
