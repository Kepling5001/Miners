#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
PKG="$ROOT/package/noid170"
BIN="$ROOT/bin"
DIST="$ROOT/dist"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN" "$DIST"

echo "===== BUILD BASELINE v0.2.5 DAEMON ====="
"$NVCC" -O3 -arch=sm_80 -lineinfo -I"$SRC" -Xptxas=-v \
  "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_live_job_daemon_baseline"

echo
echo "===== BUILD FACTORIZED MDS DAEMON ====="
"$NVCC" -O3 -arch=sm_80 -lineinfo -I"$SRC" -DNOID_MDS_FACTORIZED=1 -Xptxas=-v \
  "$SRC/noid_live_job_daemon.cu" -o "$PKG/noid_live_job_daemon"
chmod +x "$PKG/noid_live_job_daemon"

echo
echo "===== BUILD MDS CORRECTNESS ORACLE ====="
"$NVCC" -O3 -arch=sm_80 -lineinfo -I"$SRC" -Xptxas=-v \
  "$ROOT/test_mds_factor.cu" -o "$BIN/test_mds_factor"

python3 -m py_compile "$PKG/noid170_aria.py"
bash -n "$PKG/h-config.sh"
bash -n "$PKG/h-run.sh"
bash -n "$PKG/h-stats.sh"

# Version labels only; controller/mining architecture otherwise stays v0.2.5.
sed -i 's/CUSTOM_VERSION="0.2.5"/CUSTOM_VERSION="0.3.0"/' "$PKG/h-manifest.conf"
sed -i 's/NOID170 v0\.2\.4 HiveOS wrapper/NOID170 v0.3.0 MDS-factorized HiveOS wrapper/' "$PKG/h-run.sh"

rm -rf "$DIST" "$PKG/__pycache__"
mkdir -p "$DIST"
tar -C "$ROOT/package" -czf "$DIST/noid170-0.3.0.tar.gz" noid170
sha256sum "$DIST/noid170-0.3.0.tar.gz" > "$DIST/noid170-0.3.0.tar.gz.sha256"

echo
echo "===== RELEASE ====="
ls -lh "$DIST"
echo
echo "BUILD COMPLETE: $DIST/noid170-0.3.0.tar.gz"
echo "NEXT: export NOID_MINING_KEY='address.worker' && ./test-mds.sh"
