#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#define NOID_MDS_FACTORIZED 1
#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e=(x); \
    if(e!=cudaSuccess){ \
        fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); \
        exit(1); \
    } \
} while(0)

__device__ __forceinline__
void poseidon_permute_generic_test(U128 s[4])
{
    apply_mds_full_generic(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_x7(s[i]);
            }
            apply_mds_full_generic(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);
            apply_mds_partial_generic(s);
        }
    }
}

__device__ __forceinline__
unsigned long long mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__global__
void oracle_kernel(unsigned int *errors)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;

    U128 seed[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const unsigned long long a = mix64(tid * 17ULL + i + 1ULL);
        const unsigned long long b = mix64(tid * 29ULL + i + 0x12345678ULL);
        seed[i] = {a, b};
    }

    U128 g[4], f[4];
    #pragma unroll
    for (int i=0;i<4;++i) { g[i]=seed[i]; f[i]=seed[i]; }
    apply_mds_full_generic(g);
    apply_mds_full_factorized(f);
    #pragma unroll
    for (int i=0;i<4;++i)
        if (g[i].lo != f[i].lo || g[i].hi != f[i].hi)
            atomicAdd(errors, 1U);

    #pragma unroll
    for (int i=0;i<4;++i) { g[i]=seed[i]; f[i]=seed[i]; }
    apply_mds_partial_generic(g);
    apply_mds_partial_factorized(f);
    #pragma unroll
    for (int i=0;i<4;++i)
        if (g[i].lo != f[i].lo || g[i].hi != f[i].hi)
            atomicAdd(errors, 1U);

    #pragma unroll
    for (int i=0;i<4;++i) { g[i]=seed[i]; f[i]=seed[i]; }
    poseidon_permute_generic_test(g);
    poseidon_permute(f);
    #pragma unroll
    for (int i=0;i<4;++i)
        if (g[i].lo != f[i].lo || g[i].hi != f[i].hi)
            atomicAdd(errors, 1U);
}

int main()
{
    unsigned int *d_errors=nullptr;
    CUDA_OK(cudaMalloc(&d_errors,sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors,0,sizeof(unsigned int)));

    oracle_kernel<<<16,64>>>(d_errors); // 1024 independent states
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    unsigned int errors=0;
    CUDA_OK(cudaMemcpy(&errors,d_errors,sizeof(errors),cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));

    printf("MDS FACTORIZATION ORACLE: %s (errors=%u)\n",
        errors ? "FAIL" : "PASS", errors);
    return errors ? 1 : 0;
}
