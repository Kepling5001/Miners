# NOID170 v0.3.0 experimental MDS factorization

This is based on the working v0.2.5 persistent/pipelined CUDA daemon.

Only the Poseidon2 linear layer math is changed:

- external/full M4: 10 GF(2^128) multiplies -> 4
- internal/partial MDS: same 4 multiplies, fewer XORs
- total general GF multiplies per Poseidon permutation: 502 -> 448 (-10.76%)

The external factorization is exact for the Parano1d GF(2^128) field. It uses
multiplication by tower elements 2 and 4 after conversion to the exact flat/GCM
basis constants used by v1.0.3.

## Build

```bash
./build-on-rig.sh
```

## Test

```bash
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-mds.sh
```

`test-mds.sh` does three things:

1. GPU oracle: generic vs factorized full MDS, partial MDS, and full Poseidon permutation on 1024 independent states.
2. GPU0 A/B benchmark: baseline v0.2.5 math vs factorized math using the same pipelined daemon.
3. Persistent Aria protocol test, including an accepted share when vardiff permits.

Do not deploy the release unless the oracle says PASS and the persistent protocol test says PASS.
