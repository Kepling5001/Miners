#!/usr/bin/env python3
import http.client, json, os, queue, re, statistics, subprocess, threading, time
from urllib.parse import urlsplit
ROOT=os.path.dirname(os.path.abspath(__file__)); BIN=os.path.join(ROOT,'bin')
KEY=os.environ.get('NOID_MINING_KEY','').strip(); URL=os.environ.get('NOID_RPC_URL','https://pool.ariabrain.com/noid-rpc/')
SAMPLES=max(6,int(os.environ.get('NOID_BENCH_STATS','12')))
VARIANTS=[('baseline','current red2 output XOR'),('sumfold_cpp','sum folded into raw product (C++)'),('sumfold_lop3','sum folded + explicit 3-input LOP3')]
if not KEY: raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")
u=urlsplit(URL); Conn=http.client.HTTPSConnection if u.scheme=='https' else http.client.HTTPConnection; path=u.path or '/'
def rpc(method,params):
    c=Conn(u.hostname,u.port,timeout=10)
    try:
        body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})
        c.request('POST',path,body=body,headers={'Content-Type':'application/json','Authorization':f'Bearer {KEY}','User-Agent':'noid170-sumfold-bench/0.6.25'})
        r=c.getresponse(); data=r.read()
        if r.status!=200: raise RuntimeError(f'HTTP {r.status}: {data.decode(errors="replace")}')
        return json.loads(data)
    finally: c.close()
def get_job(timeout=20):
    end=time.time()+timeout
    while time.time()<end:
        a=rpc('paranoid_getBlockTemplate',[''])
        if not a.get('error'): return a['result']
        e=a.get('error') or {}
        if isinstance(e,dict) and e.get('code')==-32011:
            time.sleep(max(.05,e.get('data',{}).get('retry_in_ms',500)/1000)); continue
        raise RuntimeError(e)
    raise RuntimeError('template timeout')
def resources(name):
    try: t=open(os.path.join(BIN,f'build_{name}.log'),errors='replace').read()
    except OSError: return None,None,None
    regs=re.findall(r'Used\s+(\d+)\s+registers',t); spills=re.findall(r'(\d+)\s+bytes spill stores,\s*(\d+)\s+bytes spill loads',t)
    if spills: ss,sl=map(int,spills[-1])
    else: ss=sl=None
    return (int(regs[-1]) if regs else None),ss,sl
def run_once(name,job,n):
    env=os.environ.copy(); env['CUDA_VISIBLE_DEVICES']='0'; q=queue.Queue()
    p=subprocess.Popen([os.path.join(BIN,f'noid_daemon_{name}'),'--daemon',str(0x6500+n)],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
    threading.Thread(target=lambda:[q.put(x.strip()) for x in p.stderr],daemon=True).start()
    def wait(pre,to=20):
        end=time.time()+to
        while time.time()<end:
            if p.poll() is not None: raise RuntimeError(f'{name}: exited {p.returncode}')
            try: x=q.get(timeout=.5)
            except queue.Empty: continue
            if x.startswith(pre): return x
        raise RuntimeError(f'{name}: timeout {pre}')
    try:
        wait('READY '); hard='01'+'00'*31
        p.stdin.write(f"JOB 1 {job['pow_fields_hex']} {hard}\n"); p.stdin.flush(); wait('JOBACK 1 ')
        vals=[]
        while len(vals)<SAMPLES:
            f=wait('STAT ').split(); vals.append((float(f[1]),float(f[5])))
        vals=vals[3:]; k=statistics.mean(x[0] for x in vals); w=statistics.mean(x[1] for x in vals)
        print(f'{name:14s} run{n:02d} kernel={k:8.3f} wall={w:8.3f} MH/s'); return k,w
    finally:
        if p.poll() is None:
            try: p.stdin.write('STOP\n'); p.stdin.flush(); p.wait(timeout=4)
            except Exception: p.terminate(); p.wait(timeout=4)
job=get_job(); print('===== RED2/512 PARTIAL-SUM-FOLD A/B | GPU0 ====='); print(f"height: {job['height']} samples/run: {SAMPLES} balanced forward/reverse")
meas={n:[] for n,_ in VARIANTS}; order=[n for n,_ in VARIANTS]+[n for n,_ in reversed(VARIANTS)]
for i,n in enumerate(order,1): meas[n].append(run_once(n,job,i))
rows=[]
for n,label in VARIANTS:
    k=statistics.mean(x[0] for x in meas[n]); w=statistics.mean(x[1] for x in meas[n]); r,ss,sl=resources(n); rows.append(dict(name=n,label=label,k=k,w=w,r=r,ss=ss,sl=sl))
base=next(x for x in rows if x['name']=='baseline'); ranked=sorted(rows,key=lambda x:x['w'],reverse=True)
print('\n===== FINAL RED2/512 SUM-FOLD RANKING =====')
print(f"{'rank':>4s} {'variant':14s} {'regs':>4s} {'spill S/L':>10s} {'kernel':>10s} {'wall':>10s} {'vs base':>9s}")
for i,x in enumerate(ranked,1):
    gain=(x['w']/base['w']-1)*100; regs='?' if x['r'] is None else str(x['r']); sp='?/?' if x['ss'] is None else f"{x['ss']}/{x['sl']}"
    print(f"{i:4d} {x['name']:14s} {regs:>4s} {sp:>10s} {x['k']:10.3f} {x['w']:10.3f} {gain:+8.2f}%")
win=ranked[0]; open(os.path.join(ROOT,'winner.txt'),'w').write(win['name']+'\n')
print(f"\nbaseline: {base['w']:.3f} MH/s\nwinner:   {win['name']} {win['w']:.3f} MH/s\ngain:     {(win['w']/base['w']-1)*100:+.2f}%")
