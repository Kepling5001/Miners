#!/usr/bin/env python3
import re, sys, collections, pathlib

if len(sys.argv) != 3:
    print(f"usage: {sys.argv[0]} FULL_SASS OUTDIR", file=sys.stderr)
    sys.exit(2)

sass_path = pathlib.Path(sys.argv[1])
outdir = pathlib.Path(sys.argv[2])
text = sass_path.read_text(errors='replace')

# cuobjdump sections normally begin with 'Function : <name>'.
parts = re.split(r'(?m)^\s*Function\s*:\s*', text)
sections = []
for p in parts[1:]:
    lines = p.splitlines()
    if not lines:
        continue
    name = lines[0].strip()
    body = '\n'.join(lines[1:]) + '\n'
    sections.append((name, body))

matches = [(n,b) for n,b in sections if 'mine_kernel' in n]
if not matches:
    # Fall back to any section containing the name in demangled comments/text.
    matches = [(n,b) for n,b in sections if 'mine_kernel' in b]

summary = []
summary.append("===== MINE_KERNEL SASS ANALYSIS =====")
summary.append(f"SASS source: {sass_path}")
summary.append(f"Functions found: {len(sections)}")
summary.append(f"mine_kernel matches: {len(matches)}")

if not matches:
    summary.append("ERROR: mine_kernel section not found. See functions.txt and full-sass.txt.")
    (outdir/'analysis.txt').write_text('\n'.join(summary)+'\n')
    (outdir/'functions.txt').write_text('\n'.join(n for n,_ in sections)+'\n')
    print('\n'.join(summary))
    sys.exit(1)

# Prefer the largest matching section if multiple template instantiations/symbol variants exist.
name, body = max(matches, key=lambda x: len(x[1]))
(outdir/'mine-kernel.sass').write_text(f"Function : {name}\n{body}")
(outdir/'functions.txt').write_text('\n'.join(n for n,_ in sections)+'\n')
summary.append(f"Selected function: {name}")

# SASS instruction examples generally contain /*addr*/ followed by optional predicate and opcode.
opcodes = collections.Counter()
inst_lines = []
for line in body.splitlines():
    if not re.search(r'/\*[0-9a-fA-F]+\*/', line):
        continue
    # Remove address prefix and optional predicate, then capture first token as opcode.
    after = re.sub(r'^.*?/\*[0-9a-fA-F]+\*/\s*', '', line, count=1)
    after = re.sub(r'^@!?P\d+\s+', '', after)
    m = re.match(r'([A-Z][A-Z0-9_.]*)\b', after)
    if not m:
        continue
    op = m.group(1)
    # Normalize modifiers so CLMAD.WIDE etc. group under CLMAD, LOP3.LUT under LOP3, etc.
    base = op.split('.')[0]
    opcodes[base] += 1
    inst_lines.append(line)

summary.append(f"Total decoded SASS instructions: {sum(opcodes.values())}")
summary.append("")
summary.append("===== TOP OPCODES =====")
for op,c in opcodes.most_common(40):
    summary.append(f"{op:12s} {c:8d}  {100.0*c/max(1,sum(opcodes.values())):6.2f}%")

families = {
    'CLMAD': ['CLMAD'],
    'LOP3': ['LOP3','ULOP3'],
    'SHF/SHL/SHR': ['SHF','SHL','SHR','USHF'],
    'IADD/IMAD': ['IADD3','IADD','IMAD','UIADD3','UIMAD'],
    'LOAD': ['LDG','LDL','LDS','LDC','ULDC'],
    'STORE': ['STG','STL','STS'],
    'BRANCH/CTRL': ['BRA','BRX','JMP','CALL','RET','EXIT','BSSY','BSYNC'],
    'MOVE/SELECT': ['MOV','UMOV','SEL','PRMT'],
}
summary.append("")
summary.append("===== KEY FAMILIES =====")
for label, ops in families.items():
    c = sum(opcodes[o] for o in ops)
    summary.append(f"{label:14s} {c:8d}  {100.0*c/max(1,sum(opcodes.values())):6.2f}%")

# Dependency-oriented crude structural signals useful without performance counters.
summary.append("")
summary.append("===== STRUCTURAL SIGNALS =====")
summary.append(f"CLMAD count: {opcodes['CLMAD']}")
summary.append(f"LOP3+ULOP3 count: {opcodes['LOP3'] + opcodes['ULOP3']}")
summary.append(f"Branch count: {opcodes['BRA'] + opcodes['BRX'] + opcodes['JMP']}")
summary.append(f"Constant loads (LDC+ULDC): {opcodes['LDC'] + opcodes['ULDC']}")
summary.append(f"Global loads/stores: {opcodes['LDG'] + opcodes['STG']}")
summary.append(f"Local loads/stores (spill proxy): {opcodes['LDL'] + opcodes['STL']}")
summary.append("")
summary.append("NOTE: Static counts do not measure stall cycles. They tell us what execution resources/dependency chains are plausible targets; live counters are unavailable on CMP by NVIDIA design.")

(outdir/'analysis.txt').write_text('\n'.join(summary)+'\n')
with (outdir/'opcode-counts.csv').open('w') as f:
    f.write('opcode,count\n')
    for op,c in opcodes.most_common():
        f.write(f'{op},{c}\n')
print('\n'.join(summary))
