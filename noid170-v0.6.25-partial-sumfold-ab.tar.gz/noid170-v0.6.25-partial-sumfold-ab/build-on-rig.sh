#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"
COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41 -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3 -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1 -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1 -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 -Xptxas=-v
)
build_variant(){
  local name="$1" fold="$2"
  echo
  echo "===== BUILD $name | RED2/512 PARTIAL_SUM_FOLD=$fold ====="
  "$NVCC" "${COMMON[@]}" -DNOID_PARTIAL_SUM_FOLD="$fold" \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"
  "$NVCC" "${COMMON[@]}" -DNOID_PARTIAL_SUM_FOLD="$fold" \
    "$ROOT/test_gf_primitives.cu" -o "$BIN/test_gf_$name" 2>&1 | tee "$BIN/build_test_gf_$name.log"
  chmod 755 "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}
python3 "$ROOT/offline_verify.py"
build_variant baseline 0
build_variant sumfold_cpp 1
build_variant sumfold_lop3 2
python3 -m py_compile "$ROOT/benchmark_sumfold.py" "$ROOT/test-persistent.py" "$ROOT/sass-audit.py"
bash -n "$ROOT/test-sumfold.sh" "$ROOT/test-persistent.sh" "$ROOT/build-on-rig.sh"
echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-sumfold.sh"
