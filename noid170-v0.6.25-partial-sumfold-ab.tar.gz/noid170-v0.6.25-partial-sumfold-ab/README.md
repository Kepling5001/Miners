# NOID170 v0.6.25 — partial-MDS sum-fold A/B

Correctness-gated CMP170HX experiment. It does **not** install or replace the live HiveOS miner.

The baseline is the exact proven v0.6.22/v0.6.23 GPU math:
- 512 threads / 128 grid blocks per SM
- `red2` partial MDS (`NOID_PARTIAL_ILP=2`)
- r4top general reduction
- square reducer 3 + LOP3
- original four-stage x^7
- factorized full MDS
- paired, non-volatile CLMAD
- no register cap

## Why this test exists

The CUDA 13.3 SASS profile showed the hot kernel is almost entirely CLMAD + LOP3 + SHF and has zero spills. In every partial MDS round the baseline computes four fixed field products, reduces them, then XORs the common `sum` into each result.

GF(2^128) reduction is linear. Therefore `reduce(raw_product ^ sum) == reduce(raw_product) ^ sum` when `sum` is placed in the low 128 bits of the raw product. The candidate folds `sum` into the raw product *before* the existing paired r4top reduction. This allows `p0.hi ^ pm.lo ^ sum.hi` to become one three-input LOP3 instead of a product-assembly XOR followed later by an output XOR.

Variants:
- `baseline` — exact current red2 path.
- `sumfold_cpp` — pre-reduction sum fold with normal C++ XOR expression.
- `sumfold_lop3` — same algebra, but explicitly encodes the three-input 64-bit XOR as two `lop3.b32` instructions.

No CLMAD count is intentionally changed. The goal is fewer Boolean glue instructions and possibly a shorter dependency/lifetime path.

## Run

```bash
cd /home/user/noid170-v0.6.25-partial-sumfold-ab
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-sumfold.sh
miner start
```

Paste back:
1. `STATIC SASS AUDIT`
2. `FINAL RED2/512 SUM-FOLD RANKING`
3. `SUM-FOLD WINNER PROTOCOL: PASS`
