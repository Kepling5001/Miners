#include <iostream>
#include <string>
#include <cstdint>
#include "libethcore/EthashAux.h"
#include "libdevcore/CommonData.h"

using namespace dev;
using namespace eth;

int main(int argc, char** argv) {
    if (argc != 4) {
        std::cerr << "usage: abelmix <epoch> <contenthash_hex> <nonce_hex>\n";
        return 1;
    }

    int epoch = std::stoi(argv[1]);

    std::string header = argv[2];
    if (header.rfind("0x", 0) == 0) header = header.substr(2);

    std::string nonceHex = argv[3];
    if (nonceHex.rfind("0x", 0) == 0) nonceHex = nonceHex.substr(2);

    h256 headerHash(header);
    uint64_t nonce = std::stoull(nonceHex, nullptr, 16);

    Result r = EthashAux::eval(epoch, headerHash, nonce);
    std::cout << r.mixHash.hex() << std::endl;
    return 0;
}
