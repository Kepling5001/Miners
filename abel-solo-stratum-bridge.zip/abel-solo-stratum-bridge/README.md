# Abel Solo Stratum Bridge

Experimental bridge:

```text
Rigel miner -> AbelianStratum bridge -> abec getwork/submitwork
```

## Build

```bash
apt update
apt install -y git build-essential libboost-all-dev python3

git clone https://github.com/pqabelian/abelian-ethash-gpu-miner
cd abelian-ethash-gpu-miner
git submodule update --init --recursive
```

Copy these files into the repo root:

```text
abel_stratum_bridge.py
abelmix.cpp
build_abelmix.sh
```

Then:

```bash
chmod +x build_abelmix.sh abel_stratum_bridge.py
./build_abelmix.sh
```

## abec config

`/root/.abec/abec.conf` needs:

```ini
enablegetwork=1
externalgenerate=true
rpclistengetwork=0.0.0.0:8668
rpcuser=YOUR_RPC_USER
rpcpass=YOUR_RPC_PASS
miningaddr=YOUR_ABELIAN_RECEIVE_ADDRESS
```

Payout comes from `miningaddr`, not the Rigel username.

## Test mode

Easy target; should submit fast and abec should reject target boundary. This proves submit plumbing:

```bash
python3 abel_stratum_bridge.py --abec-host 10.10.0.149 --abec-user kepling5001 --abec-pass moocow12
```

## Production mode

Real solo target:

```bash
python3 abel_stratum_bridge.py --abec-host 10.10.0.149 --abec-user kepling5001 --abec-pass moocow12 --real-target
```

Point Rigel:

```bash
./rigel -a abel -o stratum+tcp://BRIDGE_IP:3333 -u rig1 -p x
```

`mining.noop` is normal.
