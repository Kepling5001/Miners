#!/usr/bin/env python3
import argparse
import base64
import json
import socket
import subprocess
import threading
import time
import urllib.request

JOBS = {}
LOCK = threading.Lock()

def strip0x(x):
    return str(x).replace("0x", "").lower()

def rpc(args, method, params):
    body = json.dumps({"id": 1, "jsonrpc": "2.0", "method": method, "params": params}).encode()
    auth = base64.b64encode(f"{args.abec_user}:{args.abec_pass}".encode()).decode()
    req = urllib.request.Request(
        f"http://{args.abec_host}:{args.abec_port}",
        data=body,
        headers={"Content-Type": "application/json", "Authorization": "Basic " + auth},
    )
    return json.loads(urllib.request.urlopen(req, timeout=10).read())

def abec_getwork(args):
    r = rpc(args, "getwork", [""])
    if r.get("error"):
        raise RuntimeError(r["error"])
    return r["result"]

def abec_submitwork(args, full_jobid, nonce, mixhash):
    return rpc(args, "submitwork", [full_jobid, "0x" + strip0x(nonce), "0x" + strip0x(mixhash)])

def calc_mix(args, epoch, contenthash, nonce):
    return subprocess.check_output(
        [args.abelmix, str(epoch), strip0x(contenthash), strip0x(nonce)],
        text=True,
    ).strip()

def send(conn, obj):
    msg = json.dumps(obj, separators=(",", ":")) + "\n"
    print("SEND:", msg, end="", flush=True)
    conn.sendall(msg.encode())

def send_job(args, conn):
    gw = abec_getwork(args)
    short = gw["jobid"][:8]
    with LOCK:
        JOBS[short] = gw

    target = strip0x(gw["targetboundary"]) if args.real_target else args.test_target

    send(conn, {"id": None, "method": "mining.set", "params": {
        "epoch": format(int(gw["epoch"]), "x"),
        "target": target,
        "algo": "abelhash",
        "extranonce": format(int(gw["extranonce"]), "04x"),
        "extra_nonce_bits_num": format(int(gw["extranoncebitsnum"]), "x"),
    }})

    send(conn, {"id": None, "method": "mining.notify", "params": {
        "job_id": short,
        "height": args.height_hex,
        "content_hash": strip0x(gw["contenthash"]),
        "clean_job": "1",
    }})

    print("JOB SENT:", short, gw["jobid"], flush=True)

def handle(args, conn, addr):
    print("CONNECT", addr, flush=True)
    while True:
        data = conn.recv(4096)
        if not data:
            print("DISCONNECT", addr, flush=True)
            return

        text = data.decode(errors="replace")
        print("RECV:", text, end="", flush=True)

        for line in text.splitlines():
            try:
                req = json.loads(line)
            except Exception:
                continue

            rid = req.get("id")
            method = req.get("method")

            if method == "mining.hello":
                send(conn, {"id": rid, "result": {
                    "proto": "AbelianStratum",
                    "encoding": "plain",
                    "resume": "0",
                    "timeout": "258",
                    "maxerrors": "a",
                    "node": "Abec-v3.0.1/SoloBridge-v0.1/linux-amd64",
                }, "error": None})

            elif method == "mining.subscribe":
                send(conn, {"id": rid, "result": {"session_id": "s-solo0001"}, "error": None})

            elif method == "mining.authorize":
                worker = req.get("params", ["unknown"])[0]
                send(conn, {"id": rid, "result": {"worker": worker, "registered": "0"}, "error": None})
                time.sleep(0.5)
                send_job(args, conn)

            elif method == "mining.noop":
                send(conn, {"id": rid, "result": True, "error": None})

            elif method == "mining.submit":
                params = req.get("params", [])
                print("SUBMIT:", params, flush=True)

                if len(params) < 2:
                    send(conn, {"id": rid, "result": False, "error": "bad submit params"})
                    continue

                short_jobid, nonce = params[0], params[1]
                with LOCK:
                    gw = JOBS.get(short_jobid)

                if not gw:
                    send(conn, {"id": rid, "result": False, "error": "unknown job"})
                    continue

                try:
                    mix = calc_mix(args, gw["epoch"], gw["contenthash"], nonce)
                    print("MIX:", mix, flush=True)

                    resp = abec_submitwork(args, gw["jobid"], nonce, mix)
                    print("ABEC SUBMIT RESP:", resp, flush=True)

                    if resp.get("error"):
                        send(conn, {"id": rid, "result": False, "error": resp["error"]})
                    else:
                        send(conn, {"id": rid, "result": resp.get("result", True), "error": None})
                except Exception as e:
                    print("SUBMIT ERROR:", repr(e), flush=True)
                    send(conn, {"id": rid, "result": False, "error": str(e)})

def parse_args():
    p = argparse.ArgumentParser(description="Abelian solo Stratum bridge for Rigel to abec getwork/submitwork")
    p.add_argument("--abec-host", default="10.10.0.149")
    p.add_argument("--abec-port", type=int, default=8668)
    p.add_argument("--abec-user", default="kepling5001")
    p.add_argument("--abec-pass", default="moocow12")
    p.add_argument("--listen", default="0.0.0.0")
    p.add_argument("--port", type=int, default=3333)
    p.add_argument("--abelmix", default="./abelmix")
    p.add_argument("--real-target", action="store_true", help="production solo mode")
    p.add_argument("--test-target", default="00000001ffff0000000000000000000000000000000000000000000000000000")
    p.add_argument("--height-hex", default="80f00")
    return p.parse_args()

def main():
    args = parse_args()
    server = socket.socket()
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((args.listen, args.port))
    server.listen(50)

    print(f"ABEL SOLO STRATUM BRIDGE listening on {args.listen}:{args.port}", flush=True)
    print("REAL TARGET =", args.real_target, flush=True)

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle, args=(args, conn, addr), daemon=True).start()

if __name__ == "__main__":
    main()
