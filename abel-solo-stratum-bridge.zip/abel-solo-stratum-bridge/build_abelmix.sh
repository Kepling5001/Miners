#!/usr/bin/env bash
set -euo pipefail

# Run from root of pqabelian/abelian-ethash-gpu-miner after:
# git submodule update --init --recursive

gcc -O2 -I./thirdparty/abelethash/include \
  -c thirdparty/abelethash/lib/ethash/primes.c -o primes.o

gcc -O2 -I./thirdparty/abelethash/include \
  -c thirdparty/abelethash/lib/keccak/keccak.c -o keccak.o

g++ -std=c++14 -O2 \
  -include cstdint \
  -I. \
  -I./libethcore \
  -I./libdevcore \
  -I./thirdparty/abelethash/include \
  abelmix.cpp \
  libethcore/EthashAux.cpp \
  libdevcore/CommonData.cpp \
  libdevcore/FixedHash.cpp \
  thirdparty/abelethash/lib/ethash/ethash.cpp \
  thirdparty/abelethash/lib/global_context/global_context.cpp \
  primes.o keccak.o \
  -o abelmix

echo "Built ./abelmix"
