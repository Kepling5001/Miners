# NOID170 v0.6.20 red2/512 X^7 S-box re-sweep

Correctness-gated CMP 170HX A/B package. It does **not** install or replace the live HiveOS miner.

## Exact baseline held fixed

- 512 threads / 128 grid blocks per SM
- partial-MDS `red2` (`NOID_PARTIAL_ILP=2`)
- general reduction `r4top` (`NOID_REDUCE_VARIANT=41`)
- square reducer variant 3 + explicit LOP3 folding
- paired non-volatile CLMAD scheduling
- factorized full MDS
- 2 ms CUDA event polling

The only build-time variable is the existing `NOID_SBOX_FUSE_VARIANT` X^7 path.

## Variants

- `current` / 0 — proven four-stage X^7 path
- `fused` / 1 — interleaves raw x^4 and x^3 branch products
- `fusedpair` / 2 — fused branch schedule with paired asm
- `lazy3` / 3 — keeps x^3 as a wider product and performs a later exact fold
- `lazy3lop3` / 4 — same lazy path with explicit LOP3 final folding

All five use the same v0.6.19 source/header; there is no candidate-only helper code added to the math header. Every binary must pass the GPU GF/S-box/Poseidon oracle before benchmarking. Benchmark is balanced forward/reverse and the measured winner must produce a network-accepted share.

## Run

```bash
cd /home/user/noid170-v0.6.20-x7-red2-512-ab
./build-on-rig.sh
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-x7.sh
miner start
```

Paste back `FINAL RED2/512 X7 S-BOX RANKING` and `X7-RED2 WINNER PROTOCOL: PASS`.
