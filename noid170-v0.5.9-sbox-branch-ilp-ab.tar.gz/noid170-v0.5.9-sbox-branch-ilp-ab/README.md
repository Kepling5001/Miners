# noid170 v0.5.9 intra-S-box branch ILP A/B

This experiment keeps the proven v0.5.6 `prod2 + r4top` production kernel and
targets the independent middle branches of every x^7 S-box:

```text
x2 = square(x)
x4 = square(x2)       independent after x2
x6 = multiply(x, x2)  independent after x2
x7 = multiply(x6, x4)
```

Variants test raw product/reduction splitting, explicit heterogeneous CLMAD
interleaving, batched reductions, and the alternative serial
`x2 -> x3 -> x6 -> x7` addition chain. Both 1024- and 512-thread launches are
included for the interleaved schedules. Every launch covers 4,587,520 hashes
per kernel on a 70-SM CMP170HX.

```bash
cd /home/user/noid170-v0.5.9-sbox-branch-ilp-ab
miner stop
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-sbox-branch.sh
```

The script runs offline verification, a GPU oracle for every arithmetic path,
balanced forward/reverse timing, and an accepted-share persistent test using
the measured winner.
