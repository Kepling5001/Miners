#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1
  -DNOID_DUAL_VARIANT=1
  -DNOID_FULL_SBOX_ILP=0
  -DNOID_FULL_MDS_ILP=0
  -DNOID_STAT_BATCHES=8
  -Xptxas=-v
)

build_variant() {
  local name="$1"
  local sbox_variant="$2"
  local threads="$3"
  local blocks_per_sm="$4"

  echo
  echo "===== BUILD $name | sbox=$sbox_variant threads=$threads blocks/sm=$blocks_per_sm ====="
  "$NVCC" "${COMMON[@]}" \
    -DNOID_SBOX_VARIANT="$sbox_variant" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$SRC/noid_live_job_daemon.cu" \
    -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"

  "$NVCC" "${COMMON[@]}" \
    -DNOID_SBOX_VARIANT="$sbox_variant" \
    -DNOID_THREADS="$threads" \
    -DNOID_BLOCKS_PER_SM="$blocks_per_sm" \
    "$ROOT/test_gf_primitives.cu" \
    -o "$BIN/test_gf_$name"

  chmod +x "$BIN/noid_daemon_$name" "$BIN/test_gf_$name"
}

build_variant current   0 1024 64
build_variant split     1 1024 64
build_variant interprod 2 1024 64
build_variant interfull 3 1024 64
build_variant chain3    4 1024 64
build_variant iprod512  2  512 128
build_variant ifull512  3  512 128

python3 "$ROOT/offline_verify.py"
python3 -m py_compile \
  "$ROOT/benchmark_sbox_branch.py" \
  "$ROOT/test-persistent.py"
bash -n "$ROOT/test-sbox-branch.sh" "$ROOT/test-persistent.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_gf_*
echo
echo "Next: export NOID_MINING_KEY='address.worker' && ./test-sbox-branch.sh"
