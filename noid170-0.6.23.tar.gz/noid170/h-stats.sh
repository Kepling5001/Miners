#!/usr/bin/env bash

NOID170_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NOID_STATS_FILE="/run/noid170/stats.json"

out=$(NOID_STATS_FILE="$NOID_STATS_FILE" python3 "$NOID170_DIR/hive_stats.py" 2>/dev/null)
khs=$(printf '%s\n' "$out" | sed -n '1p')
stats=$(printf '%s\n' "$out" | sed -n '2p')

[[ "$khs" =~ ^[0-9]+([.][0-9]+)?$ ]] || khs=0
[[ -n "$stats" ]] || stats='{"hs":[],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"0.6.23","ar":[0,0],"algo":"noid","bus_numbers":[]}'
