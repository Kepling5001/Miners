#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

__device__ __forceinline__
unsigned long long accum_mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__device__ __forceinline__
bool accum_different(U128 a, U128 b)
{
    return a.lo != b.lo || a.hi != b.hi;
}

template <bool Accum>
__device__ __forceinline__
U128 mul_test(U128 a, U128 b)
{
    return Accum ? gf_mul_accum(a, b) : gf_mul_current(a, b);
}

template <bool Accum>
__device__ __forceinline__
U128 sbox_test(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const U128 x4 = square_flat_clmad(x2);
    const U128 x6 = mul_test<Accum>(x, x2);
    return mul_test<Accum>(x6, x4);
}

template <bool Accum>
__device__ __forceinline__
void full_mds_test(U128 s[4])
{
    const U128 mul2{
        0x7573da4a5f7710edULL,
        0x3d5bd35c94646a24ULL
    };
    const U128 mul4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };
    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(mul_test<Accum>(mul2, b), t1);
    const U128 t3 = bxor(mul_test<Accum>(mul2, d), t0);
    const U128 t4 = bxor(mul_test<Accum>(mul4, t1), t3);
    const U128 t5 = bxor(mul_test<Accum>(mul4, t0), t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

template <bool Accum>
__device__ __forceinline__
void partial_mds_test(U128 s[4])
{
    const U128 diagonal[4] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };
    const U128 sum = bxor(bxor(s[0], s[1]), bxor(s[2], s[3]));
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = bxor(sum, mul_test<Accum>(diagonal[i], s[i]));
}

template <bool Accum>
__device__ __forceinline__
void poseidon_test(U128 s[4])
{
    full_mds_test<Accum>(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r < NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_test<Accum>(s[i]);
            }
            full_mds_test<Accum>(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_test<Accum>(s[0]);
            partial_mds_test<Accum>(s);
        }
    }
}

__global__
void accum_oracle_kernel(unsigned int *errors)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
    U128 seed[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        seed[i] = {
            accum_mix64(tid * 17ULL + i + 1ULL),
            accum_mix64(tid * 29ULL + i + 0x12345678ULL)
        };
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const U128 other = seed[(i + 1) & 3];
        if (accum_different(
                mul_test<false>(seed[i], other),
                mul_test<true>(seed[i], other)))
            atomicAdd(&errors[0], 1U);

        if (accum_different(
                sbox_test<false>(seed[i]),
                sbox_test<true>(seed[i])))
            atomicAdd(&errors[1], 1U);
    }

    U128 current[4], accum[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        current[i] = accum[i] = seed[i];

    poseidon_test<false>(current);
    poseidon_test<true>(accum);
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        if (accum_different(current[i], accum[i]))
            atomicAdd(&errors[2], 1U);
    }

    #pragma unroll 1
    for (int pass = 1; pass < 3; ++pass) {
        const U128 absorb0{
            accum_mix64(tid + 0x1000ULL * pass),
            accum_mix64(tid + 0x2000ULL * pass)
        };
        const U128 absorb1{
            accum_mix64(tid + 0x3000ULL * pass),
            accum_mix64(tid + 0x4000ULL * pass)
        };
        current[0] = bxor(current[0], absorb0);
        current[1] = bxor(current[1], absorb1);
        accum[0] = bxor(accum[0], absorb0);
        accum[1] = bxor(accum[1], absorb1);
        poseidon_test<false>(current);
        poseidon_test<true>(accum);

        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            if (accum_different(current[i], accum[i]))
                atomicAdd(&errors[3], 1U);
        }
    }
}

int main()
{
    unsigned int *d_errors = nullptr;
    CUDA_OK(cudaMalloc(&d_errors, 4 * sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors, 0, 4 * sizeof(unsigned int)));
    accum_oracle_kernel<<<16, 64>>>(d_errors);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    unsigned int errors[4] = {};
    CUDA_OK(cudaMemcpy(errors, d_errors, sizeof(errors),
                       cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));
    const unsigned int total =
        errors[0] + errors[1] + errors[2] + errors[3];

    printf("CLMAD ACCUMULATOR ORACLE: %s "
           "(mul=%u sbox=%u poseidon=%u chain=%u total=%u)\n",
           total ? "FAIL" : "PASS", errors[0], errors[1], errors[2],
           errors[3], total);
    return total ? 1 : 0;
}
