# noid170 v0.5.2 CPU/batch and template-ID experiment

This is an isolated test package. It does not replace the v0.5.1 HiveOS
installation.

## Why this exists

On the two-thread Octominer host, four v0.5.1 GPU daemons consume about 80% of
one CPU core and contribute to 16k-18k interrupts plus 32k-41k context switches
per second. The host reaches 0% idle and wall hashrate falls below kernel
hashrate. All observed submitted stales were `current-template`, with no queue,
HTTP, old-height, or old-template failures.

## Stage 1: multi-GPU CPU/batch sweep

Five exact accumulator-CLMAD miners are built:

- `b32s8`: current v0.5.1, 32 blocks/SM and STAT every 8 batches
- `b32s32`: same batch, quieter STAT output
- `b64s32`: 2x batch
- `b96s32`: 3x batch
- `b128s32`: 4x batch

The sweep runs every detected GPU simultaneously with an impossibly hard
target, so it submits no shares. It records total kernel/wall MH/s, daemon CPU,
whole-system busy percentage, interrupts/sec, context switches/sec, and TAG/FULL
job-ack latency.

```bash
miner stop
cd /home/user/noid170-v0.5.2-cpu-id-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-cpu-sweep.sh
```

Paste the final comparison table into the chat before Stage 2. Restart mining
with `miner start` if you are pausing between tests.

## Stage 2: freshest-compatible template ID

The experimental controller rebinds the newest compatible request-scoped
template ID without sending a healthy GPU job update. If the pool has already
invalidated a sequence, it performs one cheap TAG refresh. This test submits
real shares for ten minutes by default.

After selecting the batch winner from Stage 1:

```bash
miner stop
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
export NOID_TEST_VARIANT='b64s32'
./test-fresh-id.sh
miner start
```

The variant shown above is only a placeholder until the Stage 1 measurements
are reviewed. Override duration with `NOID_ID_TEST_SECONDS=900` and polling with
`NOID_ID_POLL_INTERVAL=0.10` only when requested.
