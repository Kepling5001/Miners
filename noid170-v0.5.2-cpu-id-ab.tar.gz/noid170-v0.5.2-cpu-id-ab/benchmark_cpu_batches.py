#!/usr/bin/env python3

import http.client
import json
import os
import statistics
import subprocess
import threading
import time
from urllib.parse import urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
KEY = os.environ.get("NOID_MINING_KEY", "").strip()
URL = os.environ.get("NOID_RPC_URL", "https://pool.ariabrain.com/noid-rpc/")
MEASURE_SECONDS = max(6.0, float(os.environ.get("NOID_SWEEP_SECONDS", "12")))

VARIANTS = [
    ("b32s8", 32, 8),
    ("b32s32", 32, 32),
    ("b64s32", 64, 32),
    ("b96s32", 96, 32),
    ("b128s32", 128, 32),
]

if not KEY:
    raise SystemExit("ERROR: export NOID_MINING_KEY='address.worker' first")

u = urlsplit(URL)
Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
rpc_path = u.path or "/"


def rpc(method, params):
    conn = Conn(u.hostname, u.port, timeout=10)
    try:
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        conn.request(
            "POST",
            rpc_path,
            body=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {KEY}",
                "User-Agent": "noid170-cpu-batch-sweep/0.5.2",
            },
        )
        response = conn.getresponse()
        data = response.read()
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {data.decode(errors='replace')}")
        return json.loads(data)
    finally:
        conn.close()


def get_job(timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        answer = rpc("paranoid_getBlockTemplate", [""])
        if not answer.get("error"):
            return answer["result"]
        error = answer.get("error") or {}
        if isinstance(error, dict) and error.get("code") == -32011:
            retry_ms = error.get("data", {}).get("retry_in_ms", 500)
            time.sleep(max(0.05, retry_ms / 1000.0))
            continue
        raise RuntimeError(error)
    raise RuntimeError("template timeout")


def detect_gpus():
    override = os.environ.get("NOID_SWEEP_GPUS", "").strip()
    if override:
        count = int(override)
        if count < 1:
            raise RuntimeError("NOID_SWEEP_GPUS must be >= 1")
        return count
    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    return len([line for line in p.stdout.splitlines() if line.strip()])


def system_snapshot():
    cpu = None
    intr = ctxt = 0
    with open("/proc/stat", "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("cpu "):
                values = [int(x) for x in line.split()[1:]]
                total = sum(values)
                idle = values[3] + (values[4] if len(values) > 4 else 0)
                cpu = (total, idle)
            elif line.startswith("intr "):
                intr = int(line.split()[1])
            elif line.startswith("ctxt "):
                ctxt = int(line.split()[1])
    if cpu is None:
        raise RuntimeError("cannot read aggregate CPU counters")
    return cpu[0], cpu[1], intr, ctxt


def process_cpu_ticks(pid):
    with open(f"/proc/{pid}/stat", "r", encoding="utf-8") as handle:
        data = handle.read()
    tail = data.rsplit(")", 1)[1].split()
    return int(tail[11]) + int(tail[12])


class DaemonGroup:
    def __init__(self, binary, gpu_count):
        self.binary = binary
        self.gpu_count = gpu_count
        self.procs = []
        self.condition = threading.Condition()
        self.ready = set()
        self.acks = {}
        self.stats = [[] for _ in range(gpu_count)]
        self.errors = []

    def _stderr_reader(self, gpu, proc):
        for raw in proc.stderr:
            line = raw.strip()
            now = time.monotonic()
            with self.condition:
                if line.startswith("READY "):
                    self.ready.add(gpu)
                elif line.startswith("JOBACK "):
                    parts = line.split()
                    if len(parts) >= 3:
                        try:
                            seq = int(parts[1])
                            self.acks.setdefault(seq, {})[gpu] = (now, parts[2])
                        except ValueError:
                            pass
                elif line.startswith("STAT "):
                    parts = line.split()
                    if len(parts) >= 6:
                        try:
                            self.stats[gpu].append((now, float(parts[1]), float(parts[5])))
                        except ValueError:
                            pass
                elif line:
                    self.errors.append((gpu, line))
                self.condition.notify_all()

    @staticmethod
    def _stdout_reader(proc):
        for _line in proc.stdout:
            pass

    def start(self):
        for gpu in range(self.gpu_count):
            env = os.environ.copy()
            env["CUDA_VISIBLE_DEVICES"] = str(gpu)
            proc = subprocess.Popen(
                [self.binary, "--daemon", str(0x520000 + gpu)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                env=env,
            )
            self.procs.append(proc)
            threading.Thread(target=self._stderr_reader, args=(gpu, proc), daemon=True).start()
            threading.Thread(target=self._stdout_reader, args=(proc,), daemon=True).start()
        self.wait_until(lambda: len(self.ready) == self.gpu_count, 20, "READY")

    def wait_until(self, predicate, timeout, label):
        deadline = time.monotonic() + timeout
        with self.condition:
            while not predicate():
                for proc in self.procs:
                    if proc.poll() is not None:
                        raise RuntimeError(f"daemon exited while waiting for {label}: {proc.returncode}")
                remain = deadline - time.monotonic()
                if remain <= 0:
                    raise RuntimeError(f"timeout waiting for {label}")
                self.condition.wait(min(0.25, remain))

    def send_job(self, seq, pow_hex, target_hex):
        start = time.monotonic()
        line = f"JOB {seq} {pow_hex} {target_hex}\n"
        for proc in self.procs:
            proc.stdin.write(line)
            proc.stdin.flush()
        self.wait_until(
            lambda: len(self.acks.get(seq, {})) == self.gpu_count,
            10,
            f"JOBACK {seq}",
        )
        ack_map = self.acks[seq]
        finish = max(item[0] for item in ack_map.values())
        modes = sorted(set(item[1] for item in ack_map.values()))
        return (finish - start) * 1000.0, "/".join(modes)

    def clear_stats(self):
        with self.condition:
            self.stats = [[] for _ in range(self.gpu_count)]

    def stop(self):
        for proc in self.procs:
            if proc.poll() is None:
                try:
                    proc.stdin.write("STOP\n")
                    proc.stdin.flush()
                except Exception:
                    pass
        for proc in self.procs:
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                proc.terminate()
                proc.wait(timeout=4)


def mutate_pow(pow_hex):
    first = "1" if pow_hex[0] != "1" else "2"
    return first + pow_hex[1:]


def run_variant(name, blocks_per_sm, stat_batches, job, gpu_count):
    binary = os.path.join(BIN, f"noid_daemon_{name}")
    if not os.path.exists(binary):
        raise RuntimeError(f"missing binary: {binary}")

    group = DaemonGroup(binary, gpu_count)
    try:
        group.start()
        hard_target = "01" + "00" * 31
        group.send_job(1, job["pow_fields_hex"], hard_target)

        # The slowest b128/stat32 variant reports about every four seconds.
        time.sleep(4.5)
        group.clear_stats()

        clock_ticks = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
        proc_start = sum(process_cpu_ticks(proc.pid) for proc in group.procs)
        sys_start = system_snapshot()
        started = time.monotonic()
        time.sleep(MEASURE_SECONDS)
        elapsed = time.monotonic() - started
        sys_end = system_snapshot()
        proc_end = sum(process_cpu_ticks(proc.pid) for proc in group.procs)

        tag_ms, tag_mode = group.send_job(2, job["pow_fields_hex"], hard_target)
        full_ms, full_mode = group.send_job(3, mutate_pow(job["pow_fields_hex"]), hard_target)

        with group.condition:
            measured = [list(items) for items in group.stats]
        if any(not items for items in measured):
            raise RuntimeError(f"{name}: missing STAT samples: {[len(x) for x in measured]}")

        per_gpu_kernel = [statistics.mean(item[1] for item in items) for items in measured]
        per_gpu_wall = [statistics.mean(item[2] for item in items) for items in measured]
        total_delta = sys_end[0] - sys_start[0]
        idle_delta = sys_end[1] - sys_start[1]
        system_busy = 100.0 * (total_delta - idle_delta) / max(1, total_delta)
        daemon_cpu = 100.0 * ((proc_end - proc_start) / clock_ticks) / elapsed

        return {
            "name": name,
            "blocks": blocks_per_sm,
            "stat_batches": stat_batches,
            "kernel": sum(per_gpu_kernel),
            "wall": sum(per_gpu_wall),
            "daemon_cpu": daemon_cpu,
            "system_busy": system_busy,
            "irq_s": (sys_end[2] - sys_start[2]) / elapsed,
            "ctxt_s": (sys_end[3] - sys_start[3]) / elapsed,
            "tag_ms": tag_ms,
            "tag_mode": tag_mode,
            "full_ms": full_ms,
            "full_mode": full_mode,
            "samples": sum(len(x) for x in measured),
        }
    finally:
        group.stop()


gpu_count = detect_gpus()
if gpu_count < 1:
    raise SystemExit("ERROR: no NVIDIA GPUs detected")
job = get_job()

print("===== MULTI-GPU CPU/BATCH SWEEP =====")
print(f"height: {job['height']}")
print(f"GPUs: {gpu_count}  CPU threads: {os.cpu_count()}  measure: {MEASURE_SECONDS:.1f}s/variant")
print("IMPORTANT: HiveOS miner must be stopped during this test.")

results = []
for name, blocks, stat_batches in VARIANTS:
    print(f"running {name} (blocks/SM={blocks}, STAT/{stat_batches} batches)...", flush=True)
    result = run_variant(name, blocks, stat_batches, job, gpu_count)
    results.append(result)
    print(
        f"  wall={result['wall']:.2f} MH/s  kernel={result['kernel']:.2f} MH/s  "
        f"daemonCPU={result['daemon_cpu']:.1f}%  systemBusy={result['system_busy']:.1f}%  "
        f"irq/s={result['irq_s']:.0f} ctxt/s={result['ctxt_s']:.0f}  "
        f"TAG={result['tag_ms']:.1f}ms {result['tag_mode']}  "
        f"FULL={result['full_ms']:.1f}ms {result['full_mode']}"
    )

baseline = results[0]
print("\n===== FINAL COMPARISON VS CURRENT b32/STAT8 =====")
print(
    f"{'variant':10s} {'wall MH/s':>10s} {'wall':>8s} {'daemonCPU':>10s} "
    f"{'CPU change':>11s} {'busy':>7s} {'irq/s':>9s} {'ctxt/s':>9s} "
    f"{'TAG ms':>8s} {'FULL ms':>8s}"
)
for result in results:
    wall_change = (result["wall"] / baseline["wall"] - 1.0) * 100.0
    cpu_change = (result["daemon_cpu"] / baseline["daemon_cpu"] - 1.0) * 100.0
    print(
        f"{result['name']:10s} {result['wall']:10.2f} {wall_change:+7.2f}% "
        f"{result['daemon_cpu']:9.1f}% {cpu_change:+10.1f}% "
        f"{result['system_busy']:6.1f}% {result['irq_s']:9.0f} {result['ctxt_s']:9.0f} "
        f"{result['tag_ms']:8.1f} {result['full_ms']:8.1f}"
    )

print("\nPaste the complete table back into the chat before running the live ID test.")
