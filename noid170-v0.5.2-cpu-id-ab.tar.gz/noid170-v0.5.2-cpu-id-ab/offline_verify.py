#!/usr/bin/env python3

import random

MASK64 = (1 << 64) - 1
MASK128 = (1 << 128) - 1


def spread32(x):
    value = x & 0xFFFFFFFF
    value = (value | (value << 16)) & 0x0000FFFF0000FFFF
    value = (value | (value << 8)) & 0x00FF00FF00FF00FF
    value = (value | (value << 4)) & 0x0F0F0F0F0F0F0F0F
    value = (value | (value << 2)) & 0x3333333333333333
    value = (value | (value << 1)) & 0x5555555555555555
    return value


def expand64(x):
    return spread32(x & 0xFFFFFFFF) | (spread32(x >> 32) << 64)


def clmul64(a, b):
    product = 0
    while a:
        bit = (a & -a).bit_length() - 1
        product ^= b << bit
        a &= a - 1
    return product


def reduce_gcm_256(high, low):
    shifted = high
    shifted ^= (high << 1) & MASK128
    shifted ^= (high << 2) & MASK128
    shifted ^= (high << 7) & MASK128

    high_hi = high >> 64
    overflow = (high_hi >> 63) ^ (high_hi >> 62) ^ (high_hi >> 57)
    fold = overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    return (low ^ shifted ^ fold) & MASK128


def square_spread(value):
    low = expand64(value & MASK64)
    high = expand64(value >> 64)
    return reduce_gcm_256(high, low)


def square_clmad_model(value):
    low = clmul64(value & MASK64, value & MASK64)
    high_limb = value >> 64
    high = clmul64(high_limb, high_limb)
    return reduce_gcm_256(high, low)


def main():
    rng = random.Random(0x170C1A0D)
    vectors = [0, 1, MASK128, 1 << 127, 1 << 64, MASK64]
    vectors.extend(rng.getrandbits(128) for _ in range(10000))

    for index, value in enumerate(vectors):
        spread = square_spread(value)
        clmad = square_clmad_model(value)
        if spread != clmad:
            raise SystemExit(
                f"FAIL vector={index} input={value:032x} "
                f"spread={spread:032x} clmad={clmad:032x}"
            )

    print(
        "OFFLINE CLMAD SQUARE MODEL: PASS "
        f"(vectors={len(vectors)})"
    )


if __name__ == "__main__":
    main()
