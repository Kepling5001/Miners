#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VARIANT="${NOID_TEST_VARIANT:-b64s32}"
SECONDS_TO_RUN="${NOID_ID_TEST_SECONDS:-600}"
DAEMON="$ROOT/bin/noid_daemon_$VARIANT"
STATS="/run/noid170-freshid-stats.json"

[[ -n "${NOID_MINING_KEY:-}" ]] || {
  echo "ERROR: export NOID_MINING_KEY='address.worker' first"
  exit 1
}
[[ -x "$DAEMON" ]] || {
  echo "ERROR: missing $DAEMON; run ./build-on-rig.sh first"
  exit 1
}
if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Run: miner stop"
  exit 1
fi

WARMUP="/hive/miners/custom/noid170/noid_live_job_cont"
if [[ ! -x "$WARMUP" ]]; then
  WARMUP="$ROOT/package/noid170/noid_live_job_cont"
fi

echo "===== FRESHEST-COMPATIBLE TEMPLATE-ID LIVE TEST ====="
echo "variant: $VARIANT"
echo "duration: ${SECONDS_TO_RUN}s"
echo "poll interval: ${NOID_ID_POLL_INTERVAL:-0.20}s"
echo "This test submits real shares."

set +e
NOID_DAEMON_BIN="$DAEMON" \
NOID_WARMUP_BIN="$WARMUP" \
NOID_STATS_FILE="$STATS" \
NOID_TUI=0 \
NOID_CARD_MH=75.25 \
NOID_SUBMIT_THREADS=1 \
NOID_POLL_INTERVAL="${NOID_ID_POLL_INTERVAL:-0.20}" \
timeout --signal=INT --kill-after=15 "${SECONDS_TO_RUN}s" \
  python3 -u "$ROOT/noid170_aria_freshid.py"
rc=$?
set -e

if [[ "$rc" -ne 0 && "$rc" -ne 124 && "$rc" -ne 130 ]]; then
  echo "ERROR: live test exited with code $rc"
  exit "$rc"
fi

[[ -s "$STATS" ]] || {
  echo "ERROR: no final stats written to $STATS"
  exit 1
}

python3 - "$STATS" <<'PY'
import json, sys
with open(sys.argv[1], "r", encoding="utf-8") as handle:
    d = json.load(handle)
accepted = int(d.get("accepted", 0))
stale = int(d.get("stale", 0))
rejected = int(d.get("rejected", 0))
submitted = accepted + stale + rejected
rate = 100.0 * accepted / submitted if submitted else 0.0
print("===== FRESH-ID FINAL RESULT =====")
print(f"accepted={accepted} stale={stale} rejected={rejected} acceptance={rate:.2f}%")
print(
    "stale_classes="
    f"{d.get('stale_old_height', 0)}/"
    f"{d.get('stale_old_template', 0)}/"
    f"{d.get('stale_current_template', 0)}"
)
print(
    f"found={d.get('found', 0)} queued={d.get('queued_found', 0)} "
    f"old_discarded={d.get('old_share_discarded', 0)} "
    f"id_churn={d.get('id_only_refreshes', 0)} "
    f"id_rebind={d.get('id_rebinds', 0)} "
    f"stale_tag={d.get('stale_tag_refreshes', 0)}"
)
print(
    f"kernel={d.get('total_mhs', 0):.2f}MH/s "
    f"wall={d.get('wall_total_mhs', 0):.2f}MH/s "
    f"ack_ms={d.get('last_job_ack_ms', 0):.1f} "
    f"max_ack_ms={d.get('max_job_ack_ms', 0):.1f}"
)
print(json.dumps(d, indent=2, sort_keys=True))
PY
