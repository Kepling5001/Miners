#!/usr/bin/env python3

import collections
import json
import math
import os
import queue
import signal
import socket
import ssl
import subprocess
import threading
import time
from urllib.parse import urlsplit

VERSION = "0.6.33-test1"
DEFAULT_RPC_URL = "stratum+ssl://us.innovlab.cc:19601"

MINING_KEY = os.environ.get("NOID_MINING_KEY", "").strip()
RPC_URL = os.environ.get("NOID_RPC_URL", DEFAULT_RPC_URL).strip() or DEFAULT_RPC_URL
CARD_MH = float(os.environ.get("NOID_CARD_MH", "160.9"))
GPU_STAGGER_MS = float(os.environ.get("NOID_GPU_STAGGER_MS", "5.0"))
SHARE_QUEUE_SIZE = max(256, int(os.environ.get("NOID_SHARE_QUEUE_SIZE", "5000")))
SUBMIT_THREADS = max(1, int(os.environ.get("NOID_SUBMIT_THREADS", "1")))
STATS_FILE = os.environ.get("NOID_STATS_FILE", "/run/noid170/stats.json")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DAEMON_BIN = os.environ.get(
    "NOID_DAEMON_NS_BIN", os.path.join(BASE_DIR, "noid_live_job_daemon_ns")
)
CLIENT_NAME = os.environ.get("NOID_STRATUM_CLIENT", "NOID170/0.6.33").strip() or "NOID170/0.6.33"
PASSWORD = os.environ.get("NOID_STRATUM_PASSWORD", "x")
CONNECT_TIMEOUT = max(2.0, float(os.environ.get("NOID_STRATUM_CONNECT_TIMEOUT", "10")))
REQUEST_TIMEOUT = max(1.0, float(os.environ.get("NOID_STRATUM_REQUEST_TIMEOUT", "5")))

if not MINING_KEY:
    raise RuntimeError("NOID_MINING_KEY is not set")
if not os.path.isfile(DAEMON_BIN) or not os.access(DAEMON_BIN, os.X_OK):
    raise RuntimeError(f"Namespace-aware CUDA daemon missing/not executable: {DAEMON_BIN}")


def detect_gpu_count():
    override = os.environ.get("NOID_GPU_COUNT")
    if override:
        count = int(override)
        if count < 1:
            raise RuntimeError("NOID_GPU_COUNT must be >= 1")
        return count
    p = subprocess.run(
        ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
        text=True,
        capture_output=True,
        check=True,
    )
    count = len([x for x in p.stdout.splitlines() if x.strip()])
    if count < 1:
        raise RuntimeError("No NVIDIA GPUs detected")
    return count


GPU_COUNT = detect_gpu_count()

u = urlsplit(RPC_URL)
if u.scheme != "stratum+ssl":
    raise RuntimeError(f"Stratum backend requires stratum+ssl:// URL, got: {RPC_URL}")
if not u.hostname or not u.port:
    raise RuntimeError(f"Stratum URL must include hostname and port: {RPC_URL}")
if u.username or u.password or (u.path not in ("", "/")) or u.query or u.fragment:
    raise RuntimeError("Stratum URL must not contain userinfo, path, query, or fragment")
STRATUM_HOST = u.hostname
STRATUM_PORT = u.port

running = True
state_lock = threading.RLock()
client_lock = threading.RLock()
share_queue = queue.Queue(maxsize=SHARE_QUEUE_SIZE)
protocol_events = queue.Queue()
reconnect_requested = threading.Event()

job_seq = 0
current_seq = 0
current_context = None
contexts = collections.OrderedDict()
client_generation = 0
current_client = None

ready_events = [threading.Event() for _ in range(GPU_COUNT)]
gpu_rates = [CARD_MH] * GPU_COUNT
gpu_wall_rates = [0.0] * GPU_COUNT
gpu_rate_measured = [False] * GPU_COUNT
gpu_job_seq = [0] * GPU_COUNT
seq_sent_at = {}
seq_acks = {}

stats = {
    "accepted": 0,
    "stale": 0,
    "rejected": 0,
    "found": 0,
    "queued_found": 0,
    "old_share_discarded": 0,
    "queue_dropped": 0,
    "transport_errors": 0,
    "connects": 0,
    "reconnects": 0,
    "notify": 0,
    "pause": 0,
    "job_updates": 0,
    "namespace_mismatch_local": 0,
    "submit_calls": 0,
    "submit_ms": 0.0,
    "last_job_ack_ms": 0.0,
    "max_job_ack_ms": 0.0,
}

start_monotonic = time.monotonic()
workers = []


def sig_handler(_signum, _frame):
    global running
    running = False
    reconnect_requested.set()


signal.signal(signal.SIGINT, sig_handler)
signal.signal(signal.SIGTERM, sig_handler)


def valid_hex(s, n):
    if not isinstance(s, str) or len(s) != n:
        return False
    try:
        bytes.fromhex(s)
    except ValueError:
        return False
    return True


def hashes_per_share_from_target_hex(target_hex):
    target = int.from_bytes(bytes.fromhex(target_hex), "little")
    if target <= 0:
        return 0.0
    return (1 << 256) / target


class StratumClient:
    def __init__(self, generation, event_queue):
        self.generation = generation
        self.event_queue = event_queue
        self.sock = None
        self.reader_file = None
        self.reader_thread = None
        self.send_lock = threading.Lock()
        self.pending_lock = threading.Lock()
        self.pending = {}
        self.next_id = 1
        self.dead = threading.Event()
        self.closed = False
        self.session_namespace = None
        self.hashrate_methods = []

    def connect_and_handshake(self):
        raw = socket.create_connection(
            (STRATUM_HOST, STRATUM_PORT), timeout=CONNECT_TIMEOUT
        )
        ctx = ssl.create_default_context()
        tls = ctx.wrap_socket(raw, server_hostname=STRATUM_HOST)
        tls.settimeout(None)
        self.sock = tls
        self.reader_file = tls.makefile("rb")
        self.reader_thread = threading.Thread(
            target=self._reader_loop,
            name=f"stratum-reader-{self.generation}",
            daemon=True,
        )
        self.reader_thread.start()

        sub = self.request("mining.subscribe", [CLIENT_NAME], timeout=CONNECT_TIMEOUT)
        if sub.get("error") is not None:
            raise RuntimeError(f"mining.subscribe failed: {sub.get('error')}")
        result = sub.get("result")
        if not isinstance(result, dict):
            raise RuntimeError(f"subscribe result is not an object: {result!r}")
        if result.get("protocol") != "parano1d-stratum-v1":
            raise RuntimeError(f"unexpected protocol: {result.get('protocol')!r}")
        if int(result.get("nonce_bits", -1)) != 64:
            raise RuntimeError(f"pool nonce_bits is not 64: {result.get('nonce_bits')!r}")
        ns = str(result.get("session_namespace", "")).lower()
        if not valid_hex(ns, 16):
            raise RuntimeError(f"invalid session_namespace: {ns!r}")
        self.session_namespace = ns
        hm = sub.get("hashrate_report", [])
        self.hashrate_methods = hm if isinstance(hm, list) else []

        auth = self.request(
            "mining.authorize", [MINING_KEY, PASSWORD], timeout=CONNECT_TIMEOUT
        )
        if auth.get("error") is not None or auth.get("result") is not True:
            raise RuntimeError(
                f"mining.authorize failed: result={auth.get('result')!r} error={auth.get('error')!r}"
            )
        return self

    def _reader_loop(self):
        error = None
        try:
            while not self.closed:
                raw = self.reader_file.readline()
                if not raw:
                    raise ConnectionError("pool closed connection")
                if len(raw) > 2 * 1024 * 1024:
                    raise RuntimeError("pool frame exceeds 2 MiB")
                try:
                    msg = json.loads(raw.decode("utf-8"))
                except Exception as e:
                    raise RuntimeError(f"invalid Stratum JSON: {e}") from e
                if not isinstance(msg, dict):
                    continue
                rid = msg.get("id")
                if rid is not None:
                    with self.pending_lock:
                        q = self.pending.get(rid)
                    if q is not None:
                        try:
                            q.put_nowait(msg)
                        except queue.Full:
                            pass
                    continue
                method = msg.get("method")
                if isinstance(method, str):
                    self.event_queue.put((self.generation, msg))
        except Exception as e:
            error = e
        finally:
            self.dead.set()
            if not self.closed:
                self.event_queue.put(
                    (
                        self.generation,
                        {"method": "__disconnect__", "error": str(error or "connection ended")},
                    )
                )
            with self.pending_lock:
                pending = list(self.pending.values())
            for q in pending:
                try:
                    q.put_nowait({"_transport_error": str(error or "connection ended")})
                except queue.Full:
                    pass

    def request(self, method, params, timeout=REQUEST_TIMEOUT):
        if self.dead.is_set() or self.closed or self.sock is None:
            raise ConnectionError("Stratum connection is not available")
        with self.pending_lock:
            rid = self.next_id
            self.next_id += 1
            q = queue.Queue(maxsize=1)
            self.pending[rid] = q
        payload = json.dumps(
            {"id": rid, "method": method, "params": params}, separators=(",", ":")
        ).encode("utf-8") + b"\n"
        try:
            with self.send_lock:
                self.sock.sendall(payload)
            try:
                resp = q.get(timeout=timeout)
            except queue.Empty as e:
                raise TimeoutError(f"timeout waiting for {method} response") from e
            if "_transport_error" in resp:
                raise ConnectionError(resp["_transport_error"])
            return resp
        finally:
            with self.pending_lock:
                self.pending.pop(rid, None)

    def close(self):
        self.closed = True
        self.dead.set()
        try:
            if self.sock is not None:
                self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            if self.reader_file is not None:
                self.reader_file.close()
        except Exception:
            pass
        try:
            if self.sock is not None:
                self.sock.close()
        except Exception:
            pass


def parse_notify(msg, expected_namespace):
    params = msg.get("params")
    if not isinstance(params, list) or len(params) < 1 or not isinstance(params[0], dict):
        raise RuntimeError("mining.notify missing object params[0]")
    j = params[0]
    if j.get("clean") is not True:
        raise RuntimeError("parano1d notify must be a clean assignment")
    if int(j.get("nonce_bits", -1)) != 64:
        raise RuntimeError("pool nonce_bits must be 64")
    if int(j.get("nonce_field_index", -1)) != 10:
        raise RuntimeError(f"unsupported nonce_field_index={j.get('nonce_field_index')!r}")

    powhex = str(j.get("pow_fields_hex", "")).lower()
    target = str(j.get("share_target_hex", "")).lower()
    prefix = str(j.get("nonce_prefix_hex", "")).lower()
    domain = str(j.get("work_domain_id", "")).lower()
    job_id = str(j.get("job_id", ""))

    if not valid_hex(powhex, 512):
        raise RuntimeError("pow_fields_hex must contain 256 bytes")
    if not valid_hex(target, 64):
        raise RuntimeError("share_target_hex must contain 32 bytes")
    if not valid_hex(prefix, 16):
        raise RuntimeError("nonce_prefix_hex must contain 8 bytes")
    if prefix != expected_namespace:
        raise RuntimeError(
            f"notify namespace {prefix} differs from subscribed session {expected_namespace}"
        )
    if not valid_hex(domain, 64):
        raise RuntimeError("work_domain_id must contain 32 bytes")
    if not job_id:
        raise RuntimeError("notify job_id is empty")
    nonce_field = powhex[10 * 32 : 11 * 32]
    if nonce_field != "0" * 32:
        raise RuntimeError(f"nonce field 10 is not zero: {nonce_field}")

    expires = float(j.get("expires_in_seconds", 0))
    if not math.isfinite(expires) or expires <= 0:
        raise RuntimeError(f"invalid expires_in_seconds={j.get('expires_in_seconds')!r}")

    return {
        "job_id": job_id,
        "work_domain_id": domain,
        "pow_fields_hex": powhex,
        "target_hex": target,
        "namespace": prefix,
        "height": int(j.get("height", 0)),
        "assignment_id": str(j.get("assignment_id", "")),
        "expires_seconds": expires,
        "created": time.monotonic(),
    }


def gpu_stdout_reader(gpu, proc):
    for line in proc.stdout:
        if not running:
            break
        line = line.strip()
        if not line.startswith("SHARE "):
            continue
        parts = line.split()
        if len(parts) != 3:
            continue
        try:
            seq = int(parts[1])
        except ValueError:
            continue
        nonce = parts[2].lower()
        now = time.monotonic()
        with state_lock:
            ctx = contexts.get(seq)
            active_seq = current_seq
            stats["found"] += 1
        if ctx is None or seq != active_seq or not ctx.get("submit_enabled", False):
            with state_lock:
                stats["old_share_discarded"] += 1
            continue
        if now >= ctx["expires_at"]:
            with state_lock:
                stats["old_share_discarded"] += 1
            continue
        if not valid_hex(nonce, 32) or nonce[16:] != ctx["namespace"]:
            with state_lock:
                stats["namespace_mismatch_local"] += 1
                stats["rejected"] += 1
            print(
                f"LOCAL-NAMESPACE-MISMATCH gpu={gpu} seq={seq} nonce={nonce} expected_hi={ctx['namespace']}",
                flush=True,
            )
            continue
        try:
            share_queue.put_nowait((seq, nonce, now))
            with state_lock:
                stats["queued_found"] += 1
        except queue.Full:
            with state_lock:
                stats["queue_dropped"] += 1


def gpu_stderr_reader(gpu, proc):
    for line in proc.stderr:
        if not running:
            break
        line = line.strip()
        if line.startswith("READY "):
            ready_events[gpu].set()
            print(f"GPU{gpu} {line}", flush=True)
            continue
        if line.startswith("JOBACK "):
            parts = line.split()
            if len(parts) >= 3:
                try:
                    seq = int(parts[1])
                except ValueError:
                    continue
                now = time.monotonic()
                with state_lock:
                    gpu_job_seq[gpu] = seq
                    acks = seq_acks.setdefault(seq, set())
                    acks.add(gpu)
                    if len(acks) == GPU_COUNT and seq in seq_sent_at:
                        ms = (now - seq_sent_at[seq]) * 1000.0
                        stats["last_job_ack_ms"] = ms
                        stats["max_job_ack_ms"] = max(stats["max_job_ack_ms"], ms)
            continue
        if line.startswith("STAT "):
            parts = line.split()
            try:
                kernel = float(parts[1])
                wall = float(parts[5]) if len(parts) >= 6 else kernel
            except Exception:
                continue
            with state_lock:
                gpu_rates[gpu] = kernel
                gpu_wall_rates[gpu] = wall
                gpu_rate_measured[gpu] = True
            continue
        if line.startswith("BADCOMMAND") or line.startswith("CUDA error"):
            print(f"GPU{gpu} {line}", flush=True)


def start_daemons():
    result = []
    salt_base = time.time_ns() & 0x7FFFFFFFFFFFFFFF
    print(f"Starting {GPU_COUNT} namespace-aware persistent CUDA daemon(s)...", flush=True)
    for gpu in range(GPU_COUNT):
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        proc = subprocess.Popen(
            [DAEMON_BIN, "--daemon", str(salt_base + gpu + 1)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
        tout = threading.Thread(target=gpu_stdout_reader, args=(gpu, proc), daemon=True)
        terr = threading.Thread(target=gpu_stderr_reader, args=(gpu, proc), daemon=True)
        tout.start()
        terr.start()
        result.append((gpu, proc, tout, terr))

    deadline = time.monotonic() + 45.0
    while running and time.monotonic() < deadline:
        if all(e.is_set() for e in ready_events):
            print("All namespace-aware CUDA contexts are READY.", flush=True)
            return result
        for gpu, proc, _, _ in result:
            if proc.poll() is not None:
                raise RuntimeError(f"GPU {gpu} daemon exited during startup: {proc.returncode}")
        time.sleep(0.1)
    missing = [str(i) for i, e in enumerate(ready_events) if not e.is_set()]
    raise RuntimeError("Timed out waiting for GPU daemon READY: " + ",".join(missing))


def stop_daemons():
    for _, proc, _, _ in workers:
        if proc.poll() is None:
            try:
                proc.stdin.write("STOP\n")
                proc.stdin.flush()
            except Exception:
                pass
    deadline = time.monotonic() + 3.0
    for _, proc, _, _ in workers:
        if proc.poll() is not None:
            continue
        try:
            proc.wait(timeout=max(0.0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            proc.terminate()
    for _, proc, _, _ in workers:
        if proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass


def _send_line_all(line, seq):
    with state_lock:
        seq_sent_at[seq] = time.monotonic()
        seq_acks[seq] = set()
    do_stagger = GPU_COUNT >= 8 and GPU_STAGGER_MS > 0.0
    for idx, (gpu, proc, _, _) in enumerate(workers):
        if proc.poll() is not None:
            raise RuntimeError(f"GPU {gpu} daemon exited with code {proc.returncode}")
        proc.stdin.write(line)
        proc.stdin.flush()
        if do_stagger and idx + 1 < len(workers):
            time.sleep(GPU_STAGGER_MS / 1000.0)


def activate_job(job, generation, reason="notify"):
    global job_seq, current_seq, current_context
    now = time.monotonic()
    with state_lock:
        job_seq += 1
        seq = job_seq
        ctx = dict(job)
        ctx["seq"] = seq
        ctx["generation"] = generation
        ctx["expires_at"] = now + job["expires_seconds"]
        ctx["submit_enabled"] = True
        ctx["hashes_per_share"] = hashes_per_share_from_target_hex(job["target_hex"])
        contexts[seq] = ctx
        while len(contexts) > 32:
            contexts.popitem(last=False)
        current_seq = seq
        current_context = ctx
        stats["job_updates"] += 1
    line = (
        f"JOBNS {seq} {ctx['pow_fields_hex']} {ctx['target_hex']} {ctx['namespace']}\n"
    )
    _send_line_all(line, seq)
    print(
        f"JOB {seq} -> height {ctx['height']} job={ctx['job_id']} ns={ctx['namespace']} "
        f"expires={ctx['expires_seconds']:.0f}s ({reason})",
        flush=True,
    )
    return ctx


def pause_current(reason):
    global job_seq, current_seq, current_context
    with state_lock:
        old = current_context
        if old is None or not old.get("submit_enabled", False):
            current_context = None if old is None else old
            return
        job_seq += 1
        seq = job_seq
        paused = dict(old)
        paused["seq"] = seq
        paused["target_hex"] = "0" * 64
        paused["submit_enabled"] = False
        paused["pause_reason"] = reason
        contexts[seq] = paused
        while len(contexts) > 32:
            contexts.popitem(last=False)
        current_seq = seq
        current_context = paused
    line = (
        f"JOBNS {seq} {paused['pow_fields_hex']} {'0' * 64} {paused['namespace']}\n"
    )
    _send_line_all(line, seq)
    print(f"PAUSE seq={seq} reason={reason}", flush=True)


def get_client():
    with client_lock:
        return current_client


def classify_submit(resp):
    result = resp.get("result")
    error = resp.get("error")
    if result is True:
        return "accepted", error
    if isinstance(result, str) and result.strip().lower() in (
        "true", "accepted", "share accepted", "ok"
    ):
        return "accepted", error
    text = (str(result) + " " + str(error or "")).lower()
    if any(x in text for x in ("stale", "expired", "job not found", "namespace")):
        return "stale", error
    return "rejected", error


def submitter(index):
    while running:
        try:
            item = share_queue.get(timeout=0.5)
        except queue.Empty:
            continue
        try:
            if item is None:
                return
            seq, nonce, found_at = item
            with state_lock:
                ctx = contexts.get(seq)
                active_seq = current_seq
            if (
                ctx is None
                or seq != active_seq
                or not ctx.get("submit_enabled", False)
                or time.monotonic() >= ctx["expires_at"]
            ):
                with state_lock:
                    stats["old_share_discarded"] += 1
                continue
            client = get_client()
            if client is None or client.dead.is_set() or client.generation != ctx["generation"]:
                with state_lock:
                    stats["stale"] += 1
                continue
            t0 = time.monotonic()
            try:
                resp = client.request(
                    "mining.submit",
                    [ctx["job_id"], nonce, ctx["work_domain_id"]],
                    timeout=REQUEST_TIMEOUT,
                )
            except Exception as e:
                with state_lock:
                    stats["transport_errors"] += 1
                    stats["stale"] += 1
                print(f"SUBMIT-TRANSPORT-ERROR thread={index} seq={seq}: {e}", flush=True)
                reconnect_requested.set()
                continue
            elapsed_ms = (time.monotonic() - t0) * 1000.0
            outcome, error = classify_submit(resp)
            with state_lock:
                stats["submit_calls"] += 1
                stats["submit_ms"] += elapsed_ms
                stats[outcome] += 1
            if outcome == "accepted":
                age_ms = (time.monotonic() - found_at) * 1000.0
                print(
                    f"ACCEPTED seq={seq} height={ctx['height']} nonce={nonce} "
                    f"submit_ms={elapsed_ms:.1f} share_age_ms={age_ms:.1f}",
                    flush=True,
                )
            else:
                print(
                    f"{outcome.upper()} seq={seq} height={ctx['height']} nonce={nonce} "
                    f"error={error!r}",
                    flush=True,
                )
        finally:
            share_queue.task_done()


def connect_new_client():
    global client_generation, current_client
    with client_lock:
        client_generation += 1
        generation = client_generation
    c = StratumClient(generation, protocol_events)
    try:
        c.connect_and_handshake()
    except Exception:
        c.close()
        raise
    with client_lock:
        old = current_client
        current_client = c
    if old is not None:
        old.close()
    with state_lock:
        stats["connects"] += 1
        if generation > 1:
            stats["reconnects"] += 1
    print(
        f"STRATUM READY generation={generation} protocol=parano1d-stratum-v1 "
        f"namespace={c.session_namespace} tls=webpki host={STRATUM_HOST}:{STRATUM_PORT}",
        flush=True,
    )
    return c


def disconnect_current():
    global current_client
    with client_lock:
        c = current_client
        current_client = None
    if c is not None:
        c.close()


def snapshot():
    now = time.monotonic()
    with state_lock:
        ctx = current_context
        s = dict(stats)
        rates = list(gpu_rates)
        wall = list(gpu_wall_rates)
        measured = list(gpu_rate_measured)
        active = sum(1 for x in (ctx,) if x and x.get("submit_enabled", False))
    return {
        "version": VERSION,
        "uptime": int(now - start_monotonic),
        "height": int(ctx["height"]) if ctx else 0,
        "job_seq": int(ctx["seq"]) if ctx else 0,
        "namespace": ctx.get("namespace", "") if ctx else "",
        "stratum_active": bool(active),
        "gpu_rates_mhs": rates,
        "gpu_wall_rates_mhs": wall,
        "total_mhs": sum(rates),
        "wall_total_mhs": sum(wall),
        "rate_measured": measured,
        "accepted": s["accepted"],
        "stale": s["stale"],
        "rejected": s["rejected"],
        "found": s["found"],
        "queued_found": s["queued_found"],
        "old_share_discarded": s["old_share_discarded"],
        "queue_dropped": s["queue_dropped"],
        "transport_errors": s["transport_errors"],
        "connects": s["connects"],
        "reconnects": s["reconnects"],
        "notify": s["notify"],
        "pause": s["pause"],
        "job_updates": s["job_updates"],
        "namespace_mismatch_local": s["namespace_mismatch_local"],
        "submit_calls": s["submit_calls"],
        "submit_avg_ms": s["submit_ms"] / s["submit_calls"] if s["submit_calls"] else 0.0,
        "last_job_ack_ms": s["last_job_ack_ms"],
        "max_job_ack_ms": s["max_job_ack_ms"],
        "queue": share_queue.qsize(),
    }


def write_stats_file(data):
    try:
        os.makedirs(os.path.dirname(STATS_FILE), exist_ok=True)
        tmp = STATS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
        os.replace(tmp, STATS_FILE)
    except Exception:
        pass


def print_status(data):
    print(
        f"STATUS height={data['height']} seq={data['job_seq']} active={int(data['stratum_active'])} "
        f"kernel={data['total_mhs']:.2f}MH/s wall={data['wall_total_mhs']:.2f}MH/s "
        f"found={data['found']} accepted={data['accepted']} stale={data['stale']} "
        f"rejected={data['rejected']} local_ns_bad={data['namespace_mismatch_local']} "
        f"queue={data['queue']} submit_ms={data['submit_avg_ms']:.1f} "
        f"ack_ms={data['last_job_ack_ms']:.1f}",
        flush=True,
    )


def main():
    global workers, running
    print(f"NOID170 v{VERSION} InnovLab/Parano1d Stratum functional test", flush=True)
    print(f"Pool: {RPC_URL}", flush=True)
    print(f"Mining key: {MINING_KEY}", flush=True)
    print(f"Detected GPUs: {GPU_COUNT}", flush=True)
    print("TLS: system WebPKI verification + hostname verification", flush=True)
    print("Nonce layout: uint64 counter LE || 8-byte session namespace", flush=True)
    print("Submit layout: [job_id, nonce_hex, work_domain_id]", flush=True)

    workers = start_daemons()
    submit_threads = []
    for i in range(SUBMIT_THREADS):
        t = threading.Thread(target=submitter, args=(i,), daemon=True)
        t.start()
        submit_threads.append(t)

    backoff = 1.0
    last_status = 0.0
    last_stats = 0.0

    try:
        while running:
            c = get_client()
            if c is None or c.dead.is_set() or reconnect_requested.is_set():
                reconnect_requested.clear()
                if c is not None:
                    pause_current("transport-reconnect")
                    disconnect_current()
                while running:
                    try:
                        c = connect_new_client()
                        backoff = 1.0
                        break
                    except Exception as e:
                        with state_lock:
                            stats["transport_errors"] += 1
                        print(f"STRATUM CONNECT ERROR: {e}; retry in {backoff:.1f}s", flush=True)
                        time.sleep(backoff)
                        backoff = min(15.0, backoff * 2.0)
                if not running:
                    break

            try:
                generation, msg = protocol_events.get(timeout=0.05)
            except queue.Empty:
                generation, msg = None, None

            if msg is not None:
                c = get_client()
                if c is not None and generation == c.generation:
                    method = msg.get("method")
                    if method == "mining.notify":
                        try:
                            job = parse_notify(msg, c.session_namespace)
                            with state_lock:
                                stats["notify"] += 1
                            activate_job(job, generation, "notify")
                        except Exception as e:
                            print(f"INVALID mining.notify: {e}", flush=True)
                            reconnect_requested.set()
                    elif method == "mining.pause":
                        params = msg.get("params")
                        reason = "pool-pause"
                        if isinstance(params, list) and params and isinstance(params[0], dict):
                            reason = str(params[0].get("reason", reason))
                        with state_lock:
                            stats["pause"] += 1
                        pause_current(reason)
                    elif method == "__disconnect__":
                        print(f"STRATUM DISCONNECTED: {msg.get('error')}", flush=True)
                        reconnect_requested.set()
                    else:
                        print(f"STRATUM EVENT ignored method={method!r}", flush=True)
                protocol_events.task_done()

            now = time.monotonic()
            with state_lock:
                ctx = current_context
            if ctx is not None and ctx.get("submit_enabled", False) and now >= ctx["expires_at"]:
                pause_current("job-expired")

            for gpu, proc, _, _ in workers:
                if proc.poll() is not None:
                    raise RuntimeError(f"GPU {gpu} namespace daemon exited with code {proc.returncode}")

            if now - last_stats >= 1.0:
                data = snapshot()
                write_stats_file(data)
                last_stats = now
            if now - last_status >= 10.0:
                print_status(snapshot())
                last_status = now

    finally:
        running = False
        disconnect_current()
        for _ in submit_threads:
            try:
                share_queue.put_nowait(None)
            except queue.Full:
                break
        stop_daemons()
        data = snapshot()
        write_stats_file(data)
        print("NOID170 Stratum test stopped.", flush=True)


if __name__ == "__main__":
    main()
