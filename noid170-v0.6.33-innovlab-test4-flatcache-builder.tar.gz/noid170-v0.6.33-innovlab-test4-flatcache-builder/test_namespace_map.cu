#include <cstdio>
#include <cstdint>
#include <vector>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_runtime_params.h"
#include "noid_t2f_nibble_lut.h"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        return 2; \
    } \
} while (0)

__device__ __forceinline__ int parity_mask(U128 x, U128 mask)
{
    return ((__popcll(x.lo & mask.lo) ^ __popcll(x.hi & mask.hi)) & 1);
}

__device__ __forceinline__ U128 slow_tower_to_flat(U128 tower)
{
    U128 out{0ULL, 0ULL};
    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask(tower, NOID_T2F_ROWS[bit])) {
            if (bit < 64) out.lo |= 1ULL << bit;
            else out.hi |= 1ULL << (bit - 64);
        }
    }
    return out;
}

static U128 high_to_flat_host(unsigned long long ns_hi)
{
    U128 out{0ULL, 0ULL};
    for (int nib = 0; nib < 16; ++nib) {
        const unsigned int v = (unsigned int)((ns_hi >> (nib * 4)) & 0xFULL);
        const U128 x = NOID_T2F_HIGH_NIBBLE_LUT_HOST[nib][v];
        out.lo ^= x.lo;
        out.hi ^= x.hi;
    }
    return out;
}

__global__ void test_kernel(
    const unsigned long long *counters,
    int n,
    unsigned long long ns_hi,
    U128 ns_flat,
    unsigned int *errors)
{
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    const unsigned long long counter = counters[i];
    U128 fast = ns_flat;
    #pragma unroll
    for (int nib = 0; nib < 16; ++nib) {
        const unsigned int v = (unsigned int)((counter >> (nib * 4)) & 0xFULL);
        const U128 x = NOID_T2F_LOW_NIBBLE_LUT[nib][v];
        fast.lo ^= x.lo;
        fast.hi ^= x.hi;
    }
    const U128 slow = slow_tower_to_flat(U128{counter, ns_hi});
    if (fast.lo != slow.lo || fast.hi != slow.hi)
        atomicAdd(errors, 1U);
}

int main()
{
    constexpr int N = 1024;
    std::vector<unsigned long long> h(N);
    unsigned long long x = 0x0123456789abcdefULL;
    for (int i = 0; i < N; ++i) {
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        h[i] = x + (unsigned long long)i * 0x9e3779b97f4a7c15ULL;
    }
    const unsigned long long namespaces[] = {
        0ULL,
        0x000200000001ea19ULL,
        0x0123456789abcdefULL,
        0xffffffffffffffffULL,
    };

    unsigned long long *d_counters = nullptr;
    unsigned int *d_errors = nullptr;
    CUDA_OK(cudaMalloc(&d_counters, N * sizeof(*d_counters)));
    CUDA_OK(cudaMalloc(&d_errors, sizeof(*d_errors)));
    CUDA_OK(cudaMemcpy(d_counters, h.data(), N * sizeof(*d_counters), cudaMemcpyHostToDevice));

    for (unsigned long long ns : namespaces) {
        const U128 ns_flat = high_to_flat_host(ns);
        CUDA_OK(cudaMemset(d_errors, 0, sizeof(*d_errors)));
        test_kernel<<<(N + 255) / 256, 256>>>(d_counters, N, ns, ns_flat, d_errors);
        CUDA_OK(cudaGetLastError());
        CUDA_OK(cudaDeviceSynchronize());
        unsigned int errors = 0;
        CUDA_OK(cudaMemcpy(&errors, d_errors, sizeof(errors), cudaMemcpyDeviceToHost));
        if (errors != 0) {
            fprintf(stderr, "namespace LUT mismatch ns=%016llx errors=%u\n", ns, errors);
            return 1;
        }
    }

    CUDA_OK(cudaFree(d_errors));
    CUDA_OK(cudaFree(d_counters));
    printf("NAMESPACE_MAP_PASS cases=%zu counters_per_case=%d\n", sizeof(namespaces)/sizeof(namespaces[0]), N);
    return 0;
}
