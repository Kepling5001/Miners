#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE="${1:-$ROOT/dist/noid170-0.6.33-test1.tar.gz}"
DEST="/hive/miners/custom/noid170"
[[ -f "$ARCHIVE" ]] || { echo "ERROR: build first with ./build-test.sh"; exit 1; }
echo "WARNING: this is a functional test branch. Isolated RUN-TEST.txt is preferred."
echo "This command will replace $DEST after making a backup."
read -r -p "Type INSTALL-TEST to continue: " answer
[[ "$answer" == "INSTALL-TEST" ]] || { echo "Cancelled."; exit 1; }
TS=$(date +%Y%m%d-%H%M%S)
if [[ -d "$DEST" ]]; then
  cp -a "$DEST" "/hive/miners/custom/noid170.backup-$TS"
  echo "Backup: /hive/miners/custom/noid170.backup-$TS"
fi
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
tar -xzf "$ARCHIVE" -C "$TMP"
rm -rf "$DEST"
cp -a "$TMP/noid170" "$DEST"
chmod 755 "$DEST"/noid_live_job_daemon "$DEST"/noid_live_job_daemon_ns "$DEST"/noid_live_job_cont "$DEST"/*.sh "$DEST"/*.py
printf 'Installed v0.6.33-test1 to %s\n' "$DEST"
