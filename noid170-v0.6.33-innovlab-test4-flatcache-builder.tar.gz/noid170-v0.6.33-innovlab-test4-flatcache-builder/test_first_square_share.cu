#include <cstdio>
#include <cuda_runtime.h>
struct U128 { unsigned long long lo, hi; };
#include "src/noid_cuda_tables.h"
#include "src/noid_runtime_params.h"
#include "src/noid_cuda_math.cuh"
#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); return 2;} } while(0)
__device__ __forceinline__ unsigned long long mix64(unsigned long long x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
__device__ __forceinline__ bool neq(U128 a,U128 b){return a.lo!=b.lo||a.hi!=b.hi;}
__device__ __forceinline__ void finish1(U128 s[4]){
#pragma unroll 1
 for(int r=1;r<NOID_N_ROUNDS;++r){const bool full=!(r>=NOID_F_ROUNDS/2&&r<NOID_F_ROUNDS/2+NOID_P_ROUNDS);if(full){apply_full_round_sboxes(s,r);apply_mds_full(s);}else{s[0]=bxor(s[0],NOID_RC[0][r]);s[0]=sbox_x7(s[0]);apply_mds_partial(s);}}}
__device__ __forceinline__ void make_b(const U128 base[4],U128 b[4]){for(int i=0;i<4;i++)b[i]=base[i];apply_mds_full(b);for(int i=0;i<4;i++)b[i]=bxor(b[i],NOID_RC[i][0]);}
__device__ __forceinline__ void run_share(U128 s[4],U128 n,const U128 base[4],bool interleave){U128 b[4];make_b(base,b);U128 b01=bxor(b[0],b[1]),b01_2=square_flat_clmad(b01),b01_4=square_flat_clmad(b01_2),b2_2=square_flat_clmad(b[2]),b2_4=square_flat_clmad(b2_2),b3_2=square_flat_clmad(b[3]),b3_4=square_flat_clmad(b3_2);apply_mds_full(s);for(int i=0;i<4;i++)s[i]=bxor(s[i],NOID_RC[i][0]);U128 n2,n4,x12,x14;if(!interleave){n2=square_flat_clmad(n);n4=square_flat_clmad(n2);x12=square_flat_clmad(s[1]);x14=square_flat_clmad(x12);}else{n2=square_flat_clmad(n);x12=square_flat_clmad(s[1]);n4=square_flat_clmad(n2);x14=square_flat_clmad(x12);}U128 x02=bxor(x12,bxor(n2,b01_2)),x04=bxor(x14,bxor(n4,b01_4));s[0]=sbox_x7_from_powers(s[0],x02,x04);s[1]=sbox_x7_from_powers(s[1],x12,x14);U128 x22=bxor(n2,b2_2),x24=bxor(n4,b2_4);s[2]=sbox_x7_from_powers(s[2],x22,x24);U128 x32=bxor(n2,b3_2),x34=bxor(n4,b3_4);s[3]=sbox_x7_from_powers(s[3],x32,x34);apply_mds_full(s);finish1(s);}
__global__ void oracle(unsigned *err){unsigned long long id=(unsigned long long)blockIdx.x*blockDim.x+threadIdx.x;U128 base[4];for(int i=0;i<4;i++)base[i]={mix64(id+17ULL*i),mix64(id+0x10000ULL+29ULL*i)};U128 n{mix64(id+0x7777),mix64(id+0xaaaa)};U128 ref[4],a[4],b[4];for(int i=0;i<4;i++)ref[i]=a[i]=b[i]=base[i];ref[0]=bxor(ref[0],n);a[0]=bxor(a[0],n);b[0]=bxor(b[0],n);poseidon_permute(ref);run_share(a,n,base,false);run_share(b,n,base,true);for(int i=0;i<4;i++){if(neq(ref[i],a[i]))atomicAdd(&err[0],1U);if(neq(ref[i],b[i]))atomicAdd(&err[1],1U);}}
int main(){unsigned*d=nullptr,h[2]={};CUDA_OK(cudaMalloc(&d,sizeof(h)));CUDA_OK(cudaMemset(d,0,sizeof(h)));oracle<<<16,64>>>(d);CUDA_OK(cudaGetLastError());CUDA_OK(cudaDeviceSynchronize());CUDA_OK(cudaMemcpy(h,d,sizeof(h),cudaMemcpyDeviceToHost));cudaFree(d);printf("SHARE4 REFINEMENT ORACLE: %s (share4=%u interleave=%u)\n",(h[0]||h[1])?"FAIL":"PASS",h[0],h[1]);return(h[0]||h[1])?1:0;}
