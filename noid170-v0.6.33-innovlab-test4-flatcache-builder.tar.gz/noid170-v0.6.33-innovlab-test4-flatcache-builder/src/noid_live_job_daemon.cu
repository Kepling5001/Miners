#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <chrono>
#include <algorithm>
#include <string>
#include <sstream>
#include <vector>
#include <utility>
#include <cerrno>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_f2t_rows.h"
#include "noid_runtime_params.h"
#ifdef NOID_MDS_LUT4
#include "noid_mds_lut4.h"
#endif
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

#ifndef NOID_FIRST_MDS_HOIST
#define NOID_FIRST_MDS_HOIST 0
#endif

#ifndef NOID_FIRST_ROUND_SQUARE_SHARE
#define NOID_FIRST_ROUND_SQUARE_SHARE 0
#endif

struct PreparedJob {
    U128 prefix[4];
    U128 tail[6];
#if NOID_FIRST_MDS_HOIST != 0
    U128 first_mds[4];
#if NOID_FIRST_MDS_HOIST == 2
    U128 first_rc0[4];
#endif
#endif
#if NOID_FIRST_ROUND_SQUARE_SHARE >= 2
    U128 first_b01_2;
    U128 first_b01_4;
    U128 first_b2_2;
    U128 first_b2_4;
    U128 first_b3_2;
    U128 first_b3_4;
#endif
};

struct Candidate {
    U128 nonce;
};

#ifndef NOID_BLOCKS_PER_SM
#define NOID_BLOCKS_PER_SM 32
#endif

#ifndef NOID_THREADS
#define NOID_THREADS 1024
#endif

#ifndef NOID_STAT_BATCHES
#define NOID_STAT_BATCHES 8
#endif

#ifndef NOID_EVENT_POLL_US
#define NOID_EVENT_POLL_US 0
#endif

__device__ __constant__ U128 JOB_PREFIX[4];
__device__ __constant__ U128 JOB_TAIL[6];
#if NOID_FIRST_MDS_HOIST != 0
__device__ __constant__ U128 JOB_FIRST_MDS[4];
#if NOID_FIRST_MDS_HOIST == 2
__device__ __constant__ U128 JOB_FIRST_RC0[4];
#endif
#endif
#if NOID_FIRST_ROUND_SQUARE_SHARE >= 2
__device__ __constant__ U128 JOB_FIRST_B01_2;
__device__ __constant__ U128 JOB_FIRST_B01_4;
__device__ __constant__ U128 JOB_FIRST_B2_2;
__device__ __constant__ U128 JOB_FIRST_B2_4;
__device__ __constant__ U128 JOB_FIRST_B3_2;
__device__ __constant__ U128 JOB_FIRST_B3_4;
#endif
__device__ __constant__ U128 JOB_TARGET_LO;
__device__ __constant__ U128 JOB_TARGET_HI;

__device__ __forceinline__
int parity_mask(U128 x, U128 mask)
{
    return ((__popcll(x.lo & mask.lo) ^
             __popcll(x.hi & mask.hi)) & 1);
}

__device__ __forceinline__
U128 tower_to_flat_device(U128 tower)
{
    U128 out{0ULL, 0ULL};

    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask(tower, NOID_T2F_ROWS[bit])) {
            if (bit < 64)
                out.lo |= 1ULL << bit;
            else
                out.hi |= 1ULL << (bit - 64);
        }
    }

    return out;
}

__device__ __forceinline__
U128 flat_to_tower_device(U128 flat)
{
    U128 out{0ULL, 0ULL};

    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask(flat, NOID_F2T_ROWS[bit])) {
            if (bit < 64)
                out.lo |= 1ULL << bit;
            else
                out.hi |= 1ULL << (bit - 64);
        }
    }

    return out;
}

__device__ __forceinline__
int target_bit(int bit)
{
    U128 x;
    int b;

    if (bit >= 128) {
        x = JOB_TARGET_HI;
        b = bit - 128;
    } else {
        x = JOB_TARGET_LO;
        b = bit;
    }

    if (b < 64)
        return (int)((x.lo >> b) & 1ULL);

    return (int)((x.hi >> (b - 64)) & 1ULL);
}

__device__ __forceinline__
bool digest_lt_target(U128 flat_lo, U128 flat_hi)
{
    #pragma unroll 1
    for (int bit = 255; bit >= 0; --bit) {
        const U128 lane =
            (bit >= 128) ? flat_hi : flat_lo;

        const int db =
            parity_mask(lane, NOID_F2T_ROWS[bit & 127]);

        const int tb = target_bit(bit);

        if (db != tb)
            return db < tb;
    }

    return false;
}

__device__ __forceinline__
U128 add_u64(U128 a, unsigned long long x)
{
    const unsigned long long old = a.lo;
    a.lo += x;

    if (a.lo < old)
        ++a.hi;

    return a;
}

__global__
void prepare_job(
    const U128 *tower_fields,
    PreparedJob *out)
{
    if (blockIdx.x || threadIdx.x)
        return;

    U128 flat[16];

    for (int i = 0; i < 16; ++i)
        flat[i] = tower_to_flat_device(tower_fields[i]);

    U128 s[4] = {
        {0ULL, 0ULL},
        {0ULL, 0ULL},
        NOID_POW_IV[0],
        NOID_POW_IV[1]
    };

    for (int block = 0; block < 5; ++block) {
        s[0] = bxor(s[0], flat[2 * block]);
        s[1] = bxor(s[1], flat[2 * block + 1]);
        poseidon_permute(s);
    }

    for (int i = 0; i < 4; ++i)
        out->prefix[i] = s[i];

    for (int i = 0; i < 6; ++i)
        out->tail[i] = flat[10 + i];

#if NOID_FIRST_MDS_HOIST != 0
    /*
     * First mining permutation input is prefix with nonce absorbed into lane 0
     * and flat[11] absorbed into lane 1.  Everything except nonce is job
     * constant, so hoist M*constant here.
     */
    U128 first[4] = {
        s[0],
        bxor(s[1], flat[11]),
        s[2],
        s[3]
    };
    apply_mds_full(first);
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        out->first_mds[i] = first[i];
#if NOID_FIRST_MDS_HOIST == 2
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        out->first_rc0[i] = bxor(first[i], NOID_RC[i][0]);
#endif
#endif

#if NOID_FIRST_ROUND_SQUARE_SHARE >= 2
    /*
     * For nonce n, the first external MDS produces affine lane coefficients
     * [5,4,1,1]*n.  After round-0 constants, write x_i=B_i+c_i*n.
     * Squaring is GF(2)-linear, so lanes 2/3 can reuse n^2/n^4.
     * Also c0+c1=1, hence x0+x1=(B0+B1)+n and mode 3 can derive
     * lane-0 powers from lane-1 powers plus the shared nonce powers.
     */
    U128 bstate[4] = {
        s[0],
        bxor(s[1], flat[11]),
        s[2],
        s[3]
    };
    apply_mds_full(bstate);
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        bstate[i] = bxor(bstate[i], NOID_RC[i][0]);

    const U128 b01 = bxor(bstate[0], bstate[1]);
    out->first_b01_2 = square_flat_clmad(b01);
    out->first_b01_4 = square_flat_clmad(out->first_b01_2);
    out->first_b2_2 = square_flat_clmad(bstate[2]);
    out->first_b2_4 = square_flat_clmad(out->first_b2_2);
    out->first_b3_2 = square_flat_clmad(bstate[3]);
    out->first_b3_4 = square_flat_clmad(out->first_b3_2);
#endif
}

#if NOID_FIRST_ROUND_SQUARE_SHARE != 0
/*
 * First nonce-dependent permutation only.  The external MDS remains the exact
 * production path; only round-0 Frobenius squares are shared.  Mode 1 is a
 * split-round control with identical arithmetic to baseline, mode 2 shares
 * nonce squares across lanes 2/3, and mode 3 additionally derives lane 0 from
 * lane 1 using x0+x1 = nonce + job_constant.
 */
__device__ __forceinline__
void poseidon_permute_first_square_share(U128 s[4], U128 flat_nonce)
{
    apply_mds_full(s);

#if NOID_FIRST_ROUND_SQUARE_SHARE == 1
    apply_full_round_sboxes(s, 0);
#elif NOID_FIRST_ROUND_SQUARE_SHARE >= 2 && NOID_FIRST_ROUND_SQUARE_SHARE <= 6
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = bxor(s[i], NOID_RC[i][0]);

#if NOID_FIRST_ROUND_SQUARE_SHARE == 2
    const U128 n2 = square_flat_clmad(flat_nonce);
    const U128 n4 = square_flat_clmad(n2);
    s[0] = sbox_x7(s[0]);
    s[1] = sbox_x7(s[1]);
    const U128 x2_2 = bxor(n2, JOB_FIRST_B2_2);
    const U128 x4_2 = bxor(n4, JOB_FIRST_B2_4);
    const U128 x2_3 = bxor(n2, JOB_FIRST_B3_2);
    const U128 x4_3 = bxor(n4, JOB_FIRST_B3_4);
    s[2] = sbox_x7_from_powers(s[2], x2_2, x4_2);
    s[3] = sbox_x7_from_powers(s[3], x2_3, x4_3);

#elif NOID_FIRST_ROUND_SQUARE_SHARE == 3
    const U128 n2 = square_flat_clmad(flat_nonce);
    const U128 n4 = square_flat_clmad(n2);
    const U128 x1_2 = square_flat_clmad(s[1]);
    const U128 x1_4 = square_flat_clmad(x1_2);
    const U128 x0_2 = bxor(x1_2, bxor(n2, JOB_FIRST_B01_2));
    const U128 x0_4 = bxor(x1_4, bxor(n4, JOB_FIRST_B01_4));
    const U128 x2_2 = bxor(n2, JOB_FIRST_B2_2);
    const U128 x2_3 = bxor(n2, JOB_FIRST_B3_2);
    const U128 x4_2 = bxor(n4, JOB_FIRST_B2_4);
    const U128 x4_3 = bxor(n4, JOB_FIRST_B3_4);
    s[0] = sbox_x7_from_powers(s[0], x0_2, x0_4);
    s[1] = sbox_x7_from_powers(s[1], x1_2, x1_4);
    s[2] = sbox_x7_from_powers(s[2], x2_2, x4_2);
    s[3] = sbox_x7_from_powers(s[3], x2_3, x4_3);

#elif NOID_FIRST_ROUND_SQUARE_SHARE == 4
    const U128 n2 = square_flat_clmad(flat_nonce);
    const U128 n4 = square_flat_clmad(n2);
    const U128 x1_2 = square_flat_clmad(s[1]);
    const U128 x1_4 = square_flat_clmad(x1_2);
    {
        const U128 x0_2 = bxor(x1_2, bxor(n2, JOB_FIRST_B01_2));
        const U128 x0_4 = bxor(x1_4, bxor(n4, JOB_FIRST_B01_4));
        s[0] = sbox_x7_from_powers(s[0], x0_2, x0_4);
    }
    s[1] = sbox_x7_from_powers(s[1], x1_2, x1_4);
    {
        const U128 x2_2 = bxor(n2, JOB_FIRST_B2_2);
        const U128 x2_4 = bxor(n4, JOB_FIRST_B2_4);
        s[2] = sbox_x7_from_powers(s[2], x2_2, x2_4);
    }
    {
        const U128 x3_2 = bxor(n2, JOB_FIRST_B3_2);
        const U128 x3_4 = bxor(n4, JOB_FIRST_B3_4);
        s[3] = sbox_x7_from_powers(s[3], x3_2, x3_4);
    }

#elif NOID_FIRST_ROUND_SQUARE_SHARE == 5
    const U128 n2 = square_flat_clmad(flat_nonce);
    const U128 x1_2 = square_flat_clmad(s[1]);
    const U128 n4 = square_flat_clmad(n2);
    const U128 x1_4 = square_flat_clmad(x1_2);
    const U128 x0_2 = bxor(x1_2, bxor(n2, JOB_FIRST_B01_2));
    const U128 x0_4 = bxor(x1_4, bxor(n4, JOB_FIRST_B01_4));
    const U128 x2_2 = bxor(n2, JOB_FIRST_B2_2);
    const U128 x2_3 = bxor(n2, JOB_FIRST_B3_2);
    const U128 x4_2 = bxor(n4, JOB_FIRST_B2_4);
    const U128 x4_3 = bxor(n4, JOB_FIRST_B3_4);
    s[0] = sbox_x7_from_powers(s[0], x0_2, x0_4);
    s[1] = sbox_x7_from_powers(s[1], x1_2, x1_4);
    s[2] = sbox_x7_from_powers(s[2], x2_2, x4_2);
    s[3] = sbox_x7_from_powers(s[3], x2_3, x4_3);

#elif NOID_FIRST_ROUND_SQUARE_SHARE == 6
    const U128 n2 = square_flat_clmad(flat_nonce);
    const U128 x1_2 = square_flat_clmad(s[1]);
    const U128 n4 = square_flat_clmad(n2);
    const U128 x1_4 = square_flat_clmad(x1_2);
    {
        const U128 x0_2 = bxor(x1_2, bxor(n2, JOB_FIRST_B01_2));
        const U128 x0_4 = bxor(x1_4, bxor(n4, JOB_FIRST_B01_4));
        s[0] = sbox_x7_from_powers(s[0], x0_2, x0_4);
    }
    s[1] = sbox_x7_from_powers(s[1], x1_2, x1_4);
    {
        const U128 x2_2 = bxor(n2, JOB_FIRST_B2_2);
        const U128 x2_4 = bxor(n4, JOB_FIRST_B2_4);
        s[2] = sbox_x7_from_powers(s[2], x2_2, x2_4);
    }
    {
        const U128 x3_2 = bxor(n2, JOB_FIRST_B3_2);
        const U128 x3_4 = bxor(n4, JOB_FIRST_B3_4);
        s[3] = sbox_x7_from_powers(s[3], x3_2, x3_4);
    }
#endif
#else
#error "poseidon_permute_first_square_share called with unsupported mode"
#endif

    apply_mds_full(s);
    #pragma unroll 1
    for (int r = 1; r < NOID_N_ROUNDS; ++r) {
        const bool full = !(r >= NOID_F_ROUNDS / 2 && r < NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);
        if (full) { apply_full_round_sboxes(s, r); apply_mds_full(s); }
        else { s[0] = bxor(s[0], NOID_RC[0][r]); s[0] = sbox_x7(s[0]); apply_mds_partial(s); }
    }
}
#endif

__global__
void mine_kernel(
    Candidate *candidates,
    unsigned int *count,
    unsigned int capacity,
    U128 base)
{
#ifdef NOID_MDS_LUT4
    extern __shared__ U128 noid_lut4_shared[];
    const U128 *lut_src =
        &NOID_MDS_PARTIAL_LUT4[0][0][0];

    for (int i = threadIdx.x;
         i < NOID_MDS_LUT4_ENTRIES;
         i += blockDim.x)
        noid_lut4_shared[i] = lut_src[i];

    __syncthreads();
#endif

    const unsigned long long tid =
        (unsigned long long)blockIdx.x *
        blockDim.x + threadIdx.x;

#ifdef NOID_DUAL_NONCE_ILP
    const unsigned long long lane_span =
        (unsigned long long)gridDim.x * blockDim.x;
    const U128 flat_nonce0 = add_u64(base, tid);
    const U128 flat_nonce1 = add_u64(base, lane_span + tid);

    U128 s0[4];
    U128 s1[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        s0[i] = JOB_PREFIX[i];
        s1[i] = JOB_PREFIX[i];
    }

    s0[0] = bxor(s0[0], flat_nonce0);
    s1[0] = bxor(s1[0], flat_nonce1);
    s0[1] = bxor(s0[1], JOB_TAIL[1]);
    s1[1] = bxor(s1[1], JOB_TAIL[1]);
    poseidon_permute_dual(s0, s1);

    s0[0] = bxor(s0[0], JOB_TAIL[2]);
    s1[0] = bxor(s1[0], JOB_TAIL[2]);
    s0[1] = bxor(s0[1], JOB_TAIL[3]);
    s1[1] = bxor(s1[1], JOB_TAIL[3]);
    poseidon_permute_dual(s0, s1);

    s0[0] = bxor(s0[0], JOB_TAIL[4]);
    s1[0] = bxor(s1[0], JOB_TAIL[4]);
    s0[1] = bxor(s0[1], JOB_TAIL[5]);
    s1[1] = bxor(s1[1], JOB_TAIL[5]);
    poseidon_permute_dual(s0, s1);

    if (digest_lt_target(s0[0], s0[1])) {
        const unsigned int slot = atomicAdd(count, 1U);
        if (slot < capacity)
            candidates[slot].nonce = flat_to_tower_device(flat_nonce0);
    }
    if (digest_lt_target(s1[0], s1[1])) {
        const unsigned int slot = atomicAdd(count, 1U);
        if (slot < capacity)
            candidates[slot].nonce = flat_to_tower_device(flat_nonce1);
    }
#else
    const U128 flat_nonce = add_u64(base, tid);

    U128 s[4];

#if NOID_FIRST_MDS_HOIST == 0
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = JOB_PREFIX[i];

    s[0] = bxor(s[0], flat_nonce);
    s[1] = bxor(s[1], JOB_TAIL[1]);
#if NOID_FIRST_ROUND_SQUARE_SHARE == 0
    poseidon_permute(s);
#else
    poseidon_permute_first_square_share(s, flat_nonce);
#endif
#else
    /*
     * External MDS column 0 is [5,4,1,1] in tower coefficients.  In the
     * flat basis, 5*n = 4*n ^ n, so only one general field multiply remains.
     */
    const U128 MUL4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };
    const U128 n4 = gf_mul(MUL4, flat_nonce);
#if NOID_FIRST_MDS_HOIST == 1
    s[0] = bxor(JOB_FIRST_MDS[0], bxor(n4, flat_nonce));
    s[1] = bxor(JOB_FIRST_MDS[1], n4);
    s[2] = bxor(JOB_FIRST_MDS[2], flat_nonce);
    s[3] = bxor(JOB_FIRST_MDS[3], flat_nonce);
    poseidon_permute_after_initial_mds(s);
#elif NOID_FIRST_MDS_HOIST == 2
    s[0] = bxor(JOB_FIRST_RC0[0], bxor(n4, flat_nonce));
    s[1] = bxor(JOB_FIRST_RC0[1], n4);
    s[2] = bxor(JOB_FIRST_RC0[2], flat_nonce);
    s[3] = bxor(JOB_FIRST_RC0[3], flat_nonce);
    poseidon_permute_after_initial_mds_rc0(s);
#else
#error "Unsupported NOID_FIRST_MDS_HOIST"
#endif
#endif

    s[0] = bxor(s[0], JOB_TAIL[2]);
    s[1] = bxor(s[1], JOB_TAIL[3]);
    poseidon_permute(s);

    s[0] = bxor(s[0], JOB_TAIL[4]);
    s[1] = bxor(s[1], JOB_TAIL[5]);
    poseidon_permute(s);

    if (digest_lt_target(s[0], s[1])) {
        const unsigned int slot = atomicAdd(count, 1U);
        if (slot < capacity)
            candidates[slot].nonce = flat_to_tower_device(flat_nonce);
    }
#endif
}

static int hexval(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static U128 parse_le128(const char *s)
{
    unsigned char b[16];

    for (int i = 0; i < 16; ++i) {
        int h = hexval(s[i * 2]);
        int l = hexval(s[i * 2 + 1]);

        if (h < 0 || l < 0) {
            fprintf(stderr, "invalid hex\n");
            exit(2);
        }

        b[i] = (unsigned char)((h << 4) | l);
    }

    U128 x{0ULL, 0ULL};

    for (int i = 0; i < 8; ++i)
        x.lo |= (unsigned long long)b[i] << (8 * i);

    for (int i = 0; i < 8; ++i)
        x.hi |= (unsigned long long)b[8 + i] << (8 * i);

    return x;
}

static void nonce_hex(U128 x, char out[33])
{
    static const char *hex = "0123456789abcdef";

    unsigned char b[16];

    for (int i = 0; i < 8; ++i)
        b[i] = (x.lo >> (8 * i)) & 0xff;

    for (int i = 0; i < 8; ++i)
        b[8 + i] = (x.hi >> (8 * i)) & 0xff;

    for (int i = 0; i < 16; ++i) {
        out[i * 2] = hex[b[i] >> 4];
        out[i * 2 + 1] = hex[b[i] & 15];
    }

    out[32] = 0;
}

static U128 host_add(U128 a, unsigned long long x)
{
    unsigned long long old = a.lo;
    a.lo += x;

    if (a.lo < old)
        ++a.hi;

    return a;
}


struct BatchSlot {
    Candidate *d_candidates = nullptr;
    unsigned int *d_count = nullptr;
    Candidate *h_candidates = nullptr;
    unsigned int *h_count = nullptr;
    cudaEvent_t ev_start{};
    cudaEvent_t ev_stop{};
    cudaEvent_t ev_done{};
    unsigned long long seq = 0;
    bool outstanding = false;
};

struct DaemonContext {
    U128 *d_fields = nullptr;
    PreparedJob *d_prepared = nullptr;
    BatchSlot slots[2];
    cudaStream_t stream{};
    int blocks = 0;
    int threads = NOID_THREADS;
    unsigned long long hashes_per_batch = 0;
    U128 base{0ULL, 0ULL};
    std::string current_pow;
    std::string current_target;
    unsigned long long current_seq = 0;
};

static bool valid_hex(const std::string &s, size_t n)
{
    if (s.size() != n)
        return false;
    for (char c : s)
        if (hexval(c) < 0)
            return false;
    return true;
}

static bool parse_job_line(
    const std::string &line,
    unsigned long long &seq,
    std::string &powhex,
    std::string &targethex)
{
    std::istringstream iss(line);
    std::string cmd;
    if (!(iss >> cmd) || cmd != "JOB")
        return false;
    if (!(iss >> seq >> powhex >> targethex))
        return false;
    std::string extra;
    if (iss >> extra)
        return false;
    return valid_hex(powhex, 512) && valid_hex(targethex, 64);
}

static bool extract_line(std::string &buffer, std::string &line)
{
    const size_t pos = buffer.find('\n');
    if (pos == std::string::npos)
        return false;
    line = buffer.substr(0, pos);
    buffer.erase(0, pos + 1);
    if (!line.empty() && line.back() == '\r')
        line.pop_back();
    return true;
}

static bool read_until_line(std::string &buffer, std::string &line)
{
    while (!extract_line(buffer, line)) {
        char tmp[4096];
        const ssize_t n = ::read(STDIN_FILENO, tmp, sizeof(tmp));
        if (n > 0) {
            buffer.append(tmp, (size_t)n);
            continue;
        }
        if (n == 0)
            return false;
        if (errno == EINTR)
            continue;
        perror("read stdin");
        return false;
    }
    return true;
}

static void drain_lines_nonblocking(
    std::string &buffer,
    std::vector<std::string> &lines,
    bool &stdin_closed)
{
    char tmp[4096];
    for (;;) {
        const ssize_t n = ::read(STDIN_FILENO, tmp, sizeof(tmp));
        if (n > 0) {
            buffer.append(tmp, (size_t)n);
            continue;
        }
        if (n == 0) {
            stdin_closed = true;
            break;
        }
        if (errno == EINTR)
            continue;
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            break;
        perror("read stdin");
        stdin_closed = true;
        break;
    }

    std::string line;
    while (extract_line(buffer, line))
        lines.push_back(line);
}

static void apply_job(
    DaemonContext &ctx,
    unsigned long long seq,
    const std::string &powhex,
    const std::string &targethex)
{
    const bool pow_changed = (powhex != ctx.current_pow);
    const bool target_changed = (targethex != ctx.current_target);

    if (pow_changed) {
        U128 fields[16];
        for (int i = 0; i < 16; ++i)
            fields[i] = parse_le128(powhex.c_str() + i * 32);

        CUDA_OK(cudaMemcpy(
            ctx.d_fields,
            fields,
            sizeof(fields),
            cudaMemcpyHostToDevice));

        prepare_job<<<1,1>>>(ctx.d_fields, ctx.d_prepared);
        CUDA_OK(cudaGetLastError());
        CUDA_OK(cudaDeviceSynchronize());

        PreparedJob prepared{};
        CUDA_OK(cudaMemcpy(
            &prepared,
            ctx.d_prepared,
            sizeof(prepared),
            cudaMemcpyDeviceToHost));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_PREFIX,
            prepared.prefix,
            sizeof(prepared.prefix)));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TAIL,
            prepared.tail,
            sizeof(prepared.tail)));

#if NOID_FIRST_MDS_HOIST != 0
        CUDA_OK(cudaMemcpyToSymbol(
            JOB_FIRST_MDS,
            prepared.first_mds,
            sizeof(prepared.first_mds)));
#if NOID_FIRST_MDS_HOIST == 2
        CUDA_OK(cudaMemcpyToSymbol(
            JOB_FIRST_RC0,
            prepared.first_rc0,
            sizeof(prepared.first_rc0)));
#endif
#endif
#if NOID_FIRST_ROUND_SQUARE_SHARE >= 2
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B01_2, &prepared.first_b01_2, sizeof(U128)));
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B01_4, &prepared.first_b01_4, sizeof(U128)));
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B2_2, &prepared.first_b2_2, sizeof(U128)));
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B2_4, &prepared.first_b2_4, sizeof(U128)));
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B3_2, &prepared.first_b3_2, sizeof(U128)));
        CUDA_OK(cudaMemcpyToSymbol(JOB_FIRST_B3_4, &prepared.first_b3_4, sizeof(U128)));
#endif
    }

    if (target_changed) {
        const U128 target_lo = parse_le128(targethex.c_str());
        const U128 target_hi = parse_le128(targethex.c_str() + 32);

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TARGET_LO,
            &target_lo,
            sizeof(target_lo)));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TARGET_HI,
            &target_hi,
            sizeof(target_hi)));
    }

    ctx.current_pow = powhex;
    ctx.current_target = targethex;
    ctx.current_seq = seq;

    const char *mode = pow_changed ? "FULL" : (target_changed ? "TARGET" : "TAG");
    fprintf(stderr, "JOBACK %llu %s\n", seq, mode);
    fflush(stderr);
}

static void wait_for_done(cudaEvent_t event)
{
#if NOID_EVENT_POLL_US == 0
    // Control: the original runtime wait path.
    CUDA_OK(cudaEventSynchronize(event));
#else
    // cudaEventSynchronize may spin in the NVIDIA runtime even when
    // cudaDeviceScheduleBlockingSync is requested. Explicit query + sleep
    // keeps the CPU parked while preserving the existing two-slot pipeline.
    struct timespec delay{};
    delay.tv_sec = NOID_EVENT_POLL_US / 1000000;
    delay.tv_nsec = (NOID_EVENT_POLL_US % 1000000) * 1000;
    for (;;) {
        const cudaError_t status = cudaEventQuery(event);
        if (status == cudaSuccess)
            return;
        if (status != cudaErrorNotReady) {
            fprintf(stderr, "CUDA event query error: %s\n",
                cudaGetErrorString(status));
            exit(1);
        }
        nanosleep(&delay, nullptr);
    }
#endif
}

static bool process_command_lines(
    DaemonContext &ctx,
    const std::vector<std::string> &lines,
    bool &stop_requested)
{
    bool have_job = false;
    unsigned long long latest_seq = 0;
    std::string latest_pow;
    std::string latest_target;

    for (const std::string &line : lines) {
        if (line == "STOP") {
            stop_requested = true;
            continue;
        }

        unsigned long long seq = 0;
        std::string powhex, targethex;
        if (!parse_job_line(line, seq, powhex, targethex)) {
            if (!line.empty()) {
                fprintf(stderr, "BADCOMMAND %s\n", line.c_str());
                fflush(stderr);
            }
            continue;
        }

        // Input is ordered by the controller. If multiple JOB records arrived
        // during one GPU batch, apply only the newest one.
        if (!have_job || seq > latest_seq) {
            have_job = true;
            latest_seq = seq;
            latest_pow = std::move(powhex);
            latest_target = std::move(targethex);
        }
    }

    if (have_job && latest_seq > ctx.current_seq) {
        apply_job(ctx, latest_seq, latest_pow, latest_target);
        return true;
    }
    return false;
}


static void enqueue_batch(DaemonContext &ctx, BatchSlot &slot)
{
    if (slot.outstanding) {
        fprintf(stderr, "internal error: enqueue on outstanding slot\n");
        exit(1);
    }

    constexpr unsigned int CAP = 256;

    slot.seq = ctx.current_seq;
    *slot.h_count = 0U;

    CUDA_OK(cudaMemsetAsync(
        slot.d_count,
        0,
        sizeof(unsigned int),
        ctx.stream));

    CUDA_OK(cudaEventRecord(slot.ev_start, ctx.stream));

#ifdef NOID_MDS_LUT4
    const size_t dynamic_shared_bytes =
        (size_t)NOID_MDS_LUT4_SHARED_BYTES;
#else
    const size_t dynamic_shared_bytes = 0;
#endif

    mine_kernel<<<
        ctx.blocks,
        ctx.threads,
        dynamic_shared_bytes,
        ctx.stream>>>(
        slot.d_candidates,
        slot.d_count,
        CAP,
        ctx.base);

    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaEventRecord(slot.ev_stop, ctx.stream));

    // Copy a fixed tiny result buffer into pinned host memory.  Copying all
    // 256 candidate slots (~4 KiB) lets the next GPU batch be queued without
    // waiting for the 4-byte candidate count first.
    CUDA_OK(cudaMemcpyAsync(
        slot.h_count,
        slot.d_count,
        sizeof(unsigned int),
        cudaMemcpyDeviceToHost,
        ctx.stream));

    CUDA_OK(cudaMemcpyAsync(
        slot.h_candidates,
        slot.d_candidates,
        CAP * sizeof(Candidate),
        cudaMemcpyDeviceToHost,
        ctx.stream));

    CUDA_OK(cudaEventRecord(slot.ev_done, ctx.stream));

    slot.outstanding = true;
    ctx.base = host_add(ctx.base, ctx.hashes_per_batch);
}

static float finish_batch(
    DaemonContext &ctx,
    BatchSlot &slot,
    unsigned long long &batch_number,
    double &stat_hashes,
    double &stat_ms,
    std::chrono::steady_clock::time_point &stat_wall_start)
{
    if (!slot.outstanding)
        return 0.0f;

    wait_for_done(slot.ev_done);

    float ms = 0.0f;
    CUDA_OK(cudaEventElapsedTime(&ms, slot.ev_start, slot.ev_stop));

    const unsigned int count = *slot.h_count;
    const unsigned int n = std::min(count, 256U);

    stat_hashes += ctx.hashes_per_batch;
    stat_ms += ms;
    ++batch_number;

    if (n != 0) {
        for (unsigned int i = 0; i < n; ++i) {
            char hex[33];
            nonce_hex(slot.h_candidates[i].nonce, hex);
            printf("SHARE %llu %s\n", slot.seq, hex);
        }
        fflush(stdout);
    }

    slot.outstanding = false;

    if ((batch_number % NOID_STAT_BATCHES) == 0ULL) {
        const double mh = stat_hashes / (stat_ms * 1000.0);
        const auto wall_now = std::chrono::steady_clock::now();
        const double wall_s =
            std::chrono::duration<double>(wall_now - stat_wall_start).count();
        const double wall_mh =
            (wall_s > 0.0) ? (stat_hashes / wall_s / 1.0e6) : 0.0;

        fprintf(stderr,
            "STAT %.3f %.0f %llu %llu %.3f\n",
            mh,
            stat_hashes,
            batch_number,
            slot.seq,
            wall_mh);
        fflush(stderr);

        stat_hashes = 0.0;
        stat_ms = 0.0;
        stat_wall_start = wall_now;
    }

    return ms;
}

int main(int argc, char **argv)
{
    if (argc < 2 || strcmp(argv[1], "--daemon") != 0) {
        fprintf(stderr, "usage: %s --daemon [GPU_SALT]\n", argv[0]);
        fprintf(stderr, "stdin protocol: JOB <seq> <512-char-powhex> <64-char-targethex>\\n\n");
        return 2;
    }

    const unsigned long long gpu_salt =
        (argc >= 3) ? strtoull(argv[2], nullptr, 0) : 0ULL;

    // On large multi-GPU rigs, do not let every CUDA context busy-spin
    // while waiting on ~60 ms kernels. Blocking synchronization materially
    // reduces host CPU contention without changing GPU math.
    CUDA_OK(cudaSetDeviceFlags(cudaDeviceScheduleBlockingSync));
    CUDA_OK(cudaSetDevice(0));

    DaemonContext ctx;
    CUDA_OK(cudaMalloc(&ctx.d_fields, 16 * sizeof(U128)));
    CUDA_OK(cudaMalloc(&ctx.d_prepared, sizeof(PreparedJob)));
    CUDA_OK(cudaStreamCreateWithFlags(&ctx.stream, cudaStreamNonBlocking));

    for (int i = 0; i < 2; ++i) {
        CUDA_OK(cudaMalloc(&ctx.slots[i].d_candidates, 256 * sizeof(Candidate)));
        CUDA_OK(cudaMalloc(&ctx.slots[i].d_count, sizeof(unsigned int)));
        CUDA_OK(cudaMallocHost(&ctx.slots[i].h_candidates, 256 * sizeof(Candidate)));
        CUDA_OK(cudaMallocHost(&ctx.slots[i].h_count, sizeof(unsigned int)));
        CUDA_OK(cudaEventCreate(&ctx.slots[i].ev_start));
        CUDA_OK(cudaEventCreate(&ctx.slots[i].ev_stop));
        CUDA_OK(cudaEventCreate(&ctx.slots[i].ev_done));
    }

    cudaDeviceProp prop{};
    CUDA_OK(cudaGetDeviceProperties(&prop, 0));
    ctx.blocks = prop.multiProcessorCount * NOID_BLOCKS_PER_SM;
    ctx.hashes_per_batch =
        (unsigned long long)ctx.threads * (unsigned long long)ctx.blocks;
#ifdef NOID_DUAL_NONCE_ILP
    ctx.hashes_per_batch *= 2ULL;
#endif

    const unsigned long long now =
        (unsigned long long)
        std::chrono::high_resolution_clock::now()
        .time_since_epoch().count();

    ctx.base = U128{
        now ^
        0x9e3779b97f4a7c15ULL ^
        (gpu_salt * 0xd6e8feb86659fd93ULL),

        (now << 17) ^
        0xd1b54a32d192ed03ULL ^
        (gpu_salt * 0x94d049bb133111ebULL)
    };

#ifdef NOID_DUAL_NONCE_ILP
    const int nonce_lanes = 2;
#else
    const int nonce_lanes = 1;
#endif
    fprintf(stderr,
        "READY sm=%d blocks=%d threads=%d lanes=%d hashes_per_batch=%llu\n",
        prop.multiProcessorCount,
        ctx.blocks,
        ctx.threads,
        nonce_lanes,
        ctx.hashes_per_batch);
    fflush(stderr);

    // Receive the initial job before mining. Use raw read() from the start so
    // no stdio buffering can hide subsequent controller commands.
    std::string input_buffer;
    bool stop_requested = false;
    for (;;) {
        std::string line;
        if (!read_until_line(input_buffer, line)) {
            stop_requested = true;
            break;
        }
        std::vector<std::string> one{line};
        process_command_lines(ctx, one, stop_requested);
        if (stop_requested || ctx.current_seq != 0)
            break;
    }

    if (stop_requested || ctx.current_seq == 0)
        return 0;

    const int old_flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    if (old_flags >= 0)
        fcntl(STDIN_FILENO, F_SETFL, old_flags | O_NONBLOCK);

    double stat_hashes = 0.0;
    double stat_ms = 0.0;
    auto stat_wall_start = std::chrono::steady_clock::now();
    unsigned long long batch_number = 0;
    bool stdin_closed = false;

    // Two-slot pipeline: slot 1 is already executing while the host consumes
    // slot 0.  This hides host wakeup / pipe / result-processing latency that
    // became material on 12-GPU rigs, without changing the PoW kernel itself.
    enqueue_batch(ctx, ctx.slots[0]);
    enqueue_batch(ctx, ctx.slots[1]);
    int next_slot = 0;

    while (!stop_requested && !stdin_closed) {
        const int other_slot = next_slot ^ 1;

        finish_batch(
            ctx,
            ctx.slots[next_slot],
            batch_number,
            stat_hashes,
            stat_ms,
            stat_wall_start);

        // Read controller commands after every completed batch.  If a job
        // update arrived, drain the one already-queued old-job batch before
        // touching constant-memory job data.  That keeps every emitted share
        // tied to the exact sequence it was hashed against.
        std::vector<std::string> lines;
        drain_lines_nonblocking(input_buffer, lines, stdin_closed);

        if (!lines.empty() || stdin_closed) {
            if (ctx.slots[other_slot].outstanding) {
                finish_batch(
                    ctx,
                    ctx.slots[other_slot],
                    batch_number,
                    stat_hashes,
                    stat_ms,
                    stat_wall_start);
            }

            // Capture anything that arrived while the queued batch drained so
            // only the newest JOB record is applied.
            std::vector<std::string> more;
            drain_lines_nonblocking(input_buffer, more, stdin_closed);
            lines.insert(lines.end(), more.begin(), more.end());

            if (!lines.empty())
                process_command_lines(ctx, lines, stop_requested);

            if (stop_requested || stdin_closed)
                break;

            enqueue_batch(ctx, ctx.slots[0]);
            enqueue_batch(ctx, ctx.slots[1]);
            next_slot = 0;
            continue;
        }

        // Normal steady state: put the just-consumed slot behind the batch
        // already running in the same stream.  The GPU therefore has no host
        // scheduling bubble between batches.
        enqueue_batch(ctx, ctx.slots[next_slot]);
        next_slot = other_slot;
    }

    CUDA_OK(cudaStreamSynchronize(ctx.stream));

    for (int i = 0; i < 2; ++i) {
        CUDA_OK(cudaEventDestroy(ctx.slots[i].ev_start));
        CUDA_OK(cudaEventDestroy(ctx.slots[i].ev_stop));
        CUDA_OK(cudaEventDestroy(ctx.slots[i].ev_done));
        CUDA_OK(cudaFree(ctx.slots[i].d_candidates));
        CUDA_OK(cudaFree(ctx.slots[i].d_count));
        CUDA_OK(cudaFreeHost(ctx.slots[i].h_candidates));
        CUDA_OK(cudaFreeHost(ctx.slots[i].h_count));
    }

    CUDA_OK(cudaStreamDestroy(ctx.stream));
    CUDA_OK(cudaFree(ctx.d_fields));
    CUDA_OK(cudaFree(ctx.d_prepared));

    return 0;
}
