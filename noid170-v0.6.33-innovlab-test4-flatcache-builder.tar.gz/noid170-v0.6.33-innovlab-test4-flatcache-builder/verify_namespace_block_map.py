#!/usr/bin/env python3
import random
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
runtime = (ROOT / "src" / "noid_runtime_params.h").read_text()
lut_text = (ROOT / "src" / "noid_t2f_nibble_lut.h").read_text()

m = re.search(r"NOID_T2F_ROWS\[128\]\s*=\s*\{(.*?)\};", runtime, re.S)
if not m:
    raise SystemExit("T2F rows not found")
rows = [
    (int(lo, 16), int(hi, 16))
    for lo, hi in re.findall(r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", m.group(1))
]
if len(rows) != 128:
    raise SystemExit(f"expected 128 T2F rows, got {len(rows)}")

sections = re.findall(
    r"(?:NOID_T2F_LOW_NIBBLE_LUT\[16\]\[16\]|NOID_T2F_HIGH_NIBBLE_LUT_HOST\[16\]\[16\])\s*=\s*\{(.*?)\};",
    lut_text,
    re.S,
)
if len(sections) != 2:
    raise SystemExit("could not parse both nibble LUT sections")
parsed = []
for sec in sections:
    entries = [
        (int(lo, 16), int(hi, 16))
        for lo, hi in re.findall(r"\{0x([0-9a-fA-F]+)ULL,0x([0-9a-fA-F]+)ULL\}", sec)
    ]
    if len(entries) != 256:
        raise SystemExit(f"expected 256 LUT entries, got {len(entries)}")
    parsed.append([entries[i * 16:(i + 1) * 16] for i in range(16)])
low_lut, high_lut = parsed


def slow(counter, ns_hi):
    olo = ohi = 0
    for bit, (rlo, rhi) in enumerate(rows):
        p = ((counter & rlo).bit_count() ^ (ns_hi & rhi).bit_count()) & 1
        if p:
            if bit < 64:
                olo |= 1 << bit
            else:
                ohi |= 1 << (bit - 64)
    return olo, ohi


def xor2(a, b):
    return a[0] ^ b[0], a[1] ^ b[1]


def namespace_flat(ns_hi):
    out = (0, 0)
    for nib in range(16):
        out = xor2(out, high_lut[nib][(ns_hi >> (4 * nib)) & 0xF])
    return out


def block_flat(base, ns_hi):
    out = namespace_flat(ns_hi)
    for nib in range(16):
        out = xor2(out, low_lut[nib][(base >> (4 * nib)) & 0xF])
    return out


def low9_flat(lane):
    out = (0, 0)
    for bit in range(9):
        if lane & (1 << bit):
            out = xor2(out, low_lut[bit >> 2][1 << (bit & 3)])
    return out


rng = random.Random(0x63302)
ns_cases = [0, 0x000200000001EA19, 0x000200000001EFAF, (1 << 64) - 1]
ns_cases += [rng.getrandbits(64) for _ in range(32)]
base_cases = [0, 0x123400, 0x123456789ABCDE00, 0xFFFFFFFFFFFFE000]
base_cases += [rng.getrandbits(64) & ~511 for _ in range(128)]
lanes = [0, 1, 2, 3, 255, 256, 510, 511]
lanes += [rng.randrange(512) for _ in range(24)]

checks = 0
for ns in ns_cases:
    ns &= (1 << 64) - 1
    for raw_base in base_cases:
        base = raw_base & ~511
        bf = block_flat(base, ns)
        for lane in lanes:
            fast = xor2(bf, low9_flat(lane))
            counter = (base + lane) & ((1 << 64) - 1)
            ref = slow(counter, ns)
            if fast != ref:
                raise SystemExit(
                    f"NAMESPACE_BLOCK_OFFLINE_FAIL ns={ns:016x} base={base:016x} "
                    f"lane={lane} fast={fast} ref={ref}"
                )
            checks += 1

print(f"NAMESPACE_BLOCK_OFFLINE_PASS checks={checks} threads=512 alignment=512")
