#!/usr/bin/env python3

import random

MASK64 = (1 << 64) - 1
MASK128 = (1 << 128) - 1
POLY = 0x87


def clmul64(a, b):
    product = 0
    while a:
        lowest = a & -a
        product ^= b << (lowest.bit_length() - 1)
        a ^= lowest
    return product


def clmul(a, b):
    product = 0
    while a:
        lowest = a & -a
        product ^= b << (lowest.bit_length() - 1)
        a ^= lowest
    return product


def reduce_any(value):
    """Reference reduction for an arbitrary-size polynomial."""
    while value.bit_length() > 128:
        shift = value.bit_length() - 129
        value ^= (1 << (128 + shift)) | (POLY << shift)
    return value


def reduce_384_reference(c0, c1, c2):
    # z=x^128=q, so C0+C1*z+C2*z^2 = C0+C1*q+C2*q^2.
    return reduce_any(c0 ^ clmul(c1, POLY) ^ clmul(c2, 0x4015))


def mul_small_128(value, shifts):
    product = 0
    for shift in shifts:
        product ^= value << shift
    return product & MASK128, product >> 128


def reduce_384_shift(c0, c1, c2):
    q1_low, q1_overflow = mul_small_128(c1, (0, 1, 2, 7))
    q2_low, q2_overflow = mul_small_128(c2, (0, 2, 4, 14))
    overflow = q1_overflow ^ q2_overflow
    final_fold = (
        overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    )
    return (c0 ^ q1_low ^ q2_low ^ final_fold) & MASK128


def square_field(value):
    return reduce_any(clmul(value, value))


def mul_field(a, b):
    return reduce_any(clmul(a, b))


def sbox_reference(value):
    x2 = square_field(value)
    x4 = square_field(x2)
    x3 = mul_field(value, x2)
    return mul_field(x3, x4)


def sbox_lazy_x3(value):
    x2 = square_field(value)
    x4 = square_field(x2)
    raw_x3 = clmul(value, x2)
    raw_x7 = clmul(raw_x3, x4)
    c0 = raw_x7 & MASK128
    c1 = (raw_x7 >> 128) & MASK128
    c2 = (raw_x7 >> 256) & MASK128
    return reduce_384_shift(c0, c1, c2)


def reduce_shift(high, low):
    folded = high
    folded ^= (high << 1) & MASK128
    folded ^= (high << 2) & MASK128
    folded ^= (high << 7) & MASK128
    high_hi = high >> 64
    overflow = (high_hi >> 63) ^ (high_hi >> 62) ^ (high_hi >> 57)
    folded ^= overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    return (low ^ folded) & MASK128


def reduce_r5(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1 = clmul64(h1, POLY)
    r0 = l0 ^ (p0 & MASK64)
    r1 = l1 ^ (p0 >> 64) ^ (p1 & MASK64)
    overflow = p1 >> 64
    r0 ^= clmul64(overflow, POLY) & MASK64
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r4_topshift(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1_low = clmul64(h1, POLY) & MASK64
    overflow = (h1 >> 63) ^ (h1 >> 62) ^ (h1 >> 57)
    r0 = l0 ^ (p0 & MASK64) ^ (clmul64(overflow, POLY) & MASK64)
    r1 = l1 ^ (p0 >> 64) ^ p1_low
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r4_foldshift(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1 = clmul64(h1, POLY)
    overflow = p1 >> 64
    fold = overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    r0 = l0 ^ (p0 & MASK64) ^ fold
    r1 = l1 ^ (p0 >> 64) ^ (p1 & MASK64)
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r3(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1_low = clmul64(h1, POLY) & MASK64
    overflow = (h1 >> 63) ^ (h1 >> 62) ^ (h1 >> 57)
    fold = overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    r0 = l0 ^ (p0 & MASK64) ^ fold
    r1 = l1 ^ (p0 >> 64) ^ p1_low
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def square_qlo(value):
    return (value ^ (value << 1) ^ (value << 2) ^ (value << 7)) & MASK64


def square_qhi_even(value):
    # Each square product has zero odd-numbered bits, eliminating value>>63.
    return (value >> 62) ^ (value >> 57)


def square_reduction_variant(value, variant):
    low_product = clmul64(value & MASK64, value & MASK64)
    high_product = clmul64(value >> 64, value >> 64)
    l0, l1 = low_product & MASK64, low_product >> 64
    h0, h1 = high_product & MASK64, high_product >> 64
    if (h0 | h1) & 0xAAAAAAAAAAAAAAAA:
        raise AssertionError("square product lost alternating-bit invariant")
    h0_hi = square_qhi_even(h0)
    h1_hi = square_qhi_even(h1)
    if variant == "r3even":
        r0 = l0 ^ (clmul64(h0, POLY) & MASK64) ^ square_qlo(h1_hi)
        r1 = l1 ^ (clmul64(h0, POLY) >> 64) ^ (clmul64(h1, POLY) & MASK64)
    elif variant == "r2even":
        r0 = l0 ^ (clmul64(h0, POLY) & MASK64) ^ square_qlo(h1_hi)
        r1 = l1 ^ h0_hi ^ (clmul64(h1, POLY) & MASK64)
    elif variant == "r1low":
        r0 = l0 ^ (clmul64(h0, POLY) & MASK64) ^ square_qlo(h1_hi)
        r1 = l1 ^ h0_hi ^ square_qlo(h1)
    elif variant == "r1high":
        r0 = l0 ^ square_qlo(h0) ^ square_qlo(h1_hi)
        r1 = l1 ^ h0_hi ^ (clmul64(h1, POLY) & MASK64)
    elif variant == "r0shift":
        r0 = l0 ^ square_qlo(h0) ^ square_qlo(h1_hi)
        r1 = l1 ^ h0_hi ^ square_qlo(h1)
    else:
        raise ValueError(variant)
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def main():
    rng = random.Random(0x170055)
    edge = [0, 1, MASK128, 1 << 127, 1 << 64, MASK64]
    vectors = [(a, b) for a in edge for b in edge]
    vectors.extend((rng.getrandbits(128), rng.getrandbits(128)) for _ in range(20000))
    methods = {
        "r5": reduce_r5,
        "r4top": reduce_r4_topshift,
        "r4fold": reduce_r4_foldshift,
        "r3": reduce_r3,
    }

    for index, (high, low) in enumerate(vectors):
        expected = reduce_shift(high, low)
        for name, method in methods.items():
            actual = method(high, low)
            if actual != expected:
                raise SystemExit(
                    f"FAIL {name} vector={index} high={high:032x} low={low:032x} "
                    f"expected={expected:032x} actual={actual:032x}"
                )

    print(f"OFFLINE GF REDUCTION MODEL: PASS (variants=4 vectors={len(vectors)})")

    square_rng = random.Random(0x170062)
    square_vectors = edge + [square_rng.getrandbits(128) for _ in range(50000)]
    square_variants = ("r3even", "r2even", "r1low", "r1high", "r0shift")
    for index, value in enumerate(square_vectors):
        raw_low = clmul64(value & MASK64, value & MASK64)
        raw_high = clmul64(value >> 64, value >> 64)
        expected = reduce_shift(raw_high, raw_low)
        for variant in square_variants:
            actual = square_reduction_variant(value, variant)
            if actual != expected:
                raise SystemExit(
                    f"FAIL square-{variant} vector={index} value={value:032x} "
                    f"expected={expected:032x} actual={actual:032x}"
                )
    print(
        "OFFLINE SQUARE-ONLY REDUCTION MODEL: PASS "
        f"(variants={len(square_variants)} vectors={len(square_vectors)})"
    )

    x7_rng = random.Random(0x1700711)
    x7_vectors = edge + [x7_rng.getrandbits(128) for _ in range(20000)]
    for index, value in enumerate(x7_vectors):
        expected = sbox_reference(value)
        actual = sbox_lazy_x3(value)
        if actual != expected:
            raise SystemExit(
                f"FAIL fused-x7 vector={index} value={value:032x} "
                f"expected={expected:032x} actual={actual:032x}"
            )

        # Independently check the exact limb/shift 384-bit reducer used by CUDA.
        probe = clmul(clmul(value, square_field(value)), square_field(square_field(value)))
        c0 = probe & MASK128
        c1 = (probe >> 128) & MASK128
        c2 = (probe >> 256) & MASK128
        if reduce_384_shift(c0, c1, c2) != reduce_384_reference(c0, c1, c2):
            raise SystemExit(f"FAIL 384-reduce vector={index} value={value:032x}")
    print(
        "OFFLINE FUSED X7 MODEL: PASS "
        f"(lazy-reduction=1 vectors={len(x7_vectors)})"
    )

if __name__ == "__main__":
    main()
