#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
TEMPLATE="$ROOT/template/noid170"
BUILD="$ROOT/build"
DIST="$ROOT/dist"
VERSION="0.6.33-test4-flatcache"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

mkdir -p "$BUILD" "$DIST"
rm -f "$TEMPLATE/noid_live_job_daemon_ns"
rm -rf "$TEMPLATE/__pycache__"

[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }

EXPECTED_ARIA_DAEMON="5e0c6bf353ca09f808193284358ce71a81a254b00a613f5010e528f2a24fd2bc"
EXPECTED_CONT="40c70611a2a7a2783044a2fbeeb051214882ef95e2836bba6301e2b8dfeb23a7"
EXPECTED_ARIA_WRAPPER="05a56aab90341ea1ab076e02e54d32a42043b7e2ebae9f75fc787d7f739b06af"

check_sha() {
  local file="$1" expected="$2" label="$3"
  local got
  got=$(sha256sum "$file" | awk '{print $1}')
  echo "$label SHA256: $got"
  [[ "$got" == "$expected" ]] || {
    echo "ERROR: $label no longer matches v0.6.32 production checkpoint"
    exit 1
  }
}

echo "===== OFFLINE NAMESPACE LUT GATE ====="
python3 "$ROOT/verify_namespace_lut.py"
echo
echo "===== OFFLINE NAMESPACE BLOCK-DECOMPOSITION GATE ====="
python3 "$ROOT/verify_namespace_block_map.py"
echo

echo "===== PRESERVED v0.6.32 ARIA CHECKPOINT ====="
check_sha "$TEMPLATE/noid_live_job_daemon" "$EXPECTED_ARIA_DAEMON" "Aria daemon"
check_sha "$TEMPLATE/noid_live_job_cont" "$EXPECTED_CONT" "warmup worker"
check_sha "$TEMPLATE/noid170_aria.py" "$EXPECTED_ARIA_WRAPPER" "Aria wrapper"

COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1
  -DNOID_SQUARE_CLMAD=1
  -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8
  -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=2
  -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1
  -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1
  -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000
  -DNOID_THREADS=512
  -DNOID_BLOCKS_PER_SM=128
  -DNOID_FIRST_MDS_HOIST=0
  -DNOID_FIRST_ROUND_SQUARE_SHARE=3
  -Xptxas=-v
)

echo
echo "===== COMPILE NAMESPACE-AWARE SHARE4 DAEMON ====="
"$NVCC" "${COMMON[@]}" "$SRC/noid_live_job_daemon_ns.cu" \
  -o "$BUILD/noid_live_job_daemon_ns" 2>&1 | tee "$BUILD/build-ns-daemon.log"
chmod 755 "$BUILD/noid_live_job_daemon_ns"
sha256sum "$BUILD/noid_live_job_daemon_ns"

echo
echo "===== NAMESPACE TOWER->FLAT LUT GPU ORACLE ====="
"$NVCC" -O3 -std=c++17 -arch=sm_80 -I"$SRC" \
  "$ROOT/test_namespace_map.cu" -o "$BUILD/test_namespace_map"
chmod 755 "$BUILD/test_namespace_map"
CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/test_namespace_map"

echo
echo "===== NAMESPACE BLOCK-DECOMPOSITION GPU ORACLE ====="
"$NVCC" -O3 -std=c++17 -arch=sm_80 -I"$SRC" \
  "$ROOT/test_namespace_block_map.cu" -o "$BUILD/test_namespace_block_map"
chmod 755 "$BUILD/test_namespace_block_map"
CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/test_namespace_block_map"

echo
echo "===== NAMESPACE FULL-FLAT PRECOMPUTE GPU ORACLE ====="
"$NVCC" -O3 -std=c++17 -arch=sm_80 -I"$SRC" \
  "$ROOT/test_namespace_precompute.cu" -o "$BUILD/test_namespace_precompute"
chmod 755 "$BUILD/test_namespace_precompute"
CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/test_namespace_precompute"

echo
echo "===== DAEMON JOBNS PROTOCOL SMOKE TEST ====="
POW_ZERO=$(printf '0%.0s' {1..512})
TARGET_ZERO=$(printf '0%.0s' {1..64})
NS_TEST="19ea010000000200"
SMOKE_LOG="$BUILD/jobns-smoke.log"
set +e
{
  printf 'JOBNS 1 %s %s %s\n' "$POW_ZERO" "$TARGET_ZERO" "$NS_TEST"
  sleep 0.5
  printf 'STOP\n'
} | CUDA_VISIBLE_DEVICES="${NOID_TEST_GPU:-0}" "$BUILD/noid_live_job_daemon_ns" --daemon 633 \
  >"$BUILD/jobns-smoke.stdout" 2>"$SMOKE_LOG"
RC=$?
set -e
cat "$SMOKE_LOG"
[[ "$RC" -eq 0 ]] || { echo "ERROR: JOBNS smoke daemon exited $RC"; exit 1; }
grep -q '^READY ' "$SMOKE_LOG" || { echo "ERROR: no READY in JOBNS smoke"; exit 1; }
grep -q '^JOBACK 1 ' "$SMOKE_LOG" || { echo "ERROR: no JOBACK 1 in JOBNS smoke"; exit 1; }

echo
echo "===== WRAPPER/SHELL SYNTAX ====="
python3 -m py_compile "$TEMPLATE/noid170_aria.py" "$TEMPLATE/noid170_stratum.py" "$TEMPLATE/hive_stats.py"
bash -n "$TEMPLATE/h-config.sh" "$TEMPLATE/h-run.sh" "$TEMPLATE/h-stats.sh"
rm -rf "$TEMPLATE/__pycache__"

cp -f "$BUILD/noid_live_job_daemon_ns" "$TEMPLATE/noid_live_job_daemon_ns"
chmod 755 "$TEMPLATE/noid_live_job_daemon_ns"

OUT="$DIST/noid170-$VERSION.tar.gz"
rm -f "$OUT" "$OUT.sha256"
(
  cd "$ROOT/template"
  tar --sort=name --mtime='UTC 2026-09-02' --owner=0 --group=0 --numeric-owner \
    -czf "$OUT" noid170
)
sha256sum "$OUT" | tee "$OUT.sha256"

echo
echo "===== PACKAGE CONTENTS ====="
tar -tzf "$OUT"

echo
echo "===== PACKAGE CHECKS ====="
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
tar -xzf "$OUT" -C "$TMP"
check_sha "$TMP/noid170/noid_live_job_daemon" "$EXPECTED_ARIA_DAEMON" "packaged Aria daemon"
check_sha "$TMP/noid170/noid_live_job_cont" "$EXPECTED_CONT" "packaged warmup worker"
check_sha "$TMP/noid170/noid170_aria.py" "$EXPECTED_ARIA_WRAPPER" "packaged Aria wrapper"
[[ -x "$TMP/noid170/noid_live_job_daemon_ns" ]] || { echo "ERROR: namespace daemon missing"; exit 1; }
python3 -m py_compile "$TMP/noid170/noid170_stratum.py"
rm -rf "$TMP/noid170/__pycache__"

echo
echo "===== v$VERSION TEST BUILD COMPLETE ====="
echo "Archive: $OUT"
echo "Aria path: exact v0.6.32 production checkpoint preserved"
echo "Stratum path: new namespace-aware daemon + parano1d-stratum-v1 TLS controller"
echo "This builder DOES NOT install or replace the running HiveOS miner."
