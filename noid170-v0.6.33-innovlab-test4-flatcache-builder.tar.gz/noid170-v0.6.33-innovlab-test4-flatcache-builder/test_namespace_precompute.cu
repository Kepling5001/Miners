#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>

struct U128 { unsigned long long lo, hi; };
#include "src/noid_t2f_nibble_lut.h"

#define CUDA_OK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){ \
  fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

__device__ __constant__ U128 NS_FLAT;
__device__ U128 LOW9[512];

__global__ void prep(U128 *out, int nblocks, unsigned long long batch_base)
{
    const int block=(int)(blockIdx.x*blockDim.x+threadIdx.x);
    if(block>=nblocks) return;
    const unsigned long long c=batch_base+(unsigned long long)block*512ULL;
    U128 flat=NS_FLAT;
    #pragma unroll
    for(int nib=0;nib<16;++nib){
        unsigned v=(unsigned)((c>>(nib*4))&0xfULL);
        U128 x=NOID_T2F_LOW_NIBBLE_LUT[nib][v];
        flat.lo^=x.lo; flat.hi^=x.hi;
    }
    out[block]=flat;
}

__global__ void compose(const U128 *blocks, U128 *out, unsigned long long base)
{
    unsigned tid=(unsigned)(blockIdx.x*blockDim.x+threadIdx.x);
    U128 b=blocks[blockIdx.x];
    U128 l=LOW9[threadIdx.x];
    out[tid]=U128{b.lo^l.lo,b.hi^l.hi};
}

static U128 low_to_flat(unsigned long long c)
{
    U128 out{0,0};
    for(int nib=0;nib<16;++nib){
        unsigned v=(unsigned)((c>>(nib*4))&0xfULL);
        U128 x=NOID_T2F_LOW_NIBBLE_LUT_HOST[nib][v];
        out.lo^=x.lo; out.hi^=x.hi;
    }
    return out;
}

int main()
{
    U128 hlow[512];
    for(unsigned i=0;i<512;++i) hlow[i]=low_to_flat(i);
    CUDA_OK(cudaMemcpyToSymbol(LOW9,hlow,sizeof(hlow)));

    const unsigned long long nsvals[] = {
        0x000200000001ea19ULL, 0x000200000001f27eULL,
        0x0123456789abcdefULL, 0xfedcba9876543210ULL
    };
    const unsigned long long bases[] = {
        0ULL, 512ULL, 0x1234567800000000ULL, 0xfffffff000000000ULL
    };
    constexpr int NB=32;
    constexpr int NT=NB*512;
    U128 *db=nullptr,*do_=nullptr;
    CUDA_OK(cudaMalloc(&db,NB*sizeof(U128)));
    CUDA_OK(cudaMalloc(&do_,NT*sizeof(U128)));
    U128 *h=(U128*)malloc(NT*sizeof(U128));
    if(!h) return 2;
    unsigned long long checks=0;
    for(auto ns:nsvals){
        U128 nsflat{ns^0x9e3779b97f4a7c15ULL,(ns<<7)^0xd1b54a32d192ed03ULL};
        CUDA_OK(cudaMemcpyToSymbol(NS_FLAT,&nsflat,sizeof(nsflat)));
        for(auto base:bases){
            base&=~511ULL;
            prep<<<1,256>>>(db,NB,base);
            compose<<<NB,512>>>(db,do_,base);
            CUDA_OK(cudaGetLastError());
            CUDA_OK(cudaDeviceSynchronize());
            CUDA_OK(cudaMemcpy(h,do_,NT*sizeof(U128),cudaMemcpyDeviceToHost));
            for(int i=0;i<NT;++i){
                U128 lo=low_to_flat(base+(unsigned long long)i);
                U128 want{nsflat.lo^lo.lo,nsflat.hi^lo.hi};
                if(h[i].lo!=want.lo||h[i].hi!=want.hi){
                    fprintf(stderr,"PRECOMPUTE_MISMATCH ns=%llx base=%llx tid=%d\n",ns,base,i);
                    return 1;
                }
                ++checks;
            }
        }
    }
    printf("NAMESPACE_PRECOMPUTE_PASS checks=%llu blocks=%d threads=512\n",checks,NB);
    cudaFree(db); cudaFree(do_); free(h); return 0;
}
