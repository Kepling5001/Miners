#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_runtime_params.h"
#include "noid_t2f_nibble_lut.h"

__device__ __forceinline__
int parity_mask_block(U128 a, U128 b)
{
    return (__popcll(a.lo & b.lo) + __popcll(a.hi & b.hi)) & 1;
}

__device__ __forceinline__
U128 slow_tower_to_flat_block(U128 tower)
{
    U128 out{0ULL, 0ULL};
    #pragma unroll
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask_block(tower, NOID_T2F_ROWS[bit])) {
            if (bit < 64) out.lo |= 1ULL << bit;
            else          out.hi |= 1ULL << (bit - 64);
        }
    }
    return out;
}

static U128 high_to_flat_host_block(unsigned long long ns_hi)
{
    U128 out{0ULL, 0ULL};
    for (int nib = 0; nib < 16; ++nib) {
        const unsigned int v = (unsigned int)((ns_hi >> (nib * 4)) & 0xFULL);
        const U128 x = NOID_T2F_HIGH_NIBBLE_LUT_HOST[nib][v];
        out.lo ^= x.lo;
        out.hi ^= x.hi;
    }
    return out;
}

__constant__ U128 TEST_NS_FLAT;

__device__ __forceinline__
U128 block_base_to_flat(unsigned long long block_counter)
{
    U128 out = TEST_NS_FLAT;
    #pragma unroll
    for (int nib = 0; nib < 16; ++nib) {
        const unsigned int v = (unsigned int)((block_counter >> (nib * 4)) & 0xFULL);
        const U128 x = NOID_T2F_LOW_NIBBLE_LUT[nib][v];
        out.lo ^= x.lo;
        out.hi ^= x.hi;
    }
    return out;
}

__device__ __forceinline__
U128 low9_to_flat(unsigned int lane)
{
    U128 out{0ULL, 0ULL};
    #pragma unroll
    for (int bit = 0; bit < 9; ++bit) {
        if (lane & (1U << bit)) {
            const U128 x = NOID_T2F_LOW_NIBBLE_LUT[bit >> 2][1U << (bit & 3)];
            out.lo ^= x.lo;
            out.hi ^= x.hi;
        }
    }
    return out;
}

__global__
void test_kernel(unsigned long long base, unsigned long long ns_hi, unsigned int *errors)
{
    __shared__ U128 block_flat;
    const unsigned long long block_counter =
        base + (unsigned long long)blockIdx.x * (unsigned long long)blockDim.x;

    if (threadIdx.x == 0)
        block_flat = block_base_to_flat(block_counter);
    __syncthreads();

    const U128 low = low9_to_flat((unsigned int)threadIdx.x);
    const U128 fast{block_flat.lo ^ low.lo, block_flat.hi ^ low.hi};
    const unsigned long long counter = block_counter + (unsigned long long)threadIdx.x;
    const U128 slow = slow_tower_to_flat_block(U128{counter, ns_hi});

    if (fast.lo != slow.lo || fast.hi != slow.hi)
        atomicAdd(errors, 1U);
}

int main()
{
    const unsigned long long namespaces[] = {
        0ULL,
        0x000200000001ea19ULL,
        0x000200000001efafULL,
        0xffffffffffffffffULL,
    };
    const unsigned long long bases[] = {
        0ULL,
        0x0000000000123400ULL,
        0x123456789abcde00ULL,
        0xffffffffffffe000ULL,
    };

    unsigned int *d_errors = nullptr;
    cudaError_t e = cudaMalloc(&d_errors, sizeof(unsigned int));
    if (e != cudaSuccess) {
        std::fprintf(stderr, "CUDA malloc failed: %s\n", cudaGetErrorString(e));
        return 2;
    }

    for (unsigned long long ns : namespaces) {
        const U128 ns_flat = high_to_flat_host_block(ns);
        e = cudaMemcpyToSymbol(TEST_NS_FLAT, &ns_flat, sizeof(ns_flat));
        if (e != cudaSuccess) {
            std::fprintf(stderr, "CUDA namespace copy failed: %s\n", cudaGetErrorString(e));
            return 2;
        }

        for (unsigned long long raw_base : bases) {
            const unsigned long long base = raw_base & ~511ULL;
            cudaMemset(d_errors, 0, sizeof(unsigned int));
            test_kernel<<<8, 512>>>(base, ns, d_errors);
            e = cudaDeviceSynchronize();
            if (e != cudaSuccess) {
                std::fprintf(stderr, "CUDA test kernel failed: %s\n", cudaGetErrorString(e));
                return 2;
            }

            unsigned int errors = 0;
            cudaMemcpy(&errors, d_errors, sizeof(errors), cudaMemcpyDeviceToHost);
            if (errors) {
                std::fprintf(stderr,
                    "NAMESPACE_BLOCK_MAP_FAIL ns=%016llx base=%016llx errors=%u\n",
                    ns, base, errors);
                return 1;
            }
        }
    }

    cudaFree(d_errors);
    std::printf("NAMESPACE_BLOCK_MAP_PASS cases=%zu bases=%zu blocks=8 threads=512\n",
        sizeof(namespaces)/sizeof(namespaces[0]),
        sizeof(bases)/sizeof(bases[0]));
    return 0;
}
