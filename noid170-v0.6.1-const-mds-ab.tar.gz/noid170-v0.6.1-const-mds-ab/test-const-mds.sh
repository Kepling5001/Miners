#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VARIANTS=(current ctkar pflat2 fflat2 allflat2 allr3 hybrid pflat1 allflat1 alllop3)

for variant in "${VARIANTS[@]}"; do
  [[ -x "$ROOT/bin/noid_daemon_$variant" ]] || {
    echo "ERROR: run ./build-on-rig.sh first"
    exit 1
  }
done

if pgrep -f '/hive/miners/custom/noid170/noid_live_job_daemon --daemon' >/dev/null 2>&1; then
  echo "ERROR: HiveOS noid170 is still mining. Stop or pause the flight sheet first."
  exit 1
fi

python3 "$ROOT/offline_verify.py"

echo "===== GPU CORRECTNESS ORACLES ====="
for variant in "${VARIANTS[@]}"; do
  echo "--- $variant ---"
  "$ROOT/bin/test_gf_$variant"
done

python3 "$ROOT/benchmark_const_mds.py"
env -u NOID_TEST_VARIANT -u NOID_FORCE_VARIANT "$ROOT/test-persistent.sh"

echo
echo "Paste the complete FINAL FIXED-CONSTANT MDS RANKING and persistent-worker result back into chat."
