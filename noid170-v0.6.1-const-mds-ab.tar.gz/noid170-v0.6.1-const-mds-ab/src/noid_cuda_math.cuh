__device__ __forceinline__
U128 bxor(U128 a, U128 b)
{
    return {a.lo ^ b.lo, a.hi ^ b.hi};
}

__device__ __forceinline__
bool nonzero(U128 a)
{
    return (a.lo | a.hi) != 0ULL;
}

/*
 * Correctness-first GF(2^128) multiplication.
 *
 * Flat/GCM basis polynomial:
 *     x^128 + x^7 + x^2 + x + 1
 *
 * This version is intentionally simple.
 * We optimize it only AFTER matching the Rust oracle.
 */

__device__ __forceinline__
U128 shl128(U128 a, unsigned n)
{
    if (n == 0)
        return a;

    U128 r;
    r.lo = a.lo << n;
    r.hi = (a.hi << n) | (a.lo >> (64 - n));
    return r;
}

__device__ __forceinline__
U128 clmul64_nibble(
    unsigned long long a,
    unsigned long long b)
{
    unsigned long long lo;
    unsigned long long hi;
    const unsigned long long zero = 0ULL;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(zero)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(zero)
    );

    return {lo, hi};
}

__device__ __forceinline__
U128 clmul64_accumulate(
    unsigned long long a,
    unsigned long long b,
    U128 accumulator)
{
    unsigned long long lo;
    unsigned long long hi;

    // PTX clmad performs carry-less multiplication followed by XOR with c.
    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(lo)
        : "l"(a), "l"(b), "l"(accumulator.lo)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(hi)
        : "l"(a), "l"(b), "l"(accumulator.hi)
    );

    return {lo, hi};
}

__device__ __forceinline__
U128 reduce_gcm_256_shift(U128 hi, U128 lo)
{
    // x^128 = x^7 + x^2 + x + 1  (0x87)
    U128 t = hi;
    t = bxor(t, shl128(hi, 1));
    t = bxor(t, shl128(hi, 2));
    t = bxor(t, shl128(hi, 7));

    unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    unsigned long long fold =
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    U128 r = bxor(lo, t);
    r.lo ^= fold;

    return r;
}

__device__ __forceinline__
U128 reduce_gcm_256_clmad(U128 hi, U128 lo)
{
    /*
     * Reduce hi*x^128 + lo modulo x^128 + x^7 + x^2 + x + 1.
     * Since x^128 == 0x87, first fold hi*0x87 into lo.  That product
     * can extend by at most seven bits; fold those bits by 0x87 once more.
     *
     * CLMAD's accumulator operand absorbs every XOR into the five
     * carry-less multiply instructions below:
     *
     *   r.lo = lo.lo ^ low64(hi.lo * 0x87)
     *   r.hi = lo.hi ^ high64(hi.lo * 0x87)
     *                    ^ low64(hi.hi * 0x87)
     *   r.lo ^= low64(high64(hi.hi * 0x87) * 0x87)
     */
    const unsigned long long polynomial = 0x87ULL;
    const unsigned long long zero = 0ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long overflow;
    unsigned long long folded_lo;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(overflow)
        : "l"(hi.hi), "l"(polynomial), "l"(zero)
    );

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(folded_lo)
        : "l"(overflow), "l"(polynomial), "l"(r_lo)
    );

    return {folded_lo, r_hi};
}

/*
 * Four-CLMAD hybrid A: derive the seven-bit overflow with integer shifts,
 * then retain CLMAD for the final low-limb fold.  This removes the dependent
 * clmad.hi without returning to the expensive full shift reduction.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r4_topshift(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long folded_lo;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );
    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );
    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    const unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(folded_lo)
        : "l"(overflow), "l"(polynomial), "l"(r_lo)
    );

    return {folded_lo, r_hi};
}

/*
 * Four-CLMAD hybrid B: retain CLMAD for the high overflow extraction and
 * replace only the tiny final overflow*0x87 product with shifts/XORs.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r4_foldshift(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    const unsigned long long zero = 0ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;
    unsigned long long overflow;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );
    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );
    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );
    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(overflow)
        : "l"(hi.hi), "l"(polynomial), "l"(zero)
    );

    r_lo ^=
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    return {r_lo, r_hi};
}

/*
 * Three-CLMAD hybrid: CLMAD performs the two full-width folds while shifts
 * handle the at-most-seven-bit overflow and its final multiplication by 0x87.
 */
__device__ __forceinline__
U128 reduce_gcm_256_r3_hybrid(U128 hi, U128 lo)
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo;
    unsigned long long r_hi_mid;
    unsigned long long r_hi;

    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_lo)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.lo)
    );
    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(r_hi_mid)
        : "l"(hi.lo), "l"(polynomial), "l"(lo.hi)
    );
    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(r_hi)
        : "l"(hi.hi), "l"(polynomial), "l"(r_hi_mid)
    );

    const unsigned long long overflow =
        (hi.hi >> 63) ^
        (hi.hi >> 62) ^
        (hi.hi >> 57);

    r_lo ^=
        overflow ^
        (overflow << 1) ^
        (overflow << 2) ^
        (overflow << 7);

    return {r_lo, r_hi};
}

__device__ __forceinline__
U128 reduce_gcm_256(U128 hi, U128 lo)
{
#if !defined(NOID_REDUCE_VARIANT) || NOID_REDUCE_VARIANT == 5
    return reduce_gcm_256_clmad(hi, lo);
#elif NOID_REDUCE_VARIANT == 41
    return reduce_gcm_256_r4_topshift(hi, lo);
#elif NOID_REDUCE_VARIANT == 42
    return reduce_gcm_256_r4_foldshift(hi, lo);
#elif NOID_REDUCE_VARIANT == 3
    return reduce_gcm_256_r3_hybrid(hi, lo);
#else
#error "Unsupported NOID_REDUCE_VARIANT"
#endif
}

__device__ __forceinline__
U128 gf_mul_current(U128 a, U128 b)
{
    // Karatsuba: three 64x64 carry-less multiplies.
    U128 p0 = clmul64_nibble(a.lo, b.lo);
    U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_nibble(a.lo ^ a.hi, b.lo ^ b.hi);

    pm = bxor(pm, p0);
    pm = bxor(pm, p1);

    U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 gf_mul_accum(U128 a, U128 b)
{
    /*
     * Karatsuba with p0 accumulated directly into the middle product.
     *
     * current:
     *   pm = CLMUL(am, bm) ^ p0 ^ p1
     * accumulator variant:
     *   pm = CLMAD(am, bm, p0) ^ p1
     *
     * This removes one 128-bit XOR (two 64-bit XOR instructions) without
     * changing any field arithmetic or reduction.
     */
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_accumulate(
        a.lo ^ a.hi,
        b.lo ^ b.hi,
        p0);

    pm = bxor(pm, p1);

    const U128 lo{
        p0.lo,
        p0.hi ^ pm.lo
    };

    const U128 hi{
        p1.lo ^ pm.hi,
        p1.hi
    };

    return reduce_gcm_256(hi, lo);
}

/*
 * Fused Karatsuba layout.  The middle-product XORs are folded into CLMAD's
 * accumulator operands so the final 256-bit product limbs are produced
 * directly.  The arithmetic is identical to gf_mul_accum; this variant tests
 * whether a shorter dependency graph schedules better on GA100.
 */
__device__ __forceinline__
U128 gf_mul_fused(U128 a, U128 b)
{
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);

    const unsigned long long am = a.lo ^ a.hi;
    const unsigned long long bm = b.lo ^ b.hi;
    const U128 limb_accumulator{
        p0.lo ^ p1.lo ^ p0.hi,
        p0.hi ^ p1.hi ^ p1.lo
    };
    const U128 middle = clmul64_accumulate(am, bm, limb_accumulator);

    const U128 lo{p0.lo, middle.lo};
    const U128 hi{middle.hi, p1.hi};
    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 gf_mul(U128 a, U128 b)
{
#ifdef NOID_GF_FUSED
    return gf_mul_fused(a, b);
#elif defined(NOID_CLMAD_ACCUM)
    return gf_mul_accum(a, b);
#else
    return gf_mul_current(a, b);
#endif
}

/*
 * Stage-major carry-less multiplication helpers for partial-MDS ILP tests.
 * Volatile PTX prevents the compiler from freely moving CLMAD instructions
 * between independent gf_mul() calls, so these templates explicitly issue
 * the same stage for N independent products before advancing the dependency
 * chain.  Arithmetic and instruction counts are unchanged.
 */
__device__ __forceinline__
unsigned long long clmad_lo_acc(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    asm volatile(
        "clmad.lo.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
unsigned long long clmad_hi_acc(
    unsigned long long a,
    unsigned long long b,
    unsigned long long accumulator)
{
    unsigned long long out;
    asm volatile(
        "clmad.hi.u64 %0, %1, %2, %3;"
        : "=l"(out)
        : "l"(a), "l"(b), "l"(accumulator)
    );
    return out;
}

__device__ __forceinline__
void gf_product_scalar(U128 a, U128 b, U128 &lo, U128 &hi)
{
    const U128 p0 = clmul64_nibble(a.lo, b.lo);
    const U128 p1 = clmul64_nibble(a.hi, b.hi);
    U128 pm = clmul64_accumulate(a.lo ^ a.hi, b.lo ^ b.hi, p0);
    pm = bxor(pm, p1);
    lo = {p0.lo, p0.hi ^ pm.lo};
    hi = {p1.lo ^ pm.hi, p1.hi};
}

template <int N>
__device__ __forceinline__
void gf_product_batch(
    const U128 (&a)[N],
    const U128 (&b)[N],
    U128 (&lo)[N],
    U128 (&hi)[N])
{
    unsigned long long p0_lo[N], p0_hi[N];
    unsigned long long p1_lo[N], p1_hi[N];
    unsigned long long pm_lo[N], pm_hi[N];

    #pragma unroll
    for (int i = 0; i < N; ++i)
        p0_lo[i] = clmad_lo_acc(a[i].lo, b[i].lo, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p0_hi[i] = clmad_hi_acc(a[i].lo, b[i].lo, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p1_lo[i] = clmad_lo_acc(a[i].hi, b[i].hi, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        p1_hi[i] = clmad_hi_acc(a[i].hi, b[i].hi, 0ULL);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        pm_lo[i] = clmad_lo_acc(
            a[i].lo ^ a[i].hi,
            b[i].lo ^ b[i].hi,
            p0_lo[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        pm_hi[i] = clmad_hi_acc(
            a[i].lo ^ a[i].hi,
            b[i].lo ^ b[i].hi,
            p0_hi[i]);

    #pragma unroll
    for (int i = 0; i < N; ++i) {
        pm_lo[i] ^= p1_lo[i];
        pm_hi[i] ^= p1_hi[i];
        lo[i] = {p0_lo[i], p0_hi[i] ^ pm_lo[i]};
        hi[i] = {p1_lo[i] ^ pm_hi[i], p1_hi[i]};
    }
}

template <int N>
__device__ __forceinline__
void reduce_r4top_batch(
    const U128 (&hi)[N],
    const U128 (&lo)[N],
    U128 (&out)[N])
{
    const unsigned long long polynomial = 0x87ULL;
    unsigned long long r_lo[N];
    unsigned long long r_hi_mid[N];
    unsigned long long r_hi[N];
    unsigned long long overflow[N];
    unsigned long long folded_lo[N];

    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_lo[i] = clmad_lo_acc(hi[i].lo, polynomial, lo[i].lo);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_hi_mid[i] = clmad_hi_acc(hi[i].lo, polynomial, lo[i].hi);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        r_hi[i] = clmad_lo_acc(hi[i].hi, polynomial, r_hi_mid[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i) {
        overflow[i] =
            (hi[i].hi >> 63) ^
            (hi[i].hi >> 62) ^
            (hi[i].hi >> 57);
    }
    #pragma unroll
    for (int i = 0; i < N; ++i)
        folded_lo[i] = clmad_lo_acc(overflow[i], polynomial, r_lo[i]);
    #pragma unroll
    for (int i = 0; i < N; ++i)
        out[i] = {folded_lo[i], r_hi[i]};
}

template <int N>
__device__ __forceinline__
void gf_mul_batch(
    const U128 (&a)[N],
    const U128 (&b)[N],
    U128 (&out)[N])
{
    U128 lo[N], hi[N];
    gf_product_batch<N>(a, b, lo, hi);
    reduce_r4top_batch<N>(hi, lo, out);
}

/*
 * Fixed-constant flat/GCM-basis multiplication.
 *
 * A generic 128x128 Karatsuba product plus r4top reduction executes ten
 * CLMAD instructions (six product, four reduction).  For a compile-time
 * constant C = c0 + c1*x^64 we can form the four 64x64 products directly
 * and reduce their high pieces with the sparse modulus tail 0x87.  This
 * executes eight CLMAD instructions and keeps all basis conversion out of
 * the mining loop.
 *
 * The formulas below are the exact flat-basis circuit.  qlo/qhi are the two
 * limbs of carry-less x*0x87.  qhi is at most seven bits, so its second fold
 * cannot overflow again.
 */
__device__ __forceinline__
unsigned long long xor3_lop3_u64(
    unsigned long long a,
    unsigned long long b,
    unsigned long long c)
{
    unsigned lo, hi;
    asm volatile(
        "lop3.b32 %0, %1, %2, %3, 0x96;"
        : "=r"(lo)
        : "r"((unsigned)a), "r"((unsigned)b), "r"((unsigned)c)
    );
    asm volatile(
        "lop3.b32 %0, %1, %2, %3, 0x96;"
        : "=r"(hi)
        : "r"((unsigned)(a >> 32)),
          "r"((unsigned)(b >> 32)),
          "r"((unsigned)(c >> 32))
    );
    return (unsigned long long)lo | ((unsigned long long)hi << 32);
}

__device__ __forceinline__
unsigned long long mul87_lo_flat(unsigned long long x)
{
    const unsigned long long x1 = x << 1;
    const unsigned long long x2 = x << 2;
    const unsigned long long x7 = x << 7;
#ifdef NOID_CONST_FOLD_LOP3
    return xor3_lop3_u64(x, x1, x2) ^ x7;
#else
    return x ^ x1 ^ x2 ^ x7;
#endif
}

__device__ __forceinline__
unsigned long long mul87_hi_flat(unsigned long long x)
{
    return (x >> 63) ^ (x >> 62) ^ (x >> 57);
}

__device__ __forceinline__
U128 assemble_const_flat_product(
    unsigned long long a0,
    unsigned long long a1,
    unsigned long long a2,
    unsigned long long a3,
    unsigned long long b0,
    unsigned long long b1,
    unsigned long long b2,
    unsigned long long b3)
{
    const unsigned long long h0 = b1 ^ b2;
    const unsigned long long b3_overflow = mul87_hi_flat(b3);
    const unsigned long long lo =
        a0 ^
        mul87_lo_flat(a3) ^
        mul87_lo_flat(h0) ^
        mul87_lo_flat(b3_overflow);
    const unsigned long long hi =
        a1 ^ a2 ^
        mul87_hi_flat(a3) ^
        b0 ^
        mul87_hi_flat(h0) ^
        mul87_lo_flat(b3);
    return {lo, hi};
}

template <unsigned long long CLO, unsigned long long CHI>
__device__ __forceinline__
U128 gf_mul_const_flat(U128 x)
{
    const unsigned long long a0 = clmad_lo_acc(x.lo, CLO, 0ULL);
    const unsigned long long a1 = clmad_hi_acc(x.lo, CLO, 0ULL);
    const unsigned long long a2 = clmad_lo_acc(x.lo, CHI, 0ULL);
    const unsigned long long a3 = clmad_hi_acc(x.lo, CHI, 0ULL);
    const unsigned long long b0 = clmad_lo_acc(x.hi, CLO, 0ULL);
    const unsigned long long b1 = clmad_hi_acc(x.hi, CLO, 0ULL);
    const unsigned long long b2 = clmad_lo_acc(x.hi, CHI, 0ULL);
    const unsigned long long b3 = clmad_hi_acc(x.hi, CHI, 0ULL);
    return assemble_const_flat_product(a0, a1, a2, a3, b0, b1, b2, b3);
}

template <
    unsigned long long C0LO, unsigned long long C0HI,
    unsigned long long C1LO, unsigned long long C1HI>
__device__ __forceinline__
void gf_mul_const_flat_pair(U128 x0, U128 x1, U128 &y0, U128 &y1)
{
    const U128 x[2] = {x0, x1};
    const unsigned long long clo[2] = {C0LO, C1LO};
    const unsigned long long chi[2] = {C0HI, C1HI};
    unsigned long long a0[2], a1[2], a2[2], a3[2];
    unsigned long long b0[2], b1[2], b2[2], b3[2];

    #pragma unroll
    for (int i = 0; i < 2; ++i)
        a0[i] = clmad_lo_acc(x[i].lo, clo[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        a1[i] = clmad_hi_acc(x[i].lo, clo[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        a2[i] = clmad_lo_acc(x[i].lo, chi[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        a3[i] = clmad_hi_acc(x[i].lo, chi[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        b0[i] = clmad_lo_acc(x[i].hi, clo[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        b1[i] = clmad_hi_acc(x[i].hi, clo[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        b2[i] = clmad_lo_acc(x[i].hi, chi[i], 0ULL);
    #pragma unroll
    for (int i = 0; i < 2; ++i)
        b3[i] = clmad_hi_acc(x[i].hi, chi[i], 0ULL);

    y0 = assemble_const_flat_product(
        a0[0], a1[0], a2[0], a3[0], b0[0], b1[0], b2[0], b3[0]);
    y1 = assemble_const_flat_product(
        a0[1], a1[1], a2[1], a3[1], b0[1], b1[1], b2[1], b3[1]);
}

template <
    unsigned long long C0LO, unsigned long long C0HI,
    unsigned long long C1LO, unsigned long long C1HI>
__device__ __forceinline__
void gf_mul_const_karatsuba_pair(U128 x0, U128 x1, U128 &y0, U128 &y1)
{
    const U128 factors[2] = {{C0LO, C0HI}, {C1LO, C1HI}};
    const U128 states[2] = {x0, x1};
    U128 lo[2], hi[2], out[2];
    gf_product_batch<2>(factors, states, lo, hi);
    reduce_r4top_batch<2>(hi, lo, out);
    y0 = out[0];
    y1 = out[1];
}

__device__ __forceinline__
U128 gf_mul_mds_r3(U128 constant, U128 x)
{
    U128 lo, hi;
    gf_product_scalar(constant, x, lo, hi);
    return reduce_gcm_256_r3_hybrid(hi, lo);
}

__device__ __forceinline__
unsigned long long spread32(unsigned x)
{
    unsigned long long v = x;

    v = (v | (v << 16)) & 0x0000FFFF0000FFFFULL;
    v = (v | (v <<  8)) & 0x00FF00FF00FF00FFULL;
    v = (v | (v <<  4)) & 0x0F0F0F0F0F0F0F0FULL;
    v = (v | (v <<  2)) & 0x3333333333333333ULL;
    v = (v | (v <<  1)) & 0x5555555555555555ULL;

    return v;
}

__device__ __forceinline__
U128 expand64(unsigned long long x)
{
    return {
        spread32((unsigned)x),
        spread32((unsigned)(x >> 32))
    };
}

__device__ __forceinline__
U128 square_flat_spread(U128 a)
{
    // Squaring in characteristic two = inserting zeros between bits,
    // followed by reduction modulo the GCM polynomial.
    U128 lo = expand64(a.lo);
    U128 hi = expand64(a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 square_flat_clmad(U128 a)
{
    /*
     * In characteristic two, cross terms cancel when a polynomial is
     * squared.  The low and high 64-bit limbs can therefore be squared
     * independently with carry-less self-multiplication, then passed to the
     * same exact GCM reduction as the spread-bit implementation.
     */
    const U128 lo = clmul64_nibble(a.lo, a.lo);
    const U128 hi = clmul64_nibble(a.hi, a.hi);

    return reduce_gcm_256(hi, lo);
}

__device__ __forceinline__
U128 square_flat(U128 a)
{
#ifdef NOID_SQUARE_CLMAD
    return square_flat_clmad(a);
#else
    return square_flat_spread(a);
#endif
}

__device__ __forceinline__
U128 sbox_x7_spread(U128 x)
{
    // Production Parano1d schedule:
    // x2 = square(x)
    // x4 = square(x2)
    // x6 = x * x2
    // x7 = x6 * x4
    const U128 x2 = square_flat_spread(x);
    const U128 x4 = square_flat_spread(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
U128 sbox_x7_clmad(U128 x)
{
    const U128 x2 = square_flat_clmad(x);
    const U128 x4 = square_flat_clmad(x2);
    const U128 x6 = gf_mul(x, x2);

    return gf_mul(x6, x4);
}

__device__ __forceinline__
U128 sbox_x7(U128 x)
{
#ifdef NOID_SQUARE_CLMAD
    return sbox_x7_clmad(x);
#else
    return sbox_x7_spread(x);
#endif
}

__device__ __forceinline__
void apply_mds_full_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_FULL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

__device__ __forceinline__
void apply_mds_partial_generic(U128 s[4])
{
    U128 o[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        U128 x{0ULL, 0ULL};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            U128 c = NOID_MDS_PARTIAL[i][j];

            if (c.lo == 1ULL && c.hi == 0ULL)
                x = bxor(x, s[j]);
            else
                x = bxor(x, gf_mul(c, s[j]));
        }

        o[i] = x;
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = o[i];
}

/*
 * Exact Poseidon2 M4 factorization for the external/full linear layer.
 *
 * Tower-basis matrix:
 *   [5 7 1 3]
 *   [4 6 1 1]
 *   [1 3 5 7]
 *   [1 1 4 6]
 *
 * In characteristic two, coefficient addition is XOR.  The circuit below
 * uses only four general GF(2^128) multiplications (two by tower element 2,
 * two by tower element 4), versus ten in the generic matrix multiply.
 * The constants below are the exact flat/GCM-basis images used by v1.0.3.
 */
__device__ __forceinline__
void apply_mds_full_factorized(U128 s[4])
{
    const U128 MUL2{
        0x7573da4a5f7710edULL,
        0x3d5bd35c94646a24ULL
    };

    const U128 MUL4{
        0x5e2f716f4ede412fULL,
        0xa72ec17764d7ced5ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(gf_mul(MUL2, b), t1);
    const U128 t3 = bxor(gf_mul(MUL2, d), t0);
    const U128 t4 = bxor(gf_mul(MUL4, t1), t3);
    const U128 t5 = bxor(gf_mul(MUL4, t0), t2);

    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

__device__ __forceinline__
void apply_mds_full_const_karatsuba(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    U128 m2b, m2d, m4t1, m4t0;
    gf_mul_const_karatsuba_pair<
        0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL,
        0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL>(
            b, d, m2b, m2d);
    gf_mul_const_karatsuba_pair<
        0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL,
        0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL>(
            t1, t0, m4t1, m4t0);
    const U128 t2 = bxor(m2b, t1);
    const U128 t3 = bxor(m2d, t0);
    const U128 t4 = bxor(m4t1, t3);
    const U128 t5 = bxor(m4t0, t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

__device__ __forceinline__
void apply_mds_full_const_flat_pair(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    U128 m2b, m2d, m4t1, m4t0;
    gf_mul_const_flat_pair<
        0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL,
        0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL>(
            b, d, m2b, m2d);
    gf_mul_const_flat_pair<
        0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL,
        0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL>(
            t1, t0, m4t1, m4t0);
    const U128 t2 = bxor(m2b, t1);
    const U128 t3 = bxor(m2d, t0);
    const U128 t4 = bxor(m4t1, t3);
    const U128 t5 = bxor(m4t0, t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

__device__ __forceinline__
void apply_mds_full_const_flat_scalar(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(
        gf_mul_const_flat<0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL>(b), t1);
    const U128 t3 = bxor(
        gf_mul_const_flat<0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL>(d), t0);
    const U128 t4 = bxor(
        gf_mul_const_flat<0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL>(t1), t3);
    const U128 t5 = bxor(
        gf_mul_const_flat<0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL>(t0), t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

__device__ __forceinline__
void apply_mds_full_r3(U128 s[4])
{
    const U128 MUL2{0x7573da4a5f7710edULL, 0x3d5bd35c94646a24ULL};
    const U128 MUL4{0x5e2f716f4ede412fULL, 0xa72ec17764d7ced5ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 t0 = bxor(a, b);
    const U128 t1 = bxor(c, d);
    const U128 t2 = bxor(gf_mul_mds_r3(MUL2, b), t1);
    const U128 t3 = bxor(gf_mul_mds_r3(MUL2, d), t0);
    const U128 t4 = bxor(gf_mul_mds_r3(MUL4, t1), t3);
    const U128 t5 = bxor(gf_mul_mds_r3(MUL4, t0), t2);
    s[0] = bxor(t3, t5);
    s[1] = t5;
    s[2] = bxor(t2, t4);
    s[3] = t4;
}

/*
 * Internal/partial MDS has diag(c_i) with ones everywhere off diagonal.
 * sum + (c_i + 1)*s_i is algebraically identical and keeps the same four
 * GF multiplications while substantially reducing XOR/matrix overhead.
 */
__device__ __forceinline__
void apply_mds_partial_scalar(U128 s[4])
{
    const U128 D0{
        0xfd8ee716e990cf15ULL,
        0x486fb01f93aa169aULL
    };
    const U128 D1{
        0x3e1b361e8a1a5bbeULL,
        0x86b6a57216f08319ULL
    };
    const U128 D2{
        0x2924ed9040490831ULL,
        0xb2ef6c31981e3158ULL
    };
    const U128 D3{
        0x84cb11891ab51a3dULL,
        0xff829109128b0bd8ULL
    };

    const U128 a = s[0];
    const U128 b = s[1];
    const U128 c = s[2];
    const U128 d = s[3];

    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 m0 = gf_mul(D0, a);
    const U128 m1 = gf_mul(D1, b);
    const U128 m2 = gf_mul(D2, c);
    const U128 m3 = gf_mul(D3, d);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_prod2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 factors01[2] = {D0, D1};
    const U128 states01[2] = {a, b};
    U128 lo01[2], hi01[2];
    gf_product_batch<2>(factors01, states01, lo01, hi01);
    const U128 m0 = reduce_gcm_256_r4_topshift(hi01[0], lo01[0]);
    const U128 m1 = reduce_gcm_256_r4_topshift(hi01[1], lo01[1]);

    const U128 factors23[2] = {D2, D3};
    const U128 states23[2] = {c, d};
    U128 lo23[2], hi23[2];
    gf_product_batch<2>(factors23, states23, lo23, hi23);
    const U128 m2 = reduce_gcm_256_r4_topshift(hi23[0], lo23[0]);
    const U128 m3 = reduce_gcm_256_r4_topshift(hi23[1], lo23[1]);

    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_const_karatsuba(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));
    U128 m0, m1, m2, m3;
    gf_mul_const_karatsuba_pair<
        0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL,
        0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL>(
            a, b, m0, m1);
    gf_mul_const_karatsuba_pair<
        0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL,
        0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL>(
            c, d, m2, m3);
    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_const_flat_pair(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));
    U128 m0, m1, m2, m3;
    gf_mul_const_flat_pair<
        0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL,
        0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL>(
            a, b, m0, m1);
    gf_mul_const_flat_pair<
        0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL,
        0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL>(
            c, d, m2, m3);
    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_const_flat_scalar(U128 s[4])
{
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));
    const U128 m0 = gf_mul_const_flat<
        0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL>(a);
    const U128 m1 = gf_mul_const_flat<
        0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL>(b);
    const U128 m2 = gf_mul_const_flat<
        0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL>(c);
    const U128 m3 = gf_mul_const_flat<
        0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL>(d);
    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_r3(U128 s[4])
{
    const U128 factors01[2] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL}
    };
    const U128 factors23[2] = {
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };
    const U128 states01[2] = {s[0], s[1]};
    const U128 states23[2] = {s[2], s[3]};
    const U128 sum = bxor(bxor(s[0], s[1]), bxor(s[2], s[3]));
    U128 lo01[2], hi01[2], lo23[2], hi23[2];
    gf_product_batch<2>(factors01, states01, lo01, hi01);
    gf_product_batch<2>(factors23, states23, lo23, hi23);
    const U128 m0 = reduce_gcm_256_r3_hybrid(hi01[0], lo01[0]);
    const U128 m1 = reduce_gcm_256_r3_hybrid(hi01[1], lo01[1]);
    const U128 m2 = reduce_gcm_256_r3_hybrid(hi23[0], lo23[0]);
    const U128 m3 = reduce_gcm_256_r3_hybrid(hi23[1], lo23[1]);
    s[0] = bxor(sum, m0);
    s[1] = bxor(sum, m1);
    s[2] = bxor(sum, m2);
    s[3] = bxor(sum, m3);
}

__device__ __forceinline__
void apply_mds_partial_red2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    U128 lo01[2], hi01[2], m01[2];
    gf_product_scalar(D0, a, lo01[0], hi01[0]);
    gf_product_scalar(D1, b, lo01[1], hi01[1]);
    reduce_r4top_batch<2>(hi01, lo01, m01);

    U128 lo23[2], hi23[2], m23[2];
    gf_product_scalar(D2, c, lo23[0], hi23[0]);
    gf_product_scalar(D3, d, lo23[1], hi23[1]);
    reduce_r4top_batch<2>(hi23, lo23, m23);

    s[0] = bxor(sum, m01[0]);
    s[1] = bxor(sum, m01[1]);
    s[2] = bxor(sum, m23[0]);
    s[3] = bxor(sum, m23[1]);
}

__device__ __forceinline__
void apply_mds_partial_pair2(U128 s[4])
{
    const U128 D0{0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL};
    const U128 D1{0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL};
    const U128 D2{0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL};
    const U128 D3{0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL};
    const U128 a = s[0], b = s[1], c = s[2], d = s[3];
    const U128 sum = bxor(bxor(a, b), bxor(c, d));

    const U128 factors01[2] = {D0, D1};
    const U128 states01[2] = {a, b};
    U128 m01[2];
    gf_mul_batch<2>(factors01, states01, m01);

    const U128 factors23[2] = {D2, D3};
    const U128 states23[2] = {c, d};
    U128 m23[2];
    gf_mul_batch<2>(factors23, states23, m23);

    s[0] = bxor(sum, m01[0]);
    s[1] = bxor(sum, m01[1]);
    s[2] = bxor(sum, m23[0]);
    s[3] = bxor(sum, m23[1]);
}

__device__ __forceinline__
void apply_mds_partial_quad4(U128 s[4])
{
    const U128 factors[4] = {
        {0xfd8ee716e990cf15ULL, 0x486fb01f93aa169aULL},
        {0x3e1b361e8a1a5bbeULL, 0x86b6a57216f08319ULL},
        {0x2924ed9040490831ULL, 0xb2ef6c31981e3158ULL},
        {0x84cb11891ab51a3dULL, 0xff829109128b0bd8ULL}
    };
    const U128 states[4] = {s[0], s[1], s[2], s[3]};
    const U128 sum = bxor(bxor(states[0], states[1]), bxor(states[2], states[3]));
    U128 products[4];
    gf_mul_batch<4>(factors, states, products);
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = bxor(sum, products[i]);
}

#ifdef NOID_MDS_FACTORIZED
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
#if !defined(NOID_CONST_MDS_VARIANT) || NOID_CONST_MDS_VARIANT == 0
    apply_mds_full_factorized(s);
#elif NOID_CONST_MDS_VARIANT == 1
    apply_mds_full_const_karatsuba(s);
#elif NOID_CONST_MDS_VARIANT == 2 || NOID_CONST_MDS_VARIANT == 7
    apply_mds_full_factorized(s);
#elif NOID_CONST_MDS_VARIANT == 3 || NOID_CONST_MDS_VARIANT == 4
    apply_mds_full_const_flat_pair(s);
#elif NOID_CONST_MDS_VARIANT == 5 || NOID_CONST_MDS_VARIANT == 6
    apply_mds_full_r3(s);
#elif NOID_CONST_MDS_VARIANT == 8
    apply_mds_full_const_flat_scalar(s);
#else
#error "Unsupported NOID_CONST_MDS_VARIANT for full MDS"
#endif
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
#if !defined(NOID_CONST_MDS_VARIANT) || NOID_CONST_MDS_VARIANT == 0 || NOID_CONST_MDS_VARIANT == 3
    apply_mds_partial_prod2(s);
#elif NOID_CONST_MDS_VARIANT == 1
    apply_mds_partial_const_karatsuba(s);
#elif NOID_CONST_MDS_VARIANT == 2 || NOID_CONST_MDS_VARIANT == 4 || NOID_CONST_MDS_VARIANT == 6
    apply_mds_partial_const_flat_pair(s);
#elif NOID_CONST_MDS_VARIANT == 5
    apply_mds_partial_r3(s);
#elif NOID_CONST_MDS_VARIANT == 7 || NOID_CONST_MDS_VARIANT == 8
    apply_mds_partial_const_flat_scalar(s);
#elif !defined(NOID_PARTIAL_ILP) || NOID_PARTIAL_ILP == 0
    apply_mds_partial_scalar(s);
#elif NOID_PARTIAL_ILP == 1
    apply_mds_partial_prod2(s);
#elif NOID_PARTIAL_ILP == 2
    apply_mds_partial_red2(s);
#elif NOID_PARTIAL_ILP == 3
    apply_mds_partial_pair2(s);
#elif NOID_PARTIAL_ILP == 4
    apply_mds_partial_quad4(s);
#else
#error "Unsupported NOID_PARTIAL_ILP"
#endif
}
#else
__device__ __forceinline__
void apply_mds_full(U128 s[4])
{
    apply_mds_full_generic(s);
}

__device__ __forceinline__
void apply_mds_partial(U128 s[4])
{
    apply_mds_partial_generic(s);
}
#endif

__device__ __forceinline__
void poseidon_permute(U128 s[4])
{
    apply_mds_full(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {

        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_x7(s[i]);
            }

            apply_mds_full(s);
        }
        else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_x7(s[0]);

            apply_mds_partial(s);
        }
    }
}
