# noid170 v0.6.1 fixed-constant MDS A/B

This package tests the six fixed Poseidon2 MDS multipliers in the exact
flat/GCM basis used by the production miner. It branches from the v0.5.6 GPU
winner: r4top reduction, r4top GF primitive, `prod2` partial-MDS scheduling,
and the b64/stat8 launch used by v0.6.0 production.

The main candidate replaces each ten-CLMAD generic Karatsuba field multiply
with an eight-CLMAD fixed-constant circuit. Four direct 64x64 products are
reduced by the sparse modulus tail `0x87` with XORs and shifts. There are no
tower conversions and no arithmetic changes outside MDS.

Variants:

- `current`: exact v0.5.6 production MDS baseline
- `ctkar`: constant-templated Karatsuba pairs; instruction-equivalence control
- `pflat2`: direct flat circuits for partial constants D0-D3, paired scheduling
- `fflat2`: direct flat circuits for full constants 2 and 4, paired scheduling
- `allflat2`: direct flat circuits for all six constants, paired scheduling
- `allr3`: current Karatsuba with three-CLMAD reduction only inside MDS
- `hybrid`: direct D0-D3 circuits plus r3 reduction for constants 2 and 4
- `pflat1`: direct D0-D3 circuits with scalar scheduling
- `allflat1`: direct circuits for all constants with scalar scheduling
- `alllop3`: `allflat2` with explicit 32-bit `lop3` XOR folds

Every binary must pass an independent GPU oracle before benchmarking. The
oracle checks the fixed multiplier itself for all six constants, full MDS,
partial MDS, square, S-box, Poseidon, and a chained Poseidon workload. The
winner then has to survive persistent FULL/TAG work switching and submit a
network-accepted share.

Run only while the installed HiveOS miner is stopped:

```bash
cd /home/user/noid170-v0.6.1-const-mds-ab
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_ADDRESS.OctominerTEST'
./test-const-mds.sh
```

The complete build and A/B normally takes about 8-10 minutes on the test rig.
It does not restart HiveOS mining automatically. When finished:

```bash
miner start
```

Paste the complete `FINAL FIXED-CONSTANT MDS RANKING` and persistent-worker
result back into chat.
