#!/usr/bin/env python3

import random

MASK64 = (1 << 64) - 1
MASK128 = (1 << 128) - 1
POLY = 0x87


def clmul64(a, b):
    product = 0
    while a:
        lowest = a & -a
        product ^= b << (lowest.bit_length() - 1)
        a ^= lowest
    return product


def reduce_shift(high, low):
    folded = high
    folded ^= (high << 1) & MASK128
    folded ^= (high << 2) & MASK128
    folded ^= (high << 7) & MASK128
    high_hi = high >> 64
    overflow = (high_hi >> 63) ^ (high_hi >> 62) ^ (high_hi >> 57)
    folded ^= overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    return (low ^ folded) & MASK128


def reduce_r5(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1 = clmul64(h1, POLY)
    r0 = l0 ^ (p0 & MASK64)
    r1 = l1 ^ (p0 >> 64) ^ (p1 & MASK64)
    overflow = p1 >> 64
    r0 ^= clmul64(overflow, POLY) & MASK64
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r4_topshift(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1_low = clmul64(h1, POLY) & MASK64
    overflow = (h1 >> 63) ^ (h1 >> 62) ^ (h1 >> 57)
    r0 = l0 ^ (p0 & MASK64) ^ (clmul64(overflow, POLY) & MASK64)
    r1 = l1 ^ (p0 >> 64) ^ p1_low
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r4_foldshift(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1 = clmul64(h1, POLY)
    overflow = p1 >> 64
    fold = overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    r0 = l0 ^ (p0 & MASK64) ^ fold
    r1 = l1 ^ (p0 >> 64) ^ (p1 & MASK64)
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def reduce_r3(high, low):
    h0 = high & MASK64
    h1 = high >> 64
    l0 = low & MASK64
    l1 = low >> 64
    p0 = clmul64(h0, POLY)
    p1_low = clmul64(h1, POLY) & MASK64
    overflow = (h1 >> 63) ^ (h1 >> 62) ^ (h1 >> 57)
    fold = overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7)
    r0 = l0 ^ (p0 & MASK64) ^ fold
    r1 = l1 ^ (p0 >> 64) ^ p1_low
    return (r0 & MASK64) | ((r1 & MASK64) << 64)


def gf_mul(a, b):
    a0, a1 = a & MASK64, a >> 64
    b0, b1 = b & MASK64, b >> 64
    p0 = clmul64(a0, b0)
    p1 = clmul64(a1, b1)
    pm = clmul64(a0 ^ a1, b0 ^ b1) ^ p0 ^ p1
    low = (p0 & MASK64) | ((((p0 >> 64) ^ (pm & MASK64)) & MASK64) << 64)
    high = (((p1 & MASK64) ^ (pm >> 64)) & MASK64) | ((p1 >> 64) << 64)
    return reduce_shift(high, low)


def mul87_lo(x):
    return (x ^ (x << 1) ^ (x << 2) ^ (x << 7)) & MASK64


def mul87_hi(x):
    return (x >> 63) ^ (x >> 62) ^ (x >> 57)


def gf_mul_const_flat(x, constant):
    x0, x1 = x & MASK64, x >> 64
    c0, c1 = constant & MASK64, constant >> 64
    a = clmul64(x0, c0)
    b = clmul64(x0, c1)
    c = clmul64(x1, c0)
    d = clmul64(x1, c1)
    a0, a1 = a & MASK64, a >> 64
    a2, a3 = b & MASK64, b >> 64
    b0, b1 = c & MASK64, c >> 64
    b2, b3 = d & MASK64, d >> 64
    h0 = b1 ^ b2
    low = a0 ^ mul87_lo(a3) ^ mul87_lo(h0) ^ mul87_lo(mul87_hi(b3))
    high = a1 ^ a2 ^ mul87_hi(a3) ^ b0 ^ mul87_hi(h0) ^ mul87_lo(b3)
    return (low & MASK64) | ((high & MASK64) << 64)


def main():
    rng = random.Random(0x170055)
    edge = [0, 1, MASK128, 1 << 127, 1 << 64, MASK64]
    vectors = [(a, b) for a in edge for b in edge]
    vectors.extend((rng.getrandbits(128), rng.getrandbits(128)) for _ in range(20000))
    methods = {
        "r5": reduce_r5,
        "r4top": reduce_r4_topshift,
        "r4fold": reduce_r4_foldshift,
        "r3": reduce_r3,
    }

    for index, (high, low) in enumerate(vectors):
        expected = reduce_shift(high, low)
        for name, method in methods.items():
            actual = method(high, low)
            if actual != expected:
                raise SystemExit(
                    f"FAIL {name} vector={index} high={high:032x} low={low:032x} "
                    f"expected={expected:032x} actual={actual:032x}"
                )

    print(f"OFFLINE GF REDUCTION MODEL: PASS (variants=4 vectors={len(vectors)})")

    constants = [
        0x3D5BD35C94646A247573DA4A5F7710ED,
        0xA72EC17764D7CED55E2F716F4EDE412F,
        0x486FB01F93AA169AFD8EE716E990CF15,
        0x86B6A57216F083193E1B361E8A1A5BBE,
        0xB2EF6C31981E31582924ED9040490831,
        0xFF829109128B0BD884CB11891AB51A3D,
    ]
    const_vectors = edge + [rng.getrandbits(128) for _ in range(20000)]
    for constant in constants:
        for index, value in enumerate(const_vectors):
            expected = gf_mul(value, constant)
            actual = gf_mul_const_flat(value, constant)
            if actual != expected:
                raise SystemExit(
                    f"FAIL flat-constant vector={index} constant={constant:032x} "
                    f"value={value:032x} expected={expected:032x} actual={actual:032x}"
                )
    print(
        "OFFLINE FIXED-CONSTANT FLAT MODEL: PASS "
        f"(constants={len(constants)} vectors={len(constants) * len(const_vectors)})"
    )


if __name__ == "__main__":
    main()
