#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
PKG="$ROOT/package/noid170"
DIST="$ROOT/dist"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
echo "===== BUILD NOID170 v0.2.4 LARGE-RIG CUDA WORKER ====="
"$NVCC" -O3 -arch=sm_80 -lineinfo -I"$SRC" -Xptxas=-v "$SRC/noid_live_job_daemon.cu" -o "$PKG/noid_live_job_daemon"
chmod +x "$PKG/noid_live_job_daemon"
python3 -m py_compile "$PKG/noid170_aria.py"
bash -n "$PKG/h-config.sh"
bash -n "$PKG/h-run.sh"
bash -n "$PKG/h-stats.sh"
rm -rf "$DIST" "$PKG/__pycache__"
mkdir -p "$DIST"
tar -C "$ROOT/package" -czf "$DIST/noid170-0.2.4.tar.gz" noid170
sha256sum "$DIST/noid170-0.2.4.tar.gz" > "$DIST/noid170-0.2.4.tar.gz.sha256"
echo
echo "===== RELEASE ====="
ls -lh "$DIST"
echo
echo "Daemon markers:"
strings "$PKG/noid_live_job_daemon" | grep -E 'READY sm=|JOBACK|STAT ' | head || true
echo
echo "BUILD COMPLETE: $DIST/noid170-0.2.4.tar.gz"
