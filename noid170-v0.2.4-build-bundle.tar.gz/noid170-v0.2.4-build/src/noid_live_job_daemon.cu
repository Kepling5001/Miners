#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <chrono>
#include <algorithm>
#include <string>
#include <sstream>
#include <vector>
#include <utility>
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_f2t_rows.h"
#include "noid_runtime_params.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

struct PreparedJob {
    U128 prefix[4];
    U128 tail[6];
};

struct Candidate {
    U128 nonce;
};

__device__ __constant__ U128 JOB_PREFIX[4];
__device__ __constant__ U128 JOB_TAIL[6];
__device__ __constant__ U128 JOB_TARGET_LO;
__device__ __constant__ U128 JOB_TARGET_HI;

__device__ __forceinline__
int parity_mask(U128 x, U128 mask)
{
    return ((__popcll(x.lo & mask.lo) ^
             __popcll(x.hi & mask.hi)) & 1);
}

__device__ __forceinline__
U128 tower_to_flat_device(U128 tower)
{
    U128 out{0ULL, 0ULL};

    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask(tower, NOID_T2F_ROWS[bit])) {
            if (bit < 64)
                out.lo |= 1ULL << bit;
            else
                out.hi |= 1ULL << (bit - 64);
        }
    }

    return out;
}

__device__ __forceinline__
U128 flat_to_tower_device(U128 flat)
{
    U128 out{0ULL, 0ULL};

    #pragma unroll 1
    for (int bit = 0; bit < 128; ++bit) {
        if (parity_mask(flat, NOID_F2T_ROWS[bit])) {
            if (bit < 64)
                out.lo |= 1ULL << bit;
            else
                out.hi |= 1ULL << (bit - 64);
        }
    }

    return out;
}

__device__ __forceinline__
int target_bit(int bit)
{
    U128 x;
    int b;

    if (bit >= 128) {
        x = JOB_TARGET_HI;
        b = bit - 128;
    } else {
        x = JOB_TARGET_LO;
        b = bit;
    }

    if (b < 64)
        return (int)((x.lo >> b) & 1ULL);

    return (int)((x.hi >> (b - 64)) & 1ULL);
}

__device__ __forceinline__
bool digest_lt_target(U128 flat_lo, U128 flat_hi)
{
    #pragma unroll 1
    for (int bit = 255; bit >= 0; --bit) {
        const U128 lane =
            (bit >= 128) ? flat_hi : flat_lo;

        const int db =
            parity_mask(lane, NOID_F2T_ROWS[bit & 127]);

        const int tb = target_bit(bit);

        if (db != tb)
            return db < tb;
    }

    return false;
}

__device__ __forceinline__
U128 add_u64(U128 a, unsigned long long x)
{
    const unsigned long long old = a.lo;
    a.lo += x;

    if (a.lo < old)
        ++a.hi;

    return a;
}

__global__
void prepare_job(
    const U128 *tower_fields,
    PreparedJob *out)
{
    if (blockIdx.x || threadIdx.x)
        return;

    U128 flat[16];

    for (int i = 0; i < 16; ++i)
        flat[i] = tower_to_flat_device(tower_fields[i]);

    U128 s[4] = {
        {0ULL, 0ULL},
        {0ULL, 0ULL},
        NOID_POW_IV[0],
        NOID_POW_IV[1]
    };

    for (int block = 0; block < 5; ++block) {
        s[0] = bxor(s[0], flat[2 * block]);
        s[1] = bxor(s[1], flat[2 * block + 1]);
        poseidon_permute(s);
    }

    for (int i = 0; i < 4; ++i)
        out->prefix[i] = s[i];

    for (int i = 0; i < 6; ++i)
        out->tail[i] = flat[10 + i];
}

__global__
void mine_kernel(
    Candidate *candidates,
    unsigned int *count,
    unsigned int capacity,
    U128 base)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x *
        blockDim.x + threadIdx.x;

    const U128 flat_nonce = add_u64(base, tid);

    U128 s[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i)
        s[i] = JOB_PREFIX[i];

    s[0] = bxor(s[0], flat_nonce);
    s[1] = bxor(s[1], JOB_TAIL[1]);
    poseidon_permute(s);

    s[0] = bxor(s[0], JOB_TAIL[2]);
    s[1] = bxor(s[1], JOB_TAIL[3]);
    poseidon_permute(s);

    s[0] = bxor(s[0], JOB_TAIL[4]);
    s[1] = bxor(s[1], JOB_TAIL[5]);
    poseidon_permute(s);

    if (digest_lt_target(s[0], s[1])) {
        const unsigned int slot =
            atomicAdd(count, 1U);

        if (slot < capacity)
            candidates[slot].nonce =
                flat_to_tower_device(flat_nonce);
    }
}

static int hexval(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static U128 parse_le128(const char *s)
{
    unsigned char b[16];

    for (int i = 0; i < 16; ++i) {
        int h = hexval(s[i * 2]);
        int l = hexval(s[i * 2 + 1]);

        if (h < 0 || l < 0) {
            fprintf(stderr, "invalid hex\n");
            exit(2);
        }

        b[i] = (unsigned char)((h << 4) | l);
    }

    U128 x{0ULL, 0ULL};

    for (int i = 0; i < 8; ++i)
        x.lo |= (unsigned long long)b[i] << (8 * i);

    for (int i = 0; i < 8; ++i)
        x.hi |= (unsigned long long)b[8 + i] << (8 * i);

    return x;
}

static void nonce_hex(U128 x, char out[33])
{
    static const char *hex = "0123456789abcdef";

    unsigned char b[16];

    for (int i = 0; i < 8; ++i)
        b[i] = (x.lo >> (8 * i)) & 0xff;

    for (int i = 0; i < 8; ++i)
        b[8 + i] = (x.hi >> (8 * i)) & 0xff;

    for (int i = 0; i < 16; ++i) {
        out[i * 2] = hex[b[i] >> 4];
        out[i * 2 + 1] = hex[b[i] & 15];
    }

    out[32] = 0;
}

static U128 host_add(U128 a, unsigned long long x)
{
    unsigned long long old = a.lo;
    a.lo += x;

    if (a.lo < old)
        ++a.hi;

    return a;
}


struct DaemonContext {
    U128 *d_fields = nullptr;
    PreparedJob *d_prepared = nullptr;
    Candidate *d_candidates = nullptr;
    unsigned int *d_count = nullptr;
    Candidate candidates[256];
    cudaEvent_t ev_start{};
    cudaEvent_t ev_stop{};
    int blocks = 0;
    int threads = 1024;
    unsigned long long hashes_per_batch = 0;
    U128 base{0ULL, 0ULL};
    std::string current_pow;
    std::string current_target;
    unsigned long long current_seq = 0;
};

static bool valid_hex(const std::string &s, size_t n)
{
    if (s.size() != n)
        return false;
    for (char c : s)
        if (hexval(c) < 0)
            return false;
    return true;
}

static bool parse_job_line(
    const std::string &line,
    unsigned long long &seq,
    std::string &powhex,
    std::string &targethex)
{
    std::istringstream iss(line);
    std::string cmd;
    if (!(iss >> cmd) || cmd != "JOB")
        return false;
    if (!(iss >> seq >> powhex >> targethex))
        return false;
    std::string extra;
    if (iss >> extra)
        return false;
    return valid_hex(powhex, 512) && valid_hex(targethex, 64);
}

static bool extract_line(std::string &buffer, std::string &line)
{
    const size_t pos = buffer.find('\n');
    if (pos == std::string::npos)
        return false;
    line = buffer.substr(0, pos);
    buffer.erase(0, pos + 1);
    if (!line.empty() && line.back() == '\r')
        line.pop_back();
    return true;
}

static bool read_until_line(std::string &buffer, std::string &line)
{
    while (!extract_line(buffer, line)) {
        char tmp[4096];
        const ssize_t n = ::read(STDIN_FILENO, tmp, sizeof(tmp));
        if (n > 0) {
            buffer.append(tmp, (size_t)n);
            continue;
        }
        if (n == 0)
            return false;
        if (errno == EINTR)
            continue;
        perror("read stdin");
        return false;
    }
    return true;
}

static void drain_lines_nonblocking(
    std::string &buffer,
    std::vector<std::string> &lines,
    bool &stdin_closed)
{
    char tmp[4096];
    for (;;) {
        const ssize_t n = ::read(STDIN_FILENO, tmp, sizeof(tmp));
        if (n > 0) {
            buffer.append(tmp, (size_t)n);
            continue;
        }
        if (n == 0) {
            stdin_closed = true;
            break;
        }
        if (errno == EINTR)
            continue;
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            break;
        perror("read stdin");
        stdin_closed = true;
        break;
    }

    std::string line;
    while (extract_line(buffer, line))
        lines.push_back(line);
}

static void apply_job(
    DaemonContext &ctx,
    unsigned long long seq,
    const std::string &powhex,
    const std::string &targethex)
{
    const bool pow_changed = (powhex != ctx.current_pow);
    const bool target_changed = (targethex != ctx.current_target);

    if (pow_changed) {
        U128 fields[16];
        for (int i = 0; i < 16; ++i)
            fields[i] = parse_le128(powhex.c_str() + i * 32);

        CUDA_OK(cudaMemcpy(
            ctx.d_fields,
            fields,
            sizeof(fields),
            cudaMemcpyHostToDevice));

        prepare_job<<<1,1>>>(ctx.d_fields, ctx.d_prepared);
        CUDA_OK(cudaGetLastError());
        CUDA_OK(cudaDeviceSynchronize());

        PreparedJob prepared{};
        CUDA_OK(cudaMemcpy(
            &prepared,
            ctx.d_prepared,
            sizeof(prepared),
            cudaMemcpyDeviceToHost));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_PREFIX,
            prepared.prefix,
            sizeof(prepared.prefix)));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TAIL,
            prepared.tail,
            sizeof(prepared.tail)));
    }

    if (target_changed) {
        const U128 target_lo = parse_le128(targethex.c_str());
        const U128 target_hi = parse_le128(targethex.c_str() + 32);

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TARGET_LO,
            &target_lo,
            sizeof(target_lo)));

        CUDA_OK(cudaMemcpyToSymbol(
            JOB_TARGET_HI,
            &target_hi,
            sizeof(target_hi)));
    }

    ctx.current_pow = powhex;
    ctx.current_target = targethex;
    ctx.current_seq = seq;

    const char *mode = pow_changed ? "FULL" : (target_changed ? "TARGET" : "TAG");
    fprintf(stderr, "JOBACK %llu %s\n", seq, mode);
    fflush(stderr);
}

static bool process_command_lines(
    DaemonContext &ctx,
    const std::vector<std::string> &lines,
    bool &stop_requested)
{
    bool have_job = false;
    unsigned long long latest_seq = 0;
    std::string latest_pow;
    std::string latest_target;

    for (const std::string &line : lines) {
        if (line == "STOP") {
            stop_requested = true;
            continue;
        }

        unsigned long long seq = 0;
        std::string powhex, targethex;
        if (!parse_job_line(line, seq, powhex, targethex)) {
            if (!line.empty()) {
                fprintf(stderr, "BADCOMMAND %s\n", line.c_str());
                fflush(stderr);
            }
            continue;
        }

        // Input is ordered by the controller. If multiple JOB records arrived
        // during one GPU batch, apply only the newest one.
        if (!have_job || seq > latest_seq) {
            have_job = true;
            latest_seq = seq;
            latest_pow = std::move(powhex);
            latest_target = std::move(targethex);
        }
    }

    if (have_job && latest_seq > ctx.current_seq) {
        apply_job(ctx, latest_seq, latest_pow, latest_target);
        return true;
    }
    return false;
}

int main(int argc, char **argv)
{
    if (argc < 2 || strcmp(argv[1], "--daemon") != 0) {
        fprintf(stderr, "usage: %s --daemon [GPU_SALT]\n", argv[0]);
        fprintf(stderr, "stdin protocol: JOB <seq> <512-char-powhex> <64-char-targethex>\\n\n");
        return 2;
    }

    const unsigned long long gpu_salt =
        (argc >= 3) ? strtoull(argv[2], nullptr, 0) : 0ULL;

    // On large multi-GPU rigs, do not let every CUDA context busy-spin
    // while waiting on ~60 ms kernels. Blocking synchronization materially
    // reduces host CPU contention without changing GPU math.
    CUDA_OK(cudaSetDeviceFlags(cudaDeviceScheduleBlockingSync));
    CUDA_OK(cudaSetDevice(0));

    DaemonContext ctx;
    CUDA_OK(cudaMalloc(&ctx.d_fields, 16 * sizeof(U128)));
    CUDA_OK(cudaMalloc(&ctx.d_prepared, sizeof(PreparedJob)));
    CUDA_OK(cudaMalloc(&ctx.d_candidates, 256 * sizeof(Candidate)));
    CUDA_OK(cudaMalloc(&ctx.d_count, sizeof(unsigned int)));
    CUDA_OK(cudaEventCreate(&ctx.ev_start));
    CUDA_OK(cudaEventCreate(&ctx.ev_stop));

    cudaDeviceProp prop{};
    CUDA_OK(cudaGetDeviceProperties(&prop, 0));
    ctx.blocks = prop.multiProcessorCount * 32;
    ctx.hashes_per_batch =
        (unsigned long long)ctx.threads * (unsigned long long)ctx.blocks;

    const unsigned long long now =
        (unsigned long long)
        std::chrono::high_resolution_clock::now()
        .time_since_epoch().count();

    ctx.base = U128{
        now ^
        0x9e3779b97f4a7c15ULL ^
        (gpu_salt * 0xd6e8feb86659fd93ULL),

        (now << 17) ^
        0xd1b54a32d192ed03ULL ^
        (gpu_salt * 0x94d049bb133111ebULL)
    };

    fprintf(stderr,
        "READY sm=%d blocks=%d threads=%d hashes_per_batch=%llu\n",
        prop.multiProcessorCount,
        ctx.blocks,
        ctx.threads,
        ctx.hashes_per_batch);
    fflush(stderr);

    // Receive the initial job before mining. Use raw read() from the start so
    // no stdio buffering can hide subsequent controller commands.
    std::string input_buffer;
    bool stop_requested = false;
    for (;;) {
        std::string line;
        if (!read_until_line(input_buffer, line)) {
            stop_requested = true;
            break;
        }
        std::vector<std::string> one{line};
        process_command_lines(ctx, one, stop_requested);
        if (stop_requested || ctx.current_seq != 0)
            break;
    }

    if (stop_requested || ctx.current_seq == 0)
        return 0;

    const int old_flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    if (old_flags >= 0)
        fcntl(STDIN_FILENO, F_SETFL, old_flags | O_NONBLOCK);

    constexpr unsigned int CAP = 256;
    double stat_hashes = 0.0;
    double stat_ms = 0.0;
    auto stat_wall_start = std::chrono::steady_clock::now();
    unsigned long long batch_number = 0;
    bool stdin_closed = false;

    while (!stop_requested && !stdin_closed) {
        const unsigned long long batch_seq = ctx.current_seq;

        CUDA_OK(cudaMemset(ctx.d_count, 0, sizeof(unsigned int)));
        CUDA_OK(cudaEventRecord(ctx.ev_start));

        mine_kernel<<<ctx.blocks, ctx.threads>>>(
            ctx.d_candidates,
            ctx.d_count,
            CAP,
            ctx.base);

        CUDA_OK(cudaGetLastError());
        CUDA_OK(cudaEventRecord(ctx.ev_stop));
        CUDA_OK(cudaEventSynchronize(ctx.ev_stop));

        float ms = 0.0f;
        CUDA_OK(cudaEventElapsedTime(&ms, ctx.ev_start, ctx.ev_stop));

        unsigned int count = 0;
        CUDA_OK(cudaMemcpy(
            &count,
            ctx.d_count,
            sizeof(count),
            cudaMemcpyDeviceToHost));

        stat_hashes += ctx.hashes_per_batch;
        stat_ms += ms;
        ++batch_number;

        if (count != 0) {
            const unsigned int n = std::min(count, CAP);
            CUDA_OK(cudaMemcpy(
                ctx.candidates,
                ctx.d_candidates,
                n * sizeof(Candidate),
                cudaMemcpyDeviceToHost));

            for (unsigned int i = 0; i < n; ++i) {
                char hex[33];
                nonce_hex(ctx.candidates[i].nonce, hex);
                printf("SHARE %llu %s\n", batch_seq, hex);
            }
            fflush(stdout);
        }

        // Faster stats cadence helps HiveOS without recreating events or CUDA
        // contexts. Eight 1024-thread batches is ~18.35M hashes/card.
        if ((batch_number & 7ULL) == 0ULL) {
            const double mh = stat_hashes / (stat_ms * 1000.0);
            const auto wall_now = std::chrono::steady_clock::now();
            const double wall_s =
                std::chrono::duration<double>(wall_now - stat_wall_start).count();
            const double wall_mh =
                (wall_s > 0.0) ? (stat_hashes / wall_s / 1.0e6) : 0.0;
            fprintf(stderr,
                "STAT %.3f %.0f %llu %llu %.3f\n",
                mh,
                stat_hashes,
                batch_number,
                batch_seq,
                wall_mh);
            fflush(stderr);
            stat_hashes = 0.0;
            stat_ms = 0.0;
            stat_wall_start = wall_now;
        }

        ctx.base = host_add(ctx.base, ctx.hashes_per_batch);

        // A new job waits at most one GPU batch (~60-65 ms at the current
        // 170HX kernel rate). Shares from the completed batch are tagged with
        // the exact old sequence and remain correctly attributable.
        std::vector<std::string> lines;
        drain_lines_nonblocking(input_buffer, lines, stdin_closed);
        if (!lines.empty())
            process_command_lines(ctx, lines, stop_requested);
    }

    CUDA_OK(cudaEventDestroy(ctx.ev_start));
    CUDA_OK(cudaEventDestroy(ctx.ev_stop));
    CUDA_OK(cudaFree(ctx.d_candidates));
    CUDA_OK(cudaFree(ctx.d_count));
    CUDA_OK(cudaFree(ctx.d_fields));
    CUDA_OK(cudaFree(ctx.d_prepared));

    return 0;
}
