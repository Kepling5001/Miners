# NOID170 v0.2.4 large-rig build

This build keeps the exact v0.2.x PoW/kernel math and adds two large-rig host-side changes:

1. `cudaDeviceScheduleBlockingSync` in each persistent CUDA daemon to avoid 12 host threads busy-spinning while kernels run.
2. A 5 ms initial phase stagger for rigs with 8+ GPUs so all CUDA daemons do not hit their host-side batch boundary simultaneously.

It also reports wall-clock MH/s from inside the C++ daemon itself, avoiding Python pipe-reader timing distortion.

Build on OctominerTEST with `./build-on-rig.sh`.
