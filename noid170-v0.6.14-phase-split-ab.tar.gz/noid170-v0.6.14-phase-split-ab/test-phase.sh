#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ -n "${NOID_MINING_KEY:-}" ]] || { echo "ERROR: export NOID_MINING_KEY='address.worker' first"; exit 1; }
for v in current512 phase1 phase2 phase4 phase8; do
  [[ -x "$ROOT/bin/noid_daemon_$v" ]] || { echo "ERROR: missing $v; run ./build-on-rig.sh"; exit 1; }
done

echo "===== GPU CORRECTNESS ORACLES ====="
for u in 1 2 4 8; do "$ROOT/bin/test_phase$u"; done

echo
python3 "$ROOT/benchmark_phase.py"
echo
python3 "$ROOT/test-persistent.py"
echo
echo "Paste the complete FINAL POSEIDON PHASE-SPLIT RANKING"
echo "and PHASE-SPLIT WINNER PROTOCOL result back into chat."
echo
echo "This experiment did NOT install or replace the HiveOS miner."
echo "Restart normal mining when finished: miner start"
