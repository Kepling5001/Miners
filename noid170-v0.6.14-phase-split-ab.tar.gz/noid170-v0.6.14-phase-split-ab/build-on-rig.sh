#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"
[[ -x "$NVCC" ]] || { echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"; exit 1; }
mkdir -p "$BIN"
COMMON=(
  -O3 -std=c++17 -arch=sm_80 -lineinfo -I"$SRC"
  -DNOID_MDS_FACTORIZED=1 -DNOID_SQUARE_CLMAD=1 -DNOID_CLMAD_ACCUM=1
  -DNOID_SBOX_FUSE_VARIANT=0
  -DNOID_STAT_BATCHES=8 -DNOID_REDUCE_VARIANT=41
  -DNOID_PARTIAL_ILP=1 -DNOID_SQUARE_REDUCE_VARIANT=3
  -DNOID_SQUARE_FOLD_LOP3=1 -DNOID_CLMAD_PAIR_OUTPUTS=1
  -DNOID_CLMAD_PAIR_REDUCE=1 -DNOID_CLMAD_NONVOLATILE=1
  -DNOID_EVENT_POLL_US=2000 -Xptxas=-v
)
build_daemon(){
  local name="$1" unroll="$2"; local extra=()
  if [[ "$unroll" != "0" ]]; then
    extra+=( -DNOID_POSEIDON_PHASE_SPLIT=1 -DNOID_PARTIAL_ROUND_UNROLL="$unroll" )
  fi
  echo
  echo "===== BUILD $name | T=512 GRID-B/SM=128 PHASE_UNROLL=$unroll ====="
  "$NVCC" "${COMMON[@]}" "${extra[@]}" -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 \
    "$SRC/noid_live_job_daemon.cu" -o "$BIN/noid_daemon_$name" 2>&1 | tee "$BIN/build_$name.log"
  chmod 755 "$BIN/noid_daemon_$name"
}
python3 "$ROOT/offline_verify.py"
build_daemon current512 0
build_daemon phase1 1
build_daemon phase2 2
build_daemon phase4 4
build_daemon phase8 8

echo
echo "===== BUILD PHASE-SPLIT GPU ORACLES ====="
for u in 1 2 4 8; do
  "$NVCC" "${COMMON[@]}" -DNOID_POSEIDON_PHASE_SPLIT=1 -DNOID_PARTIAL_ROUND_UNROLL="$u" \
    -DNOID_THREADS=512 -DNOID_BLOCKS_PER_SM=128 "$ROOT/test_phase.cu" -o "$BIN/test_phase$u" \
    2>&1 | tee "$BIN/build_oracle_phase$u.log"
  chmod 755 "$BIN/test_phase$u"
done
python3 -m py_compile "$ROOT/benchmark_phase.py" "$ROOT/test-persistent.py"
bash -n "$ROOT/test-phase.sh" "$ROOT/test-persistent.sh"
echo
echo "===== BUILD COMPLETE ====="
ls -lh "$BIN"/noid_daemon_* "$BIN"/test_phase*
echo
echo "Next: miner stop && export NOID_MINING_KEY='address.worker' && ./test-phase.sh"
