# noid170 v0.5.1 CLMAD accumulator A/B

Isolated correctness and live-hashrate experiment. This does not replace the
HiveOS production miner.

The current Karatsuba GF(2^128) multiply computes three independent 64x64
carry-less products and then XORs both outer products into the middle product.
PTX `clmad` has a fourth carry-less accumulator operand. The experimental
variant accumulates `p0` directly into the middle CLMAD and removes one U128
XOR (two 64-bit XOR instructions) from every general field multiplication.

The tradeoff is dependency: the middle CLMAD must wait for `p0`. Only the live
A/B can determine whether the instruction saving beats the lost independence.

Before benchmarking, GPU oracles compare current and experimental arithmetic
across:

- general GF(2^128) multiplication
- x^7 S-box
- complete Poseidon permutation
- exact three-permutation mining chain

The persistent test then requires a network-accepted share from the
experimental binary.

## Run on OctominerTEST

```bash
tar -xzf noid170-v0.5.1-clmad-accum-ab.tar.gz
cd noid170-v0.5.1-clmad-accum-ab
chmod +x build-on-rig.sh test-accum.sh test-persistent.sh
./build-on-rig.sh
export NOID_MINING_KEY='YOUR_NOID_ADDRESS.OctominerTEST'
./test-accum.sh
```

Paste the complete build and test output back into the chat. Do not install the
experimental binary into HiveOS until the result is reviewed.
