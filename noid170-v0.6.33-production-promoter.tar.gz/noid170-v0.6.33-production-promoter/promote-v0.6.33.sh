#!/usr/bin/env bash
set -euo pipefail

# Promote the already-live-tested v0.6.33 test3-precompute-r1 package to the
# production HiveOS package without recompiling or changing either CUDA binary.
# Optional arg 1: source test3 package path
# Optional arg 2: output directory

SRC="${1:-/home/user/noid170-v0.6.33-innovlab-test3-precompute-r1-builder/dist/noid170-0.6.33-test3-precompute-r1.tar.gz}"
OUTDIR="${2:-/home/user}"
OUT="$OUTDIR/noid170-0.6.33-production.tar.gz"
SHAOUT="$OUT.sha256"

EXPECTED_SRC_SHA="a91b4000e491c412ef4fadd793e580b74c0c58334d71233506dd270bca6f4a8e"
EXPECTED_ARIA_DAEMON="5e0c6bf353ca09f808193284358ce71a81a254b00a613f5010e528f2a24fd2bc"
EXPECTED_WARMUP="40c70611a2a7a2783044a2fbeeb051214882ef95e2836bba6301e2b8dfeb23a7"
EXPECTED_ARIA_WRAPPER="05a56aab90341ea1ab076e02e54d32a42043b7e2ebae9f75fc787d7f739b06af"
EXPECTED_NS_DAEMON="c54e34b2056a980d5c31a41cb00d7ac3a031a3a7ce94a5ed76e5b0169e316a03"

[[ -f "$SRC" ]] || { echo "ERROR: tested source package not found: $SRC" >&2; exit 1; }
mkdir -p "$OUTDIR"

actual_src_sha=$(sha256sum "$SRC" | awk '{print $1}')
if [[ "$actual_src_sha" != "$EXPECTED_SRC_SHA" ]]; then
  echo "ERROR: source package SHA mismatch" >&2
  echo " expected: $EXPECTED_SRC_SHA" >&2
  echo " actual:   $actual_src_sha" >&2
  exit 1
fi

echo "===== SOURCE CHECKPOINT VERIFIED ====="
echo "$actual_src_sha  $SRC"

TMP=$(mktemp -d /tmp/noid633prod.XXXXXX)
trap 'rm -rf "$TMP"' EXIT

tar -xzf "$SRC" -C "$TMP"
D="$TMP/noid170"
[[ -d "$D" ]] || { echo "ERROR: package does not contain noid170/" >&2; exit 1; }

check_sha() {
  local path="$1" expected="$2" label="$3"
  local actual
  actual=$(sha256sum "$path" | awk '{print $1}')
  if [[ "$actual" != "$expected" ]]; then
    echo "ERROR: $label SHA mismatch" >&2
    echo " expected: $expected" >&2
    echo " actual:   $actual" >&2
    exit 1
  fi
  printf '%-30s %s\n' "$label" "$actual"
}

echo
echo "===== TESTED BINARY / ARIA CHECKS ====="
check_sha "$D/noid_live_job_daemon" "$EXPECTED_ARIA_DAEMON" "Aria daemon"
check_sha "$D/noid_live_job_cont" "$EXPECTED_WARMUP" "Warmup worker"
check_sha "$D/noid170_aria.py" "$EXPECTED_ARIA_WRAPPER" "Aria wrapper"
check_sha "$D/noid_live_job_daemon_ns" "$EXPECTED_NS_DAEMON" "InnovLab daemon (test3)"

# Production naming only. CUDA binaries and Aria wrapper stay byte-identical.
sed -i 's/CUSTOM_VERSION="0\.6\.33-test1"/CUSTOM_VERSION="0.6.33"/' "$D/h-manifest.conf"
sed -i 's/NOID170 v0\.6\.33-test1/NOID170 v0.6.33/g' "$D/h-run.sh"
sed -i 's/InnovLab TLS backend: namespace-aware share4 functional test/InnovLab TLS backend: namespace-aware share4 production/' "$D/h-run.sh"
sed -i 's/VERSION = "0\.6\.33-test1"/VERSION = "0.6.33"/' "$D/noid170_stratum.py"

# Make the config wording explicitly worker-optional. Behavior remains: send
# CUSTOM_TEMPLATE verbatim to mining.authorize; no suffix is auto-appended.
python3 - "$D/h-config.sh" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
s = s.replace('wallet_worker="${CUSTOM_TEMPLATE:-}"', 'mining_key="${CUSTOM_TEMPLATE:-}"')
s = s.replace('if [[ -z "$wallet_worker" ]]; then', 'if [[ -z "$mining_key" ]]; then')
s = s.replace('Wallet and worker template is empty', 'Wallet/mining-key template is empty')
s = s.replace("printf 'NOID_MINING_KEY=%q\\n' \"$wallet_worker\"", "printf 'NOID_MINING_KEY=%q\\n' \"$mining_key\"")
p.write_text(s)
PY

cat > "$D/README-PRODUCTION.txt" <<'EOF'
NOID170 v0.6.33 production — HiveOS custom miner

Backends
--------
https:// / http://
  Aria HTTP backend. The v0.6.32 production Aria wrapper and CUDA daemon are
  preserved byte-for-byte.

stratum+ssl://
  InnovLab parano1d-stratum-v1 over system WebPKI TLS verification.
  The production InnovLab CUDA path is the live-tested test3-precompute-r1
  namespace-aware share4 build.

InnovLab flight-sheet settings
------------------------------
Pool URL:
  stratum+ssl://us.innovlab.cc:19601

Wallet and worker template:
  Your bare NOID wallet address is supported by this miner and is sent exactly
  as entered. The miner does NOT append a worker name. If the pool account
  later requires a worker suffix, use address.worker instead.

Password:
  x is used automatically by the Stratum backend.

Extra config:
  Leave blank for normal operation.

Important
---------
For Aria, continue using a unique .worker suffix per rig because that produced
materially better accepted-share behavior in prior testing.

For InnovLab, worker names are optional from the miner's perspective: the
CUSTOM_TEMPLATE string is authorized verbatim.

Measured live InnovLab behavior before promotion:
  - genuine GPU-found shares accepted
  - 0 protocol rejects in repeated tests
  - 0 local namespace mismatches
  - mining.pause / clean new-job handling verified
  - test3-precompute-r1 was the fastest fully tested namespace build (~157.9 MH/s
    on the one-CMP170HX test card versus ~160.9 MH/s Aria production checkpoint)

No dev fee is implemented by NOID170.
EOF

# Syntax gates on modified shell/Python control files.
bash -n "$D/h-config.sh"
bash -n "$D/h-run.sh"
bash -n "$D/h-stats.sh"
python3 -m py_compile "$D/noid170_stratum.py" "$D/noid170_aria.py" "$D/hive_stats.py"
rm -rf "$D/__pycache__"

# Confirm binary/wrapper checkpoint again after text-only promotion edits.
echo
echo "===== FINAL BINARY CHECKS ====="
check_sha "$D/noid_live_job_daemon" "$EXPECTED_ARIA_DAEMON" "Aria daemon"
check_sha "$D/noid_live_job_cont" "$EXPECTED_WARMUP" "Warmup worker"
check_sha "$D/noid170_aria.py" "$EXPECTED_ARIA_WRAPPER" "Aria wrapper"
check_sha "$D/noid_live_job_daemon_ns" "$EXPECTED_NS_DAEMON" "InnovLab daemon (test3)"

rm -f "$OUT" "$SHAOUT"
tar -C "$TMP" -czf "$OUT" noid170
sha256sum "$OUT" | tee "$SHAOUT"

echo
echo "===== v0.6.33 PRODUCTION PACKAGE READY ====="
echo "Archive: $OUT"
echo "SHA256:  $SHAOUT"
echo "InnovLab: stratum+ssl://us.innovlab.cc:19601"
echo "InnovLab wallet template: bare wallet is allowed by the miner; no worker suffix is appended."
echo "Aria: preserved v0.6.32 production backend; keep unique .worker suffixes there."
