NOID170 v0.6.33 production promoter

This does NOT recompile the miner. It promotes the exact v0.6.33 test3-precompute-r1
archive that was already live-tested on OctominerTEST, verifies all known SHA256
checkpoints, changes only production labels/config wording, and outputs:

  /home/user/noid170-0.6.33-production.tar.gz
  /home/user/noid170-0.6.33-production.tar.gz.sha256

Default source expected on OctominerTEST:
  /home/user/noid170-v0.6.33-innovlab-test3-precompute-r1-builder/dist/noid170-0.6.33-test3-precompute-r1.tar.gz

Run:
  ./promote-v0.6.33.sh

You may pass a different source path as arg 1 if needed.
