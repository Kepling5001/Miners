# noid170 v0.5.0 tower-basis sparse-MDS A/B

This is an isolated correctness and performance experiment. It does not
replace the HiveOS production miner.

## What it tests

The current v0.4.0 miner keeps Poseidon state in flat/GCM basis so NVIDIA
`clmad` can accelerate squaring and multiplication. The MDS constants are
much sparser in the protocol's serialized AES-tower basis:

- full MDS multipliers: `0x02`, `0x04`
- partial diagonal-minus-one: `0x0021`, `0x2001`, `0x0201`, `0x0801`

The A/B reports three MDS schedules, each containing the same nine full and
58 partial layers used by one Poseidon permutation:

1. `flat/current`: current v0.4.0 factorized MDS
2. `tower/roundtrip`: exact flat-to-tower and tower-to-flat conversion around
   every MDS layer; this is the only direct drop-in for the CLMAD miner
3. `tower/resident`: one entry/exit conversion with all MDS layers kept in
   tower basis; this is an optimistic MDS-only ceiling because the CLMAD S-box
   still needs flat/GCM basis between layers

The GPU oracle checks full MDS, partial MDS, a 67-layer chained schedule, and
both basis conversions across 1,024 independent randomized states before any
timing is printed.

## Run on the Octominer test rig

```bash
tar -xzf noid170-v0.5.0-tower-mds-ab.tar.gz
cd noid170-v0.5.0-tower-mds-ab
chmod +x build-on-rig.sh test-tower-mds.sh
./build-on-rig.sh
./test-tower-mds.sh
```

No mining key is needed. Paste the complete build output and A/B result back
into the chat. Do not install the experimental tower-roundtrip binary in
HiveOS unless the full live-miner test is explicitly enabled afterward.
