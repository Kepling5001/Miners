#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

[[ -x "$ROOT/bin/test_tower_mds" ]] || {
  echo "ERROR: run ./build-on-rig.sh first"
  exit 1
}

python3 "$ROOT/offline_verify.py"
"$ROOT/bin/test_square_clmad"
"$ROOT/bin/test_tower_mds"
