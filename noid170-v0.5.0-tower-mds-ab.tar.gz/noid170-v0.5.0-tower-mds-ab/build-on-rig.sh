#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
BIN="$ROOT/bin"
NVCC="${NVCC:-/usr/local/cuda-13.3/bin/nvcc}"

[[ -x "$NVCC" ]] || {
  echo "ERROR: CUDA 13.3 nvcc not found at $NVCC"
  exit 1
}

mkdir -p "$BIN"

COMMON=(
  -O3
  -std=c++17
  -arch=sm_80
  -lineinfo
  -I"$SRC"
  -DNOID_SQUARE_CLMAD=1
  -Xptxas=-v
)

echo "===== BUILD CURRENT FLAT/GCM MDS + CLMAD SQUARING ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_MDS_FACTORIZED=1 \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_flat"

echo
echo "===== BUILD EXPERIMENTAL TOWER-MDS ROUNDTRIP MINER ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_MDS_TOWER_ROUNDTRIP=1 \
  "$SRC/noid_live_job_daemon.cu" \
  -o "$BIN/noid_live_job_daemon_tower_roundtrip"

echo
echo "===== BUILD CLMAD REGRESSION ORACLE ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_MDS_FACTORIZED=1 \
  "$ROOT/test_square_clmad.cu" \
  -o "$BIN/test_square_clmad"

echo
echo "===== BUILD TOWER-MDS ORACLE + A/B ====="
"$NVCC" "${COMMON[@]}" \
  -DNOID_MDS_FACTORIZED=1 \
  "$ROOT/test_tower_mds.cu" \
  -o "$BIN/test_tower_mds"

chmod +x \
  "$BIN/noid_live_job_daemon_flat" \
  "$BIN/noid_live_job_daemon_tower_roundtrip" \
  "$BIN/test_square_clmad" \
  "$BIN/test_tower_mds"

python3 -m py_compile "$ROOT/offline_verify.py"
bash -n "$ROOT/test-tower-mds.sh"

echo
echo "===== BUILD COMPLETE ====="
ls -lh \
  "$BIN/noid_live_job_daemon_flat" \
  "$BIN/noid_live_job_daemon_tower_roundtrip" \
  "$BIN/test_square_clmad" \
  "$BIN/test_tower_mds"
echo
echo "Next: ./test-tower-mds.sh"
