#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_f2t_rows.h"
#include "noid_runtime_params.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

__device__ __forceinline__
unsigned long long mix64(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__device__ __forceinline__
bool different(U128 a, U128 b)
{
    return a.lo != b.lo || a.hi != b.hi;
}

template <bool UseClmad>
__device__ __forceinline__
U128 sbox_test(U128 x)
{
    return UseClmad ? sbox_x7_clmad(x) : sbox_x7_spread(x);
}

template <bool UseClmad>
__device__ __forceinline__
void poseidon_test(U128 s[4])
{
    apply_mds_full_factorized(s);

    #pragma unroll 1
    for (int r = 0; r < NOID_N_ROUNDS; ++r) {
        const bool full =
            !(r >= NOID_F_ROUNDS / 2 &&
              r <  NOID_F_ROUNDS / 2 + NOID_P_ROUNDS);

        if (full) {
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                s[i] = bxor(s[i], NOID_RC[i][r]);
                s[i] = sbox_test<UseClmad>(s[i]);
            }
            apply_mds_full_factorized(s);
        } else {
            s[0] = bxor(s[0], NOID_RC[0][r]);
            s[0] = sbox_test<UseClmad>(s[0]);
            apply_mds_partial_factorized(s);
        }
    }
}

__global__
void oracle_kernel(unsigned int *errors)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;

    U128 seed[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        seed[i] = {
            mix64(tid * 17ULL + i + 1ULL),
            mix64(tid * 29ULL + i + 0x12345678ULL)
        };
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const U128 spread_sq = square_flat_spread(seed[i]);
        const U128 clmad_sq = square_flat_clmad(seed[i]);
        if (different(spread_sq, clmad_sq))
            atomicAdd(&errors[0], 1U);

        const U128 spread_sbox = sbox_x7_spread(seed[i]);
        const U128 clmad_sbox = sbox_x7_clmad(seed[i]);
        if (different(spread_sbox, clmad_sbox))
            atomicAdd(&errors[1], 1U);
    }

    U128 spread_state[4], clmad_state[4];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        spread_state[i] = seed[i];
        clmad_state[i] = seed[i];
    }

    poseidon_test<false>(spread_state);
    poseidon_test<true>(clmad_state);

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        if (different(spread_state[i], clmad_state[i]))
            atomicAdd(&errors[2], 1U);
    }

    // Repeat the permutation with deterministic absorption to exercise the
    // exact three-permutation pattern used by the mining kernel.
    #pragma unroll 1
    for (int pass = 1; pass < 3; ++pass) {
        const U128 absorb0{
            mix64(tid + 0x1000ULL * pass),
            mix64(tid + 0x2000ULL * pass)
        };
        const U128 absorb1{
            mix64(tid + 0x3000ULL * pass),
            mix64(tid + 0x4000ULL * pass)
        };
        spread_state[0] = bxor(spread_state[0], absorb0);
        spread_state[1] = bxor(spread_state[1], absorb1);
        clmad_state[0] = bxor(clmad_state[0], absorb0);
        clmad_state[1] = bxor(clmad_state[1], absorb1);
        poseidon_test<false>(spread_state);
        poseidon_test<true>(clmad_state);

        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            if (different(spread_state[i], clmad_state[i]))
                atomicAdd(&errors[3], 1U);
        }
    }
}

int main()
{
    unsigned int *d_errors = nullptr;
    CUDA_OK(cudaMalloc(&d_errors, 4 * sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors, 0, 4 * sizeof(unsigned int)));

    oracle_kernel<<<16, 64>>>(d_errors); // 1024 independent states
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    unsigned int errors[4] = {};
    CUDA_OK(cudaMemcpy(
        errors,
        d_errors,
        sizeof(errors),
        cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));

    const unsigned int total =
        errors[0] + errors[1] + errors[2] + errors[3];

    printf(
        "CLMAD SQUARING ORACLE: %s "
        "(square=%u sbox=%u poseidon=%u chain=%u total=%u)\n",
        total ? "FAIL" : "PASS",
        errors[0], errors[1], errors[2], errors[3], total);

    return total ? 1 : 0;
}
