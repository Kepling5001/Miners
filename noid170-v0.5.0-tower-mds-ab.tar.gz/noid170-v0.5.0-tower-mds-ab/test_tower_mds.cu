#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cuda_runtime.h>

struct U128 {
    unsigned long long lo;
    unsigned long long hi;
};

#include "noid_cuda_tables.h"
#include "noid_f2t_rows.h"
#include "noid_runtime_params.h"
#include "noid_cuda_math.cuh"

#define CUDA_OK(x) do { \
    cudaError_t e = (x); \
    if (e != cudaSuccess) { \
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(e)); \
        exit(1); \
    } \
} while (0)

__device__ __forceinline__
unsigned long long mix64_mds(unsigned long long x)
{
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__device__ __forceinline__
bool mds_different(U128 a, U128 b)
{
    return a.lo != b.lo || a.hi != b.hi;
}

__device__ __forceinline__
void seed_state(U128 s[4], unsigned long long tid)
{
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        s[i] = {
            mix64_mds(tid * 17ULL + i + 1ULL),
            mix64_mds(tid * 29ULL + i + 0x12345678ULL)
        };
    }
}

__device__ __forceinline__
void flat_schedule(U128 s[4])
{
    #pragma unroll 1
    for (int i = 0; i < 9; ++i)
        apply_mds_full_factorized(s);
    #pragma unroll 1
    for (int i = 0; i < 58; ++i)
        apply_mds_partial_factorized(s);
}

__device__ __forceinline__
void roundtrip_schedule(U128 s[4])
{
    #pragma unroll 1
    for (int i = 0; i < 9; ++i)
        apply_mds_full_tower_roundtrip(s);
    #pragma unroll 1
    for (int i = 0; i < 58; ++i)
        apply_mds_partial_tower_roundtrip(s);
}

__device__ __forceinline__
void tower_schedule(U128 s[4])
{
    #pragma unroll 1
    for (int i = 0; i < 9; ++i)
        apply_mds_full_tower(s);
    #pragma unroll 1
    for (int i = 0; i < 58; ++i)
        apply_mds_partial_tower(s);
}

__global__
void tower_mds_oracle(unsigned int *errors)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;

    U128 seed[4];
    seed_state(seed, tid);

    U128 flat_full[4], tower_full[4];
    U128 flat_partial[4], tower_partial[4];
    U128 flat_chain[4], tower_chain[4];

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        flat_full[i] = tower_full[i] = seed[i];
        flat_partial[i] = tower_partial[i] = seed[i];
        flat_chain[i] = tower_chain[i] = seed[i];
    }

    apply_mds_full_factorized(flat_full);
    apply_mds_full_tower_roundtrip(tower_full);
    apply_mds_partial_factorized(flat_partial);
    apply_mds_partial_tower_roundtrip(tower_partial);
    flat_schedule(flat_chain);
    roundtrip_schedule(tower_chain);

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        if (mds_different(flat_full[i], tower_full[i]))
            atomicAdd(&errors[0], 1U);
        if (mds_different(flat_partial[i], tower_partial[i]))
            atomicAdd(&errors[1], 1U);
        if (mds_different(flat_chain[i], tower_chain[i]))
            atomicAdd(&errors[2], 1U);

        const U128 roundtrip =
            mds_tower_to_flat(mds_flat_to_tower(seed[i]));
        if (mds_different(seed[i], roundtrip))
            atomicAdd(&errors[3], 1U);
    }
}

template <int Mode>
__global__
void bench_kernel(U128 *out, unsigned long long salt)
{
    const unsigned long long tid =
        (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
    U128 s[4];
    seed_state(s, tid ^ salt);

    if (Mode == 0) {
        flat_schedule(s);
    } else if (Mode == 1) {
        roundtrip_schedule(s);
    } else {
        #pragma unroll
        for (int i = 0; i < 4; ++i)
            s[i] = mds_flat_to_tower(s[i]);
        tower_schedule(s);
        // A single exit conversion is included.  This is the optimistic
        // ceiling if the whole permutation could remain in tower basis.
        #pragma unroll
        for (int i = 0; i < 4; ++i)
            s[i] = mds_tower_to_flat(s[i]);
    }

    out[tid] = bxor(bxor(s[0], s[1]), bxor(s[2], s[3]));
}

template <int Mode>
double time_mode(U128 *out, int blocks, int threads, int launches)
{
    cudaEvent_t start, stop;
    CUDA_OK(cudaEventCreate(&start));
    CUDA_OK(cudaEventCreate(&stop));

    bench_kernel<Mode><<<blocks, threads>>>(out, 0x1234ULL);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    CUDA_OK(cudaEventRecord(start));
    for (int i = 0; i < launches; ++i)
        bench_kernel<Mode><<<blocks, threads>>>(out, 0x10000ULL + i);
    CUDA_OK(cudaEventRecord(stop));
    CUDA_OK(cudaEventSynchronize(stop));

    float elapsed_ms = 0.0f;
    CUDA_OK(cudaEventElapsedTime(&elapsed_ms, start, stop));
    CUDA_OK(cudaEventDestroy(start));
    CUDA_OK(cudaEventDestroy(stop));
    return elapsed_ms / launches;
}

int main()
{
    unsigned int *d_errors = nullptr;
    CUDA_OK(cudaMalloc(&d_errors, 4 * sizeof(unsigned int)));
    CUDA_OK(cudaMemset(d_errors, 0, 4 * sizeof(unsigned int)));
    tower_mds_oracle<<<16, 64>>>(d_errors);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaDeviceSynchronize());

    unsigned int errors[4] = {};
    CUDA_OK(cudaMemcpy(errors, d_errors, sizeof(errors),
                       cudaMemcpyDeviceToHost));
    CUDA_OK(cudaFree(d_errors));

    const unsigned int total =
        errors[0] + errors[1] + errors[2] + errors[3];
    printf("TOWER MDS ORACLE: %s "
           "(full=%u partial=%u chain=%u conversion=%u total=%u)\n",
           total ? "FAIL" : "PASS", errors[0], errors[1], errors[2],
           errors[3], total);
    if (total)
        return 1;

    cudaDeviceProp prop{};
    CUDA_OK(cudaGetDeviceProperties(&prop, 0));
    const int threads = 256;
    const int blocks = prop.multiProcessorCount * 4;
    const unsigned long long states =
        (unsigned long long)blocks * threads;

    U128 *out = nullptr;
    CUDA_OK(cudaMalloc(&out, states * sizeof(U128)));

    const double flat_ms = time_mode<0>(out, blocks, threads, 5);
    const double roundtrip_ms = time_mode<1>(out, blocks, threads, 3);
    const double resident_ms = time_mode<2>(out, blocks, threads, 5);
    CUDA_OK(cudaFree(out));

    const double flat_rate = states / (flat_ms * 1000.0);
    const double roundtrip_rate = states / (roundtrip_ms * 1000.0);
    const double resident_rate = states / (resident_ms * 1000.0);

    printf("===== TOWER-BASIS SPARSE MDS A/B | GPU0 =====\n");
    printf("GPU: %s  sm=%d  states=%llu\n",
           prop.name, prop.multiProcessorCount, states);
    printf("schedule: 9 full + 58 partial MDS layers\n");
    printf("flat/current       %10.3f ms  %10.3f Mstate/s  baseline\n",
           flat_ms, flat_rate);
    printf("tower/roundtrip    %10.3f ms  %10.3f Mstate/s  %+8.2f%%\n",
           roundtrip_ms, roundtrip_rate,
           (roundtrip_rate / flat_rate - 1.0) * 100.0);
    printf("tower/resident     %10.3f ms  %10.3f Mstate/s  %+8.2f%%\n",
           resident_ms, resident_rate,
           (resident_rate / flat_rate - 1.0) * 100.0);
    printf("roundtrip conversion penalty: %.2fx current time\n",
           roundtrip_ms / flat_ms);
    printf("NOTE: resident is an optimistic MDS-only ceiling; the CLMAD S-box\n"
           "      still requires flat/GCM basis between these layers.\n");

    return 0;
}
